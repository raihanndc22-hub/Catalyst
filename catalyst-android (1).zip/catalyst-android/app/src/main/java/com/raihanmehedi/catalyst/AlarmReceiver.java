package com.raihanmehedi.catalyst;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        Scheduler.show(c, in.getStringExtra("title"), in.getStringExtra("src"));
    }
}
