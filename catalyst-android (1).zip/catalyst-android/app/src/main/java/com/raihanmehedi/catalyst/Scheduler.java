package com.raihanmehedi.catalyst;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/** Turns the app's list of upcoming reminders into phone alarms and shows the notifications. */
public class Scheduler {
    static final int SLOTS = 150;
    static final String CHANNEL = "reminders";

    static void apply(Context c, String json) {
        c.getSharedPreferences("catalyst", Context.MODE_PRIVATE).edit().putString("agenda", json).apply();
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int i = 0; i < SLOTS; i++) {
            PendingIntent old = PendingIntent.getBroadcast(c, i, new Intent(c, AlarmReceiver.class),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (old != null) { am.cancel(old); old.cancel(); }
        }
        try {
            JSONArray a = new JSONArray(json);
            long now = System.currentTimeMillis();
            int slot = 0;
            for (int i = 0; i < a.length() && slot < SLOTS; i++) {
                JSONObject o = a.getJSONObject(i);
                long at = o.optLong("at");
                if (at <= now) continue;
                set(c, am, slot, at, o.optString("t"), o.optString("s"));
                slot++;
            }
        } catch (Exception e) { /* a bad list simply sets nothing */ }
    }

    static void set(Context c, AlarmManager am, int slot, long at, String title, String src) {
        Intent in = new Intent(c, AlarmReceiver.class);
        in.putExtra("title", title);
        in.putExtra("src", src);
        PendingIntent pi = PendingIntent.getBroadcast(c, slot, in,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    static void show(Context c, String title, String src) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Prayer times, classes, medicines, bills and your own reminders");
        nm.createNotificationChannel(ch);
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 9000, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title == null || title.isEmpty() ? "Catalyst reminder" : title)
                .setContentText(src == null ? "" : src)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        nm.notify((int) (System.currentTimeMillis() % 1000000), n);
    }
}
