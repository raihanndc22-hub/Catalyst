package com.raihanmehedi.catalyst.admin;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/** Every hour or so, checks Firebase for new feedback and new students, and tells the admin. */
public class Watch extends BroadcastReceiver {
    static final String KEY = "AIzaSyCXikzs_2w4SKUH8xUvPEstKzOwG6Ztx8s";
    static final String DOCS = "https://firestore.googleapis.com/v1/projects/catalyst-73816/databases/(default)/documents/";

    static SharedPreferences p(Context c) { return c.getSharedPreferences("watch", Context.MODE_PRIVATE); }

    static void setAccount(Context c, String token) {
        p(c).edit().putString("rt", token == null ? "" : token).apply();
        schedule(c);
    }

    static void setCounts(Context c, int users, int feedback) {
        p(c).edit().putInt("users", users).putInt("fb", feedback).apply();
    }

    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = PendingIntent.getBroadcast(c, 1, new Intent(c, Watch.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
        if (p(c).getString("rt", "").isEmpty()) return;
        am.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, android.os.SystemClock.elapsedRealtime() + AlarmManager.INTERVAL_HALF_HOUR,
                AlarmManager.INTERVAL_HOUR, pi);
    }

    @Override
    public void onReceive(Context c, Intent in) {
        final PendingResult done = goAsync();
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            try { check(app); } catch (Exception ignored) { }
            done.finish();
        }).start();
    }

    static String read(InputStream in) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        in.close();
        return b.toString("UTF-8");
    }

    static String idToken(Context c) throws Exception {
        String rt = p(c).getString("rt", "");
        if (rt.isEmpty()) return null;
        HttpURLConnection h = (HttpURLConnection) new URL("https://securetoken.googleapis.com/v1/token?key=" + KEY).openConnection();
        h.setRequestMethod("POST");
        h.setDoOutput(true);
        h.setConnectTimeout(15000);
        h.setReadTimeout(15000);
        h.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        try (OutputStream o = h.getOutputStream()) { o.write(("grant_type=refresh_token&refresh_token=" + URLEncoder.encode(rt, "UTF-8")).getBytes("UTF-8")); }
        if (h.getResponseCode() != 200) return null;
        JSONObject j = new JSONObject(read(h.getInputStream()));
        String nrt = j.optString("refresh_token", "");
        if (!nrt.isEmpty() && !nrt.equals(rt)) p(c).edit().putString("rt", nrt).apply();
        return j.optString("id_token", null);
    }

    /** Counts documents in a collection, following pages. */
    static int count(String token, String col, String field) throws Exception {
        int total = 0;
        String page = "";
        for (int guard = 0; guard < 20; guard++) {
            String u = DOCS + col + "?pageSize=300&mask.fieldPaths=" + field + (page.isEmpty() ? "" : "&pageToken=" + URLEncoder.encode(page, "UTF-8"));
            HttpURLConnection h = (HttpURLConnection) new URL(u).openConnection();
            h.setConnectTimeout(15000);
            h.setReadTimeout(20000);
            h.setRequestProperty("Authorization", "Bearer " + token);
            if (h.getResponseCode() != 200) throw new Exception("HTTP " + h.getResponseCode());
            JSONObject j = new JSONObject(read(h.getInputStream()));
            JSONArray d = j.optJSONArray("documents");
            if (d != null) total += d.length();
            page = j.optString("nextPageToken", "");
            if (page.isEmpty()) break;
        }
        return total;
    }

    static void check(Context c) throws Exception {
        String t = idToken(c);
        if (t == null) return;
        SharedPreferences sp = p(c);
        int users = count(t, "users", "name"), fb = count(t, "feedback", "created");
        int oldU = sp.getInt("users", -1), oldF = sp.getInt("fb", -1);
        if (oldU >= 0 && users > oldU) show(c, 1, (users - oldU) + " new student" + (users - oldU > 1 ? "s" : "") + " joined Catalyst", "You now have " + users + " students.");
        if (oldF >= 0 && fb > oldF) show(c, 2, (fb - oldF) + " new feedback message" + (fb - oldF > 1 ? "s" : ""), "Open Catalyst Admin to read and reply.");
        sp.edit().putInt("users", users).putInt("fb", fb).apply();
    }

    static void show(Context c, int id, String title, String body) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.createNotificationChannel(new NotificationChannel("admin", "Students and feedback", NotificationManager.IMPORTANCE_DEFAULT));
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, AdminActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, "admin")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build();
        nm.notify(id, n);
    }
}
