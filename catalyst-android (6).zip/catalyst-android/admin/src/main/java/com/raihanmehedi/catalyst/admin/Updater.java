package com.raihanmehedi.catalyst.admin;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Downloads newer admin screens from the Catalyst website, so installed apps update without reinstalling. */
public class Updater {
    static final String BASE = "https://raihanndc22-hub.github.io/Catalyst/";

    static String readAll(InputStream in) throws IOException { return new String(bytes(in), "UTF-8"); }

    static byte[] bytes(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        in.close();
        return b.toByteArray();
    }

    static int version(InputStream in) {
        try { return new JSONObject(readAll(in)).optInt("v", 0); } catch (Exception e) { return 0; }
    }

    static File dir(Context c) { return new File(c.getFilesDir(), "www"); }

    static int assetVersion(Context c) {
        try { return version(c.getAssets().open("www/version.json")); } catch (Exception e) { return 0; }
    }

    static int localVersion(Context c) {
        try {
            File f = new File(dir(c), "version.json");
            return f.exists() ? version(new FileInputStream(f)) : 0;
        } catch (Exception e) { return 0; }
    }

    static int current(Context c) { return Math.max(assetVersion(c), localVersion(c)); }

    static String startUrl(Context c) {
        File idx = new File(dir(c), "admin.html");
        if (idx.exists() && localVersion(c) > assetVersion(c)) return "file://" + idx.getAbsolutePath();
        return "file:///android_asset/www/admin.html";
    }

    static byte[] get(String url) throws IOException {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setConnectTimeout(10000);
        h.setReadTimeout(30000);
        h.setUseCaches(false);
        try {
            if (h.getResponseCode() != 200) throw new IOException("HTTP " + h.getResponseCode());
            return bytes(h.getInputStream());
        } finally { h.disconnect(); }
    }

    /** Returns the new version number if an update was downloaded and installed, or 0. */
    static int check(Context c) {
        try {
            JSONObject v = new JSONObject(new String(get(BASE + "version.json?t=" + System.currentTimeMillis()), "UTF-8"));
            int nv = v.optInt("v", 0);
            if (nv <= current(c)) return 0;
            JSONArray req = v.optJSONArray("files"), opt = v.optJSONArray("opt");
            if (req == null) return 0;
            File tmp = new File(c.getFilesDir(), "www_tmp");
            deleteAll(tmp);
            tmp.mkdirs();
            for (int i = 0; i < req.length(); i++) write(tmp, req.getString(i), get(BASE + req.getString(i) + "?v=" + nv));
            if (opt != null) for (int i = 0; i < opt.length(); i++) {
                String n = opt.getString(i);
                try { write(tmp, n, get(BASE + n + "?v=" + nv)); } catch (Exception e) { copyOld(c, n, tmp); }
            }
            write(tmp, "version.json", v.toString().getBytes("UTF-8"));
            File d = dir(c);
            deleteAll(d);
            return tmp.renameTo(d) ? nv : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    static void write(File root, String name, byte[] data) throws IOException {
        if (name.contains("..")) throw new IOException("bad name");
        File f = new File(root, name);
        File parent = f.getParentFile();
        if (parent != null) parent.mkdirs();
        FileOutputStream o = new FileOutputStream(f);
        o.write(data);
        o.close();
    }

    static void copyOld(Context c, String name, File tmp) {
        try {
            File cur = new File(dir(c), name);
            InputStream in = cur.exists() ? new FileInputStream(cur) : c.getAssets().open("www/" + name);
            write(tmp, name, bytes(in));
        } catch (Exception e) { /* optional file, fine to skip */ }
    }

    static void deleteAll(File f) {
        if (f == null || !f.exists()) return;
        File[] k = f.listFiles();
        if (k != null) for (File x : k) deleteAll(x);
        f.delete();
    }
}
