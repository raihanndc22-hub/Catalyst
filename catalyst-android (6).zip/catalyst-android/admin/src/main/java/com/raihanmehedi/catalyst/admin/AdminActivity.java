package com.raihanmehedi.catalyst.admin;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;

/** Catalyst Admin: shows admin.html and gives it a few phone features. */
public class AdminActivity extends Activity {
    private WebView web;
    private boolean checked = false;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        web.addJavascriptInterface(new Bridge(), "CatalystAdmin");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                if (checked) return;
                checked = true;
                final android.content.Context app = getApplicationContext();
                new Thread(() -> {
                    int nv = Updater.check(app);
                    if (nv > 0) runOnUiThread(() -> Toast.makeText(app, "Catalyst Admin updated. It will use the new version next time.", Toast.LENGTH_LONG).show());
                }).start();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
        });
        if (saved != null) web.restoreState(saved);
        else web.loadUrl(Updater.startUrl(this));
        setContentView(web);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

    @Override
    public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }

    class Bridge {
        /** The page passes the signed-in admin's refresh token, so the phone can check for news in the background. */
        @JavascriptInterface
        public void setAccount(String refreshToken) { Watch.setAccount(getApplicationContext(), refreshToken); }

        /** Current totals, so background checks only report what is new since the app was last open. */
        @JavascriptInterface
        public void counts(int users, int feedback) { Watch.setCounts(getApplicationContext(), users, feedback); }

        @JavascriptInterface
        public String appVersion() { return String.valueOf(Updater.current(getApplicationContext())); }

        /** Saves a CSV export into Downloads. */
        @JavascriptInterface
        public void saveFile(String name, String text) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv");
                Uri uri;
                if (Build.VERSION.SDK_INT >= 29) {
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download");
                    uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                } else uri = null;
                if (uri == null) throw new Exception("no uri");
                try (OutputStream o = getContentResolver().openOutputStream(uri)) { o.write(("﻿" + text).getBytes("UTF-8")); }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(AdminActivity.this, "Could not save the file", Toast.LENGTH_SHORT).show());
            }
        }
    }
}
