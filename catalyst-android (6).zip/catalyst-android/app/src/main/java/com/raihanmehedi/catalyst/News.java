package com.raihanmehedi.catalyst;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Checks for new announcements from the developer every few hours and shows them as notifications. */
public class News {
    static final String ACTION = "com.raihanmehedi.catalyst.NEWS";
    static final String CHANNEL = "news";
    static final String URL_LIST = "https://firestore.googleapis.com/v1/projects/catalyst-73816/databases/(default)/documents/announce?pageSize=30&orderBy=created%20desc";
    private static final int CODE = 9001;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("catalyst_news", Context.MODE_PRIVATE); }

    /** Repeats about every 3 hours; Android may group it with other apps' work to save battery. */
    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = PendingIntent.getBroadcast(c, CODE, new Intent(c, AlarmReceiver.class).setAction(ACTION),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, android.os.SystemClock.elapsedRealtime() + 15 * 60 * 1000L,
                3 * AlarmManager.INTERVAL_HOUR, pi);
    }

    static void setAudience(Context c, String json) {
        SharedPreferences.Editor e = prefs(c).edit().putString("aud", json == null ? "{}" : json);
        try {
            JSONArray seen = new JSONObject(json).optJSONArray("seen");
            if (seen != null) { Set<String> s = new HashSet<>(prefs(c).getStringSet("seen", new HashSet<>())); for (int i = 0; i < seen.length(); i++) s.add(seen.getString(i)); e.putStringSet("seen", s); }
        } catch (Exception ignored) { }
        e.apply();
    }

    static void markSeen(Context c, String id) {
        Set<String> s = new HashSet<>(prefs(c).getStringSet("seen", new HashSet<>()));
        s.add(id);
        prefs(c).edit().putStringSet("seen", s).apply();
    }

    /** Called from the alarm: fetch on a background thread. */
    static void check(Context c, BroadcastReceiver.PendingResult done) {
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            try { run(app); } catch (Exception ignored) { }
            if (done != null) done.finish();
        }).start();
    }

    private static String sv(JSONObject f, String k) {
        JSONObject o = f.optJSONObject(k);
        if (o == null) return "";
        if (o.has("stringValue")) return o.optString("stringValue");
        if (o.has("integerValue")) return o.optString("integerValue");
        if (o.has("doubleValue")) return o.optString("doubleValue");
        if (o.has("booleanValue")) return o.optBoolean("booleanValue") ? "true" : "false";
        return "";
    }

    private static boolean forMe(String aud, JSONObject me) {
        if (aud == null || aud.isEmpty() || aud.equals("all")) return true;
        if (aud.equals("android")) return true;
        if (aud.equals("nosign")) return !me.optBoolean("signed");
        int i = aud.indexOf(':');
        if (i < 0) return false;
        String k = aud.substring(0, i), v = aud.substring(i + 1);
        if (k.equals("sem")) return v.equalsIgnoreCase(me.optString("sem"));
        if (k.equals("uid")) return v.equals(me.optString("uid"));
        if (k.equals("course")) {
            JSONArray cs = me.optJSONArray("courses");
            String want = v.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
            if (cs != null) for (int j = 0; j < cs.length(); j++) if (want.equals(cs.optString(j))) return true;
        }
        return false;
    }

    private static void run(Context c) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(URL_LIST).openConnection();
        h.setConnectTimeout(15000);
        h.setReadTimeout(15000);
        if (h.getResponseCode() != 200) return;
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"))) { String l; while ((l = r.readLine()) != null) sb.append(l); }
        JSONArray docs = new JSONObject(sb.toString()).optJSONArray("documents");
        if (docs == null) return;
        SharedPreferences p = prefs(c);
        JSONObject me;
        try { me = new JSONObject(p.getString("aud", "{}")); } catch (Exception e) { me = new JSONObject(); }
        Set<String> seen = new HashSet<>(p.getStringSet("seen", new HashSet<>()));
        long firstRun = p.getLong("since", 0);
        if (firstRun == 0) { firstRun = System.currentTimeMillis() - 2 * 86400000L; p.edit().putLong("since", firstRun).apply(); }
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(new Date());
        int shown = 0;
        for (int i = 0; i < docs.length() && shown < 3; i++) {
            JSONObject d = docs.getJSONObject(i), f = d.optJSONObject("fields");
            if (f == null) continue;
            String name = d.optString("name"), id = name.substring(name.lastIndexOf('/') + 1);
            if (seen.contains(id)) continue;
            if ("true".equals(sv(f, "off")) || "false".equals(sv(f, "notify"))) continue;
            String until = sv(f, "until");
            if (!until.isEmpty() && until.compareTo(today) < 0) continue;
            long created = 0;
            try { created = (long) Double.parseDouble(sv(f, "created")); } catch (Exception ignored) { }
            if (created < firstRun) continue;
            if (!forMe(sv(f, "aud"), me)) continue;
            boolean gift = !sv(f, "badge").isEmpty() || (!sv(f, "atp").isEmpty() && !sv(f, "atp").equals("0"));
            show(c, id, (gift ? "🎁 " : "📣 ") + sv(f, "title"), gift ? "A gift is waiting for you in Catalyst. Open the app to claim it." : sv(f, "body"));
            seen.add(id);
            shown++;
        }
        p.edit().putStringSet("seen", seen).apply();
    }

    private static void show(Context c, String id, String title, String body) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "News from Catalyst", NotificationManager.IMPORTANCE_DEFAULT);
        ch.setDescription("Announcements and gifts from the Catalyst developer");
        nm.createNotificationChannel(ch);
        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(Scheduler.openApp(c))
                .build();
        nm.notify(700000 + Math.abs(id.hashCode() % 100000), n);
    }
}
