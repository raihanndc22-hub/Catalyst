package com.raihanmehedi.catalyst;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        String act = in.getAction();
        int id = in.getIntExtra("nid", 0);
        if (Scheduler.ACTION_STOP.equals(act)) { Scheduler.stop(c, id); return; }
        if (Scheduler.ACTION_SNOOZE.equals(act)) { Scheduler.snooze(c, id, in.getStringExtra("title"), in.getStringExtra("src")); return; }
        if (Scheduler.ACTION_SNZ.equals(act)) { Scheduler.stop(c, id); Scheduler.snooze10(c, in.getStringExtra("title"), in.getStringExtra("src"), in.getStringExtra("k"), in.getStringExtra("d")); return; }
        if (Scheduler.ACTION_QUICK.equals(act)) {
            Scheduler.stop(c, id);
            Scheduler.queue(c, in.getStringExtra("act"), in.getStringExtra("d"));
            if ("water".equals(in.getStringExtra("act"))) CatalystWidget.addWater(c);
            android.widget.Toast.makeText(c, "Saved in Catalyst", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        if (in.getBooleanExtra("alarm", false)) Scheduler.ring(c, in.getStringExtra("title"), in.getStringExtra("src"));
        else Scheduler.show(c, in.getStringExtra("title"), in.getStringExtra("src"), in.getStringExtra("k"), in.getStringExtra("d"));
    }
}
