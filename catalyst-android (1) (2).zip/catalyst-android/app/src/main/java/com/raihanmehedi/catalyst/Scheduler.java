package com.raihanmehedi.catalyst;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/** Turns the app's list of upcoming reminders into phone alarms, and shows notifications and alarms. */
public class Scheduler {
    static final int SLOTS = 150;
    static final String CHANNEL = "reminders";
    static final String ALARM_CHANNEL = "alarms_v1";
    static final String ACTION_STOP = "com.raihanmehedi.catalyst.STOP";
    static final String ACTION_SNOOZE = "com.raihanmehedi.catalyst.SNOOZE";
    static final String ACTION_QUICK = "com.raihanmehedi.catalyst.QUICK";
    static final String ACTION_SNZ = "com.raihanmehedi.catalyst.SNZ";

    static void apply(Context c, String json) {
        c.getSharedPreferences("catalyst", Context.MODE_PRIVATE).edit().putString("agenda", json).apply();
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int i = 0; i < SLOTS; i++) {
            PendingIntent old = PendingIntent.getBroadcast(c, i, new Intent(c, AlarmReceiver.class),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (old != null) { am.cancel(old); old.cancel(); }
        }
        try {
            JSONArray a = new JSONArray(json);
            long now = System.currentTimeMillis();
            int slot = 0;
            for (int i = 0; i < a.length() && slot < SLOTS; i++) {
                JSONObject o = a.getJSONObject(i);
                long at = o.optLong("at");
                if (at <= now) continue;
                set(c, am, slot, at, o.optString("t"), o.optString("s"), o.optInt("a") == 1, o.optString("k"), o.optString("d"));
                slot++;
            }
        } catch (Exception e) { /* a bad list simply sets nothing */ }
    }

    static void set(Context c, AlarmManager am, int slot, long at, String title, String src, boolean alarm) { set(c, am, slot, at, title, src, alarm, "", ""); }

    static void set(Context c, AlarmManager am, int slot, long at, String title, String src, boolean alarm, String kind, String data) {
        Intent in = new Intent(c, AlarmReceiver.class);
        in.putExtra("k", kind);
        in.putExtra("d", data);
        in.putExtra("title", title);
        in.putExtra("src", src);
        in.putExtra("alarm", alarm);
        PendingIntent pi = PendingIntent.getBroadcast(c, slot, in,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (alarm) {
                Intent open = new Intent(c, MainActivity.class);
                PendingIntent show = PendingIntent.getActivity(c, 8000 + slot, open,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pi);
                return;
            }
            boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    static PendingIntent openApp(Context c) {
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, 9000, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void show(Context c, String title, String src) { show(c, title, src, "", ""); }

    static PendingIntent quick(Context c, int nid, int n, String act, String data, String title, String src, String kind) {
        Intent q = new Intent(c, AlarmReceiver.class).setAction(n == 9 ? ACTION_SNZ : ACTION_QUICK)
                .putExtra("nid", nid).putExtra("act", act).putExtra("d", data).putExtra("title", title).putExtra("src", src).putExtra("k", kind);
        return PendingIntent.getBroadcast(c, nid * 10 + n, q, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void show(Context c, String title, String src, String kind, String data) {
        if (kind == null) kind = "";
        if (data == null) data = "";
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Prayer times, classes, medicines, bills and your own reminders");
        nm.createNotificationChannel(ch);
        int nid = (int) (System.currentTimeMillis() % 1000000);
        Notification.Builder nb = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title == null || title.isEmpty() ? "Catalyst reminder" : title)
                .setContentText(src == null ? "" : src)
                .setStyle(new Notification.BigTextStyle().bigText(title == null ? "" : title))
                .setCategory(Notification.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setContentIntent(openApp(c));
        if (kind.equals("water")) nb.addAction(new Notification.Action.Builder(null, "Drank a glass", quick(c, nid, 1, "water", data, title, src, kind)).build());
        else if (kind.equals("task")) nb.addAction(new Notification.Action.Builder(null, "Done", quick(c, nid, 1, "task", data, title, src, kind)).build());
        else if (kind.equals("prayer")) nb.addAction(new Notification.Action.Builder(null, "Prayed", quick(c, nid, 1, "prayer", data, title, src, kind)).build());
        else if (kind.equals("attend")) {
            nb.addAction(new Notification.Action.Builder(null, "Attended", quick(c, nid, 1, "attend:p", data, title, src, kind)).build());
            nb.addAction(new Notification.Action.Builder(null, "Missed", quick(c, nid, 2, "attend:a", data, title, src, kind)).build());
        }
        nb.addAction(new Notification.Action.Builder(null, "Snooze 10 min", quick(c, nid, 9, "", data, title, src, kind)).build());
        nm.notify(nid, nb.build());
    }

    /** A ringing alarm: loud, repeats until stopped, and opens a full-screen alarm page. */
    static void ring(Context c, String title, String src) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (sound == null) sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationChannel ch = new NotificationChannel(ALARM_CHANNEL, "Alarms", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Alarms you set in Catalyst");
        ch.setSound(sound, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 600, 400, 600, 400, 600});
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
        int id = 500000 + (int) (System.currentTimeMillis() % 400000);
        String t = title == null || title.isEmpty() ? "Catalyst alarm" : title;

        Intent full = new Intent(c, AlarmActivity.class);
        full.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        full.putExtra("title", t);
        full.putExtra("src", src);
        full.putExtra("nid", id);
        PendingIntent fullPi = PendingIntent.getActivity(c, id, full, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(c, AlarmReceiver.class).setAction(ACTION_STOP).putExtra("nid", id);
        Intent snooze = new Intent(c, AlarmReceiver.class).setAction(ACTION_SNOOZE).putExtra("nid", id).putExtra("title", t).putExtra("src", src);
        PendingIntent stopPi = PendingIntent.getBroadcast(c, id + 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent snoozePi = PendingIntent.getBroadcast(c, id + 2, snooze, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(c, ALARM_CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(t)
                .setContentText(src == null ? "Alarm" : src)
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setFullScreenIntent(fullPi, true)
                .setContentIntent(fullPi)
                .addAction(new Notification.Action.Builder(null, "Stop", stopPi).build())
                .addAction(new Notification.Action.Builder(null, "Snooze 5 min", snoozePi).build())
                .build();
        n.flags |= Notification.FLAG_INSISTENT;
        nm.notify(id, n);
    }

    /** Saves a tap on a notification button so the app applies it the next time it is open. */
    static void queue(Context c, String act, String data) {
        android.content.SharedPreferences p = c.getSharedPreferences("catalyst", Context.MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(p.getString("pending", "[]"));
            JSONObject o = new JSONObject();
            o.put("a", act); o.put("d", data); o.put("at", System.currentTimeMillis());
            a.put(o);
            p.edit().putString("pending", a.toString()).apply();
        } catch (Exception e) { /* ignore */ }
    }

    static void snooze10(Context c, String title, String src, String kind, String data) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) set(c, am, SLOTS + 60 + (int) (System.currentTimeMillis() / 1000 % 40), System.currentTimeMillis() + 10 * 60000L, title, src, false, kind, data);
    }

    static void stop(Context c, int id) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(id);
    }

    static void snooze(Context c, int id, String title, String src) {
        stop(c, id);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) set(c, am, SLOTS + 10 + (id % 50), System.currentTimeMillis() + 5 * 60000L, title, "Snoozed", true);
    }
}
