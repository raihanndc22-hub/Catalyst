package com.raihanmehedi.catalyst;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> pending;
    private static final int PICK = 7;
    private volatile boolean ready = false;
    private boolean checked = false;

    private void checkUpdate() {
        final android.content.Context app = getApplicationContext();
        new Thread(() -> {
            int nv = Updater.check(app);
            if (nv > 0) runOnUiThread(() -> web.evaluateJavascript("window.onAppUpdate&&window.onAppUpdate(" + nv + ")", null));
        }).start();
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "CatalystNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                v.postDelayed(() -> ready = true, 80);
                if (!checked) { checked = true; checkUpdate(); }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (pending != null) pending.onReceiveValue(null);
                pending = cb;
                try {
                    Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("*/*");
                    if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(Intent.createChooser(pick, "Choose a file"), PICK);
                } catch (Exception e) { pending = null; return false; }
                return true;
            }
        });
        if (saved != null) web.restoreState(saved);
        else web.loadUrl(Updater.startUrl(this));
        setContentView(web);
        // Keep the launch screen up until the page has drawn, so the logo hands over without a blank flash.
        final android.view.View content = findViewById(android.R.id.content);
        content.getViewTreeObserver().addOnPreDrawListener(new android.view.ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                if (ready) { content.getViewTreeObserver().removeOnPreDrawListener(this); return true; }
                return false;
            }
        });
        content.postDelayed(() -> ready = true, 2500);
        askNotifications();
    }

    private void askNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
    }

    /** Functions the app's own page can call. */
    class Bridge {
        private File current;
        private FileOutputStream out;
        private String mime = "application/octet-stream";

        @JavascriptInterface
        public void sync(String json) { Scheduler.apply(getApplicationContext(), json); }

        @JavascriptInterface
        public void askPermission() { runOnUiThread(() -> askNotifications()); }

        @JavascriptInterface
        public void test() {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null) Scheduler.set(getApplicationContext(), am, Scheduler.SLOTS + 1,
                    System.currentTimeMillis() + 10000, "Catalyst notifications work", "Test", false);
        }

        @JavascriptInterface
        public String pending() {
            android.content.SharedPreferences p = getSharedPreferences("catalyst", MODE_PRIVATE);
            String s = p.getString("pending", "[]");
            p.edit().putString("pending", "[]").apply();
            return s;
        }

        @JavascriptInterface
        public void widget(String json) { CatalystWidget.save(getApplicationContext(), json); }

        @JavascriptInterface
        public void keepOn(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void reloadApp() { runOnUiThread(() -> web.loadUrl(Updater.startUrl(MainActivity.this))); }

        @JavascriptInterface
        public String appVersion() { return String.valueOf(Updater.current(getApplicationContext())); }

        @JavascriptInterface
        public void shareText(String text) {
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(send, "Send to"));
                } catch (Exception e) { }
            });
        }

        @JavascriptInterface
        public void testAlarm() {
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null) Scheduler.set(getApplicationContext(), am, Scheduler.SLOTS + 2,
                    System.currentTimeMillis() + 10000, "Test alarm", "Alarm", true);
        }

        @JavascriptInterface
        public void fileBegin(String name, String type) {
            try {
                if (out != null) out.close();
                File dir = new File(getCacheDir(), "open");
                dir.mkdirs();
                File[] old = dir.listFiles();
                if (old != null) for (File f : old) f.delete();
                String safe = name == null ? "file" : name.replaceAll("[\\\\/:*?\"<>|]", "_");
                current = new File(dir, safe.isEmpty() ? "file" : safe);
                out = new FileOutputStream(current);
                mime = type == null || type.isEmpty() ? "application/octet-stream" : type;
            } catch (Exception e) { out = null; current = null; }
        }

        @JavascriptInterface
        public void fileChunk(String b64) {
            try { if (out != null) out.write(Base64.decode(b64, Base64.DEFAULT)); } catch (Exception e) { }
        }

        @JavascriptInterface
        public String fileShareEnd() {
            try {
                if (out == null || current == null) return "error: could not write the file";
                out.close();
                out = null;
                final Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", current);
                final String type = mime;
                runOnUiThread(() -> {
                    try {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType(type);
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "Save backup to"));
                    } catch (Exception e) { }
                });
                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public String fileEnd() {
            try {
                if (out == null || current == null) return "error: could not write the file";
                out.close();
                out = null;
                final File f = current;
                final String type = mime;
                Uri shown = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", f);
                if (Build.VERSION.SDK_INT >= 29) {
                    try {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.Downloads.DISPLAY_NAME, f.getName());
                        v.put(MediaStore.Downloads.MIME_TYPE, type);
                        v.put(MediaStore.Downloads.RELATIVE_PATH, "Download/Catalyst");
                        Uri dl = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                        if (dl != null) {
                            try (InputStream in = new FileInputStream(f); OutputStream o = getContentResolver().openOutputStream(dl)) {
                                byte[] buf = new byte[65536];
                                int n;
                                while (o != null && (n = in.read(buf)) > 0) o.write(buf, 0, n);
                            }
                        }
                    } catch (Exception e) { /* opening still works without the Downloads copy */ }
                }
                final Uri uri = shown;
                runOnUiThread(() -> {
                    try {
                        Intent view = new Intent(Intent.ACTION_VIEW);
                        view.setDataAndType(uri, type);
                        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(view, "Open with"));
                    } catch (Exception e) { }
                });
                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == PICK && pending != null) {
            Uri[] out = null;
            if (res == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    out = new Uri[n];
                    for (int i = 0; i < n; i++) out[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) out = new Uri[]{data.getData()};
            }
            pending.onReceiveValue(out);
            pending = null;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){var s=document.getElementById('shade'),b=document.body;if(document.getElementById('onb'))return 1;if(s&&s.classList.contains('open')){closeSheet();return 1}if(b.classList.contains('dopen')){b.classList.remove('dopen');return 1}if(ui.tab!=='today'){A.tab({tab:'today'});return 1}return 0})()",
            r -> { if (!"1".equals(r)) finish(); });
    }
}
