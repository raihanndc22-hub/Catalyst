package com.raihanmehedi.catalyst;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

/** Home-screen widget: next prayer, next class, water with a + button, and today's tasks. */
public class CatalystWidget extends AppWidgetProvider {
    static final String ACTION_WATER = "com.raihanmehedi.catalyst.WIDGET_WATER";

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("catalyst", Context.MODE_PRIVATE); }

    static void save(Context c, String json) {
        prefs(c).edit().putString("widget", json).apply();
        refresh(c);
    }

    static void addWater(Context c) {
        try {
            JSONObject o = new JSONObject(prefs(c).getString("widget", "{}"));
            o.put("w", o.optInt("w", 0) + 1);
            prefs(c).edit().putString("widget", o.toString()).apply();
        } catch (Exception e) { /* ignore */ }
        refresh(c);
    }

    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, CatalystWidget.class));
        if (ids != null && ids.length > 0) for (int id : ids) draw(c, m, id);
    }

    static void draw(Context c, AppWidgetManager m, int id) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        try {
            JSONObject o = new JSONObject(prefs(c).getString("widget", "{}"));
            v.setTextViewText(R.id.w_prayer, o.optString("pr", "Open Catalyst once to set up"));
            v.setTextViewText(R.id.w_class, o.optString("cls", "No more classes today"));
            v.setTextViewText(R.id.w_water, o.optInt("w", 0) + " / " + o.optInt("wg", 8) + " glasses");
            JSONArray t = o.optJSONArray("tasks");
            StringBuilder sb = new StringBuilder();
            if (t != null) for (int i = 0; i < t.length() && i < 3; i++) sb.append(i > 0 ? "\n" : "").append("• ").append(t.optString(i));
            v.setTextViewText(R.id.w_tasks, sb.length() > 0 ? sb.toString() : "No tasks due today");
        } catch (Exception e) { /* show defaults */ }
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        v.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 7100, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        Intent w = new Intent(c, CatalystWidget.class).setAction(ACTION_WATER);
        v.setOnClickPendingIntent(R.id.w_plus, PendingIntent.getBroadcast(c, 7101, w, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        m.updateAppWidget(id, v);
    }

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id : ids) draw(c, m, id); }

    @Override
    public void onReceive(Context c, Intent in) {
        if (ACTION_WATER.equals(in.getAction())) {
            Scheduler.queue(c, "water", "");
            addWater(c);
            return;
        }
        super.onReceive(c, in);
    }
}
