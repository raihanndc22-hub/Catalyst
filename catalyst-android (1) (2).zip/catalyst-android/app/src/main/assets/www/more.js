/* Daybook add-ons: deen, health, sleep, food, reminders, files, PDF tools, mail, history, menu */
(function(){
"use strict";
KEYS.push('prayers','quran','dhikr','duas','fasts','sleep','sick','reminders','meals','goals','debts','files','contacts');
OBJ.push('prayers','quran','dhikr','fasts');
Object.assign(DEF_SET,{city:'Dhaka',lat:23.8103,lng:90.4125,asr:'Hanafi',qaza:0,qgoal:20,sleepBed:'23:30',sleepWake:'06:30',sleepStart:0,nPrayer:1,nMeds:1,nClass:1,nSleep:1,nWater:0,email:''});
normalize();
Object.assign(ui,{deen:'prayer',foodDay:today(),histDay:today(),ep:null,tz:{n:0,target:33,ph:0}});
TABS.push('deen');
NAV.splice(3,2,['deen','Deen'],['life','Life']);
IC.deen='<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>';
SUB.deen=[['prayer','Prayer'],['quran','Quran'],['duas','Duas'],['tasbih','Tasbih']];
SUB.plan=[['tasks','Tasks'],['cal','Calendar'],['routine','Class routine']];
SUB.study.push(['files','Files'],['tools','PDF tools']);
SUB.life.splice(0,SUB.life.length,['water','Water'],['food','Food'],['habits','Habits'],['sleep','Sleep'],['health','Health'],['acts','Activities'],['money','Money']);
SUB.more.splice(0,SUB.more.length,['reminders','Reminders'],['links','Links'],['notes','Notes'],['mail','Mail'],['history','History'],['settings','Settings']);

let AS=null,DL=null,SM=null;
(async()=>{try{if(window.claude&&window.claude.use){AS=await window.claude.use('assets');DL=await window.claude.use('downloads')}}catch(e){}})();

/* ---------- small helpers ---------- */
const toMin=t=>{const a=String(t||'0:0').split(':');return(+a[0]||0)*60+(+a[1]||0)};
const hm=m=>{m=((Math.round(m)%1440)+1440)%1440;return pad(Math.floor(m/60))+':'+pad(m%60)};
const nowMin=()=>{const d=new Date();return d.getHours()*60+d.getMinutes()};
const dur=m=>m<60?m+' min':Math.floor(m/60)+'h'+(m%60?' '+m%60+'m':'');
const chk=(on,a,attrs,label)=>`<button class="check${on?' on':''}" data-a="${a}" ${attrs} aria-pressed="${on?'true':'false'}" aria-label="${esc(label)}">${ic('check')}</button>`;
const stat=(v,l)=>`<div class="stat"><b>${v}</b><span>${l}</span></div>`;
const dayNav=(a,ds)=>`<div class="row between"><button class="btn sm" data-a="${a}" data-n="-1" aria-label="Previous day">${ic('back')}</button><h3>${ds===today()?'Today':fmt(ds)}</h3><button class="btn sm" data-a="${a}" data-n="1" aria-label="Next day">${ic('next')}</button></div>`;
const fsz=b=>b>1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB';
let note={};const say=(k,t)=>{note[k]=t;render()};const said=k=>note[k]?`<p class="muted" role="status">${esc(note[k])}</p>`:'';

/* ---------- prayer times (sun position maths, 18°/18°, Hanafi or Shafi Asr) ---------- */
const CITY={Dhaka:[23.8103,90.4125],Chattogram:[22.3569,91.7832],Sylhet:[24.8949,91.8687],Rajshahi:[24.3745,88.6042],Khulna:[22.8456,89.5403],Barishal:[22.701,90.3535],Rangpur:[25.7439,89.2752],Mymensingh:[24.7471,90.4203],Cumilla:[23.4607,91.1809]};
const PR=[['fajr','Fajr'],['dhuhr','Dhuhr'],['asr','Asr'],['maghrib','Maghrib'],['isha','Isha']];
const rad=d=>d*Math.PI/180,deg=r=>r*180/Math.PI,fix=(a,b)=>{a=a-b*Math.floor(a/b);return a<0?a+b:a};
function julian(y,m,d){if(m<=2){y-=1;m+=12}const A=Math.floor(y/100),B=2-A+Math.floor(A/4);return Math.floor(365.25*(y+4716))+Math.floor(30.6001*(m+1))+d+B-1524.5}
function sun(jd){const D=jd-2451545,g=fix(357.529+0.98560028*D,360),q=fix(280.459+0.98564736*D,360),L=fix(q+1.915*Math.sin(rad(g))+0.02*Math.sin(rad(2*g)),360),e=23.439-0.00000036*D,RA=deg(Math.atan2(Math.cos(rad(e))*Math.sin(rad(L)),Math.cos(rad(L))))/15;return{decl:deg(Math.asin(Math.sin(rad(e))*Math.sin(rad(L)))),eqt:q/15-fix(RA,24)}}
let ptc={};
function ptimes(ds){
  const s=S.settings,key=ds+'|'+s.lat+'|'+s.lng+'|'+s.asr;if(ptc.k===key)return ptc.v;
  const d=parse(ds),lat=num(s.lat),lng=num(s.lng),tz=-d.getTimezoneOffset()/60,jd=julian(d.getFullYear(),d.getMonth()+1,d.getDate())-lng/360;
  const mid=t=>fix(12-sun(jd+t).eqt,24);
  const ang=(a,t,ccw)=>{const dc=sun(jd+t).decl,x=(-Math.sin(rad(a))-Math.sin(rad(dc))*Math.sin(rad(lat)))/(Math.cos(rad(dc))*Math.cos(rad(lat))),v=deg(Math.acos(Math.max(-1,Math.min(1,x))))/15;return mid(t)+(ccw?-v:v)};
  const asr=(f,t)=>{const dc=sun(jd+t).decl;return ang(-deg(Math.atan(1/(f+Math.tan(rad(Math.abs(lat-dc)))))),t)};
  const raw={fajr:ang(18,5/24,true),sunrise:ang(0.833,6/24,true),dhuhr:mid(.5)+1/60,asr:asr(s.asr==='Shafi'?1:2,13/24),maghrib:ang(0.833,18/24),isha:ang(18,18/24)},v={};
  Object.keys(raw).forEach(k=>{v[k]=hm(fix(raw[k]+tz-lng/15,24)*60)});
  ptc={k:key,v:v};return v;
}
function nextPrayer(){
  const t=ptimes(today()),n=nowMin();
  for(const p of PR){const m=toMin(t[p[0]]);if(m>n)return{name:p[1],t:t[p[0]],mins:m-n}}
  const f=ptimes(addDays(today(),1)).fajr;return{name:'Fajr',t:f,mins:toMin(f)+1440-n};
}
function hijri(){try{return new Intl.DateTimeFormat('en-u-ca-islamic-umalqura',{day:'numeric',month:'long',year:'numeric'}).format(new Date())}catch(e){return''}}
function qibla(){const la=rad(num(S.settings.lat)),dl=rad(39.8262-num(S.settings.lng)),k=rad(21.4225);return Math.round(fix(deg(Math.atan2(Math.sin(dl),Math.cos(la)*Math.tan(k)-Math.sin(la)*Math.cos(dl))),360))}

/* ---------- health episodes ---------- */
const WHEN={'Morning':['08:00'],'Night':['21:00'],'Morning and night':['08:00','21:00'],'Morning, noon and night':['08:00','14:00','21:00'],'Every 6 hours':['06:00','12:00','18:00','23:30'],'Every 8 hours':['06:00','14:00','22:00'],'Custom times':null};
const fixEp=e=>{if(e){e.meds=e.meds||[];e.taken=e.taken||{};e.log=e.log||[];e.photos=e.photos||[]}return e};
const activeEp=()=>fixEp(S.sick.find(e=>e.active));
function doses(ep,ds){
  const a=[];
  ep.meds.forEach(m=>{const st=m.start||ep.start||ds;if(ds<st||(m.days&&diffDays(ds,st)>=m.days))return;
    (m.times||[]).forEach(t=>{const key=m.id+'@'+t;a.push({m:m,t:t,key:key,taken:!!(ep.taken[ds]||{})[key]})})});
  return a.sort((x,y)=>x.t<y.t?-1:1);
}
const doseList=(ep,ds)=>{const l=doses(ep,ds),n=nowMin();return l.length?'<div class="list">'+l.map(x=>`<div class="item${x.taken?' done':''}">${chk(x.taken,'doseTog',`data-id="${x.key}" data-d="${ds}"`,x.m.name)}<div class="grow"><span class="t">${esc(x.m.name)}</span><br><span class="muted">${esc([x.m.dose,x.m.meal].filter(Boolean).join(' · '))}</span></div><span class="pill ${!x.taken&&ds===today()&&toMin(x.t)<n?'bad':''}">${tfmt(x.t)}</span></div>`).join('')+'</div>':'<p class="muted">No doses on this day.</p>'};

/* ---------- agenda: everything that has a time today ---------- */
function agenda(ds){
  const s=S.settings,a=[],dow=parse(ds).getDay();
  S.reminders.forEach(r=>{if(r.on===0||!r.time)return;
    const ok=r.repeat==='Every day'||(r.repeat==='Once'&&r.date===ds)||(r.repeat==='Sun to Thu'&&dow<5)||(r.repeat==='Every week'&&+r.day===dow);
    if(ok)a.push({t:r.time,title:r.title,src:'Reminder',key:'r-'+r.id})});
  S.events.forEach(e=>{if(e.date===ds&&e.time)a.push({t:e.time,title:e.title,src:'Event',key:'e-'+e.id})});
  if(s.nPrayer&&!s.deenOff){const t=ptimes(ds);PR.forEach(p=>a.push({t:t[p[0]],title:p[1]+' prayer time',src:'Prayer',key:'p-'+p[0]}))}
  const ep=activeEp();
  if(ep&&s.nMeds)doses(ep,ds).forEach(x=>{if(!x.taken)a.push({t:x.t,title:'Take '+x.m.name+(x.m.dose?' ('+x.m.dose+')':''),src:'Medicine',key:'m-'+x.key})});
  if(s.nClass)S.routine.forEach(r=>{if(+r.day===dow&&r.start)a.push({t:hm(toMin(r.start)-10),title:rName(r)+' starts at '+tfmt(r.start)+(r.room?' in '+r.room:''),src:'Class',key:'c-'+r.id})});
  if(s.nSleep&&s.sleepBed)a.push({t:hm(toMin(s.sleepBed)-30),title:'Wind down. Bedtime is '+tfmt(s.sleepBed),src:'Sleep',key:'s-bed'});
  if(+s.nWater>0&&(S.water[ds]||0)<s.waterGoal)for(let m=480;m<=1320;m+=+s.nWater)a.push({t:hm(m),title:'Drink a glass of water',src:'Water',key:'w-'+m});
  return a.sort((x,y)=>x.t<y.t?-1:1);
}
let fired={};
try{const o=JSON.parse(localStorage.getItem('daybook.fired')||'{}');if(o.d===today())fired=o.k||{}}catch(e){}
let AC=null;
function beep(){try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume();[0,.28].forEach(o=>{const os=AC.createOscillator(),g=AC.createGain();os.frequency.value=o?1040:780;os.connect(g);g.connect(AC.destination);g.gain.setValueAtTime(.25,AC.currentTime+o);g.gain.exponentialRampToValueAtTime(.001,AC.currentTime+o+.22);os.start(AC.currentTime+o);os.stop(AC.currentTime+o+.24)})}catch(e){}}
function toast(x){
  const box=$('#toasts');if(!box)return;
  const el=document.createElement('div');el.className='toast';
  el.innerHTML=`<div class="grow"><b>${esc(x.title)}</b><span>${esc(x.src)} · ${tfmt(x.t)}</span></div><button class="btn sm" data-a="toastOk">OK</button>`;
  box.appendChild(el);beep();
  try{if(window.Notification&&Notification.permission==='granted')new Notification(x.title,{body:x.src+' · '+tfmt(x.t)})}catch(e){}
}
function tick(){
  const n=nowMin();let hit=false;
  agenda(today()).forEach(x=>{const m=toMin(x.t);if(m<=n&&n-m<=15&&!fired[x.key]){fired[x.key]=1;hit=true;toast(x)}});
  if(hit)try{localStorage.setItem('daybook.fired',JSON.stringify({d:today(),k:fired}))}catch(e){}
}
setInterval(tick,20000);setTimeout(tick,3000);

/* ---------- day score + history ---------- */
function dayParts(ds){
  const pl=S.prayers[ds]||{},hl=S.habitLog[ds]||{},ep=S.sick.map(fixEp).find(e=>e.taken[ds]);
  return{pr:PR.filter(p=>pl[p[0]]).length,water:S.water[ds]||0,hab:S.habits.filter(h=>hl[h.id]).length,
    done:S.tasks.filter(t=>t.done&&t.doneAt===ds),open:ds===today()?S.tasks.filter(t=>!t.done&&t.due&&t.due<=ds).length:0,
    focus:S.focus.filter(f=>f.date===ds).reduce((a,f)=>a+f.min,0),spent:S.money.filter(m=>m.date===ds&&m.type!=='in').reduce((a,m)=>a+m.amount,0),
    meals:S.meals.filter(m=>m.date===ds),sleep:S.sleep.find(l=>l.date===ds),acts:S.acts.filter(a=>a.date===ds),
    quran:(S.quran.log||{})[ds]||0,meds:ep?Object.keys(ep.taken[ds]).length:0};
}
function dayScore(ds){
  const p=dayParts(ds),a=[p.pr/5,Math.min(1,p.water/S.settings.waterGoal)];
  if(S.habits.length)a.push(p.hab/S.habits.length);
  if(p.done.length+p.open)a.push(p.done.length/(p.done.length+p.open));
  return Math.round(a.reduce((x,y)=>x+y,0)/a.length*100);
}

/* ---------- TODAY additions ---------- */
EXT.todayTop=()=>{
  const t=today(),sc=dayScore(t),np=nextPrayer(),pl=S.prayers[t]||{},ep=activeEp(),n=nowMin();
  const up=agenda(t).filter(x=>toMin(x.t)>=n).slice(0,4);
  let o=`<div class="card"><div class="row"><div class="ring" style="--p:${sc}"><span>${sc}%</span></div><div class="grow"><h3>Today’s score</h3><p class="muted">Prayers, water, habits and tasks together. ${sc>=80?'A strong day.':sc>=40?'Keep going.':'Start with one small thing.'}</p></div></div></div>`;
  o+=`<div class="card c-leaf"><div class="row between"><h3>Next: ${np.name}</h3><span class="pill">${tfmt(np.t)} · in ${dur(np.mins)}</span></div><div class="prow">${PR.map(p=>`<div>${chk(pl[p[0]],'prTog',`data-id="${p[0]}" data-d="${t}"`,p[1])}<span>${p[1]}</span></div>`).join('')}</div></div>`;
  if(ep)o+=`<div class="card c-tomato">${head('Medicine today',`<button class="btn sm" data-a="go" data-tab="life" data-k="life" data-v="health">Open</button>`)}<p class="muted">${esc(ep.name)}</p>${doseList(ep,t)}</div>`;
  if(up.length)o+=`<div class="card">${head('Up next',`<button class="btn sm" data-a="go" data-tab="more" data-k="more" data-v="reminders">All</button>`)}<div class="list">${up.map(x=>`<div class="item"><span class="pill">${tfmt(x.t)}</span><span class="t grow">${esc(x.title)}</span></div>`).join('')}</div></div>`;
  return o;
};

/* ---------- DEEN ---------- */
const SUR="Al-Fatihah:7|Al-Baqarah:286|Ali 'Imran:200|An-Nisa:176|Al-Ma'idah:120|Al-An'am:165|Al-A'raf:206|Al-Anfal:75|At-Tawbah:129|Yunus:109|Hud:123|Yusuf:111|Ar-Ra'd:43|Ibrahim:52|Al-Hijr:99|An-Nahl:128|Al-Isra:111|Al-Kahf:110|Maryam:98|Ta-Ha:135|Al-Anbiya:112|Al-Hajj:78|Al-Mu'minun:118|An-Nur:64|Al-Furqan:77|Ash-Shu'ara:227|An-Naml:93|Al-Qasas:88|Al-'Ankabut:69|Ar-Rum:60|Luqman:34|As-Sajdah:30|Al-Ahzab:73|Saba:54|Fatir:45|Ya-Sin:83|As-Saffat:182|Sad:88|Az-Zumar:75|Ghafir:85|Fussilat:54|Ash-Shura:53|Az-Zukhruf:89|Ad-Dukhan:59|Al-Jathiyah:37|Al-Ahqaf:35|Muhammad:38|Al-Fath:29|Al-Hujurat:18|Qaf:45|Adh-Dhariyat:60|At-Tur:49|An-Najm:62|Al-Qamar:55|Ar-Rahman:78|Al-Waqi'ah:96|Al-Hadid:29|Al-Mujadila:22|Al-Hashr:24|Al-Mumtahanah:13|As-Saff:14|Al-Jumu'ah:11|Al-Munafiqun:11|At-Taghabun:18|At-Talaq:12|At-Tahrim:12|Al-Mulk:30|Al-Qalam:52|Al-Haqqah:52|Al-Ma'arij:44|Nuh:28|Al-Jinn:28|Al-Muzzammil:20|Al-Muddaththir:56|Al-Qiyamah:40|Al-Insan:31|Al-Mursalat:50|An-Naba:40|An-Nazi'at:46|'Abasa:42|At-Takwir:29|Al-Infitar:19|Al-Mutaffifin:36|Al-Inshiqaq:25|Al-Buruj:22|At-Tariq:17|Al-A'la:19|Al-Ghashiyah:26|Al-Fajr:30|Al-Balad:20|Ash-Shams:15|Al-Layl:21|Ad-Duha:11|Ash-Sharh:8|At-Tin:8|Al-'Alaq:19|Al-Qadr:5|Al-Bayyinah:8|Az-Zalzalah:8|Al-'Adiyat:11|Al-Qari'ah:11|At-Takathur:8|Al-'Asr:3|Al-Humazah:9|Al-Fil:5|Quraysh:4|Al-Ma'un:7|Al-Kawthar:3|Al-Kafirun:6|An-Nasr:3|Al-Masad:5|Al-Ikhlas:4|Al-Falaq:5|An-Nas:6".split('|').map(x=>{const a=x.split(':');return[a[0],+a[1]]});
const QN=()=>{const q=S.quran;q.done=q.done||{};q.log=q.log||{};return q};
const DUA=[
 {id:'kursi',g:'Morning and evening',t:'Ayatul Kursi',w:'Morning, evening, after each prayer and before sleep',n:1,ref:'Quran 2:255',q:'2/255'},
 {id:'3qul',g:'Morning and evening',t:'Surah Al-Ikhlas, Al-Falaq and An-Nas',w:'Three times each, morning and evening',n:3,ref:'Quran 112 to 114',q:'112'},
 {id:'sayyid',g:'Morning and evening',t:'Sayyidul Istighfar',w:'Once in the morning and once in the evening',n:1,ar:'اللهم أنت ربي لا إله إلا أنت، خلقتني وأنا عبدك، وأنا على عهدك ووعدك ما استطعت، أعوذ بك من شر ما صنعت، أبوء لك بنعمتك علي، وأبوء لك بذنبي فاغفر لي، فإنه لا يغفر الذنوب إلا أنت',m:'O Allah, You are my Lord. There is no god but You. You created me and I am Your servant, and I keep Your covenant and promise as best I can. I seek refuge in You from the evil I have done. I acknowledge Your favour upon me and I acknowledge my sin, so forgive me, for none forgives sins but You.',ref:'Bukhari 6306'},
 {id:'bism3',g:'Morning and evening',t:'Protection from every harm',w:'Three times, morning and evening',n:3,ar:'بسم الله الذي لا يضر مع اسمه شيء في الأرض ولا في السماء وهو السميع العليم',m:'In the name of Allah, with whose name nothing on earth or in the heavens can cause harm. He is the All-Hearing, the All-Knowing.',ref:'Abu Dawud 5088'},
 {id:'hasbi',g:'Morning and evening',t:'Hasbiyallah',w:'Seven times, morning and evening',n:7,ar:'حسبي الله لا إله إلا هو عليه توكلت وهو رب العرش العظيم',m:'Allah is enough for me. There is no god but Him. In Him I put my trust, and He is the Lord of the mighty Throne.',ref:'Quran 9:129, Abu Dawud 5081'},
 {id:'sbh',g:'Morning and evening',t:'SubhanAllahi wa bihamdihi',w:'100 times in the day',n:100,ar:'سبحان الله وبحمده',m:'Glory and praise be to Allah.',ref:'Bukhari 6405'},
 {id:'tahlil',g:'Morning and evening',t:'La ilaha illallahu wahdahu',w:'100 times in the day',n:100,ar:'لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير',m:'There is no god but Allah alone, with no partner. His is the kingdom and His is the praise, and He has power over all things.',ref:'Bukhari 3293'},
 {id:'salawat',g:'Morning and evening',t:'Durood on the Prophet ﷺ',w:'Ten times, morning and evening',n:10,ar:'اللهم صل وسلم على نبينا محمد',m:'O Allah, send blessings and peace upon our Prophet Muhammad.',ref:'Send blessings often, above all on Friday'},
 {id:'istigh',g:'After each prayer',t:'Astaghfirullah',w:'Three times after every fard prayer',n:15,ar:'أستغفر الله',m:'I ask Allah for forgiveness.',ref:'Muslim 591'},
 {id:'tasbih',g:'After each prayer',t:'Tasbih after prayer',w:'33, 33 and 34 after every fard prayer. Tap once per prayer.',n:5,ar:'سبحان الله (33) · الحمد لله (33) · الله أكبر (34)',m:'Glory be to Allah. All praise is for Allah. Allah is the Greatest.',ref:'Muslim 596'},
 {id:'ainni',g:'After each prayer',t:'Help me remember You',w:'After every prayer',n:5,ar:'اللهم أعني على ذكرك وشكرك وحسن عبادتك',m:'O Allah, help me to remember You, to thank You, and to worship You well.',ref:'Abu Dawud 1522'},
 {id:'wake',g:'Through the day',t:'On waking up',w:'When you wake',n:1,ar:'الحمد لله الذي أحيانا بعد ما أماتنا وإليه النشور',m:'All praise is for Allah, who gave us life after He caused us to die, and to Him is the return.',ref:'Bukhari 6312'},
 {id:'leave',g:'Through the day',t:'Leaving home',w:'Each time you go out',n:1,ar:'بسم الله توكلت على الله ولا حول ولا قوة إلا بالله',m:'In the name of Allah. I trust in Allah. There is no might and no power except with Allah.',ref:'Abu Dawud 5095'},
 {id:'eat',g:'Through the day',t:'Before and after eating',w:'Say Bismillah before eating, and this after',n:3,ar:'الحمد لله الذي أطعمني هذا ورزقنيه من غير حول مني ولا قوة',m:'All praise is for Allah, who fed me this and provided it for me with no might or power of my own.',ref:'Tirmidhi 3458'},
 {id:'ilm',g:'Through the day',t:'Before studying',w:'Before class or study',n:1,ar:'رب زدني علما · رب اشرح لي صدري ويسر لي أمري',m:'My Lord, increase me in knowledge. My Lord, open my heart for me and make my task easy for me.',ref:'Quran 20:114 and 20:25-26',q:'20/114'},
 {id:'rabbana',g:'Through the day',t:'Good in this world and the next',w:'Any time, in every dua',n:1,ar:'ربنا آتنا في الدنيا حسنة وفي الآخرة حسنة وقنا عذاب النار',m:'Our Lord, give us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.',ref:'Quran 2:201',q:'2/201'},
 {id:'parents',g:'Through the day',t:'For your parents',w:'Every day',n:1,ar:'رب ارحمهما كما ربياني صغيرا',m:'My Lord, have mercy on them as they raised me when I was small.',ref:'Quran 17:24',q:'17/24'},
 {id:'baqarah',g:'Before sleep',t:'Last two ayahs of Al-Baqarah',w:'At night',n:1,ref:'Quran 2:285-286',q:'2/285'},
 {id:'mulk',g:'Before sleep',t:'Surah Al-Mulk',w:'Every night before sleep',n:1,ref:'Quran 67, Tirmidhi 2891',q:'67'},
 {id:'sleep',g:'Before sleep',t:'Going to sleep',w:'When you lie down',n:1,ar:'باسمك اللهم أموت وأحيا',m:'In Your name, O Allah, I die and I live.',ref:'Bukhari 6324'}
];
const TZP=['SubhanAllah','Alhamdulillah','Allahu Akbar','La ilaha illallah','Astaghfirullah','Durood'];
const allDuas=()=>DUA.concat(S.duas.map(d=>({id:d.id,g:'My duas',t:d.title,w:d.when,n:Math.max(1,+d.n||1),ar:d.text,m:d.meaning,mine:true})));
function vDeen(){
  const t=today(),s=S.settings;
  let o=sub('deen',SUB.deen);
  if(ui.deen==='prayer'){
    const pt=ptimes(t),np=nextPrayer(),pl=S.prayers[t]||{},d7=last7(),hj=hijri();
    o+=`<div class="card c-leaf"><div class="row between"><div><h2>Prayer times</h2><p class="muted">${esc(s.city)} · ${s.asr} Asr${hj?' · '+hj:''}</p></div><button class="btn sm" data-a="setDeen">Change</button></div>
      <div class="ptime"><b>Sunrise</b><span>${tfmt(pt.sunrise)}</span><span style="width:28px"></span></div>
      ${PR.map(p=>`<div class="ptime${np.name===p[1]&&np.mins<1440&&toMin(pt[p[0]])>nowMin()?' next':''}"><b>${p[1]}</b><span>${tfmt(pt[p[0]])}</span>${chk(pl[p[0]],'prTog',`data-id="${p[0]}" data-d="${t}"`,p[1]+' prayed')}</div>`).join('')}
      <p class="muted">Next is ${np.name} in ${dur(np.mins)}. Times are calculated for your city and can differ from your mosque by a minute or two.</p></div>`;
    o+=`<div class="card">${head('This week',`<span class="pill">${d7.reduce((a,x)=>a+PR.filter(p=>(S.prayers[x]||{})[p[0]]).length,0)} / 35</span>`)}<div class="pgrid"><span></span>${d7.map(x=>`<span>${DAYS[parse(x).getDay()][0]}${parse(x).getDate()}</span>`).join('')}
      ${PR.map(p=>`<b>${p[1]}</b>`+d7.map(x=>`<button class="${(S.prayers[x]||{})[p[0]]?'on':''}" data-a="prTog" data-id="${p[0]}" data-d="${x}" aria-label="${p[1]} on ${fmt(x)}"></button>`).join('')).join('')}</div><p class="muted">Tap a box to mark a prayer you offered.</p></div>`;
    const fm=Object.keys(S.fasts).filter(k=>k.slice(0,7)===t.slice(0,7)).length;
    o+=`<div class="grid"><div class="card"><h3>Qaza prayers</h3><div class="big">${+s.qaza||0}</div><p class="muted">Missed prayers still to make up</p><div class="row"><button class="btn sm" data-a="qaza" data-n="-1" aria-label="One made up">−</button><button class="btn sm" data-a="qaza" data-n="1" aria-label="Add one missed">+</button></div></div>
      <div class="card"><h3>Fasting</h3><div class="big">${fm}<small> this month</small></div><div class="row">${chk(S.fasts[t],'fastTog','','Fasting today')}<span class="muted">I am fasting today</span></div></div></div>
      <div class="card"><h3>Qibla</h3><p>About <b>${qibla()}°</b> from north, measured clockwise. From Bangladesh that is almost due west, turned slightly to the north.</p></div>`;
  }
  if(ui.deen==='quran'){
    const q=QN(),read=SUR.reduce((a,x,i)=>a+(q.done[i+1]?x[1]:0),0),d7=last7(),td=q.log[t]||0,mk=q.mark;
    o+=`<div class="card c-leaf"><div class="row between"><h2>Quran</h2><span class="pill">${Object.keys(q.done).length} / 114 surahs</span></div><div class="big">${Math.round(read/6236*100)}%<small> of 6,236 ayahs</small></div><div class="bar"><i style="width:${read/6236*100}%"></i></div>
      ${mk?`<p>Bookmark: <b>${esc(SUR[mk.s-1][0])}</b>, ayah ${mk.a}</p><div class="row wrap"><a class="btn sm" href="https://quran.com/${mk.s}/${mk.a}" target="_blank" rel="noopener">Continue reading</a><button class="btn sm" data-a="qMark">Move bookmark</button></div>`:`<button class="btn sm" data-a="qMark" style="align-self:flex-start">Set a bookmark</button>`}
      <p class="muted">Reading opens Quran.com, which has the Arabic with vowels, Bangla and English, and audio. The full Quran text is not stored inside this app yet.</p></div>`;
    o+=`<div class="card">${head('Daily recitation',`<span class="pill">${td} / ${s.qgoal} ayahs</span>`)}<div class="bar"><i style="width:${Math.min(100,td/Math.max(1,s.qgoal)*100)}%"></i></div><div class="row wrap"><button class="btn sm" data-a="qLog" data-n="5">+5 ayahs</button><button class="btn sm" data-a="qLog" data-n="10">+10</button><button class="btn sm" data-a="qLog" data-n="-5">−5</button><button class="btn sm" data-a="qGoal">Daily goal</button></div>${bars(d7.map(x=>q.log[x]||0),d7.map(x=>DAYS[parse(x).getDay()][0]),'leaf',+s.qgoal)}</div>`;
    o+=`<div class="card"><h2>Surahs</h2><p class="muted">Tick a surah when you finish it.</p>${SUR.map((x,i)=>`<div class="sur">${chk(q.done[i+1],'qDone',`data-id="${i+1}"`,x[0]+' finished')}<em>${i+1}</em><span class="t grow">${x[0]}<br><span class="muted">${x[1]} ayahs</span></span><a class="btn sm" href="https://quran.com/${i+1}" target="_blank" rel="noopener">Read</a></div>`).join('')}</div>`;
  }
  if(ui.deen==='duas'){
    const all=allDuas(),log=S.dhikr[t]||{},dn=all.filter(d=>(log[d.id]||0)>=d.n).length,gs=[];
    all.forEach(d=>{if(!gs.includes(d.g))gs.push(d.g)});
    o+=`<div class="card c-leaf"><div class="row between"><h2>Daily duas</h2><span class="pill">${dn} / ${all.length} today</span></div><div class="bar"><i style="width:${dn/all.length*100}%"></i></div><div class="chips">${[['bn','অর্থ বাংলায়'],['en','Meaning in English']].map(x=>`<button class="chip${S.settings.dl===x[0]?' on':''}" data-a="duaLang" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><p class="muted">The Arabic, pronunciation and meanings were entered by hand and have not been checked against a printed book. Please confirm the wording with Hisnul Muslim or your teacher before memorising.</p></div>`;
    o+=gs.map(g=>`<div class="card"><h2>${g}</h2>${all.filter(d=>d.g===g).map(d=>{const c=log[d.id]||0,ok=c>=d.n;return`<div class="dua"><div class="row between"><h3>${esc(d.t)}</h3>${d.mine?`<button class="btn sm" data-a="duaEdit" data-id="${d.id}" aria-label="Edit dua">${ic('edit')}</button>`:''}</div>${d.w?`<p class="muted">${esc(d.w)}</p>`:''}${d.ar?`<p class="ar" lang="ar">${esc(d.ar)}</p>`:''}${d.bp?`<p><b>উচ্চারণ:</b> ${esc(d.bp)}</p>`:''}${S.settings.dl==='en'||!d.bm?(d.m?`<p>${esc(d.m)}</p>`:''):`<p><b>অর্থ:</b> ${esc(d.bm)}</p>`}${d.ref?`<p class="muted">${esc(d.ref)}${d.q?` · <a href="https://quran.com/${d.q}" target="_blank" rel="noopener">Read on Quran.com</a>`:''}</p>`:''}
      <div class="row wrap"><span class="pill ${ok?'col c-leaf':''}">${Math.min(c,d.n)} / ${d.n}</span>${d.n>1?`<button class="btn sm" data-a="duaInc" data-id="${d.id}" data-n="${d.n}">+1</button>`:''}<button class="btn sm" data-a="duaDone" data-id="${d.id}" data-n="${d.n}">${ok?'Undo':'Done'}</button></div></div>`}).join('')}</div>`).join('');
    o+=`<div class="card"><h3>Add your own dua</h3><p class="muted">Any dua your family or teacher gave you can sit in this list.</p>${addBtn('duaAdd','Add a dua')}</div>`;
  }
  if(ui.deen==='tasbih'){
    const z=ui.tz,tot=(S.dhikr[t]||{}).tasbih||0;
    o+=`<div class="card"><div class="chips">${TZP.map((p,i)=>`<button class="chip${z.ph===i?' on':''}" data-a="tzPh" data-n="${i}">${p}</button>`).join('')}</div><button class="tz" data-a="tzTap" id="tzn" aria-label="Count ${TZP[z.ph]}">${z.n}</button><p class="muted" style="text-align:center" id="tzs">${TZP[z.ph]} · target ${z.target} · ${tot} counted today</p><div class="row wrap" style="justify-content:center">${[33,99,100].map(n=>`<button class="chip${z.target===n?' on':''}" data-a="tzTarget" data-n="${n}">${n}</button>`).join('')}<button class="btn sm" data-a="tzReset">Reset</button></div></div>`;
  }
  if(EXT[ui.deen])o+=EXT[ui.deen]();
  return o;
}
VIEWS.deen=vDeen;

/* ---------- LIFE: food, sleep, health, habit and money extras ---------- */
const SLOT=['Breakfast','Lunch','Dinner','Snack'],FTAG=['Homemade','Hall or canteen','Restaurant','Junk food'];
EXT.food=()=>{
  const ds=ui.foodDay,l=S.meals.filter(m=>m.date===ds),d7=last7(),wk=S.meals.filter(m=>d7.includes(m.date));
  const bf=d7.filter(x=>S.meals.some(m=>m.date===x&&m.meal==='Breakfast')).length;
  let o=`<div class="card">${dayNav('foodDay',ds)}<div class="list">${SLOT.map(sl=>{const ms=l.filter(m=>m.meal===sl);return`<div class="item"><div class="grow"><span class="pill col c-${ms.length?'leaf':'sun'}">${sl}</span>${ms.map(m=>`<button class="tap" data-a="mealEdit" data-id="${m.id}"><span class="t">${esc(m.text)}</span><span class="muted">${esc([m.tag,m.cost?money(m.cost):''].filter(Boolean).join(' · '))}</span></button>`).join('')||'<p class="muted">Not logged</p>'}</div><button class="btn sm" data-a="mealAdd" data-meal="${sl}" aria-label="Add ${sl}">${ic('plus')}</button></div>`}).join('')}</div></div>`;
  o+=`<div class="card c-sun"><h3>Last 7 days</h3><div class="g3">${stat(bf+' / 7','breakfasts eaten')}${stat(wk.filter(m=>m.tag==='Junk food').length,'junk meals')}${stat(money(wk.reduce((a,m)=>a+(+m.cost||0),0)),'spent on food')}</div><p class="muted">${bf<5?'Breakfast is the meal you skip most. A small one still counts.':'Good breakfast routine this week.'}</p></div>`;
  return o;
};
const sleepMin=l=>(toMin(l.wake)-toMin(l.bed)+1440)%1440;
EXT.sleep=()=>{
  const s=S.settings,d7=last7(),logs=d7.map(x=>S.sleep.find(l=>l.date===x)),got=logs.filter(Boolean),target=(toMin(s.sleepWake)-toMin(s.sleepBed)+1440)%1440;
  const avg=got.length?got.reduce((a,l)=>a+sleepMin(l),0)/got.length:0,debt=got.reduce((a,l)=>a+(target-sleepMin(l)),0),last=S.sleep.find(l=>l.date===today());
  const asleep=s.sleepStart&&Date.now()-s.sleepStart<20*36e5,w=toMin(s.sleepWake),n=nowMin();
  let o=`<div class="card c-grape"><div class="row between"><h2>Sleep</h2><button class="btn sm" data-a="setSleep">Schedule</button></div><div class="g3">${stat(last?dur(sleepMin(last)):'–','last night')}${stat(got.length?dur(Math.round(avg)):'–','7-day average')}${stat(got.length?(debt>0?dur(Math.round(debt)):'None'):'–','sleep debt')}</div>
    <p class="muted">Schedule: bed ${tfmt(s.sleepBed)}, wake ${tfmt(s.sleepWake)} (${dur(target)}).</p>
    ${asleep?`<button class="btn pri" data-a="wakeNow">I am awake. Log my sleep</button><p class="muted">Went to bed at ${tfmt(hm(new Date(s.sleepStart).getHours()*60+new Date(s.sleepStart).getMinutes()))}.</p>`:`<div class="row wrap"><button class="btn pri" data-a="bedNow">Going to bed now</button><button class="btn" data-a="slAdd">Log by hand</button></div>`}</div>`;
  o+=`<div class="card"><h2>Sleep cycles</h2><p class="muted">A cycle is about 90 minutes. Waking at the end of one feels easier. This allows 15 minutes to fall asleep.</p><div class="list"><div class="item"><span class="grow">To wake at <b>${tfmt(s.sleepWake)}</b>, go to bed at</span></div>${[6,5,4].map(c=>`<div class="item"><span class="pill col c-grape">${c} cycles · ${dur(c*90)}</span><span class="t grow" style="text-align:right">${tfmt(hm(w-c*90-15))}</span></div>`).join('')}<div class="item"><span class="grow">If you sleep now, wake at</span></div>${[4,5,6].map(c=>`<div class="item"><span class="pill">${c} cycles</span><span class="t grow" style="text-align:right">${tfmt(hm(n+c*90+15))}</span></div>`).join('')}</div></div>`;
  o+=`<div class="card">${head('Last 7 nights','<span class="muted">hours</span>')}${bars(logs.map(l=>l?Math.round(sleepMin(l)/6)/10:0),d7.map(x=>DAYS[parse(x).getDay()][0]),'grape',Math.round(target/6)/10)}${got.length?'<div class="list">'+S.sleep.slice().sort((a,b)=>a.date<b.date?1:-1).slice(0,7).map(l=>`<div class="item"><button class="tap" data-a="slEdit" data-id="${l.id}"><span class="t">${fmt(l.date)} · ${dur(sleepMin(l))}</span><span class="muted">${tfmt(l.bed)} to ${tfmt(l.wake)}${l.q?' · '+esc(l.q):''}</span></button>${ic('edit')}</div>`).join('')+'</div>':'<p class="muted">Tap “Going to bed now” tonight and “I am awake” tomorrow. Your chart builds itself.</p>'}</div>`;
  return o;
};
function epCard(ep,live){
  const t=today(),dn=diffDays(ep.end||t,ep.start)+1;
  let o=`<div class="card c-tomato"><div class="row between"><span class="pill">${live?'Sick now · day '+dn:'Recovered · '+dn+' days'}</span><button class="btn sm" data-a="epEdit" data-id="${ep.id}">${ic('edit')}Edit</button></div><h1>${esc(ep.name)}</h1><p class="muted">${esc([ep.doctor?'Dr. '+ep.doctor:'','from '+fmt(ep.start),ep.end?'to '+fmt(ep.end):''].filter(Boolean).join(' · '))}</p>${ep.notes?`<p class="note-body">${esc(ep.notes)}</p>`:''}${live?`<button class="btn" data-a="sickEnd">I have recovered</button>`:''}</div>`;
  if(live)o+=`<div class="card">${head('Doses today',`<span class="pill">${doses(ep,t).filter(x=>x.taken).length} / ${doses(ep,t).length}</span>`)}${doseList(ep,t)}<p class="muted">The app alerts you at each time while it is open. Follow your doctor’s prescription. This is a record, not medical advice.</p></div>`;
  o+=`<div class="card">${head('Prescription',live?addBtn('medAdd','Medicine'):'')}${ep.meds.length?'<div class="list">'+ep.meds.map(m=>`<div class="item"><button class="tap" data-a="medEdit" data-id="${m.id}"><span class="t">${esc(m.name)}${m.dose?' · '+esc(m.dose):''}</span><span class="muted">${esc([(m.times||[]).map(tfmt).join(', '),m.meal,m.days?m.days+' days':''].filter(Boolean).join(' · '))}</span></button>${ic('edit')}</div>`).join('')+'</div>':'<p class="muted">Add each medicine from your prescription with its dose and times.</p>'}
    ${ep.photos.length?`<div class="row wrap">${ep.photos.map(p=>String(p).indexOf('local:')===0?`<button class="btn sm" data-a="rxOpen" data-id="${esc(p)}">${ic('cam')}Photo</button>`:`<a href="/_blob/${p}" target="_blank" rel="noopener"><img class="thumb" src="/_blob/${p}" alt="Prescription photo" style="width:84px;height:84px"></a>`).join('')}</div>`:''}
    <label class="btn sm filebtn" style="align-self:flex-start">${ic('plus')}Photo of prescription<input type="file" id="rxup" accept="image/*,application/pdf"></label>${said('rx')}</div>`;
  o+=`<div class="card">${head('Symptoms and temperature',live?addBtn('symAdd','Log'):'')}${ep.log.length?'<div class="list">'+ep.log.slice().reverse().map(x=>`<div class="item"><div class="grow"><span class="t">${esc(x.text||'Temperature')}</span><br><span class="muted">${fmt(x.date)} ${tfmt(x.time)}</span></div>${x.temp?`<span class="pill ${x.temp>=100.4?'bad':''}">${x.temp}°F</span>`:''}</div>`).join('')+'</div>':'<p class="muted">Nothing logged.</p>'}</div>`;
  return o;
}
EXT.health=()=>{
  const live=activeEp(),past=S.sick.filter(e=>!e.active).map(fixEp).sort((a,b)=>a.start<b.start?1:-1);
  if(ui.ep){const e=fixEp(S.sick.find(x=>x.id===ui.ep));if(e&&!e.active)return`<button class="btn sm" data-a="epBack" style="align-self:flex-start">${ic('back')}Health</button>`+epCard(e,false)}
  let o=live?epCard(live,true):`<div class="card c-leaf"><h2>Feeling well</h2><p class="muted">This part stays quiet until you need it. When you fall sick, tell the app. It keeps your prescription, reminds you of each dose, and saves the record for next time.</p><button class="btn pri" data-a="sickStart">I am sick</button></div>`;
  o+=`<div class="card"><h2>Health history</h2>${past.length?'<div class="list">'+past.map(e=>`<div class="item"><button class="tap" data-a="epOpen" data-id="${e.id}"><span class="t">${esc(e.name)}</span><span class="muted">${fmt(e.start)}${e.end?' to '+fmt(e.end):''} · ${e.meds.length} medicine${e.meds.length===1?'':'s'}</span></button>${ic('next')}</div>`).join('')+'</div>':'<p class="muted">Past illnesses and their prescriptions will be listed here.</p>'}</div>`;
  return o;
};
EXT.habits=()=>{
  if(!S.habits.length)return'';
  const d30=[];for(let i=29;i>=0;i--)d30.push(addDays(today(),-i));
  return`<div class="card"><h2>Last 30 days</h2>${S.habits.map(h=>{const n=d30.filter(x=>(S.habitLog[x]||{})[h.id]).length;let best=0,run=0;for(let i=89;i>=0;i--){if((S.habitLog[addDays(today(),-i)]||{})[h.id]){run++;best=Math.max(best,run)}else run=0}
    const wk=last7().filter(x=>(S.habitLog[x]||{})[h.id]).length,g=+h.goal||7;
    return`<div><div class="row between"><span class="t">${esc(h.name)}${h.kind==='Quit'?' <span class="pill bad">Quit</span>':''}</span><span class="muted">${Math.round(n/30*100)}% · best ${best} days</span></div><div class="bar"><i style="width:${n/30*100}%"></i></div><p class="muted">This week ${wk} of ${g} days${wk>=g?'. Goal met.':''}</p></div>`}).join('')}<p class="muted">For a habit you want to quit, tick the days you stayed away from it.</p></div>`;
};
EXT.money=()=>{
  const t=today(),cur=ui.month===t.slice(0,7),l=S.money.filter(m=>m.date.slice(0,7)===ui.month&&m.type!=='in'),out=l.reduce((a,m)=>a+m.amount,0);
  const mo=ui.month.split('-').map(Number),dim=new Date(mo[0],mo[1],0).getDate(),day=cur?new Date().getDate():dim;
  const pm=ymd(new Date(mo[0],mo[1]-2,1)).slice(0,7),prev=S.money.filter(m=>m.date.slice(0,7)===pm&&m.type!=='in').reduce((a,m)=>a+m.amount,0);
  let o=`<div class="card c-sun"><h3>Insights</h3><div class="g3">${stat(money(out/Math.max(1,day)),'per day')}${stat(cur?money(out/Math.max(1,day)*dim):money(out),cur?'month forecast':'month total')}${stat(prev?(out>=prev?'+':'−')+Math.abs(Math.round((out-prev)/prev*100))+'%':'–','vs last month')}</div>${cur&&S.settings.budget?`<p class="muted">${out/Math.max(1,day)*dim>S.settings.budget?'At this pace you will pass your budget. Safe to spend '+money(Math.max(0,(S.settings.budget-out)/Math.max(1,dim-day+1)))+' a day from now.':'You are on pace to stay inside your budget.'}</p>`:''}</div>`;
  o+=`<div class="card">${head('Savings goals',addBtn('goalAdd','Goal'))}${S.goals.length?S.goals.map(g=>`<div><div class="row between"><button class="tap" data-a="goalEdit" data-id="${g.id}"><span class="t">${esc(g.name)}</span><span class="muted">${money(g.saved||0)} of ${money(g.target)}</span></button><button class="btn sm" data-a="goalPut" data-id="${g.id}">${ic('plus')}Save</button></div><div class="bar"><i style="width:${Math.min(100,(g.saved||0)/Math.max(1,g.target)*100)}%"></i></div></div>`).join(''):'<p class="muted">Saving for a laptop, a trip or the semester fee? Track it here.</p>'}</div>`;
  const open=S.debts.filter(d=>!d.settled),get=open.filter(d=>d.dir==='I lent').reduce((a,d)=>a+d.amount,0),owe=open.filter(d=>d.dir!=='I lent').reduce((a,d)=>a+d.amount,0);
  o+=`<div class="card">${head('Lent and borrowed',addBtn('debtAdd','Add'))}<div class="row"><span class="pill col c-leaf">To get back ${money(get)}</span><span class="pill col c-tomato">To pay ${money(owe)}</span></div>${S.debts.length?'<div class="list">'+S.debts.map(d=>`<div class="item${d.settled?' done':''}">${chk(d.settled,'debtTog',`data-id="${d.id}"`,'Settled')}<button class="tap" data-a="debtEdit" data-id="${d.id}"><span class="t">${esc(d.person)} · ${money(d.amount)}</span><span class="muted">${esc(d.dir)}${d.date?' · '+fmt(d.date):''}${d.note?' · '+esc(d.note):''}</span></button></div>`).join('')+'</div>':'<p class="muted">Note who owes you and whom you owe, so nothing is forgotten.</p>'}</div>`;
  return o;
};

/* ---------- STUDY: files and PDF tools ---------- */
const FT={pdf:'application/pdf',jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',gif:'image/gif',webp:'image/webp',txt:'text/plain',md:'text/markdown',csv:'text/csv',mp4:'video/mp4'};
const ext=n=>(String(n).split('.').pop()||'').toLowerCase();
async function putFilesOld(list,msgKey,each){
  if(!AS){say(msgKey,'File storage is not available in this view. Open the app from your account.');return}
  const bad=[];
  for(const f of list){
    const type=FT[ext(f.name)];
    if(!type){bad.push(f.name+' (this type cannot be stored. Save it as PDF first)');continue}
    if(f.size>20*1048576){bad.push(f.name+' (over 20 MB)');continue}
    say(msgKey,'Uploading '+f.name+'…');
    try{const r=await AS.upload(f,{type:type});each(r,f)}
    catch(e){bad.push(f.name+' ('+(e&&e.code==='quota_or_state'?'storage is full':'upload failed')+')')}
  }
  say(msgKey,bad.length?'Not saved: '+bad.join('; '):'Saved.');
}
const fileRowsOld=l=>'<div class="list">'+l.map(f=>`<div class="item linkrow">${/^image\//.test(f.type)?`<img class="thumb" src="/_blob/${f.asset}" alt="">`:`<span class="thumb">${esc(ext(f.name))}</span>`}<div class="grow"><a href="/_blob/${f.asset}" target="_blank" rel="noopener">${esc(f.name)}</a><small>${fsz(f.size)} · ${fmt(f.added)}</small></div><button class="btn sm" data-a="fSave" data-id="${f.id}">Save</button><button class="btn sm" data-a="fEdit" data-id="${f.id}" aria-label="Edit file">${ic('edit')}</button></div>`).join('')+'</div>';
const upBtn=cid=>`<label class="btn sm pri filebtn">${ic('plus')}Upload<input type="file" id="fup" multiple data-course="${cid}" accept=".pdf,.jpg,.jpeg,.png,.gif,.webp,.txt,.md,.csv,.mp4"></label>`;
EXT.files=()=>{
  const g={};S.files.forEach(f=>{const k=cname(f.courseId)||'General';(g[k]=g[k]||[]).push(f)});
  let o=`<div class="card"><div class="row between"><h2>Study files</h2>${upBtn('')}</div><label>Put new uploads in<select id="fcourse">${courseOpts().map(x=>`<option value="${x[0]}">${esc(x[1]==='No course'?'General':x[1])}</option>`).join('')}</select></label>${said('files')}<p class="muted">PDF, JPG, PNG, GIF, WEBP, text and MP4, up to 20 MB each. Word and PowerPoint files cannot be stored as they are: export them as PDF first, or save their Drive link in Links. Files belong to this app, so anyone you share the app with could open them.</p></div>`;
  o+=Object.keys(g).sort().map(k=>`<div class="card"><h3>${esc(k)}</h3>${fileRows(g[k])}</div>`).join('')||`<div class="card">${empty('No files yet','Lecture slides as PDF, photos of the board, scanned notes. Each file can belong to a course.')}</div>`;
  return o;
};
EXT.courseFiles=cid=>{const l=S.files.filter(f=>f.courseId===cid);return`<div class="card"><div class="row between"><h2>Files</h2>${upBtn(cid)}</div>${said('files')}${l.length?fileRows(l):'<p class="muted">Slides, scans and photos for this course.</p>'}</div>`};
let toolOut=null;
function loadPdf(){return new Promise((res,rej)=>{if(window.PDFLib)return res(window.PDFLib);const s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js';s.onload=()=>res(window.PDFLib);s.onerror=()=>rej(new Error('offline'));document.head.appendChild(s)})}
function pageList(txt,max){
  const out=[];
  for(const part of String(txt).split(',')){const m=part.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);if(!m)return null;const a=+m[1],b=m[2]?+m[2]:a;if(a<1||b>max||a>b)return null;for(let i=a;i<=b;i++)out.push(i-1)}
  return out.length?out:null;
}
async function runTool(kind){
  const inp=document.getElementById('t_'+kind),files=inp?[...inp.files]:[];
  if(!files.length){say('tool','Choose the file first.');return}
  say('tool','Working…');toolOut=null;
  try{
    const P=await loadPdf(),out=await P.PDFDocument.create();let name='daybook.pdf';
    if(kind==='merge'){
      if(files.length<2){say('tool','Choose two or more PDF files to merge.');return}
      for(const f of files){const src=await P.PDFDocument.load(await f.arrayBuffer());(await out.copyPages(src,src.getPageIndices())).forEach(p=>out.addPage(p))}
      name='merged.pdf';
    }else if(kind==='split'){
      const src=await P.PDFDocument.load(await files[0].arrayBuffer()),n=src.getPageCount(),idx=pageList(document.getElementById('t_pages').value,n);
      if(!idx){say('tool','This PDF has '+n+' pages. Write pages like 1-3, 5.');return}
      (await out.copyPages(src,idx)).forEach(p=>out.addPage(p));name=files[0].name.replace(/\.pdf$/i,'')+'-pages.pdf';
    }else{
      for(const f of files){
        const e=ext(f.name),buf=await f.arrayBuffer(),img=e==='png'?await out.embedPng(buf):(e==='jpg'||e==='jpeg')?await out.embedJpg(buf):null;
        if(!img){say('tool',f.name+' is not a JPG or PNG image.');return}
        const pg=out.addPage([595,842]),k=Math.min(547/img.width,794/img.height,1),w=img.width*k,h=img.height*k;
        pg.drawImage(img,{x:(595-w)/2,y:(842-h)/2,width:w,height:h});
      }
      name='images.pdf';
    }
    const bytes=await out.save();
    toolOut={name:name,blob:new Blob([bytes],{type:'application/pdf'}),pages:out.getPageCount()};
    say('tool','Ready: '+name+', '+toolOut.pages+' page'+(toolOut.pages===1?'':'s')+', '+fsz(bytes.length)+'.');
  }catch(e){say('tool',e&&e.message==='offline'?'The PDF engine could not load. Check your internet and try again.':'That file could not be read. It may be password protected or damaged.')}
}
EXT.tools=()=>`<div class="card"><h2>PDF tools</h2><p class="muted">Everything runs on your phone. Your files are not sent anywhere.</p>
  <div class="tool"><h3>Merge PDFs</h3><input type="file" id="t_merge" accept="application/pdf" multiple aria-label="PDF files to merge"><button class="btn sm" data-a="tool" data-k="merge" style="align-self:flex-start">Merge into one</button></div>
  <div class="tool"><h3>Split a PDF</h3><input type="file" id="t_split" accept="application/pdf" aria-label="PDF to split"><label>Pages to keep<input id="t_pages" placeholder="1-3, 5" inputmode="text"></label><button class="btn sm" data-a="tool" data-k="split" style="align-self:flex-start">Extract pages</button></div>
  <div class="tool"><h3>Photos to PDF</h3><input type="file" id="t_img" accept="image/jpeg,image/png" multiple aria-label="Images to turn into a PDF"><button class="btn sm" data-a="tool" data-k="img" style="align-self:flex-start">Make PDF</button></div>
  ${said('tool')}${toolOut?`<div class="row wrap"><button class="btn pri" data-a="toolSave">Save to phone</button><button class="btn" data-a="toolKeep">Keep in Files</button></div>`:''}</div>
  <div class="card"><h3>Word or PowerPoint to PDF</h3><p class="muted">A phone browser cannot convert these files reliably, so this app does not pretend to. Use “Save as PDF” in Word, Docs or PowerPoint.</p></div>
  <div class="card"><h3>Word counter</h3><textarea id="wc" data-c="wc" placeholder="Paste your assignment text" aria-label="Text to count"></textarea><p class="muted" id="wcout">0 words · 0 characters</p></div>`;

/* ---------- MORE: reminders, mail, history, storage ---------- */
const flag=(k,label)=>`<div class="item">${chk(+S.settings[k],'flag',`data-id="${k}"`,label)}<span class="t grow">${label}</span></div>`;
EXT.reminders=()=>{
  const t=today(),ag=agenda(t),n=nowMin(),s=S.settings;
  let o=`<div class="card c-sun"><h2>Alerts</h2><p class="muted">An alert pops up with a sound at the right time while this app is open on your screen. A web app cannot wake a closed phone, so for must-not-miss times also set a phone alarm.</p><div class="row wrap"><button class="btn sm" data-a="remTest">Test alert</button><button class="btn sm" data-a="nAsk">Try phone notifications</button></div>${said('notif')}</div>`;
  o+=`<div class="card">${head('Today',`<span class="pill">${ag.filter(x=>toMin(x.t)>=n).length} left</span>`)}${ag.length?'<div class="list">'+ag.map(x=>`<div class="item${toMin(x.t)<n?' past':''}"><span class="pill">${tfmt(x.t)}</span><span class="t grow">${esc(x.title)}</span><span class="muted">${x.src}</span></div>`).join('')+'</div>':'<p class="muted">Nothing timed today.</p>'}</div>`;
  o+=`<div class="card">${head('My reminders',addBtn('remAdd','Reminder'))}${S.reminders.length?'<div class="list">'+S.reminders.map(r=>`<div class="item">${chk(r.on!==0,'remTog',`data-id="${r.id}"`,'On')}<button class="tap" data-a="remEdit" data-id="${r.id}"><span class="t">${esc(r.title)}</span><span class="muted">${tfmt(r.time)} · ${esc(r.repeat)}${r.repeat==='Once'&&r.date?' · '+fmt(r.date):''}${r.repeat==='Every week'?' · '+DAYSL[+r.day||0]:''}</span></button></div>`).join('')+'</div>':'<p class="muted">Call home, take vitamins, submit attendance. Anything with a time.</p>'}</div>`;
  o+=`<div class="card"><h2>Automatic alerts</h2><div class="list">${flag('nPrayer','Prayer times')}${flag('nMeds','Medicine doses when I am sick')}${flag('nClass','10 minutes before each class')}${flag('nSleep','30 minutes before bedtime')}</div><p class="muted">Water nudges</p><div class="chips">${[[0,'Off'],[60,'Every hour'],[90,'Every 90 min'],[120,'Every 2 hours']].map(x=>`<button class="chip${+s.nWater===x[0]?' on':''}" data-a="nWater" data-n="${x[0]}">${x[1]}</button>`).join('')}</div></div>`;
  return o;
};
const gm=o=>'https://mail.google.com/mail/?view=cm&fs=1'+Object.keys(o).map(k=>'&'+k+'='+encodeURIComponent(o[k])).join('');
const TPL=[
 ['Leave application','Application for leave of absence','Dear Sir/Madam,\n\nI am [Name], a student of your course. I was unable to attend class on [date] because [reason]. I request you to kindly consider my absence.\n\nSincerely,\n[Name]'],
 ['Assignment submission','Submission of assignment','Dear Sir/Madam,\n\nPlease find my assignment attached for [course]. Kindly let me know if anything is missing.\n\nRegards,\n[Name]'],
 ['Ask for an appointment','Request for an appointment','Dear Sir/Madam,\n\nI would like to meet you to discuss [topic]. Could you please let me know a suitable time during your office hours?\n\nThank you,\n[Name]'],
 ['Ask for an extension','Request for deadline extension','Dear Sir/Madam,\n\nI am writing to request a short extension for [assignment], due on [date], because [reason]. I can submit it by [new date].\n\nThank you for considering this.\n[Name]']
];
EXT.mail=()=>{
  const s=S.settings,nm=s.name||'[Name]';
  let o=`<div class="card c-pink"><div class="row between"><h2>Mail</h2><button class="btn sm" data-a="setMail">${s.email?'Change':'Add my email'}</button></div><p>${s.email?esc(s.email):'No email linked yet.'}</p><div class="row wrap"><a class="btn sm" href="https://mail.google.com/mail/u/${s.email?'?authuser='+encodeURIComponent(s.email):''}" target="_blank" rel="noopener">Open inbox</a><a class="btn sm" href="${gm({})}" target="_blank" rel="noopener">Write a mail</a></div><p class="muted">These open Gmail. Reading your inbox inside this app needs Gmail connected to your account first.</p></div>`;
  o+=`<div class="card">${head('People I mail',addBtn('ctAdd','Contact'))}${S.contacts.length?'<div class="list">'+S.contacts.map(c=>`<div class="item linkrow"><div class="grow"><a href="${gm({to:c.email})}" target="_blank" rel="noopener">${esc(c.name)}</a><small>${esc([c.role,c.email].filter(Boolean).join(' · '))}</small></div><button class="btn sm" data-a="ctEdit" data-id="${c.id}" aria-label="Edit contact">${ic('edit')}</button></div>`).join('')+'</div>':'<p class="muted">Teachers, supervisor, department office, group members. One tap opens a mail to them.</p>'}</div>`;
  o+=`<div class="card"><h2>Ready-made mails</h2><p class="muted">Opens a draft with the subject and text filled in.</p><div class="list">${TPL.map(x=>`<div class="item linkrow"><div class="grow"><a href="${gm({su:x[1],body:x[2].replace(/\[Name\]/g,nm)})}" target="_blank" rel="noopener">${x[0]}</a><small>${x[1]}</small></div>${ic('next')}</div>`).join('')}</div></div>`;
  return o;
};
EXT.history=()=>{
  const ds=ui.histDay,p=dayParts(ds),d14=[];for(let i=13;i>=0;i--)d14.push(addDays(today(),-i));
  const rows=[['Prayers',p.pr+' of 5'],['Water',p.water+' of '+S.settings.waterGoal+' glasses'],['Habits',S.habits.length?p.hab+' of '+S.habits.length:''],['Tasks finished',p.done.map(t=>t.title).join(', ')],['Study time',p.focus?dur(p.focus):''],['Quran',p.quran?p.quran+' ayahs':''],['Sleep',p.sleep?dur(sleepMin(p.sleep))+' ('+tfmt(p.sleep.bed)+' to '+tfmt(p.sleep.wake)+')':''],['Meals',p.meals.map(m=>m.meal+': '+m.text).join(', ')],['Spent',p.spent?money(p.spent):''],['Activities',p.acts.map(a=>a.text).join(', ')],['Medicine doses taken',p.meds||'']].filter(r=>r[1]!=='');
  return`<div class="card"><h2>Last 14 days</h2><p class="muted">Your daily score. Tap a day to open it.</p><div class="bars" style="gap:4px">${d14.map(x=>{const v=dayScore(x);return`<div><i class="c-${x===ds?'tomato':'leaf'}" data-a="histPick" data-d="${x}" style="height:${Math.max(4,v*.75)}%;cursor:pointer" role="button" aria-label="${fmt(x)}: ${v}%"></i><span>${parse(x).getDate()}</span></div>`}).join('')}</div></div>
    <div class="card">${dayNav('histDay',ds)}<div class="row"><div class="ring" style="--p:${dayScore(ds)}"><span>${dayScore(ds)}%</span></div><p class="muted grow">Everything you recorded on this day, from every part of the app.</p></div><div class="list">${rows.map(r=>`<div class="item"><span class="muted" style="flex:none;width:112px">${r[0]}</span><span class="t grow">${esc(r[1])}</span></div>`).join('')}</div></div>`;
};
EXT.settings=()=>{
  const c=[['Tasks',S.tasks.length],['Notes',S.notes.length],['Files',S.files.length],['Courses',S.courses.length],['Money entries',S.money.length],['Days of prayer log',Object.keys(S.prayers).length],['Sleep logs',S.sleep.length],['Health records',S.sick.length]];
  return`<div class="card"><h2>Memory</h2><p class="muted">${cloud==='on'?'Every change is saved to your account within a second and comes back whenever you open the app, on any phone. A copy also stays on this phone for quick opening.':'Cloud saving is not reachable right now, so changes are kept on this phone and sent up when the connection returns.'} Nothing is deleted unless you delete it. Past days stay in History.</p><div class="g3">${c.map(x=>stat(x[1],x[0])).join('')}</div><button class="btn sm" data-a="bFile" style="align-self:flex-start">Download backup file</button>${said('backup')}</div>`;
};

/* ---------- actions ---------- */
const epNow=()=>activeEp()||fixEp(S.sick.find(e=>e.id===ui.ep));
const medFields=()=>[['name','Medicine','text',{req:true,ph:'Napa 500'}],['dose','Dose','text',{ph:'1 tablet, 2 spoons'}],['when','When','select',{opts:Object.keys(WHEN)}],['custom','Custom times','text',{ph:'09:00, 15:00, 22:00'}],['meal','With food','select',{opts:['After food','Before food','Any time']}],['days','For how many days','number'],['start','Starting','date',R]];
const medVal=v=>{v.times=WHEN[v.when]||(String(v.custom).match(/\d{1,2}:\d{2}/g)||[]).map(x=>hm(toMin(x)));if(!v.times.length)v.times=['08:00'];return v};
const remFields=()=>[['title','Remind me to','text',R],['time','Time','time',R],['repeat','Repeat','select',{opts:['Every day','Sun to Thu','Every week','Once']}],['day','Day (for every week)','select',{opts:WEEK.map(w=>[w,DAYSL[w]])}],['date','Date (for once)','date']];
const mealFields=[['text','What did you eat?','text',R],['meal','Meal','select',{opts:SLOT}],['tag','Where from','select',{opts:FTAG}],['cost','Cost','number'],['date','Date','date',R]];
const slFields=[['date','Morning of','date',R],['bed','Went to bed','time',R],['wake','Woke up','time',R],['q','How was it?','select',{opts:['Good','Okay','Poor']}]];
const debtFields=[['person','Person','text',R],['amount','Amount','number',R],['dir','Which way','select',{opts:['I lent','I borrowed']}],['date','Date','date'],['note','Note','text']];
const _tab=A.tab,_sub=A.sub,_go=A.go;
Object.assign(A,{
  tab(d){document.body.classList.remove('dopen');_tab(d)},
  go(d){if(d.k==='study'){ui.course=null;ui.proj=null}if(d.k==='life')ui.ep=null;ui[d.k]=d.v;A.tab(d)},
  sub(d){if(d.k==='life')ui.ep=null;_sub(d)},
  drawer(){document.body.classList.add('dopen');drawDrawer()},
  drawerClose(){document.body.classList.remove('dopen')},
  toastOk(d,el){const t=el.closest('.toast');if(t)t.remove()},
  tTog(d){const t=S.tasks.find(x=>x.id===d.id);t.done=!t.done;t.doneAt=t.done?today():'';save('tasks');render()},
  hAdd(){form('New habit',[['name','Habit','text',{req:true,ph:'Sleep by 12, exercise, no phone in class'}],['kind','Type','select',{opts:['Build','Quit']}],['goal','Days per week','number']],{kind:'Build',goal:7},v=>upsert('habits',null,v))},
  hEdit(d){const h=S.habits.find(x=>x.id===d.id);form('Edit habit',[['name','Habit','text',R],['kind','Type','select',{opts:['Build','Quit']}],['goal','Days per week','number']],Object.assign({kind:'Build',goal:7},h),v=>upsert('habits',h.id,v),()=>remove('habits',h.id))},
  // deen
  prTog(d){const l=S.prayers[d.d]=S.prayers[d.d]||{};if(l[d.id])delete l[d.id];else l[d.id]=1;save('prayers');render()},
  qaza(d){S.settings.qaza=Math.max(0,(+S.settings.qaza||0)+(+d.n));save('settings');render()},
  fastTog(){const t=today();if(S.fasts[t])delete S.fasts[t];else S.fasts[t]=1;save('fasts');render()},
  setDeen(){form('Prayer settings',[['city','City','select',{opts:Object.keys(CITY).concat('Custom')}],['asr','Asr time','select',{opts:['Hanafi','Shafi']}],['lat','Latitude (custom only)','number'],['lng','Longitude (custom only)','number']],S.settings,v=>{if(CITY[v.city]){v.lat=CITY[v.city][0];v.lng=CITY[v.city][1]}Object.assign(S.settings,v);save('settings')})},
  qDone(d){const q=QN();if(q.done[d.id])delete q.done[d.id];else q.done[d.id]=1;save('quran');render()},
  qLog(d){const q=QN(),t=today();q.log[t]=Math.max(0,(q.log[t]||0)+(+d.n));save('quran');render()},
  qGoal(){form('Daily Quran goal',[['qgoal','Ayahs per day','number',R]],S.settings,v=>{S.settings.qgoal=Math.max(1,Math.round(v.qgoal));save('settings')})},
  qMark(){const q=QN();form('Bookmark',[['s','Surah','select',{opts:SUR.map((x,i)=>[i+1,(i+1)+'. '+x[0]])}],['a','Ayah','number',R]],q.mark||{s:1,a:1},v=>{const s=+v.s;q.mark={s:s,a:Math.min(SUR[s-1][1],Math.max(1,Math.round(v.a)))};save('quran')})},
  duaInc(d){const l=S.dhikr[today()]=S.dhikr[today()]||{};l[d.id]=Math.min(+d.n,(l[d.id]||0)+1);save('dhikr');render()},
  duaDone(d){const l=S.dhikr[today()]=S.dhikr[today()]||{};l[d.id]=(l[d.id]||0)>=+d.n?0:+d.n;save('dhikr');render()},
  duaF:[['title','Name of the dua','text',R],['text','Arabic or Bangla text','textarea'],['meaning','Meaning','text'],['when','When to recite','text'],['n','Times per day','number']],
  duaAdd(){form('New dua',A.duaF,{n:1},v=>upsert('duas',null,v))},
  duaEdit(d){const x=S.duas.find(k=>k.id===d.id);form('Edit dua',A.duaF,x,v=>upsert('duas',x.id,v),()=>remove('duas',x.id))},
  tzTap(){const z=ui.tz,t=today(),l=S.dhikr[t]=S.dhikr[t]||{};z.n++;l.tasbih=(l.tasbih||0)+1;if(z.n===z.target)beep();save('dhikr');const a=$('#tzn'),b=$('#tzs');if(a)a.textContent=z.n;if(b)b.textContent=TZP[z.ph]+' · target '+z.target+(z.n>=z.target?' reached':'')+' · '+l.tasbih+' counted today'},
  tzPh(d){ui.tz.ph=+d.n;ui.tz.n=0;render()},tzTarget(d){ui.tz.target=+d.n;render()},tzReset(){ui.tz.n=0;render()},
  // food
  foodDay(d){ui.foodDay=addDays(ui.foodDay,+d.n);render()},
  mealAdd(d){form('Log a meal',mealFields,{meal:d.meal,date:ui.foodDay,tag:'Homemade'},v=>{upsert('meals',null,v);if(v.cost>0){S.money.push({id:uid(),date:v.date,amount:v.cost,type:'out',cat:'Food',note:v.text});save('money')}})},
  mealEdit(d){const m=S.meals.find(x=>x.id===d.id);form('Edit meal',mealFields,m,v=>upsert('meals',m.id,v),()=>remove('meals',m.id))},
  // sleep
  setSleep(){form('Sleep schedule',[['sleepBed','Bedtime','time',R],['sleepWake','Wake-up time','time',R]],S.settings,v=>{Object.assign(S.settings,v);save('settings')})},
  bedNow(){S.settings.sleepStart=Date.now();save('settings');render()},
  wakeNow(){const b=new Date(S.settings.sleepStart),n=new Date();S.sleep=S.sleep.filter(l=>l.date!==today());S.sleep.push({id:uid(),date:today(),bed:pad(b.getHours())+':'+pad(b.getMinutes()),wake:pad(n.getHours())+':'+pad(n.getMinutes()),q:''});S.settings.sleepStart=0;save('sleep','settings');render()},
  slAdd(){form('Log sleep',slFields,{date:today(),bed:S.settings.sleepBed,wake:S.settings.sleepWake,q:'Good'},v=>{S.sleep=S.sleep.filter(l=>l.date!==v.date);upsert('sleep',null,v)})},
  slEdit(d){const l=S.sleep.find(x=>x.id===d.id);form('Edit sleep',slFields,l,v=>upsert('sleep',l.id,v),()=>remove('sleep',l.id))},
  // health
  sickStart(){form('I am sick',[['name','What is wrong?','text',{req:true,ph:'Fever, cold, stomach'}],['doctor','Doctor','text'],['start','Since','date',R],['notes','Notes','textarea',{ph:'Advice from the doctor, tests, next visit'}]],{start:today()},v=>{S.sick.push(Object.assign({id:uid(),active:true,meds:[],taken:{},log:[],photos:[]},v));save('sick')})},
  sickEnd(){const e=activeEp();form('Glad you are better',[['end','Recovered on','date',R]],{end:today()},v=>{e.active=false;e.end=v.end;save('sick')})},
  epEdit(d){const e=S.sick.find(x=>x.id===d.id);form('Edit record',[['name','Illness','text',R],['doctor','Doctor','text'],['start','Since','date',R],['notes','Notes','textarea']],e,v=>{Object.assign(e,v);save('sick')},()=>{remove('sick',e.id);ui.ep=null})},
  epOpen(d){ui.ep=d.id;render();window.scrollTo(0,0)},epBack(){ui.ep=null;render()},
  medAdd(){const e=epNow();form('Add medicine',medFields(),{when:'Morning and night',meal:'After food',start:today(),days:5},v=>{e.meds.push(Object.assign({id:uid()},medVal(v)));save('sick')})},
  medEdit(d){const e=epNow(),m=e.meds.find(x=>x.id===d.id);form('Edit medicine',medFields(),Object.assign({},m,m.when==='Custom times'||!m.when?{custom:(m.times||[]).join(', ')}:{}),v=>{Object.assign(m,medVal(v));save('sick')},()=>{e.meds=e.meds.filter(x=>x.id!==m.id);save('sick')})},
  doseTog(d){const e=activeEp();if(!e)return;const l=e.taken[d.d]=e.taken[d.d]||{};if(l[d.id])delete l[d.id];else l[d.id]=1;save('sick');render()},
  symAdd(){const e=epNow(),n=new Date();form('Log how you feel',[['text','Symptoms','text',{ph:'Headache, cough, weak'}],['temp','Temperature in °F','number'],['date','Date','date',R],['time','Time','time',R]],{date:today(),time:pad(n.getHours())+':'+pad(n.getMinutes())},v=>{if(!v.temp)delete v.temp;if(v.text||v.temp){e.log.push(Object.assign({id:uid()},v));save('sick')}})},
  // money
  goalF:[['name','Saving for','text',R],['target','Target amount','number',R],['saved','Saved so far','number']],
  goalAdd(){form('New savings goal',A.goalF,{},v=>upsert('goals',null,v))},
  goalEdit(d){const g=S.goals.find(x=>x.id===d.id);form('Edit goal',A.goalF,g,v=>upsert('goals',g.id,v),()=>remove('goals',g.id))},
  goalPut(d){const g=S.goals.find(x=>x.id===d.id);form('Add to '+esc(g.name),[['amt','Amount to add','number',R]],{},v=>{g.saved=(+g.saved||0)+v.amt;save('goals')})},
  debtAdd(){form('Lent or borrowed',debtFields,{dir:'I lent',date:today()},v=>upsert('debts',null,v))},
  debtEdit(d){const x=S.debts.find(k=>k.id===d.id);form('Edit',debtFields,x,v=>upsert('debts',x.id,v),()=>remove('debts',x.id))},
  debtTog(d){const x=S.debts.find(k=>k.id===d.id);x.settled=!x.settled;save('debts');render()},
  // files + tools
  fEdit(d){const f=S.files.find(x=>x.id===d.id);form('File',[['name','Name','text',R],['courseId','Course','select',{opts:courseOpts()}]],f,v=>{if(ext(v.name)!==ext(f.name))v.name+='.'+ext(f.name);upsert('files',f.id,v)},()=>{remove('files',f.id);if(AS)AS.delete(f.asset).catch(()=>{})})},
  async fSave(d){const f=S.files.find(x=>x.id===d.id);if(!DL){say('files','Saving to the phone is not available here. Tap the file name to open it.');return}try{const b=await(await fetch('/_blob/'+f.asset)).blob();await DL.save({filename:f.name,data:b});say('files','Saved '+f.name+'.')}catch(e){say('files',e&&e.code==='declined'?'Cancelled.':'Could not save that file.')}},
  tool(d){runTool(d.k)},
  async toolSave(){if(!toolOut)return;if(!DL){say('tool','Saving to the phone is not available here. Use Keep in Files.');return}try{await DL.save({filename:toolOut.name,data:toolOut.blob});say('tool','Saved '+toolOut.name+'.')}catch(e){say('tool',e&&e.code==='declined'?'Cancelled.':'Could not save the file.')}},
  toolKeep(){if(!toolOut)return;const o=toolOut;putFiles([new File([o.blob],o.name,{type:'application/pdf'})],'tool',(r,f)=>{S.files.push({id:uid(),courseId:'',name:f.name,type:'application/pdf',size:r.sizeBytes,asset:r.id,local:r.local||'',added:today()});save('files')})},
  // reminders
  remAdd(){form('New reminder',remFields(),{repeat:'Every day',day:new Date().getDay(),date:today()},v=>upsert('reminders',null,v,{on:1}))},
  remEdit(d){const r=S.reminders.find(x=>x.id===d.id);form('Edit reminder',remFields(),r,v=>upsert('reminders',r.id,v),()=>remove('reminders',r.id))},
  remTog(d){const r=S.reminders.find(x=>x.id===d.id);r.on=r.on===0?1:0;save('reminders');render()},
  remTest(){toast({title:'This is how an alert looks',src:'Test',t:hm(nowMin())})},
  flag(d){S.settings[d.id]=+S.settings[d.id]?0:1;save('settings');render()},
  nWater(d){S.settings.nWater=+d.n;save('settings');render()},
  nAsk(){const no='Phone notifications are blocked for this kind of web app. Alerts will show while the app is open.';try{if(!window.Notification){say('notif',no);return}Notification.requestPermission().then(p=>say('notif',p==='granted'?'Allowed. You will also get a notification while this page stays open in the background.':no),()=>say('notif',no))}catch(e){say('notif',no)}},
  // mail + history + backup
  setMail(){form('My email',[['email','Email address','text',{ph:'you@gmail.com'}]],S.settings,v=>{S.settings.email=v.email;save('settings')})},
  ctF:[['name','Name','text',R],['email','Email','text',R],['role','Who is this?','text',{ph:'Course teacher, supervisor, office'}]],
  ctAdd(){form('New contact',A.ctF,{},v=>upsert('contacts',null,v))},
  ctEdit(d){const c=S.contacts.find(x=>x.id===d.id);form('Edit contact',A.ctF,c,v=>upsert('contacts',c.id,v),()=>remove('contacts',c.id))},
  histDay(d){const n=addDays(ui.histDay,+d.n);if(n<=today())ui.histDay=n;render()},
  histPick(d){ui.histDay=d.d;render()},
  async bFile(){if(!DL){say('backup','Downloading is not available here. Use Copy backup below.');return}try{await DL.save({filename:'daybook-backup-'+today()+'.json',data:JSON.stringify(S)});say('backup','Backup saved.')}catch(e){say('backup',e&&e.code==='declined'?'Cancelled.':'Could not save the backup.')}}
});
document.addEventListener('change',e=>{
  const t=e.target;
  if(t.id==='fup'&&t.files.length){const sel=document.getElementById('fcourse'),cid=t.dataset.course||(sel?sel.value:'');putFiles([...t.files],'files',(r,f)=>{S.files.push({id:uid(),courseId:cid,name:f.name,type:r.contentType,size:r.sizeBytes,asset:r.id,local:r.local||'',added:today()});save('files')})}
  if(t.id==='rxup'&&t.files.length){const ep=epNow();if(ep)putFiles([...t.files],'rx',r=>{ep.photos.push(r.id||('local:'+r.local));save('sick')})}
});
document.addEventListener('input',e=>{if(e.target.dataset.c==='wc'){const v=e.target.value,w=(v.trim().match(/\S+/g)||[]).length,o=$('#wcout');if(o)o.textContent=w+' words · '+v.length+' characters · about '+Math.max(1,Math.round(w/200))+' min to read'}});

/* ---------- menu, top bar, motion ---------- */
const MENU=[
 ['My day',[['today','','','Today','sun'],['more','more','reminders','Reminders','pink',()=>{const n=nowMin(),c=agenda(today()).filter(x=>toMin(x.t)>=n).length;return c?c+' left':''}],['more','more','history','History','pink']]],
 ['Plan',[['plan','plan','tasks','Tasks','tomato',()=>{const c=S.tasks.filter(x=>!x.done&&x.due&&x.due<=today()).length;return c?c+' due':''}],['plan','plan','cal','Calendar','tomato'],['plan','plan','routine','Class routine','tomato']]],
 ['Study',[['study','study','courses','Courses','grape',()=>S.courses.length||''],['study','study','files','Files','grape',()=>S.files.length||''],['study','study','exams','Exams','grape',()=>{const e=S.exams.filter(x=>x.date>=today()).sort((a,b)=>a.date<b.date?-1:1)[0];return e?diffDays(e.date,today())+' d':''}],['study','study','timer','Focus timer','grape'],['study','study','cgpa','CGPA','grape'],['study','study','research','Research','grape'],['study','study','tools','PDF tools','grape']]],
 ['Deen',[['deen','deen','prayer','Prayer','leaf',()=>{const p=nextPrayer();return p.name+' '+tfmt(p.t)}],['deen','deen','quran','Quran','leaf'],['deen','deen','duas','Daily duas','leaf'],['deen','deen','tasbih','Tasbih','leaf'],['deen','deen','hadith','Hadith','leaf']]],
 ['Life',[['life','life','water','Water','sky',()=>(S.water[today()]||0)+'/'+S.settings.waterGoal],['life','life','food','Food','sky'],['life','life','habits','Habits','sky'],['life','life','sleep','Sleep','sky'],['life','life','health','Health','sky',()=>activeEp()?'Sick':''],['life','life','acts','Activities','sky'],['life','life','money','Money','sky']]],
 ['Keep',[['more','more','links','Links','pink'],['more','more','notes','Notes','pink'],['more','more','mail','Mail','pink'],['more','more','settings','Settings and backup','pink']]]
];
function drawDrawer(){
  const el=$('#drawer');if(!el)return;const s=S.settings;let i=0;
  el.innerHTML=`<div class="dhead">${avatar()}<div><b>${esc(s.name||'Catalyst')}</b><span>${fmt(today())}</span></div></div>`+
    MENU.filter(g=>!(s.deenOff&&g[0]==='Deen')).map(g=>`<div class="dgroup"><h4>${g[0]}</h4>${g[1].map(x=>{const on=ui.tab===x[0]&&(!x[1]||ui[x[1]]===x[2]),b=x[5]?x[5]():'';return`<button class="ditem${on?' on':''}" style="animation-delay:${Math.min(i++,14)*22}ms" data-a="${x[1]?'go':'tab'}" data-tab="${x[0]}" data-k="${x[1]}" data-v="${x[2]}"><i class="c-${x[4]}"></i>${x[3]}${b!==''?`<span class="pill">${esc(b)}</span>`:''}</button>`}).join('')}</div>`).join('')+
    `<p class="credit">${CREDIT}</p>`;
}
const TABL={today:'Today',plan:'Plan',study:'Study',deen:'Deen',life:'Life',more:'More'};
let lastKey='',tk=0;
function tickerItems(){
  const s=S.settings,t=today(),np=nextPrayer(),n=nowMin(),a=[fmt(t)];if(!s.deenOff)a.push(np.name+' at '+tfmt(np.t)+' · in '+dur(np.mins));
  const nx=agenda(t).find(x=>toMin(x.t)>=n&&x.src!=='Prayer');if(nx)a.push('Next: '+nx.title+' · '+tfmt(nx.t));
  const due=S.tasks.filter(x=>!x.done&&x.due&&x.due<=t).length;if(due)a.push(due+' task'+(due>1?'s':'')+' due now');
  a.push('Water '+(S.water[t]||0)+' of '+s.waterGoal+' glasses');
  const ep=activeEp();if(ep){const l=doses(ep,t).filter(x=>!x.taken).length;if(l)a.push(l+' medicine dose'+(l>1?'s':'')+' left today')}
  return a;
}
function ticker(step){
  const el=$('#bsub');if(!el)return;const a=tickerItems();if(step)tk++;
  el.textContent=a[tk%a.length];
  if(step){el.classList.remove('flip');void el.offsetWidth;el.classList.add('flip')}
}
setInterval(()=>ticker(true),4500);
window.afterRender=function(){
  document.body.dataset.tab=ui.tab;
  const sl=(SUB[ui.tab]||[]).find(x=>x[0]===ui[ui.tab]),bt=$('#btitle'),v=$('#view');
  if(bt)bt.textContent=ui.tab==='today'?'Catalyst':TABL[ui.tab]+(sl?' · '+sl[1]:'');
  const key=ui.tab+'/'+(ui[ui.tab]||'')+'/'+(ui.course||ui.proj||ui.ep||'');
  if(v&&key!==lastKey){v.classList.remove('enter');void v.offsetWidth;v.classList.add('enter');lastKey=key}else if(v)v.classList.remove('enter');
  if(document.body.classList.contains('dopen'))drawDrawer();
  ticker(false);
};
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.body.classList.remove('dopen')});

/* ================= v3: illustrated home, first-run setup, NSU CGPA, Bangla duas, hadith, phone files, smart add ================= */
Object.assign(DEF_SET,{dob:'',setup:0,cgBase:0,cgCred:0,cgTarget:0,cgRemain:0,retake:'Latest grade',dl:'bn',fstore:'cloud'});
normalize();
delete EXT.todayTop;
SUB.deen.push(['hadith','Hadith']);
const ILL={
 mosque:'<path d="M8 40V26h32v14z" fill="var(--card)"/><path d="M14 26c0-8 10-9 10-15 0 6 10 7 10 15z" fill="var(--leaf)"/><path d="M24 7v4M20 40v-6a4 4 0 0 1 8 0v6" fill="var(--sun)"/><path d="M38 40V17l3-5 3 5v23z" fill="var(--sun)"/>',
 drop:'<path d="M24 6c8 10 12 16 12 22a12 12 0 0 1-24 0c0-6 4-12 12-22z" fill="var(--sky)"/><path d="M18 29a6 6 0 0 0 5 6"/>',
 wallet:'<rect x="6" y="13" width="36" height="25" rx="5" fill="var(--leaf)"/><path d="M6 20h36"/><circle cx="33" cy="29" r="3.5" fill="var(--sun)"/>',
 tasks:'<rect x="9" y="6" width="30" height="37" rx="5" fill="var(--tomato)"/><path d="m15 18 3 3 5-6M15 31l3 3 5-6M28 19h6M28 32h6"/>',
 book:'<path d="M6 12c6-3 12-3 18 1v26c-6-4-12-4-18-1z" fill="var(--grape)"/><path d="M42 12c-6-3-12-3-18 1v26c6-4 12-4 18-1z" fill="var(--pink)"/>',
 moon:'<path d="M38 28A15 15 0 1 1 20 10a12 12 0 0 0 18 18z" fill="var(--sun)"/><path d="M30 8h8l-8 8h8"/>',
 sprout:'<path d="M24 43V24"/><path d="M24 27c0-8-6-12-15-12 0 8 5 12 15 12z" fill="var(--leaf)"/><path d="M24 22c0-7 5-11 14-11 0 7-4 11-14 11z" fill="var(--sun)"/>',
 timer:'<circle cx="24" cy="28" r="14" fill="var(--pink)"/><path d="M24 28v-8M20 6h8M24 6v8"/>',
 exam:'<rect x="7" y="10" width="34" height="31" rx="5" fill="var(--sun)"/><path d="M7 19h34M16 6v8M32 6v8M18 30l4 4 8-8"/>',
 pill:'<g transform="rotate(-35 24 24)"><rect x="5" y="16" width="38" height="16" rx="8" fill="var(--tomato)"/><path d="M24 16v16"/></g>',
 quran:'<path d="M8 10h14c2 0 2 2 2 2s0-2 2-2h14v28H26c-2 0-2 2-2 2s0-2-2-2H8z" fill="var(--leaf)"/><path d="M24 12v28M13 18h6M13 24h6M29 18h6M29 24h6"/>',
 mail:'<rect x="6" y="11" width="36" height="26" rx="5" fill="var(--pink)"/><path d="m8 15 16 12 16-12"/>'
};
const ill=n=>`<svg class="ill" viewBox="0 0 48 48" aria-hidden="true">${ILL[n]}</svg>`;
const bday=()=>{const d=S.settings.dob;if(!/^\d{4}-\d{2}-\d{2}$/.test(d||''))return null;const t=today(),y=+t.slice(0,4);let nx=y+d.slice(4);if(nx<t)nx=(y+1)+d.slice(4);return diffDays(nx,t)};

/* ---------- home ---------- */
function skyHero(){
  const t=today(),pt=ptimes(t),n=nowMin(),fj=toMin(pt.fajr),sr=toMin(pt.sunrise),mg=toMin(pt.maghrib),is=toMin(pt.isha),s=S.settings,h=new Date().getHours();
  const ph=n<fj||n>=is?'night':n<sr?'dawn':n<mg-45?'day':'dusk',G={night:['#10143F','#2C2F7A'],dawn:['#6F62D0','#FFB48A'],day:['#4DB4FF','#D4F0FF'],dusk:['#5546BD','#FF9A62']}[ph];
  const up=n>=sr&&n<mg,fr=up?(n-sr)/(mg-sr):((n-mg+1440)%1440)/(sr+1440-mg),x=28+304*fr,y=110-78*Math.sin(Math.PI*fr);
  let arc='';for(let i=0;i<=24;i++)arc+=(i?'L':'M')+(28+304*i/24).toFixed(1)+' '+(110-78*Math.sin(Math.PI*i/24)).toFixed(1);
  const dark=ph!=='day',bd=bday(),np=nextPrayer(),K='stroke="#3B2F80" stroke-width="2" stroke-linejoin="round"';
  const stars=ph==='night'||ph==='dusk'?[[150,18],[205,40],[250,14],[322,52],[120,58],[285,70],[60,74]].map((p,i)=>`<circle class="star" style="animation-delay:${i*.35}s" cx="${p[0]}" cy="${p[1]}" r="1.8" fill="#fff"/>`).join(''):'';
  const clouds=ph==='day'||ph==='dawn'?`<g class="cloud" fill="#fff" opacity=".9"><ellipse cx="208" cy="62" rx="20" ry="8"/><ellipse cx="222" cy="56" rx="13" ry="8"/><ellipse cx="300" cy="80" rx="15" ry="6"/></g>`:'';
  const orb=up?`<g class="orb"><circle cx="${x}" cy="${y}" r="20" fill="#FFD23F" opacity=".35"/><circle cx="${x}" cy="${y}" r="13" fill="#FFD23F" ${K}/></g>`:`<g class="orb"><circle cx="${x}" cy="${y}" r="12" fill="#FFF3C4" ${K}/><circle cx="${x-4}" cy="${y-3}" r="2.2" fill="#E3D49A"/><circle cx="${x+4}" cy="${y+4}" r="1.6" fill="#E3D49A"/></g>`;
  const conf=bd===0?['#FF6B5E','#FFC83A','#3DCB82','#FF8CC3','#fff'].map((c,i)=>`<circle class="star" style="animation-delay:${i*.2}s" cx="${40+i*66}" cy="${30+(i%2)*26}" r="4" fill="${c}"/>`).join(''):'';
  const svg=`<svg viewBox="0 0 360 150" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="skg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${G[0]}"/><stop offset="1" stop-color="${G[1]}"/></linearGradient></defs><rect width="360" height="150" fill="url(#skg)"/>${stars}${clouds}<path d="${arc}" fill="none" stroke="#fff" stroke-opacity=".5" stroke-width="2" stroke-dasharray="2 7" stroke-linecap="round"/>${orb}${conf}
    <path d="M0 150v-26c40-14 84-14 124-4s92 12 132-2 76-8 104 4v28z" fill="${dark?'#1F8A5B':'#3DCB82'}" ${K}/>
    <path d="M249 127h10M249 115h10M249 101h10M249 89h10" stroke="#3B2F80" stroke-width="2" stroke-linecap="round"/><g fill="none" stroke-linecap="round" stroke-width="4"><path d="M246 134c0-13 16-13 16-26s-16-13-16-26" stroke="#A58BFF"/><path d="M262 134c0-13-16-13-16-26s16-13 16-26" stroke="#FFC83A"/></g><g ${K}><path d="M298 78h22M302 78v18l-17 28a5 5 0 0 0 4 8h40a5 5 0 0 0 4-8l-17-28V78z" fill="${dark?'#CFC8F7':'#fff'}"/><path d="M291 112h36l6 12a5 5 0 0 1-4 8h-40a5 5 0 0 1-4-8z" fill="#FF8CC3"/></g><circle class="star" cx="304" cy="121" r="2.4" fill="#fff"/><circle class="star" style="animation-delay:.6s" cx="315" cy="125" r="1.7" fill="#fff"/><circle class="orb" cx="310" cy="68" r="3.2" fill="#FF8CC3" stroke="#1F1A3D" stroke-width="1.5"/></svg>`;
  const hi=bd===0?'Happy birthday':h<5?'Peaceful night':h<12?'Good morning':h<17?'Good afternoon':h<21?'Good evening':'Good night';
  return`<div class="sky ${ph}">${svg}<div class="skytext"><p>${hi}</p><h1>${esc(s.name||'Welcome')}</h1><p>${fmt(t)}${s.deenOff||!hijri()?'':' · '+hijri()}</p>${bd&&bd<=7?`<p>Your birthday is in ${bd} day${bd>1?'s':''}</p>`:''}</div>${s.deenOff?'':`<span class="pill skypill">${np.name} ${tfmt(np.t)} · ${dur(np.mins)}</span>`}${streakPill()}</div>`;
}
const tile=(col,icon,big,label,tab,k,v,extra)=>`<div class="tile t-${col}" role="button" tabindex="0" data-a="go" data-tab="${tab}" data-k="${k}" data-v="${v}">${ill(icon)}<b>${big}</b><span>${esc(label)}</span>${extra||''}</div>`;
const XK=['Quiz','Mid-term','Final','Assignment','Presentation','Lab report','Viva','Other'];
const HAD=[
 ['সকল কাজ নিয়তের উপর নির্ভরশীল, আর প্রত্যেক ব্যক্তি তা-ই পাবে যার সে নিয়ত করেছে।','Actions are judged by intentions, and everyone gets what they intended.','Bukhari 1'],
 ['তোমাদের মধ্যে সর্বোত্তম সেই ব্যক্তি, যে কুরআন শেখে এবং অন্যকে শেখায়।','The best of you are those who learn the Quran and teach it.','Bukhari 5027'],
 ['যে আল্লাহ ও শেষ দিনের প্রতি ঈমান রাখে, সে যেন ভালো কথা বলে অথবা চুপ থাকে।','Whoever believes in Allah and the Last Day should speak good or stay silent.','Bukhari 6018'],
 ['তোমাদের কেউ ততক্ষণ পূর্ণ মুমিন হতে পারবে না, যতক্ষণ না সে তার ভাইয়ের জন্য তা-ই পছন্দ করে যা নিজের জন্য পছন্দ করে।','None of you truly believes until he loves for his brother what he loves for himself.','Bukhari 13'],
 ['প্রকৃত শক্তিশালী সে নয় যে কুস্তিতে অন্যকে হারায়; বরং সে, যে রাগের সময় নিজেকে নিয়ন্ত্রণ করে।','The strong one is not the one who wrestles others down, but the one who controls himself when angry.','Bukhari 6114'],
 ['সহজ করো, কঠিন করো না; সুসংবাদ দাও, বিমুখ করো না।','Make things easy and do not make them hard. Give good news and do not drive people away.','Bukhari 69'],
 ['পবিত্রতা ঈমানের অর্ধেক।','Cleanliness is half of faith.','Muslim 223'],
 ['তোমার ভাইয়ের সামনে তোমার মুচকি হাসি সদকা।','Your smile for your brother is charity.','Tirmidhi 1956'],
 ['আল্লাহর কাছে সবচেয়ে প্রিয় আমল তা-ই, যা নিয়মিত করা হয়, যদিও তা অল্প হয়।','The deeds most loved by Allah are those done regularly, even if they are small.','Bukhari 6464'],
 ['প্রকৃত মুসলিম সে, যার জিহ্বা ও হাত থেকে অন্য মুসলিমরা নিরাপদ থাকে।','A Muslim is one from whose tongue and hand other Muslims are safe.','Bukhari 10'],
 ['যে ব্যক্তি জ্ঞান অর্জনের পথে চলে, আল্লাহ তার জন্য জান্নাতের পথ সহজ করে দেন।','Whoever walks a path in search of knowledge, Allah makes the path to Paradise easy for him.','Muslim 2699'],
 ['দুনিয়াতে এমনভাবে থাকো যেন তুমি একজন অপরিচিত অথবা পথিক।','Be in this world as though you were a stranger or a traveller.','Bukhari 6416'],
 ['দুটি নিয়ামতের ব্যাপারে অনেক মানুষ ধোঁকায় পড়ে আছে: সুস্থতা এবং অবসর।','Two blessings that many people waste: health and free time.','Bukhari 6412'],
 ['জ্ঞান অর্জন করা প্রত্যেক মুসলিমের উপর ফরজ।','Seeking knowledge is a duty on every Muslim.','Ibn Majah 224']
];
const hadRow=h=>`<div class="dua"><p style="font-size:17px">${h[0]}</p><p class="muted">${h[1]}</p><p class="muted">${h[2]}</p></div>`;
const hadToday=()=>HAD[Math.floor(parse(today()).getTime()/864e5)%HAD.length];
EXT.hadith=()=>`<div class="card c-leaf"><h2>আজকের হাদিস</h2>${hadRow(hadToday())}</div><div class="card"><h2>Short hadith to live by</h2><p class="muted">These are the meanings in Bangla and English, not the full narrations. A complete hadith collection is not stored in the app yet.</p>${HAD.map(hadRow).join('')}</div>`;
VIEWS.today=()=>{
  const t=today(),s=S.settings,d=new Date(),n=nowMin(),pl=S.prayers[t]||{},pt=ptimes(t),np=nextPrayer(),ep=activeEp();
  const due=S.tasks.filter(x=>!x.done&&x.due&&x.due<=t),w=S.water[t]||0,out=m=>m.type!=='in';
  const spent=S.money.filter(m=>m.date===t&&out(m)).reduce((a,m)=>a+m.amount,0),mo=S.money.filter(m=>m.date.slice(0,7)===t.slice(0,7)&&out(m)).reduce((a,m)=>a+m.amount,0);
  const cls=S.routine.filter(r=>+r.day===d.getDay()).sort(byStart),nc=cls.find(r=>toMin(r.start)>=n);
  const sl=S.sleep.find(l=>l.date===t),hl=S.habitLog[t]||{},hd=S.habits.filter(x=>hl[x.id]).length;
  const fm=S.focus.filter(f=>f.date===t).reduce((a,f)=>a+f.min,0),q=QN().log[t]||0,nx=S.exams.filter(e=>e.date>=t).sort((a,b)=>a.date<b.date?-1:1)[0];
  const left=ep?doses(ep,t).filter(x=>!x.taken).length:0,up=agenda(t).filter(x=>toMin(x.t)>=n&&x.src!=='Prayer').slice(0,4),hd0=hadToday();
  let o=skyHero();
  if(!s.deenOff&&!s.noRow)o+=`<div class="hprow">${PR.map(p=>`<button class="hp${pl[p[0]]?' on':''}${np.name===p[1]&&toMin(pt[p[0]])>n?' next':''}" data-a="prTog" data-id="${p[0]}" data-d="${t}" aria-pressed="${pl[p[0]]?'true':'false'}" aria-label="${p[1]} prayed"><b>${p[1]}</b>${tfmt(pt[p[0]]).replace(/ [AP]M/,'')}</button>`).join('')}</div>`;
  o+=homeTiles();
  o+=(EXT.todayMid?EXT.todayMid():'')+streakCard();
  o+=`<div class="card">${head('Due now',`<button class="btn sm" data-a="go" data-tab="plan" data-k="plan" data-v="tasks">All tasks</button>`)}${due.length?'<div class="list">'+due.slice(0,5).map(taskRow).join('')+'</div>':'<p class="muted">Nothing is waiting. Add a task with a date and it shows here.</p>'}<form class="quick" data-f="task"><input id="q_task" placeholder="Add a task for today" aria-label="New task for today"><button class="btn pri" aria-label="Add task">${ic('plus')}</button></form></div>`;
  if(ep)o+=`<div class="card c-tomato">${head('Medicine today',`<button class="btn sm" data-a="go" data-tab="life" data-k="life" data-v="health">Open</button>`)}<p class="muted">${esc(ep.name)}</p>${doseList(ep,t)}</div>`;
  if(up.length)o+=`<div class="card">${head('Up next',`<button class="btn sm" data-a="go" data-tab="more" data-k="more" data-v="reminders">All</button>`)}<div class="list">${up.map(x=>`<div class="item"><span class="pill">${tfmt(x.t)}</span><span class="t grow">${esc(x.title)}</span></div>`).join('')}</div></div>`;
  o+=`<div class="card"><div class="row">${ill('dna')}<div class="grow"><h3>Biochem bite</h3><p>${esc(factToday())}</p></div></div></div>`;
  return o;
};
const BAN={plan:['tomato','tasks','Plan',()=>{const t=today(),c=S.tasks.filter(x=>!x.done&&x.due&&x.due<=t).length,k=S.routine.filter(r=>+r.day===new Date().getDay()).length;return c+' task'+(c===1?'':'s')+' due · '+k+' class'+(k===1?'':'es')+' today'}],
 study:['grape','book','Study',()=>{const e=S.exams.filter(x=>x.date>=today()).sort((a,b)=>a.date<b.date?-1:1)[0];return e?e.title+' in '+diffDays(e.date,today())+' days':'CGPA '+cg().g.toFixed(2)+' · no exam set'}],
 deen:['leaf','mosque','Deen',()=>{const p=nextPrayer();return p.name+' at '+tfmt(p.t)+' · in '+dur(p.mins)}],
 life:['sky','drop','Life',()=>(S.water[today()]||0)+' of '+S.settings.waterGoal+' glasses · '+(activeEp()?'sick mode on':'feeling well')],
 more:['pink','mail','Keep',()=>S.links.length+' links · '+S.notes.length+' notes · '+S.files.length+' files']};
Object.keys(BAN).forEach(k=>{const v=VIEWS[k],b=BAN[k];VIEWS[k]=()=>(k==='study'&&((ui.study==='courses'&&ui.course)||(ui.study==='research'&&ui.proj)))||(k==='life'&&ui.life==='health'&&ui.ep)?v():`<div class="banner b-${b[0]}">${ill(b[1])}<div><b>${b[2]}</b><span>${esc(b[3]())}</span></div></div>`+v()});

/* ---------- smart add (asks Claude to read one sentence) ---------- */
const isD=x=>/^\d{4}-\d{2}-\d{2}$/.test(x||''),isT=x=>/^\d{2}:\d{2}$/.test(x||'');
function applyItems(items){
  const t=today(),out=[],keys=new Set();
  (Array.isArray(items)?items:[]).slice(0,12).forEach(i=>{
    if(!i||typeof i!=='object')return;
    const title=String(i.title||i.text||i.name||'').slice(0,200),amt=Math.abs(num(i.amount));
    if(i.type==='task'&&title){S.tasks.push({id:uid(),title:title,due:isD(i.due)?i.due:'',cat:'',pri:'Normal',done:false});keys.add('tasks');out.push('task “'+title+'”')}
    else if((i.type==='expense'||i.type==='income')&&amt){S.money.push({id:uid(),date:t,amount:amt,type:i.type==='income'?'in':'out',cat:MCAT.includes(i.cat)?i.cat:'Other',note:String(i.note||'').slice(0,100)});keys.add('money');out.push((i.type==='income'?'received ':'spent ')+money(amt))}
    else if(i.type==='water'){const g=Math.min(20,Math.max(0,Math.round(num(i.glasses))));if(g){S.water[t]=(S.water[t]||0)+g;keys.add('water');out.push(g+' glass'+(g>1?'es':'')+' of water')}}
    else if(i.type==='meal'&&title){const c=Math.abs(num(i.cost));S.meals.push({id:uid(),date:t,meal:SLOT.includes(i.meal)?i.meal:'Snack',text:title,tag:'',cost:c});keys.add('meals');if(c){S.money.push({id:uid(),date:t,amount:c,type:'out',cat:'Food',note:title});keys.add('money')}out.push('meal “'+title+'”')}
    else if(i.type==='reminder'&&title&&isT(i.time)){S.reminders.push({id:uid(),title:title,time:i.time,repeat:'Once',date:isD(i.date)?i.date:t,day:0,on:1});keys.add('reminders');out.push('reminder at '+tfmt(i.time))}
    else if(i.type==='event'&&title&&isD(i.date)){S.events.push({id:uid(),title:title,date:i.date,time:isT(i.time)?i.time:'',note:''});keys.add('events');out.push('event on '+fmt(i.date))}
    else if(i.type==='exam'&&title&&isD(i.date)){const k=String(i.course||'').toLowerCase().replace(/\s/g,''),c=S.courses.find(x=>k&&String(x.code||'').toLowerCase().replace(/\s/g,'')===k);S.exams.push({id:uid(),title:title,type:XK.includes(i.kind)?i.kind:'Other',courseId:c?c.id:'',date:i.date,time:isT(i.time)?i.time:''});keys.add('exams');out.push(title+' on '+fmt(i.date))}
    else if(i.type==='prayer'&&PR.some(p=>p[0]===i.name)){(S.prayers[t]=S.prayers[t]||{})[i.name]=1;keys.add('prayers');out.push(i.name+' prayer')}
    else if(i.type==='habit'){const h=S.habits.find(x=>x.name.toLowerCase()===title.toLowerCase());if(h){(S.habitLog[t]=S.habitLog[t]||{})[h.id]=1;keys.add('habitLog');out.push('habit “'+h.name+'”')}}
    else if(i.type==='activity'&&title){S.acts.push({id:uid(),date:t,time:hm(nowMin()),text:title,kind:'Other',min:Math.round(num(i.minutes))||''});keys.add('acts');out.push('activity “'+title+'”')}
    else if(i.type==='note'&&title){const nn={id:uid(),ref:'',title:title,body:String(i.body||'').slice(0,5000),updated:Date.now()};S.notes.push(nn);keys.add('n_'+nn.id);out.push('note “'+title+'”')}
  });
  if(keys.size)save.apply(null,[...keys]);
  return out;
}
const smErr=e=>e&&e.code==='rate_limited'?'Too many requests. Try again in a minute.':e&&e.code==='not_granted'?'This needs your permission.':'That did not work. Try shorter wording.';
async function capture(text){
  if(!SM){say('cap','Smart add is not available in this view. Use the + buttons instead.');return}
  say('cap','Reading…');
  const t=today(),p=`You turn a student's short message into JSON for their planner app. Today is ${t} (${DAYSL[new Date().getDay()]}), time ${hm(nowMin())}. Their course codes: ${S.courses.map(c=>c.code).filter(Boolean).join(', ')||'none'}. Their habits: ${S.habits.map(h=>h.name).join(', ')||'none'}.
Reply with ONLY JSON shaped {"items":[...]}. Each item is one of:
{"type":"task","title":"","due":"YYYY-MM-DD or empty"}
{"type":"expense","amount":0,"cat":"Food|Transport|Study|Mobile and internet|Shopping|Health|Fun|Other","note":""}
{"type":"income","amount":0,"note":""}
{"type":"water","glasses":0}
{"type":"meal","meal":"Breakfast|Lunch|Dinner|Snack","title":"what was eaten","cost":0}
{"type":"reminder","title":"","time":"HH:MM","date":"YYYY-MM-DD"}
{"type":"event","title":"","date":"YYYY-MM-DD","time":"HH:MM or empty"}
{"type":"exam","title":"","kind":"Quiz|Mid-term|Final|Assignment|Presentation|Lab report|Viva|Other","date":"YYYY-MM-DD","time":"HH:MM or empty","course":"course code or empty"}
{"type":"prayer","name":"fajr|dhuhr|asr|maghrib|isha"}
{"type":"habit","title":"exact habit name from the list"}
{"type":"activity","title":"","minutes":0}
{"type":"note","title":"","body":""}
Rules: the message may be Bangla, English or mixed; keep titles in the language used. Food that was bought is one meal item with its cost, not also an expense. Use only what the message says and invent nothing. If nothing fits, return {"items":[]}.
Message: """${text.slice(0,600)}"""`;
  try{const r=await SM(p,{modelTier:'quick',cache:false}),m=String(r&&r.text||'').match(/\{[\s\S]*\}/),done=applyItems(m?JSON.parse(m[0]).items:[]);say('cap',done.length?'Added: '+done.join(', ')+'.':'I could not find anything to add in that.')}
  catch(e){say('cap',smErr(e))}
}
async function planDay(){
  if(!SM){say('cap','Day planning is not available in this view.');return}
  say('cap','Planning your day…');
  const t=today(),pt=ptimes(t),dow=new Date().getDay();
  const p=`Write a short time-blocked plan for the rest of today for a Muslim university student in Bangladesh. The time now is ${hm(nowMin())}.
Fixed times: prayers ${PR.map(x=>x[1]+' '+pt[x[0]]).join(', ')}; classes ${S.routine.filter(r=>+r.day===dow).map(r=>rName(r)+' '+r.start+(r.end?'-'+r.end:'')).join(', ')||'none'}; events ${S.events.filter(e=>e.date===t).map(e=>e.title+' '+(e.time||'')).join(', ')||'none'}; bedtime ${S.settings.sleepBed}.
Open tasks: ${S.tasks.filter(x=>!x.done).slice(0,12).map(x=>x.title+(x.due?' (due '+x.due+')':'')).join('; ')||'none'}.
Coming exams and deadlines: ${S.exams.filter(e=>e.date>=t).slice(0,5).map(e=>e.title+' on '+e.date).join('; ')||'none'}.
Rules: 8 to 10 lines, each "HH:MM  what to do". Only times after now. Put the hardest or most urgent work first, in focus blocks of 25 to 50 minutes with short breaks. Keep prayers, meals and the bedtime. Do not invent tasks. Plain text only, no markdown, no intro and no closing line.`;
  try{const r=await SM(p,{cache:false});note.plan=String(r&&r.text||'').trim().slice(0,1500);say('cap','Here is a plan for the rest of today.')}
  catch(e){say('cap',smErr(e))}
}
Q.capture=()=>{const v=$('#q_cap').value.trim();if(v)capture(v)};

/* ---------- NSU CGPA ---------- */
const NSU=[['A',4,'93 and above'],['A-',3.7,'90 to 92'],['B+',3.3,'87 to 89'],['B',3,'83 to 86'],['B-',2.7,'80 to 82'],['C+',2.3,'77 to 79'],['C',2,'73 to 76'],['C-',1.7,'70 to 72'],['D+',1.3,'67 to 69'],['D',1,'60 to 66'],['F',0,'below 60']];
const ngp=g=>{const x=NSU.find(k=>k[0]===g);return x?x[1]:null};
function cg(){
  const s=S.settings;let cr=num(s.cgCred),pts=num(s.cgBase)*cr;
  S.sems.forEach(se=>(se.items||[]).forEach(i=>{const c=num(i.credits),g=ngp(i.grade);if(g==null||!c)return;const o=i.old?ngp(i.old):null;
    if(o!=null){if(s.retake==='Better grade'&&o>=g)return;pts+=c*(g-o)}else{pts+=c*g;cr+=c}}));
  return{cr:cr,pts:pts,g:cr?pts/cr:0};
}
const termGpa=items=>{let c=0,p=0;items.forEach(i=>{const g=ngp(i.grade),k=num(i.credits);if(g!=null){c+=k;p+=k*g}});return c?p/c:0};
EXT.cgpa=()=>{
  const s=S.settings,c=cg(),tg=num(s.cgTarget),rm=num(s.cgRemain),need=tg&&rm?(tg*(c.cr+rm)-c.pts)/rm:null;
  let o=`<div class="card c-sun"><div class="row between"><h3>CGPA</h3><span class="pill">North South University scale</span></div><div class="big">${c.g.toFixed(2)}</div><p class="muted">${Math.round(c.cr*10)/10} credits counted${c.cr&&c.g<2?'. Below 2.00 means academic probation at NSU.':''}</p></div>`;
  o+=`<div class="card">${head('Where I stand now',`<button class="btn sm" data-a="cgBase">${ic('edit')}Edit</button>`)}<p>${num(s.cgCred)?`Starting from CGPA <b>${num(s.cgBase).toFixed(2)}</b> with <b>${num(s.cgCred)}</b> credits.`:'Not set yet.'}</p><p class="muted">Type your current CGPA and completed credits from RDS once. After that, add only new semesters. Or leave this empty and enter every semester yourself.</p></div>`;
  o+=`<div class="card">${head('Target',`<button class="btn sm" data-a="cgTarget">${ic('edit')}Set</button>`)}${need==null?'<p class="muted">Set the CGPA you want and how many credits you still have to take. The app tells you the average you need.</p>':`<p>To finish with <b>${tg.toFixed(2)}</b> you need an average of <b>${need>4?'more than 4.00':need<=0?'0.00':need.toFixed(2)}</b> in your remaining ${rm} credits.</p><p class="muted">${need>4?'That target cannot be reached with these credits. Retaking low grades can help.':need>3.7?'That means nearly all A and A-.':need<=0?'You are already above it.':'That is within reach.'}</p>`}</div>`;
  o+=`<div class="card"><h3>When I retake a course, count</h3><div class="chips">${['Latest grade','Better grade'].map(x=>`<button class="chip${s.retake===x?' on':''}" data-a="cgRule" data-v="${x}">${x}</button>`).join('')}</div><p class="muted">Pick the rule your transcript follows. A retake replaces the old grade inside your total, so the first attempt must already be counted in your current CGPA or an earlier semester here.</p></div>`;
  o+=`<div class="row between"><p class="muted">${S.sems.length} semester${S.sems.length===1?'':'s'}</p>${addBtn('sAdd','Semester')}</div>`;
  o+=S.sems.map(se=>`<div class="card"><div class="row between"><button class="tap" data-a="sEdit" data-id="${se.id}"><h3>${esc(se.name)}</h3></button><span class="pill col c-sun">GPA ${termGpa(se.items||[]).toFixed(2)}</span></div>${(se.items||[]).length?'<div class="list">'+se.items.map(i=>`<div class="item"><button class="tap" data-a="giEdit" data-sem="${se.id}" data-id="${i.id}"><span class="t">${esc(i.name)}</span><span class="muted">${num(i.credits)} credits${i.old?' · retake, was '+esc(i.old):''}${ngp(i.grade)==null?' · not counted':''}</span></button><span class="big" style="font-size:22px">${esc(i.grade)}</span></div>`).join('')+'</div>':''}<button class="btn sm" data-a="giAdd" data-sem="${se.id}" style="align-self:flex-start">${ic('plus')}Course grade</button></div>`).join('');
  o+=`<div class="card"><h3>NSU grading scale</h3><div class="list">${NSU.map(g=>`<div class="item"><span class="t" style="width:34px">${g[0]}</span><span class="grow muted">${g[2]}</span><span class="t">${g[1].toFixed(1)}</span></div>`).join('')}</div><p class="muted">W (withdrawn) and I (incomplete) carry no grade points and are not counted.</p></div>`;
  return o;
};
A.giFields=[['name','Course','text',R],['credits','Credits','number',R],['grade','Grade','select',{opts:NSU.map(g=>[g[0],g[0]+'  ('+g[1].toFixed(1)+')']).concat([['W','W  (withdrawn)'],['I','I  (incomplete)']])}],['old','Is this a retake?','select',{opts:[['','No, first attempt']].concat(NSU.map(g=>[g[0],'Yes, old grade was '+g[0]]))}]];

/* ---------- duas: vowels, Bangla pronunciation and meaning ---------- */
const DX={
 sayyid:['اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ','আল্লাহুম্মা আনতা রাব্বী, লা ইলাহা ইল্লা আনতা, খালাক্বতানী ওয়া আনা আবদুকা, ওয়া আনা আলা আহদিকা ওয়া ওয়া‘দিকা মাসতাত্বা‘তু, আউযু বিকা মিন শাররি মা সানা‘তু, আবূউ লাকা বিনি‘মাতিকা আলাইয়া, ওয়া আবূউ লাকা বিযাম্বী, ফাগফিরলী, ফাইন্নাহু লা ইয়াগফিরুয যুনূবা ইল্লা আনতা।','হে আল্লাহ, তুমি আমার রব, তুমি ছাড়া কোনো ইলাহ নেই। তুমি আমাকে সৃষ্টি করেছ এবং আমি তোমার বান্দা। আমি সাধ্যমতো তোমার অঙ্গীকার ও প্রতিশ্রুতির উপর আছি। আমার কৃতকর্মের অনিষ্ট থেকে তোমার কাছে আশ্রয় চাই। আমার প্রতি তোমার নিয়ামত স্বীকার করছি এবং আমার গুনাহ স্বীকার করছি। অতএব আমাকে ক্ষমা করো, কারণ তুমি ছাড়া কেউ গুনাহ ক্ষমা করতে পারে না।'],
 bism3:['بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ','বিসমিল্লাহিল্লাযী লা ইয়াদুররু মা‘আসমিহী শাইউন ফিল আরদি ওয়ালা ফিস সামাই ওয়া হুয়াস সামীউল আলীম।','আল্লাহর নামে, যাঁর নামের সাথে আসমান ও জমিনের কোনো কিছুই ক্ষতি করতে পারে না। তিনি সর্বশ্রোতা, সর্বজ্ঞ।'],
 hasbi:['حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ','হাসবিয়াল্লাহু লা ইলাহা ইল্লা হুয়া, আলাইহি তাওয়াক্কালতু ওয়া হুয়া রাব্বুল আরশিল আযীম।','আল্লাহই আমার জন্য যথেষ্ট। তিনি ছাড়া কোনো ইলাহ নেই। তাঁর উপরই আমি ভরসা করি এবং তিনি মহান আরশের রব।'],
 sbh:['سُبْحَانَ اللَّهِ وَبِحَمْدِهِ','সুবহানাল্লাহি ওয়া বিহামদিহী।','আল্লাহ পবিত্র এবং সকল প্রশংসা তাঁরই।'],
 tahlil:['لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ','লা ইলাহা ইল্লাল্লাহু ওয়াহদাহু লা শারীকা লাহু, লাহুল মুলকু ওয়া লাহুল হামদু ওয়া হুয়া আলা কুল্লি শাইয়িন ক্বাদীর।','আল্লাহ ছাড়া কোনো ইলাহ নেই, তিনি একক, তাঁর কোনো শরিক নেই। রাজত্ব তাঁরই, প্রশংসাও তাঁরই এবং তিনি সব কিছুর উপর ক্ষমতাবান।'],
 salawat:['اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ','আল্লাহুম্মা সাল্লি ওয়া সাল্লিম আলা নাবিয়্যিনা মুহাম্মাদ।','হে আল্লাহ, আমাদের নবী মুহাম্মাদ (সা.)-এর উপর রহমত ও শান্তি বর্ষণ করো।'],
 istigh:['أَسْتَغْفِرُ اللَّهَ','আস্তাগফিরুল্লাহ।','আমি আল্লাহর কাছে ক্ষমা চাই।'],
 tasbih:['سُبْحَانَ اللَّهِ (33) · الْحَمْدُ لِلَّهِ (33) · اللَّهُ أَكْبَرُ (34)','সুবহানাল্লাহ, আলহামদুলিল্লাহ, আল্লাহু আকবার।','আল্লাহ পবিত্র। সকল প্রশংসা আল্লাহর। আল্লাহ সবচেয়ে মহান।'],
 ainni:['اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ','আল্লাহুম্মা আ‘ইন্নী আলা যিকরিকা ওয়া শুকরিকা ওয়া হুসনি ইবাদাতিকা।','হে আল্লাহ, তোমার যিকির, তোমার শুকরিয়া এবং সুন্দরভাবে তোমার ইবাদত করতে আমাকে সাহায্য করো।'],
 wake:['الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ','আলহামদু লিল্লাহিল্লাযী আহইয়ানা বা‘দা মা আমাতানা ওয়া ইলাইহিন নুশূর।','সকল প্রশংসা আল্লাহর, যিনি আমাদের মৃত্যুর (ঘুমের) পর আবার জীবিত করেছেন এবং তাঁর কাছেই ফিরে যেতে হবে।'],
 leave:['بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ','বিসমিল্লাহি তাওয়াক্কালতু আলাল্লাহি ওয়ালা হাওলা ওয়ালা কুওয়াতা ইল্লা বিল্লাহ।','আল্লাহর নামে বের হচ্ছি, আল্লাহর উপর ভরসা করলাম। আল্লাহ ছাড়া কোনো শক্তি ও সামর্থ্য নেই।'],
 eat:['الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ','আলহামদু লিল্লাহিল্লাযী আত্ব‘আমানী হাযা ওয়া রাযাক্বানীহি মিন গাইরি হাওলিম মিন্নী ওয়ালা কুওয়াহ।','সকল প্রশংসা আল্লাহর, যিনি আমাকে এটি খাইয়েছেন এবং আমার কোনো শক্তি-সামর্থ্য ছাড়াই এই রিযিক দিয়েছেন।'],
 ilm:['رَبِّ زِدْنِي عِلْمًا · رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي','রাব্বি যিদনী ইলমা। রাব্বিশরাহলী সাদরী, ওয়া ইয়াসসিরলী আমরী।','হে আমার রব, আমার জ্ঞান বাড়িয়ে দাও। হে আমার রব, আমার বক্ষ প্রশস্ত করে দাও এবং আমার কাজ সহজ করে দাও।'],
 rabbana:['رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ','রাব্বানা আতিনা ফিদ্দুনইয়া হাসানাতাও ওয়া ফিল আখিরাতি হাসানাতাও ওয়া ক্বিনা আযাবান নার।','হে আমাদের রব, আমাদের দুনিয়াতে কল্যাণ দাও, আখিরাতেও কল্যাণ দাও এবং আমাদের জাহান্নামের আযাব থেকে রক্ষা করো।'],
 parents:['رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا','রাব্বির হামহুমা কামা রাব্বাইয়ানী সাগীরা।','হে আমার রব, তাঁদের প্রতি রহম করো, যেমন তাঁরা শৈশবে আমাকে লালন-পালন করেছেন।'],
 sleep:['بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا','বিসমিকা আল্লাহুম্মা আমূতু ওয়া আহইয়া।','হে আল্লাহ, তোমার নামেই আমি মরি (ঘুমাই) এবং জীবিত হই (জাগি)।']
};
DUA.forEach(d=>{const x=DX[d.id];if(x){d.ar=x[0];d.bp=x[1];d.bm=x[2]}});

/* ---------- files kept on this phone (any type) ---------- */
let IDB=null;
function idb(){return new Promise((res,rej)=>{if(IDB)return res(IDB);try{const r=indexedDB.open('barakah-files',1);r.onupgradeneeded=()=>r.result.createObjectStore('f');r.onsuccess=()=>{IDB=r.result;res(IDB)};r.onerror=()=>rej(r.error)}catch(e){rej(e)}})}
const idbDo=(mode,fn)=>idb().then(d=>new Promise((res,rej)=>{const t=d.transaction('f',mode),q=fn(t.objectStore('f'));t.oncomplete=()=>res(q.result);t.onerror=()=>rej(t.error)}));
async function putFiles(list,msgKey,each,cloudOnly){
  const bad=[];let local=0;
  for(const f of list){
    const type=FT[ext(f.name)],phone=!cloudOnly&&(S.settings.fstore==='phone'||!type||!AS);
    if(!phone&&(!type||!AS)){bad.push(f.name+' (use a JPG, PNG or PDF)');continue}
    if(f.size>(phone?100:20)*1048576){bad.push(f.name+' (too large)');continue}
    say(msgKey,'Saving '+f.name+'…');
    try{
      if(phone){const k='L'+uid();await idbDo('readwrite',s=>s.put(f,k));each({id:'',local:k,sizeBytes:f.size,contentType:f.type||type||''},f);local++}
      else each(await AS.upload(f,{type:type}),f);
    }catch(e){bad.push(f.name+' ('+(e&&e.code==='quota_or_state'?'storage is full':'could not be saved')+')')}
  }
  say(msgKey,(bad.length?'Not saved: '+bad.join('; ')+'. ':'Saved. ')+(local?local+' file'+(local>1?'s are':' is')+' kept on this phone only.':''));
}
const fileRows=l=>'<div class="list">'+l.map(f=>`<div class="item linkrow">${f.asset&&/^image\//.test(f.type)?`<img class="thumb" src="/_blob/${f.asset}" alt="">`:`<span class="thumb">${esc(ext(f.name))}</span>`}<div class="grow">${f.asset?`<a href="/_blob/${f.asset}" target="_blank" rel="noopener">${esc(f.name)}</a>`:`<span class="t">${esc(f.name)}</span>`}<small>${fsz(f.size)} · ${fmt(f.added)} · ${f.asset?'cloud':'this phone'}</small></div><button class="btn sm" data-a="fSave" data-id="${f.id}">${f.asset?'Save':'Open'}</button><button class="btn sm" data-a="fEdit" data-id="${f.id}" aria-label="Edit file">${ic('edit')}</button></div>`).join('')+'</div>';
EXT.files=()=>{
  const g={},s=S.settings;S.files.forEach(f=>{const k=cname(f.courseId)||'General';(g[k]=g[k]||[]).push(f)});
  let o=`<div class="card"><div class="row between"><h2>Study files</h2><label class="btn sm pri filebtn">${ic('plus')}Upload<input type="file" id="fup" multiple data-course=""></label></div><label>Put new uploads in<select id="fcourse">${courseOpts().map(x=>`<option value="${x[0]}">${esc(x[1]==='No course'?'General':x[1])}</option>`).join('')}</select></label>
    <p class="muted">Keep new files</p><div class="chips">${[['cloud','In my account'],['phone','On this phone']].map(x=>`<button class="chip${s.fstore===x[0]?' on':''}" data-a="fStore" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>${said('files')}
    <p class="muted"><b>In my account</b> takes PDF, images, text and MP4 up to 20 MB and follows you to any phone. <b>On this phone</b> takes any file, including Word and PowerPoint, up to 100 MB, but it lives in this phone’s browser storage: it will not appear on another device and is lost if the app’s data is cleared. Word and PowerPoint always go to the phone.</p></div>`;
  o+=Object.keys(g).sort().map(k=>`<div class="card"><h3>${esc(k)}</h3>${fileRows(g[k])}</div>`).join('')||`<div class="card">${empty('No files yet','Lecture slides, photos of the board, scanned notes. Each file can belong to a course.')}</div>`;
  return o;
};
EXT.courseFiles=cid=>{const l=S.files.filter(f=>f.courseId===cid);return`<div class="card"><div class="row between"><h2>Files</h2><label class="btn sm pri filebtn">${ic('plus')}Upload<input type="file" id="fup" multiple data-course="${cid}"></label></div>${said('files')}${l.length?fileRows(l):'<p class="muted">Slides, scans and photos for this course.</p>'}</div>`};
async function fileBlob(f){if(f.asset)return(await fetch('/_blob/'+f.asset)).blob();const b=await idbDo('readonly',s=>s.get(f.local));if(!b)throw{code:'gone'};return b}

/* ---------- history without scores ---------- */
EXT.history=()=>{
  const ds=ui.histDay,p=dayParts(ds),d14=[];for(let i=0;i<14;i++)d14.push(addDays(today(),-i));
  const rows=[['Prayers',p.pr?p.pr+' of 5':''],['Water',p.water?p.water+' glasses':''],['Habits',p.hab?p.hab+' of '+S.habits.length:''],['Tasks finished',p.done.map(t=>t.title).join(', ')],['Study time',p.focus?dur(p.focus):''],['Quran',p.quran?p.quran+' ayahs':''],['Sleep',p.sleep?dur(sleepMin(p.sleep))+' ('+tfmt(p.sleep.bed)+' to '+tfmt(p.sleep.wake)+')':''],['Meals',p.meals.map(m=>m.meal+': '+m.text).join(', ')],['Spent',p.spent?money(p.spent):''],['Activities',p.acts.map(a=>a.text).join(', ')],['Medicine doses',p.meds||'']].filter(r=>r[1]!=='');
  return`<div class="card"><h2>History</h2><p class="muted">Every day you used the app is kept. Pick a day to see what you recorded.</p><div class="chips">${d14.map(x=>`<button class="chip${x===ds?' on':''}" data-a="histPick" data-d="${x}">${x===today()?'Today':DAYS[parse(x).getDay()]+' '+parse(x).getDate()}</button>`).join('')}</div></div>
    <div class="card">${dayNav('histDay',ds)}${rows.length?'<div class="list">'+rows.map(r=>`<div class="item"><span class="muted" style="flex:none;width:112px">${r[0]}</span><span class="t grow">${esc(r[1])}</span></div>`).join('')+'</div>':'<p class="muted">Nothing was recorded on this day.</p>'}</div>`;
};
const _set=EXT.settings;
EXT.settings=()=>{const b=bday(),s=S.settings;return`<div class="card">${head('About me',`<button class="btn sm" data-a="welcome">${ic('edit')}Edit</button>`)}<div class="list"><div class="item"><span class="grow muted">Birthday</span><span class="t">${s.dob?fmt(s.dob).replace(/^\w+, /,'')+(b===0?' · today':' · in '+b+' days'):'Not set'}</span></div><div class="item"><span class="grow muted">City for prayer times</span><span class="t">${esc(s.city)}</span></div></div></div>`+_set()+
  `<div class="card"><h2>Permissions</h2><div class="list"><div class="item"><span class="grow"><b>Photos and files</b><br><span class="muted">Your phone asks each time you tap Upload. Nothing is read without that.</span></span></div><div class="item"><span class="grow"><b>Location</b><br><span class="muted">This web app is not allowed to read GPS, so prayer times use the city you choose.</span></span></div><div class="item"><span class="grow"><b>Sound</b><br><span class="muted">Alert sounds play after your first tap in the app. For voice typing, use the microphone key on your keyboard.</span></span></div><div class="item"><span class="grow"><b>Live websites</b><br><span class="muted">The app cannot pull from other websites. Prayer times, Hijri date and the sky on Today are worked out on your phone and renew themselves every day.</span></span></div></div></div>`};

Object.assign(A,{
  welcome(){form(S.settings.setup?'About me':'Welcome to Catalyst',[['name','What should I call you?','text',R],['dob','Date of birth','date'],['city','Your city, for prayer times','select',{opts:Object.keys(CITY).concat('Custom')}],['asr','Asr time','select',{opts:['Hanafi','Shafi']}],['cgBase','Current CGPA (optional)','number'],['cgCred','Credits completed (optional)','number'],['waterGoal','Glasses of water a day','number',R],['sleepBed','Usual bedtime','time',R],['sleepWake','Usual wake-up time','time',R],['email','Email (optional)','text']],S.settings,v=>{
    if(CITY[v.city]){v.lat=CITY[v.city][0];v.lng=CITY[v.city][1]}v.waterGoal=Math.max(1,Math.round(v.waterGoal));v.cgBase=Math.min(4,v.cgBase);v.setup=1;Object.assign(S.settings,v);save('settings')})},
  planDay(){planDay()},
  cgBase(){form('Where I stand now',[['cgBase','Current CGPA','number'],['cgCred','Credits completed','number']],S.settings,v=>{v.cgBase=Math.min(4,v.cgBase);Object.assign(S.settings,v);save('settings')})},
  cgTarget(){form('My target',[['cgTarget','CGPA I want','number',R],['cgRemain','Credits still to take','number',R]],S.settings,v=>{v.cgTarget=Math.min(4,v.cgTarget);Object.assign(S.settings,v);save('settings')})},
  cgRule(d){S.settings.retake=d.v;save('settings');render()},
  giAdd(d){const s=S.sems.find(x=>x.id===d.sem);form('Add grade',A.giFields,{credits:3,grade:'A',old:''},v=>{s.items.push(Object.assign({id:uid()},v));save('sems')})},
  duaLang(d){S.settings.dl=d.v;save('settings');render()},
  fStore(d){S.settings.fstore=d.v;save('settings');render()},
  fEdit(d){const f=S.files.find(x=>x.id===d.id);form('File',[['name','Name','text',R],['courseId','Course','select',{opts:courseOpts()}]],f,v=>{if(ext(v.name)!==ext(f.name))v.name+='.'+ext(f.name);upsert('files',f.id,v)},()=>{remove('files',f.id);if(f.asset){if(AS)AS.delete(f.asset).catch(()=>{})}else idbDo('readwrite',s=>s.delete(f.local)).catch(()=>{})})},
  async fSave(d){const f=S.files.find(x=>x.id===d.id);if(!DL){say('files',f.asset?'Tap the file name to open it.':'Opening phone files is not available in this view.');return}try{await DL.save({filename:f.name,data:await fileBlob(f)});say('files','Saved '+f.name+' to your phone.')}catch(e){say('files',e&&e.code==='gone'?'This file was kept on a different phone, or the app’s storage was cleared.':e&&e.code==='declined'?'Cancelled.':e&&e.code==='rejected_extension'?'This file type cannot be handed to the phone from here.':'Could not open that file.')}}
});
document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.getAttribute&&e.target.getAttribute('role')==='button'){e.preventDefault();e.target.click()}});
const _ar=window.afterRender;let asked=false;
window.afterRender=function(){_ar();if(cloud!=='loading'&&!S.settings.setup&&!F&&!asked){asked=true;setTimeout(()=>{if(!F&&!S.settings.setup)A.welcome()},600)}};
window.__v3={cg:cg,applyItems:applyItems,bday:bday,HAD:HAD};


/* ================= v4: Catalyst. Biochemistry and biotechnology theme, Lab tab, feedback ================= */
const FB_MAIL='raihan.ndc22@gmail.com';
TABS.push('lab');NAV.splice(3,0,['lab','Lab']);TABL.lab='Lab';
IC.lab='<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 2 3h10a2 2 0 0 0 2-3l-5-9V3M8 15h8"/>';
SUB.lab=[['calc','Calculators'],['seq','Sequence'],['ref','Reference'],['timers','Timers'],['book','Notebook']];
SUB.more.splice(SUB.more.length-1,0,['feedback','Feedback']);
Object.assign(ui,{lab:'calc',cv:{},fb:{n:'',t:'New feature',m:''}});
ILL.flask='<path d="M18 6h12M20 6v12L9 37a4 4 0 0 0 4 6h22a4 4 0 0 0 4-6L28 18V6z" fill="var(--card)"/><path d="M14 29h20l5 8a4 4 0 0 1-4 6H13a4 4 0 0 1-4-6z" fill="var(--pink)"/><circle cx="21" cy="35" r="1.6"/><circle cx="28" cy="38" r="1.2"/>';
ILL.dna='<path d="M15 5c0 12 18 12 18 19S15 31 15 43" stroke="var(--grape)" stroke-width="3.5"/><path d="M33 5c0 12-18 12-18 19s18 7 18 19" stroke="var(--tomato)" stroke-width="3.5"/><path d="M18 11h12M18 37h12M20 24h8"/>';
MENU.splice(3,0,['Lab',[['lab','lab','calc','Lab calculators','sun'],['lab','lab','seq','Sequence tools','sun'],['lab','lab','ref','Quick reference','sun'],['lab','lab','timers','Lab timers','sun',()=>LT.length||''],['lab','lab','book','Lab notebook','sun',()=>S.notes.filter(n=>n.ref==='lab').length||'']]]);
MENU[MENU.length-1][1].push(['more','more','feedback','Feedback','pink']);
BAN.lab=['sun','flask','Lab bench',()=>LT.length?LT.length+' timer'+(LT.length>1?'s':'')+' running':'Calculators, sequences and quick reference'];
BAN.deen[2]='Assalamu alaikum';

const FACTS=['An adult turns over roughly their own body weight in ATP every day, recycling the same small pool again and again.','The DNA in one human cell is about 2 metres long, with around 3.2 billion base pairs.','Carbonic anhydrase can convert about a million CO₂ molecules every second. It is one of the fastest enzymes known.','Taq polymerase, the enzyme behind PCR, comes from Thermus aquaticus, a bacterium that lives in hot springs.','Insulin was the first protein to be fully sequenced, by Frederick Sanger, and the first medicine made with recombinant DNA.','One haemoglobin molecule carries four O₂ molecules. Binding one makes the next easier, which gives the S-shaped curve.','Mitochondria keep their own small circular DNA, and you inherit it from your mother.','In ideal conditions E. coli divides about every 20 minutes.','Rubisco, the enzyme that fixes CO₂ in plants, is thought to be the most abundant protein on Earth.','The genetic code has 64 codons: 61 code for amino acids and 3 are stop signals.','Glycolysis nets 2 ATP per glucose. Full oxidation in mitochondria yields about 30 to 32.','CRISPR-Cas9 began as a bacterial immune system that cuts the DNA of invading viruses.','Penicillin, noticed by Alexander Fleming in 1928, kills bacteria by blocking cell wall synthesis.','Humans cannot make vitamin C because the gene for the last enzyme in the pathway, L-gulonolactone oxidase, no longer works.'];
const factToday=()=>FACTS[Math.floor(parse(today()).getTime()/864e5)%FACTS.length];

/* ---------- lab calculators ---------- */
const SUP={'-':'⁻','0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹'};
const sig=x=>String(Number(Number(x).toPrecision(4)));
const sci=x=>{if(!isFinite(x))return'–';if(x!==0&&(Math.abs(x)>=1e4||Math.abs(x)<1e-2)){const a=x.toExponential(2).split('e');return a[0]+' × 10'+String(+a[1]).split('').map(c=>SUP[c]).join('')}return sig(x)};
const CALC=[
 {id:'mol',t:'Molarity: how much to weigh',f:[['mw','Molecular weight (g/mol)'],['c','Concentration (M)'],['v','Final volume (mL)']],fn:v=>v.mw&&v.c&&v.v?'Weigh '+sig(v.mw*v.c*v.v/1000)+' g and make up to '+sig(v.v)+' mL.':'',n:'mass = M × volume in L × MW'},
 {id:'dil',t:'Dilution: C₁V₁ = C₂V₂',f:[['c1','Stock concentration'],['c2','Final concentration'],['v2','Final volume (mL)']],fn:v=>{if(!(v.c1&&v.c2&&v.v2))return'';if(v.c2>v.c1)return'The final concentration cannot be higher than the stock.';const a=v.c2*v.v2/v.c1;return'Take '+sig(a)+' mL of stock and add '+sig(v.v2-a)+' mL of diluent.'},n:'Use the same unit for both concentrations.'},
 {id:'pct',t:'Percent solution (w/v)',f:[['p','Percent (%)'],['v','Final volume (mL)']],fn:v=>v.p&&v.v?'Dissolve '+sig(v.p*v.v/100)+' g and make up to '+sig(v.v)+' mL.':'',n:'1% w/v is 1 g in 100 mL'},
 {id:'cfu',t:'CFU per mL from a plate count',f:[['n','Colonies counted'],['d','Dilution as a power of ten (4 means 10⁻⁴)'],['v','Volume plated (mL)']],fn:v=>v.n&&v.v?sci(v.n*Math.pow(10,v.d||0)/v.v)+' CFU/mL'+(v.n<30||v.n>300?'. This count is outside 30 to 300, so treat it as an estimate.':''):'',n:'CFU/mL = colonies ÷ (dilution × volume plated)'},
 {id:'na',t:'DNA or RNA concentration from A260',sel:['k','Sample',[['50','Double-stranded DNA'],['40','RNA'],['33','Single-stranded DNA']]],f:[['a','A260 reading'],['df','Dilution factor (1 if undiluted)'],['a280','A280 reading (optional)']],fn:v=>{if(!v.a)return'';const k=v.k||50,c=v.a*k*(v.df||1);let o=sig(c)+' µg/mL';if(v.a280){const r=v.a/v.a280;o+='. A260/A280 = '+r.toFixed(2)+(k===40?(r>=1.9?', clean RNA.':', below 2.0, so check for protein or phenol.'):(r>=1.7&&r<=2?', clean DNA.':r<1.7?', below 1.8, so protein may be present.':', above 2.0, so RNA may be present.'))}return o},n:'A260 of 1.0 is about 50 µg/mL dsDNA, 40 µg/mL RNA or 33 µg/mL ssDNA.'},
 {id:'rcf',t:'Centrifuge: RPM and × g',f:[['r','Rotor radius (cm)'],['rpm','Speed (RPM)'],['g','or the force you want (× g)']],fn:v=>{if(!v.r)return'';if(v.rpm)return sig(1.118e-5*v.r*v.rpm*v.rpm)+' × g';if(v.g)return'Set about '+Math.round(Math.sqrt(v.g/(1.118e-5*v.r)))+' RPM.';return''},n:'RCF = 1.118 × 10⁻⁵ × radius × RPM²'},
 {id:'hh',t:'Buffer pH (Henderson–Hasselbalch)',f:[['pka','pKa'],['a','Base form [A⁻]'],['ha','Acid form [HA]']],fn:v=>v.pka&&v.a&&v.ha?'pH = '+(v.pka+Math.log10(v.a/v.ha)).toFixed(2):'',n:'pH = pKa + log([A⁻] / [HA])'},
 {id:'bl',t:'Beer–Lambert law',f:[['A','Absorbance'],['e','ε (L mol⁻¹ cm⁻¹)'],['l','Path length in cm (1 if blank)']],fn:v=>v.A&&v.e?'c = '+sci(v.A/(v.e*(v.l||1)))+' mol/L':'',n:'A = ε × c × l'}
];
const AM={H:1.008,He:4.0026,Li:6.94,B:10.81,C:12.011,N:14.007,O:15.999,F:18.998,Na:22.99,Mg:24.305,Al:26.982,Si:28.085,P:30.974,S:32.06,Cl:35.45,K:39.098,Ca:40.078,Mn:54.938,Fe:55.845,Co:58.933,Ni:58.693,Cu:63.546,Zn:65.38,Se:78.971,Br:79.904,Mo:95.95,Ag:107.868,I:126.904,Ba:137.327};
function fwGroup(s,i){let m=0;while(i<s.length&&s[i]!==')'){let x;if(s[i]==='('){const r=fwGroup(s,i+1);if(!r||s[r.i]!==')')return null;x=r.m;i=r.i+1}else{const e=/^[A-Z][a-z]?/.exec(s.slice(i));if(!e||!(e[0] in AM))return null;x=AM[e[0]];i+=e[0].length}const n=/^\d+/.exec(s.slice(i));if(n){x*=+n[0];i+=n[0].length}m+=x}return{m:m,i:i}}
function fw(str){let tot=0;for(const part of String(str).replace(/\s/g,'').split(/[.·*+]/)){if(!part)continue;const m=part.match(/^(\d+)(.+)$/),k=m?+m[1]:1,b=m?m[2]:part,r=fwGroup(b,0);if(!r||r.i!==b.length)return null;tot+=k*r.m}return tot||null}
const fwOut=t=>{if(!String(t||'').trim())return'';const m=fw(t);return m?'Molecular weight = '+m.toFixed(2)+' g/mol':'I could not read that formula. Write it like C6H12O6, Ca(OH)2 or CuSO4.5H2O.'};
const cvals=id=>{const o={},c=ui.cv[id]||{};Object.keys(c).forEach(k=>o[k]=num(c[k]));return o};
const CODE='FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG',B4='TCAG';
function seqInfo(raw){
  const s=String(raw||'').toUpperCase().replace(/[^A-Z]/g,'').replace(/U/g,'T');
  if(!s)return null;if(/[^ACGTN]/.test(s))return{err:true};
  const n=s.length,gc=(s.match(/[GC]/g)||[]).length,at=(s.match(/[AT]/g)||[]).length,cp={A:'T',T:'A',G:'C',C:'G',N:'N'};
  let p='';for(let i=0;i+2<n;i+=3){const a=B4.indexOf(s[i]),b=B4.indexOf(s[i+1]),c=B4.indexOf(s[i+2]);p+=a<0||b<0||c<0?'X':CODE[a*16+b*4+c]}
  return{n:n,gc:gc/n*100,tm:n<14?2*at+4*gc:64.9+41*(gc-16.4)/n,rc:s.split('').reverse().map(c=>cp[c]).join(''),rna:s.replace(/T/g,'U'),prot:p};
}
const seqOut=raw=>{const q=seqInfo(raw);if(!q)return'<p class="muted">Paste a DNA or RNA sequence above.</p>';if(q.err)return'<p class="muted">Only the letters A, C, G, T or U are allowed.</p>';
  return`<div class="g3">${stat(q.n,'bases')}${stat(q.gc.toFixed(1)+'%','GC content')}${stat(q.tm.toFixed(1)+'°C','Tm, estimate')}</div>`+[['Reverse complement (5′→3′)',q.rc],['mRNA',q.rna],['Protein, reading frame 1'+(q.prot?' · about '+sig(q.prot.replace(/\*/g,'').length*0.11)+' kDa':''),q.prot||'Needs at least 3 bases']].map(r=>`<p class="muted">${r[0]}</p><p class="seq">${r[1]}</p>`).join('')+`<p class="muted">Tm uses the Wallace rule under 14 bases and a GC-based formula above that. * marks a stop codon.</p>`};
const AA=[['Glycine','Gly','G',75.07,'n'],['Alanine','Ala','A',89.09,'n'],['Valine','Val','V',117.15,'n',1],['Leucine','Leu','L',131.17,'n',1],['Isoleucine','Ile','I',131.17,'n',1],['Proline','Pro','P',115.13,'n'],['Phenylalanine','Phe','F',165.19,'n',1],['Tryptophan','Trp','W',204.23,'n',1],['Methionine','Met','M',149.21,'n',1],['Serine','Ser','S',105.09,'p'],['Threonine','Thr','T',119.12,'p',1],['Cysteine','Cys','C',121.16,'p'],['Tyrosine','Tyr','Y',181.19,'p'],['Asparagine','Asn','N',132.12,'p'],['Glutamine','Gln','Q',146.15,'p'],['Aspartate','Asp','D',133.1,'a'],['Glutamate','Glu','E',147.13,'a'],['Lysine','Lys','K',146.19,'b',1],['Arginine','Arg','R',174.2,'b'],['Histidine','His','H',155.16,'b',1]];
const AAC={n:['Nonpolar','sun'],p:['Polar','sky'],a:['Acidic','tomato'],b:['Basic','grape']};
const BUF=[['Citrate','3.13, 4.76, 6.40'],['Acetate','4.76'],['MES','6.1'],['Bicarbonate','6.35'],['Phosphate (pKa₂)','7.21'],['HEPES','7.5'],['Tris','8.1'],['Glycine (amino group)','9.8']];
const NOTES=[['Autoclave','121 °C at 15 psi for 15 to 20 minutes.'],['Gram stain','Crystal violet 1 min, iodine 1 min, alcohol 10 to 20 s, safranin 30 to 60 s. Gram-positive stays purple, Gram-negative turns pink.'],['Countable plate','Use plates with 30 to 300 colonies.'],['PCR cycle','Denature at 94 to 95 °C, anneal at 50 to 65 °C, extend at 72 °C.'],['Disinfecting the bench','70% ethanol works better than 100%.'],['Glycerol stock','Mix culture with sterile glycerol to a final 15 to 25% and store at −80 °C.']];
let LT=[];try{LT=(JSON.parse(localStorage.getItem('catalyst.timers')||'[]')||[]).filter(x=>x&&x.end>Date.now())}catch(e){}
const ltSave=()=>{try{localStorage.setItem('catalyst.timers',JSON.stringify(LT))}catch(e){}};
const ltLeft=x=>{const s=Math.max(0,Math.round((x.end-Date.now())/1000));return(s>=3600?Math.floor(s/3600)+':':'')+pad(Math.floor(s%3600/60))+':'+pad(s%60)};
const LTP=[['Crystal violet',60],['Iodine',60],['Decolorise',15],['Safranin',45],['5 min',300],['10 min',600],['15 min',900],['30 min',1800],['1 hour',3600]];
setInterval(()=>{if(!LT.length)return;const now=Date.now(),doneL=LT.filter(x=>x.end<=now);
  if(doneL.length){LT=LT.filter(x=>x.end>now);ltSave();doneL.forEach(x=>toast({title:x.name+' is done',src:'Lab timer',t:hm(nowMin())}));if(ui.tab==='lab'||ui.tab==='today')render()}
  LT.forEach(x=>{const el=document.getElementById('lt_'+x.id);if(el)el.textContent=ltLeft(x)})},1000);
function vLab(){
  let o=sub('lab',SUB.lab);
  if(ui.lab==='calc'){
    o+=`<div class="card"><h3>Molecular weight from a formula</h3><label>Chemical formula<input data-calc="fw" data-k="f" value="${esc((ui.cv.fw||{}).f||'')}" placeholder="C6H12O6" autocapitalize="off" autocomplete="off" spellcheck="false"></label><p class="res" id="res_fw">${fwOut((ui.cv.fw||{}).f)}</p></div>`;
    o+=CALC.map(c=>{const cur=ui.cv[c.id]||{};return`<div class="card"><h3>${c.t}</h3>${c.sel?`<label>${c.sel[1]}<select data-calc="${c.id}" data-k="${c.sel[0]}">${c.sel[2].map(x=>`<option value="${x[0]}"${String(cur[c.sel[0]]||'')===x[0]?' selected':''}>${x[1]}</option>`).join('')}</select></label>`:''}${c.f.map(f=>`<label>${f[1]}<input inputmode="decimal" data-calc="${c.id}" data-k="${f[0]}" value="${esc(cur[f[0]]||'')}"></label>`).join('')}<p class="res" id="res_${c.id}">${esc(c.fn(cvals(c.id)))}</p><p class="muted">${c.n}</p></div>`}).join('');
  }
  if(ui.lab==='seq')o+=`<div class="card"><h2>Sequence tools</h2><label>DNA or RNA sequence<textarea data-calc="seq" data-k="s" placeholder="ATGGCCATTGTAATGGGCCGCTGA" autocapitalize="characters" autocomplete="off" spellcheck="false">${esc((ui.cv.seq||{}).s||'')}</textarea></label><div id="res_seq">${seqFull((ui.cv.seq||{}).s)}</div></div>
    <div class="card"><h3>Codon table</h3><p class="muted">Read first base down the left, second across the top. DNA letters; T is U in mRNA.</p><div class="codons"><span></span>${B4.split('').map(b=>`<b>${b}</b>`).join('')}${B4.split('').map((a,i)=>`<b>${a}</b>`+B4.split('').map((b,j)=>`<span>${B4.split('').map((c,k)=>a+b+c+' '+CODE[i*16+j*4+k]).join('<br>')}</span>`).join('')).join('')}</div></div>`;
  if(ui.lab==='ref')o+=`<div class="card"><h2>Amino acids</h2><p class="muted">Molecular weights are for the free amino acid. In a protein, count about 110 Da per residue. ★ marks the essential ones.</p><div class="list">${AA.map(a=>`<div class="item"><span class="pill col c-${AAC[a[4]][1]}" style="width:26px;text-align:center;padding:1px 0">${a[2]}</span><span class="t grow">${a[0]}${a[5]?' ★':''}<br><span class="muted">${a[1]} · ${AAC[a[4]][0]}</span></span><span class="muted">${a[3].toFixed(2)}</span></div>`).join('')}</div></div>
    <div class="card"><h2>Buffer pKa values</h2><p class="muted">Approximate, at 25 °C. A buffer works best within one pH unit of its pKa.</p><div class="list">${BUF.map(b=>`<div class="item"><span class="t grow">${b[0]}</span><span class="muted">${b[1]}</span></div>`).join('')}</div></div>
    <div class="card"><h2>Bench notes</h2><div class="list">${NOTES.map(n=>`<div class="item"><span class="grow"><b>${n[0]}</b><br><span class="muted">${n[1]}</span></span></div>`).join('')}</div><p class="muted">These are common textbook values. Your lab manual and instructor come first.</p></div>`;
  if(ui.lab==='timers')o+=`<div class="card">${head('Lab timers',addBtn('ltAdd','Custom'))}<p class="muted">Start several at once for staining, incubation or spinning. They ring while the app is open.</p><div class="chips" style="flex-wrap:wrap;overflow:visible">${LTP.map(p=>`<button class="chip" data-a="ltGo" data-n="${p[1]}" data-name="${p[0]}">${p[0]}${p[1]<300?' · '+p[1]+' s':''}</button>`).join('')}</div>${LT.length?'<div class="list">'+LT.map(x=>`<div class="item"><span class="t grow">${esc(x.name)}</span><span class="big" style="font-size:24px" id="lt_${x.id}">${ltLeft(x)}</span><button class="btn sm danger" data-a="ltStop" data-id="${x.id}" aria-label="Cancel timer">×</button></div>`).join('')+'</div>':'<p class="muted">No timer is running.</p>'}</div>`;
  if(ui.lab==='book')o+=`<div class="card">${head('Lab notebook',addBtn('nAdd','Entry',' data-ref="lab"'))}${noteList('lab')}<p class="muted">Write each practical as you do it: date, aim, samples, what you saw, result. Notes for a research project live inside that project in Study.</p></div>`;
  return o;
}
VIEWS.lab=()=>`<div class="banner b-sun">${ill(BAN.lab[1])}<div><b>${BAN.lab[2]}</b><span>${esc(BAN.lab[3]())}</span></div></div>`+vLab();
document.addEventListener('input',e=>{
  const t=e.target,id=t.dataset&&t.dataset.calc;
  if(id){(ui.cv[id]=ui.cv[id]||{})[t.dataset.k]=t.value;const r=document.getElementById('res_'+id);if(!r)return;if(id==='seq')r.innerHTML=seqFull(t.value);else if(id==='fw')r.textContent=fwOut(t.value);else{const c=CALC.find(c=>c.id===id);if(c)r.textContent=c.fn(cvals(id),ui.cv[id]||{})}}
  if(t.dataset&&t.dataset.fb){ui.fb[t.dataset.fb]=t.value;fbLinks()}
});
document.addEventListener('change',e=>{const t=e.target;if(t.dataset&&t.dataset.calc&&t.tagName==='SELECT'){(ui.cv[t.dataset.calc]=ui.cv[t.dataset.calc]||{})[t.dataset.k]=t.value;const r=document.getElementById('res_'+t.dataset.calc);const c=CALC.find(c=>c.id===t.dataset.calc);if(r&&c)r.textContent=c.fn(cvals(t.dataset.calc),ui.cv[t.dataset.calc]||{})}if(t.dataset&&t.dataset.fb){ui.fb[t.dataset.fb]=t.value;fbLinks()}});

/* ---------- deen extras ---------- */
const JUM=[['ghusl','Take a bath and wear clean clothes'],['kahf','Recite Surah Al-Kahf'],['durood','Send plenty of durood on the Prophet ﷺ'],['early','Go early for Jumu‘ah'],['dua','Make dua in the last hour before Maghrib']];
EXT.prayer=()=>{
  const t=today(),dow=new Date().getDay(),l=S.dhikr[t]||{},tips=[];let hd=0;
  hd=hijriDay();
  if(dow===1||dow===4)tips.push('Today is '+DAYSL[dow]+', a sunnah day to fast.');
  if(dow===0||dow===3)tips.push('Tomorrow is '+DAYSL[dow+1]+', a sunnah day to fast.');
  if(hd>=13&&hd<=15)tips.push('By the calendar this is one of the white days (13, 14, 15). Fasting them is sunnah. Confirm the date with your local moon sighting.');
  let o='';
  if(dow===5)o+=`<div class="card c-leaf star"><h2>Jumu‘ah Mubarak</h2><div class="list">${JUM.map(j=>`<div class="item">${chk(l['jum_'+j[0]],'jumTog',`data-id="${j[0]}"`,j[1])}<span class="t grow">${j[1]}</span></div>`).join('')}</div><p class="muted"><a href="https://quran.com/18" target="_blank" rel="noopener">Open Surah Al-Kahf</a></p></div>`;
  if(tips.length)o+=`<div class="card"><h3>Sunnah for today</h3>${tips.map(x=>`<p>${x}</p>`).join('')}</div>`;
  return o;
};
const _deen=VIEWS.deen;
VIEWS.deen=()=>`<p class="ar bism" lang="ar">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>`+_deen();

/* ---------- feedback ---------- */
const CREDIT=`App developed by <a href="https://www.facebook.com/share/1FQERoNhgz/" target="_blank" rel="noopener"><b>Md. Raihan Mehedi</b></a><span>Undergraduate Student, Department of Biochemistry &amp; Biotechnology, North South University</span>`;
const fbText=()=>'Feedback type: '+ui.fb.t+'\nFrom: '+(ui.fb.n||S.settings.name||'A user')+'\n\n'+ui.fb.m;
const fbSubject=()=>'Catalyst app feedback: '+ui.fb.t;
function fbLinks(){const a=document.getElementById('fbsend'),b=document.getElementById('fbmail');if(a)a.href=gm({to:FB_MAIL,su:fbSubject(),body:fbText()});if(b)b.href='mailto:'+FB_MAIL+'?subject='+encodeURIComponent(fbSubject())+'&body='+encodeURIComponent(fbText())}
EXT.feedback=()=>`<div class="card b-pink"><div class="row">${ill('mail')}<div class="grow"><h2>Help improve Catalyst</h2><p class="muted">Tell the developer what to add, change or fix.</p></div></div></div>
  <div class="card"><label>Your name<input data-fb="n" id="fb_n" value="${esc(ui.fb.n||S.settings.name||'')}" autocomplete="name"></label><label>What is it about?<select data-fb="t" id="fb_t">${['New feature','Change something','Something is broken','Other'].map(x=>`<option${ui.fb.t===x?' selected':''}>${x}</option>`).join('')}</select></label><label>Your feedback<textarea data-fb="m" id="fb_m" placeholder="What would make this app more useful for you?">${esc(ui.fb.m)}</textarea></label>
  <div class="row wrap"><a class="btn pri" id="fbsend" href="${gm({to:FB_MAIL,su:fbSubject(),body:fbText()})}" target="_blank" rel="noopener">Send with Gmail</a><a class="btn" id="fbmail" href="mailto:${FB_MAIL}?subject=${encodeURIComponent(fbSubject())}&body=${encodeURIComponent(fbText())}">Other mail app</a><button class="btn" data-a="fbCopy">Copy</button></div>${said('fb')}
  <p class="muted">Your mail app opens with the message written and addressed to <b>${FB_MAIL}</b>. Tap send there to deliver it. If nothing opens, copy the message and mail it to that address.</p></div>`;

Object.assign(A,{
  ltGo(d){LT.push({id:uid(),name:d.name,end:Date.now()+(+d.n)*1000});ltSave();render()},
  ltAdd(){form('Custom timer',[['name','What is it for?','text',{req:true,ph:'Incubation, centrifuge, water bath'}],['min','Minutes','number',R]],{},v=>{if(v.min>0){LT.push({id:uid(),name:v.name,end:Date.now()+v.min*60000});ltSave()}})},
  ltStop(d){LT=LT.filter(x=>x.id!==d.id);ltSave();render()},
  jumTog(d){const l=S.dhikr[today()]=S.dhikr[today()]||{},k='jum_'+d.id;if(l[k])delete l[k];else l[k]=1;save('dhikr');render()},
  fbCopy(){try{navigator.clipboard.writeText(fbText()).then(()=>say('fb','Copied. Paste it into a mail to '+FB_MAIL+'.'),()=>say('fb','Copying was blocked here.'))}catch(e){say('fb','Copying was blocked here.')}}
});
window.__v4={fw:fw,seqInfo:seqInfo,CALC:CALC,sci:sci};


/* ================= v5: personalisation, motion, celebration, richer lab ================= */
Object.assign(DEF_SET,{mode:'auto',motion:'full',big:0,intro:1,noRow:0,deenOff:0,tilesOff:{quran:1,food:1}});
normalize();
Object.assign(ui,{lcat:'All',cmode:'std',mt:{},rv:1000});
ILL.bowl='<path d="M6 24h36a18 18 0 0 1-36 0z" fill="var(--tomato)"/><path d="M18 17c0-4 4-4 4-8M27 17c0-4 4-4 4-8"/>';
ILL.scope='<path d="M19 8l8 4-9 18-8-4z" fill="var(--sky)"/><path d="M14 40h22M24 40V30M30 34a11 11 0 0 0 0-18"/><circle cx="14" cy="33" r="3" fill="var(--sun)"/>';
SUB.lab.splice(0,SUB.lab.length,['calc','Calculators'],['curve','Curves'],['microbe','Microbes'],['recipes','Recipes'],['seq','Sequence'],['ref','Reference'],['timers','Timers'],['book','Notebook']);
SUB.more.splice(SUB.more.length-1,0,['look','Personalise']);
MENU.find(g=>g[0]==='Lab')[1].splice(1,0,['lab','lab','curve','Standard curves','sun'],['lab','lab','microbe','Bacteria finder','sun'],['lab','lab','recipes','Media and buffers','sun']);
MENU[MENU.length-1][1].push(['more','more','look','Personalise','pink']);

/* ---------- look and feel ---------- */
function applyLook(){
  const s=S.settings,r=document.documentElement;let changed=false;
  if(s.mode==='light'||s.mode==='dark')r.dataset.mode=s.mode;else delete r.dataset.mode;
  r.dataset.motion=s.motion||'full';
  if(s.big)r.dataset.big='1';else delete r.dataset.big;
  try{localStorage.setItem('catalyst.intro',s.intro===0?'0':'1')}catch(e){}
  const i=NAV.findIndex(x=>x[0]==='deen');
  if(s.deenOff&&i>=0){NAV.splice(i,1);changed=true;if(ui.tab==='deen')ui.tab='today'}
  if(!s.deenOff&&i<0){NAV.splice(NAV.findIndex(x=>x[0]==='life'),0,['deen','Deen']);changed=true}
  return changed;
}
const _ar5=window.afterRender;
window.afterRender=function(){if(applyLook()){render();return}_ar5()};
const pick=(k,opts)=>`<div class="chips">${opts.map(x=>`<button class="chip${String(S.settings[k])===String(x[0])?' on':''}" data-a="setPick" data-k="${k}" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>`;
const TILES=[['water','Water'],['money','Money'],['tasks','Tasks'],['class','Next class'],['sleep','Sleep'],['habits','Habits'],['focus','Study time'],['exam','Exam, or medicine when sick'],['lab','Lab'],['quran','Quran'],['food','Meals']];
function homeTiles(){
  const t=today(),s=S.settings,d=new Date(),n=nowMin(),off=s.tilesOff||{},out=m=>m.type!=='in',ep=activeEp();
  const M={
    water:()=>tile('sky wave" style="--fill:'+Math.min(100,(S.water[t]||0)/s.waterGoal*100)+'%','drop',(S.water[t]||0)+'/'+s.waterGoal,'Water','life','life','water',`<button class="tplus" data-a="water" data-n="1" aria-label="Add one glass">+</button>`),
    money:()=>{const sp=S.money.filter(m=>m.date===t&&out(m)).reduce((a,m)=>a+m.amount,0),mo=S.money.filter(m=>m.date.slice(0,7)===t.slice(0,7)&&out(m)).reduce((a,m)=>a+m.amount,0);return tile('leaf','wallet',money(sp),s.budget?money(Math.max(0,s.budget-mo))+' left':'Spent today','life','life','money',`<button class="tplus" data-a="mAdd" aria-label="Add money entry">+</button>`)},
    tasks:()=>{const c=S.tasks.filter(x=>!x.done&&x.due&&x.due<=t).length;return tile('tomato','tasks',c,c?'Tasks due':'All clear','plan','plan','tasks')},
    class:()=>{const cls=S.routine.filter(r=>+r.day===d.getDay()).sort(byStart),nc=cls.find(r=>toMin(r.start)>=n);return tile('grape','book',nc?tfmt(nc.start).replace(/ ([AP])M/,'$1'):cls.length?'Done':'–',nc?rName(nc):cls.length?'Classes over':'No class today','plan','plan','routine')},
    sleep:()=>{const sl=S.sleep.find(l=>l.date===t);return tile('sun','moon',sl?dur(sleepMin(sl)).replace(' ',''):'–',sl?'Slept':'Sleep not logged','life','life','sleep')},
    habits:()=>{const hl=S.habitLog[t]||{};return tile('leaf','sprout',S.habits.filter(x=>hl[x.id]).length+'/'+S.habits.length,'Habits','life','life','habits')},
    focus:()=>tile('pink','timer',S.focus.filter(f=>f.date===t).reduce((a,f)=>a+f.min,0)+'m','Study time','study','study','timer'),
    exam:()=>{if(ep){const l=doses(ep,t).filter(x=>!x.taken).length;return tile('tomato','pill',l,l?'Doses left':'Medicine done','life','life','health')}const nx=S.exams.filter(e=>e.date>=t).sort((a,b)=>a.date<b.date?-1:1)[0];return tile('sun','exam',nx?diffDays(nx.date,t)+'d':'–',nx?nx.title:'No exam set','study','study','exams')},
    lab:()=>tile('grape','flask',LT.length||'Lab',LT.length?'Timers running':'Bench tools','lab','lab',LT.length?'timers':'calc'),
    quran:()=>tile('leaf','quran',(QN().log[t]||0)+'/'+s.qgoal,'Ayahs today','deen','deen','quran'),
    food:()=>tile('tomato','bowl',S.meals.filter(m=>m.date===t).length,'Meals logged','life','life','food')
  };
  return'<div class="tiles">'+TILES.filter(x=>!off[x[0]]&&!(x[0]==='quran'&&s.deenOff)).map(x=>M[x[0]]()).join('')+'</div>';
}
EXT.look=()=>{const s=S.settings,off=s.tilesOff||{};return`<div class="card"><h2>Appearance</h2><p class="muted">Light or dark</p>${pick('mode',[['auto','Match my phone'],['light','Light'],['dark','Dark']])}<p class="muted">Movement of icons and screens</p>${pick('motion',[['full','Lively'],['calm','Calm'],['off','Still']])}<p class="muted">Text size</p>${pick('big',[[0,'Normal'],[1,'Large']])}</div>
  <div class="card"><h2>Opening</h2><div class="list"><div class="item">${chk(s.intro!==0,'setFlag','data-id="intro" data-on="1"','Play the logo intro')}<span class="t grow">Play the logo intro when the app opens</span></div></div><button class="btn sm" data-a="welcome" style="align-self:flex-start">${ic('edit')}Change my name and details</button><button class="btn sm" data-a="obAgain" style="align-self:flex-start">Run the welcome setup again</button></div>
  <div class="card"><h2>Home screen</h2><p class="muted">Choose what appears on Today.</p><div class="list">${TILES.map(x=>`<div class="item">${chk(!off[x[0]],'tileTog',`data-id="${x[0]}"`,x[1])}<span class="t grow">${x[1]}</span></div>`).join('')}<div class="item">${chk(!s.noRow,'setFlag','data-id="noRow"','Prayer row')}<span class="t grow">Row of the five prayers</span></div></div></div>
  <div class="card"><h2>Sections</h2><div class="list"><div class="item">${chk(!s.deenOff,'setFlag','data-id="deenOff"','Deen section')}<span class="t grow">Show the Deen section<br><span class="muted">Turn off to hide prayers, Quran and duas everywhere.</span></span></div></div></div>`};
function celebrate(msg){
  toast({title:msg,src:'Well done',t:hm(nowMin())});
  if(S.settings.motion==='off')return;
  const box=document.createElement('div');box.className='confetti';
  box.innerHTML=Array.from({length:26},(x,i)=>`<i style="left:${(i*37)%100}%;background:var(--${COLORS[i%6]});animation-delay:${(i%9)*70}ms;animation-duration:${1400+(i%5)*220}ms"></i>`).join('');
  document.body.appendChild(box);setTimeout(()=>box.remove(),2800);
}
const _water=A.water,_prTog=A.prTog,_hDay=A.hDay;

/* ---------- more lab calculators ---------- */
const CAT={mol:'Solutions',dil:'Solutions',pct:'Solutions',hh:'Solutions',cfu:'Microbiology',na:'Molecular',rcf:'Molecular',bl:'Analysis'};
CALC.forEach(c=>{c.g=CAT[c.id]});
const UNIT={kg:['m',1e3],g:['m',1],mg:['m',1e-3],'µg':['m',1e-6],ng:['m',1e-9],L:['v',1],mL:['v',1e-3],'µL':['v',1e-6],M:['c',1],mM:['c',1e-3],'µM':['c',1e-6],nM:['c',1e-9]},UO=Object.keys(UNIT).map(u=>[u,u]);
CALC.push(
 {id:'conv',g:'Solutions',t:'Unit converter',sels:[['from','From',UO],['to','To',UO]],f:[['x','Value']],fn:(v,r)=>{const a=UNIT[r.from||'kg'],b=UNIT[r.to||'kg'];if(!r.x)return'';if(a[0]!==b[0])return'Pick two units of the same kind: mass, volume or concentration.';return sci(v.x*a[1]/b[1])+' '+(r.to||'kg')},n:'Mass kg to ng, volume L to µL, concentration M to nM.'},
 {id:'m2c',g:'Solutions',t:'mg/mL and molarity',f:[['mw','Molecular weight (g/mol)'],['mg','Concentration (mg/mL)'],['M','or concentration (M)']],fn:v=>!v.mw?'':v.mg?sci(v.mg/v.mw)+' M':v.M?sci(v.M*v.mw)+' mg/mL':'',n:'M = (mg/mL) ÷ MW'},
 {id:'ser',g:'Microbiology',t:'Serial dilution planner',f:[['f','Dilution each step (10 for ten-fold)'],['n','Number of tubes'],['v','Final volume in each tube (mL)']],fn:v=>{if(!(v.f>1&&v.n&&v.v))return'';const a=v.v/v.f,n=Math.min(12,Math.round(v.n));return'Put '+sig(v.v-a)+' mL of diluent in each of '+n+' tubes. Move '+sig(a)+' mL from the sample into tube 1, mix, then '+sig(a)+' mL from each tube to the next. Last tube is diluted '+sci(Math.pow(v.f,n))+' times.'},n:'Change tips between tubes and mix well each time.'},
 {id:'gen',g:'Microbiology',t:'Generation time',f:[['n0','Cells at the start (N₀)'],['n1','Cells at the end (N)'],['t','Time between them (minutes)']],fn:v=>{if(!(v.n0&&v.n1>v.n0&&v.t))return'';const n=Math.log2(v.n1/v.n0);return sig(n)+' generations. Generation time '+sig(v.t/n)+' min. Growth rate '+sig(n/(v.t/60))+' per hour.'},n:'n = log₂(N ÷ N₀), g = t ÷ n'},
 {id:'hemo',g:'Microbiology',t:'Haemocytometer cell count',f:[['c','Cells counted'],['q','Large squares counted'],['d','Dilution factor (1 if undiluted)']],fn:v=>v.c&&v.q?sci(v.c/v.q*(v.d||1)*1e4)+' cells/mL':'',n:'Each large square is 1 mm² × 0.1 mm deep, so × 10⁴ gives per mL.'},
 {id:'te',g:'Molecular',t:'Transformation efficiency',f:[['c','Colonies on the plate'],['ng','DNA used (ng)'],['fr','Fraction of the mix plated (0.1 for one tenth)']],fn:v=>v.c&&v.ng?sci(v.c/(v.ng*(v.fr||1))*1000)+' CFU per µg DNA':'',n:'colonies ÷ ng plated × 1000'},
 {id:'pcr',g:'Molecular',t:'PCR master mix',f:[['n','Number of reactions'],['v','Reaction volume (µL), usually 25'],['p','Each primer per reaction (µL)'],['t','Template per reaction (µL)']],fn:v=>{if(!(v.n&&v.v))return'';const k=v.n*1.1,p=v.p||1,t=v.t||1,w=v.v-v.v/2-2*p-t;if(w<0)return'Those volumes add up to more than the reaction volume.';return'For '+v.n+' reactions plus 10% spare: '+sig(v.v/2*k)+' µL 2× master mix, '+sig(p*k)+' µL forward primer, '+sig(p*k)+' µL reverse primer, '+sig(w*k)+' µL water. Put '+sig(v.v-t)+' µL in each tube, then add '+sig(t)+' µL template.'},n:'Assumes a ready 2× master mix. Follow your kit sheet if it differs.'},
 {id:'lig',g:'Molecular',t:'Ligation: how much insert',f:[['vn','Vector (ng)'],['vb','Vector size (bp)'],['ib','Insert size (bp)'],['r','Insert to vector ratio (3 for 3:1)']],fn:v=>v.vn&&v.vb&&v.ib?'Use '+sig(v.vn*v.ib/v.vb*(v.r||3))+' ng of insert.':'',n:'ng insert = ng vector × (insert bp ÷ vector bp) × ratio'}
);
const calcCard=c=>{const cur=ui.cv[c.id]||{},sels=c.sels||(c.sel?[c.sel]:[]);return`<details class="card calc" data-name="${esc((c.t+' '+c.g).toLowerCase())}"${Object.keys(cur).length?' open':''}><summary><span class="pill">${c.g}</span><h3>${c.t}</h3></summary>${sels.map(x=>`<label>${x[1]}<select data-calc="${c.id}" data-k="${x[0]}">${x[2].map(o=>`<option value="${o[0]}"${String(cur[x[0]]||'')===o[0]?' selected':''}>${o[1]}</option>`).join('')}</select></label>`).join('')}${c.f.map(f=>`<label>${f[1]}<input inputmode="decimal" data-calc="${c.id}" data-k="${f[0]}" value="${esc(cur[f[0]]||'')}"></label>`).join('')}<p class="res" id="res_${c.id}">${esc(c.fn(cvals(c.id),cur))}</p><p class="muted">${c.n}</p></details>`};

/* ---------- curves: standard curve and enzyme kinetics ---------- */
const parsePts=txt=>String(txt||'').split(/\n/).map(l=>(l.match(/-?\d*\.?\d+(?:e-?\d+)?/gi)||[]).map(Number)).filter(a=>a.length>=2).map(a=>[a[0],a[1]]);
function fit(pts){const n=pts.length;if(n<2)return null;let sx=0,sy=0,sxx=0,sxy=0,syy=0;pts.forEach(p=>{sx+=p[0];sy+=p[1];sxx+=p[0]*p[0];sxy+=p[0]*p[1];syy+=p[1]*p[1]});const d=n*sxx-sx*sx;if(!d)return null;const m=(n*sxy-sx*sy)/d,b=(sy-m*sx)/n,sst=syy-sy*sy/n,sse=pts.reduce((a,p)=>a+Math.pow(p[1]-(m*p[0]+b),2),0);return{m:m,b:b,r2:sst>0?1-sse/sst:1}}
function plot(pts,f,xl,yl){
  const xs=pts.map(p=>p[0]).concat(0),ys=pts.map(p=>p[1]).concat(0,f.b),x0=Math.min.apply(null,xs),x1=Math.max.apply(null,xs),y0=Math.min.apply(null,ys),y1=Math.max.apply(null,ys.concat(f.m*x1+f.b));
  const X=x=>34+(x-x0)/((x1-x0)||1)*250,Y=y=>150-(y-y0)/((y1-y0)||1)*132;
  return`<svg class="plot" viewBox="0 0 300 180" role="img" aria-label="Plot of the points and the fitted line"><path d="M34 12v138h256" fill="none" stroke="var(--muted)" stroke-width="1.5"/><path class="fitline" d="M${X(x0)} ${Y(f.m*x0+f.b)}L${X(x1)} ${Y(f.m*x1+f.b)}" fill="none" stroke="var(--grape)" stroke-width="3" stroke-linecap="round"/>${pts.map(p=>`<circle cx="${X(p[0]).toFixed(1)}" cy="${Y(p[1]).toFixed(1)}" r="4.5" fill="var(--tomato)" stroke="var(--ill)" stroke-width="1.5"/>`).join('')}<text x="162" y="174" text-anchor="middle" font-size="11" fill="var(--muted)">${xl}</text><text x="12" y="84" text-anchor="middle" font-size="11" fill="var(--muted)" transform="rotate(-90 12 84)">${yl}</text></svg>`;
}
function curveOut(){
  const c=ui.cv.curve||{},raw=parsePts(c.pts),lb=ui.cmode==='lb';
  if(raw.length<2)return`<p class="muted">Enter at least two points, one per line. Three or more gives a real check of the fit.</p>`;
  if(lb){const p=raw.filter(a=>a[0]>0&&a[1]>0).map(a=>[1/a[0],1/a[1]]),f=fit(p);if(!f||f.b<=0)return`<p class="muted">These points do not give a usable Lineweaver–Burk line. Check for zero or negative values.</p>`;
    return plot(p,f,'1 / [S]','1 / v')+`<div class="g3">${stat(sci(1/f.b),'Vmax')}${stat(sci(f.m/f.b),'Km')}${stat(f.r2.toFixed(4),'R²')}</div><p class="muted">Line: 1/v = ${sci(f.m)} × 1/[S] + ${sci(f.b)}. Vmax is in your v units, Km in your [S] units.</p>`}
  const f=fit(raw);if(!f)return`<p class="muted">All the x values are the same, so no line can be drawn.</p>`;
  const u=String(c.u||'').trim()===''?null:num(c.u);
  return plot(raw,f,'concentration (x)','reading (y)')+`<div class="g3">${stat(sci(f.m),'slope')}${stat(sci(f.b),'intercept')}${stat(f.r2.toFixed(4),'R²')}</div><p class="res">${u==null||!f.m?'':'Unknown concentration = '+sci((u-f.b)/f.m)}</p><p class="muted">y = ${sci(f.m)}x ${f.b<0?'−':'+'} ${sci(Math.abs(f.b))}${f.r2<0.98?'. R² is below 0.98, so re-check your standards.':''}</p>`;
}

/* ---------- bacteria finder ---------- */
const BT=[['gram','Gram'],['cat','Catalase'],['ox','Oxidase'],['ind','Indole'],['mr','Methyl red'],['vp','VP'],['cit','Citrate'],['ure','Urease'],['h2s','H₂S'],['lac','Lactose'],['mot','Motility']];
const ORG=[['Escherichia coli','Rod','-+-++----++'],['Klebsiella pneumoniae','Rod, capsule','-+---+++-+-'],['Enterobacter aerogenes','Rod','-+---++--++'],['Citrobacter freundii','Rod','-+--+-+v+v+'],['Salmonella enterica (non-typhoidal)','Rod','-+--+-+-+-+'],['Shigella species','Rod','-+-v+------'],['Proteus mirabilis','Rod, swarms on agar','-+--+vv++-+'],['Serratia marcescens','Rod, may be red','-+--v++v--+'],['Pseudomonas aeruginosa','Rod, green pigment','-++---+v--+'],['Staphylococcus aureus','Cocci in clusters','++--++v+-+-'],['Bacillus subtilis','Rod with spores','++v--++---+']];
function orgRank(){
  const picked=BT.map(t=>ui.mt[t[0]]||'');
  return ORG.map(o=>{let hit=0,miss=0;picked.forEach((p,i)=>{if(!p||o[2][i]==='v')return;if(p===o[2][i])hit++;else miss++});return{o:o,hit:hit,miss:miss}}).sort((a,b)=>(a.miss-b.miss)||(b.hit-a.hit));
}
/* ---------- recipes ---------- */
const REC=[['LB broth (Miller)','Autoclave. For LB agar add 15 g agar per litre.',[['Tryptone',10,'g'],['Yeast extract',5,'g'],['NaCl',10,'g']]],['Nutrient broth','For nutrient agar add 15 g agar per litre. pH about 7.',[['Peptone',5,'g'],['Beef extract',3,'g'],['NaCl',5,'g']]],['Peptone water','Autoclave before use.',[['Peptone',10,'g'],['NaCl',5,'g']]],['Normal saline, 0.85%','Used for dilutions of bacterial samples.',[['NaCl',8.5,'g']]],['PBS, 1×, pH 7.4','Adjust pH to 7.4 before making up the volume.',[['NaCl',8,'g'],['KCl',0.2,'g'],['Na₂HPO₄',1.44,'g'],['KH₂PO₄',0.24,'g']]],['TAE buffer, 50× stock','Dilute 1 in 50 to make 1× for gels.',[['Tris base',242,'g'],['Glacial acetic acid',57.1,'mL'],['0.5 M EDTA, pH 8.0',100,'mL']]],['TBE buffer, 10× stock','Dilute 1 in 10, or 1 in 20 for 0.5×.',[['Tris base',108,'g'],['Boric acid',55,'g'],['0.5 M EDTA, pH 8.0',40,'mL']]],['TE buffer','10 mM Tris, 1 mM EDTA, for storing DNA.',[['1 M Tris-HCl, pH 8.0',10,'mL'],['0.5 M EDTA, pH 8.0',2,'mL']]],['1 M Tris-HCl','Dissolve in less water, set the pH with HCl, then make up.',[['Tris base',121.1,'g']]],['0.5 M EDTA, pH 8.0','It dissolves only as the pH nears 8. Add NaOH slowly.',[['Na₂EDTA·2H₂O',186.1,'g']]],['Agarose gel, 1%','Dissolve in 1× TAE or TBE by heating. Use 0.8% for large DNA, 2% for small.',[['Agarose',10,'g']]],['70% ethanol from 95%','Make up to the final volume with distilled water.',[['95% ethanol',737,'mL']]]];
const LABT='Date: \nPractical: \n\nAim:\n\nPrinciple:\n\nMaterials:\n\nProcedure:\n\nObservation:\n\nResult:\n\nDiscussion:\n\nPrecautions:\n';
const _vLab4=vLab;
VIEWS.lab=()=>{
  const ban=`<div class="banner b-sun">${ill(ui.lab==='microbe'?'scope':ui.lab==='seq'?'dna':'flask')}<div><b>${BAN.lab[2]}</b><span>${esc(BAN.lab[3]())}</span></div></div>`;
  if(['seq','ref','timers'].includes(ui.lab))return ban+_vLab4()+(EXT['lab_'+ui.lab]?EXT['lab_'+ui.lab]():'');
  let o=ban+sub('lab',SUB.lab);
  if(ui.lab==='calc'){
    const cats=['All','Solutions','Microbiology','Molecular','Analysis'];
    o+=`<input data-c="labq" placeholder="Search calculators" aria-label="Search calculators"><div class="chips">${cats.map(x=>`<button class="chip${ui.lcat===x?' on':''}" data-a="lcat" data-v="${x}">${x}</button>`).join('')}</div>`;
    if(ui.lcat==='All'||ui.lcat==='Solutions')o+=`<details class="card calc" data-name="molecular weight formula solutions"${(ui.cv.fw||{}).f?' open':''}><summary><span class="pill">Solutions</span><h3>Molecular weight from a formula</h3></summary><label>Chemical formula<input data-calc="fw" data-k="f" value="${esc((ui.cv.fw||{}).f||'')}" placeholder="C6H12O6" autocapitalize="off" autocomplete="off" spellcheck="false"></label><p class="res" id="res_fw">${fwOut((ui.cv.fw||{}).f)}</p></details>`;
    o+=CALC.filter(c=>ui.lcat==='All'||c.g===ui.lcat).map(calcCard).join('')+`<p class="muted">Tap a calculator to open it. Results update as you type.</p>`;
  }
  if(ui.lab==='curve'){const c=ui.cv.curve||{};o+=`<div class="card"><h2>Fit a line to your data</h2><div class="chips">${[['std','Standard curve'],['lb','Enzyme kinetics'],['stats','Replicates']].map(x=>`<button class="chip${ui.cmode===x[0]?' on':''}" data-a="cmode" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><p class="muted">${ui.cmode==='stats'?'Paste your repeated readings to get the mean, standard deviation and more.':ui.cmode==='lb'?'Type substrate concentration and rate on each line. The app draws the Lineweaver–Burk plot and gives Km and Vmax.':'For Bradford, Lowry, DNS or any colour assay. Type concentration and absorbance on each line.'}</p><label>${ui.cmode==='lb'?'[S], v':ui.cmode==='stats'?'Your replicate readings':'Concentration, reading'}<textarea data-calc="curve" data-k="pts" inputmode="text" placeholder="${ui.cmode==='lb'?'1, 3.33\n2, 5.0\n4, 6.67\n8, 8.0':'0, 0.02\n0.2, 0.21\n0.4, 0.43\n0.8, 0.82'}" spellcheck="false">${esc(c.pts||'')}</textarea></label>${ui.cmode!=='std'?'':`<label>Reading of your unknown<input inputmode="decimal" data-calc="curve" data-k="u" value="${esc(c.u||'')}"></label>`}<div id="res_curve">${curveOut()}</div></div>`}
  if(ui.lab==='microbe'){const rk=orgRank(),any=BT.some(t=>ui.mt[t[0]]);o+=`<div class="card"><div class="row between"><h2>Bacteria finder</h2><button class="btn sm" data-a="mtReset">Clear</button></div><p class="muted">Tap each test you have done until it shows your result. The list below sorts itself by best match.</p><div class="mtests">${BT.map(t=>{const v=ui.mt[t[0]]||'';return`<button class="mt${v==='+'?' pos':v==='-'?' neg':''}" data-a="mtTog" data-id="${t[0]}" aria-label="${t[1]}: ${v==='+'?'positive':v==='-'?'negative':'not done'}"><b>${v||'?'}</b>${t[1]}</button>`}).join('')}</div></div>`+
    rk.map((r,i)=>`<div class="card${any&&i===0&&!r.miss&&r.hit?' c-leaf':''}"><div class="row between"><h3><i>${r.o[0]}</i></h3>${any?`<span class="pill">${r.hit} match${r.hit===1?'':'es'}${r.miss?', '+r.miss+' against':''}</span>`:''}</div><p class="muted">${r.o[1]}</p><div class="orow">${BT.map((t,j)=>`<span class="${r.o[2][j]==='+'?'pos':r.o[2][j]==='-'?'neg':''}${ui.mt[t[0]]&&r.o[2][j]!=='v'&&ui.mt[t[0]]!==r.o[2][j]?' no':''}">${t[1]} ${r.o[2][j]==='v'?'±':r.o[2][j]==='-'?'−':'+'}</span>`).join('')}</div></div>`).join('')+`<p class="muted">These are typical textbook reactions for common species. Strains vary (± means variable), and many bacteria are not listed. Confirm with Bergey’s Manual and your instructor before reporting an identification.</p>`}
  if(ui.lab==='recipes')o+=`<div class="card"><h2>Media and buffers</h2><label>Volume I want to make (mL)<input inputmode="decimal" data-c="rvol" value="${esc(ui.rv)}"></label><p class="muted">Amounts below change with the volume. Make up to the final volume with distilled water.</p></div>`+REC.map(r=>`<div class="card"><h3>${r[0]}</h3><div class="list">${r[2].map(x=>`<div class="item"><span class="t grow">${x[0]}</span><span class="t"><span data-amt="${x[1]}">${sig(x[1]*num(ui.rv)/1000)}</span> ${x[2]}</span></div>`).join('')}</div><p class="muted">${r[1]}</p></div>`).join('')+`<p class="muted">Standard recipes, entered by hand. Check against your lab manual before preparing.</p>`;
  if(ui.lab==='book')o+=`<div class="card">${head('Lab notebook',`<button class="btn sm pri" data-a="labNew">${ic('plus')}Practical</button>`)}${noteList('lab')}<p class="muted">Each new entry opens with the usual headings: aim, principle, materials, procedure, observation, result, discussion and precautions.</p></div>`;
  if(EXT['lab_'+ui.lab])o+=EXT['lab_'+ui.lab]();
  return o;
};
document.addEventListener('input',e=>{
  const t=e.target,d=t.dataset||{};
  if(d.calc==='curve'){const r=document.getElementById('res_curve');if(r)r.innerHTML=curveOut()}
  if(d.c==='labq'){const q=t.value.toLowerCase().trim();document.querySelectorAll('details.calc').forEach(x=>{x.style.display=!q||x.dataset.name.includes(q)?'':'none'})}
  if(d.c==='rvol'){ui.rv=t.value;const v=num(t.value);document.querySelectorAll('[data-amt]').forEach(x=>{x.textContent=sig(+x.dataset.amt*v/1000)})}
});
Object.assign(A,{
  setPick(d){S.settings[d.k]=d.k==='big'?+d.v:d.v;save('settings');render()},
  setFlag(d){const k=d.id;if(k==='intro')S.settings.intro=S.settings.intro===0?1:0;else S.settings[k]=S.settings[k]?0:1;save('settings');render()},
  tileTog(d){const o=Object.assign({},S.settings.tilesOff);if(o[d.id])delete o[d.id];else o[d.id]=1;S.settings.tilesOff=o;save('settings');render()},
  water(d){const t=today(),b=S.water[t]||0;_water(d);if(b<S.settings.waterGoal&&(S.water[t]||0)>=S.settings.waterGoal)celebrate('Water goal reached')},
  prTog(d){const b=PR.filter(p=>(S.prayers[d.d]||{})[p[0]]).length;_prTog(d);if(d.d===today()&&b<5&&PR.every(p=>(S.prayers[d.d]||{})[p[0]]))celebrate('All five prayers today')},
  hDay(d){_hDay(d);const l=S.habitLog[today()]||{};if(d.d===today()&&l[d.id]&&S.habits.length&&S.habits.every(h=>l[h.id]))celebrate('Every habit done today')},
  hTog(d){A.hDay({id:d.id,d:today()})},
  lcat(d){ui.lcat=d.v;render()},
  cmode(d){ui.cmode=d.v;render()},
  mtTog(d){const v=ui.mt[d.id]||'';ui.mt[d.id]=v===''?'+':v==='+'?'-':'';render()},
  mtReset(){ui.mt={};render()},
  labNew(){form('New practical',A.nFields,{title:'',body:LABT},v=>{const n=Object.assign({id:uid(),ref:'lab',updated:Date.now()},v);S.notes.push(n);save('n_'+n.id)})}
});
(function(){const sp=document.getElementById('splash');if(!sp||!sp.addEventListener)return;sp.addEventListener('click',()=>sp.remove());setTimeout(()=>{if(sp.parentNode)sp.remove()},3600)})();
window.__v5={fit:fit,parsePts:parsePts,orgRank:orgRank,ORG:ORG,BT:BT,REC:REC,applyLook:applyLook};


/* ================= v6: streak, photo, guidelines, money tools, bigger lab, offline sync, more motion ================= */
KEYS.push('streak','bills','billPaid','fv','protocols');OBJ.push('streak','billPaid','fv');
Object.assign(DEF_SET,{photo:'',income:0});
normalize();
Object.assign(ui,{pr:null,prDone:{}});
SUB.lab.splice(4,0,['tests','Test guide'],['protocols','Protocols']);
MENU.find(g=>g[0]==='Lab')[1].push(['lab','lab','tests','Test guide','sun'],['lab','lab','protocols','Protocols','sun']);
ILL.flame='<path d="M24 4c2 9 12 13 12 24a12 12 0 0 1-24 0c0-5 3-8 5-11 1 4 3 5 4 5 1-6 0-12 3-18z" fill="var(--tomato)"/><path d="M24 26c3 3 5 5 5 8a5 5 0 0 1-10 0c0-3 2-5 5-8z" fill="var(--sun)" stroke="none"/>';

/* ---------- sync when the phone comes back online ---------- */
const _ss=setStatus;
setStatus=function(){_ss();const el=$('#status');if(el&&typeof navigator!=='undefined'&&navigator.onLine===false){el.textContent='Offline · saved on phone';el.classList.add('warn')}};
const pushAll=()=>{if(col)[...dirty].forEach(k=>{tries[k]=0;flush(k)});setStatus()};
window.addEventListener('online',pushAll);window.addEventListener('offline',()=>setStatus());
setInterval(()=>{if(col&&dirty.size&&(typeof navigator==='undefined'||navigator.onLine!==false))pushAll()},60000);

/* ---------- profile photo ---------- */
const okPhoto=p=>typeof p==='string'&&p.indexOf('data:image/')===0;
const avatar=()=>`<label class="avatar avpick" title="Change my photo">${okPhoto(S.settings.photo)?`<img src="${esc(S.settings.photo)}" alt="">`:esc((S.settings.name||'C').trim().charAt(0).toUpperCase())}<input type="file" id="avup" accept="image/*" aria-label="Choose my photo"></label>`;
function readPhoto(file){return new Promise((res,rej)=>{const fr=new FileReader();fr.onerror=rej;fr.onload=()=>{const im=new Image();im.onerror=rej;im.onload=()=>{const c=document.createElement('canvas'),k=Math.max(160/im.width,160/im.height);c.width=c.height=160;c.getContext('2d').drawImage(im,(160-im.width*k)/2,(160-im.height*k)/2,im.width*k,im.height*k);res(c.toDataURL('image/jpeg',.82))};im.src=fr.result};fr.readAsDataURL(file)})}
document.addEventListener('change',e=>{const t=e.target;if(t.id==='avup'&&t.files.length)readPhoto(t.files[0]).then(u=>{S.settings.photo=u;save('settings');render()},()=>say('photo','That picture could not be read. Try a JPG or PNG.'))});

/* ---------- streak ---------- */
const ST=()=>{const s=S.streak;if(s.restores==null||s.restores>3)s.restores=3;s.count=s.count||0;s.best=s.best||0;return s};
function streakTick(){
  const s=ST(),t=today();if(s.paused||s.last===t)return;
  if(!s.last)s.count=1;else{const gap=diffDays(t,s.last);if(gap<1)return;if(gap===1)s.count++;else{s.lost={count:s.count,days:gap-1};s.count=1}}
  s.last=t;s.best=Math.max(s.best,s.count);save('streak');
  if([7,30,50,100,200,365].includes(s.count))setTimeout(()=>celebrate(s.count+'-day streak'),1500);
}
const flame=()=>`<svg class="ill flame" viewBox="0 0 48 48" aria-hidden="true">${ILL.flame}</svg>`;
const streakPill=()=>{const s=ST();return`<span class="pill stk">${flame()}${s.paused?'Paused':s.count+' day'+(s.count===1?'':'s')}</span>`};
function streakCard(){
  const s=ST();
  if(s.lost&&s.restores>0&&!s.paused)return`<div class="card c-sun"><div class="row">${flame()}<div class="grow"><h3>Your ${s.lost.count}-day streak slipped</h3><p class="muted">You missed ${s.lost.days} day${s.lost.days>1?'s':''}. You can bring it back ${s.restores} more time${s.restores>1?'s':''}.</p></div></div><div class="row wrap"><button class="btn pri" data-a="stRestore">Restore my streak</button><button class="btn" data-a="stFresh">Start fresh</button></div></div>`;
  return`<div class="card"><div class="row">${flame()}<div class="grow"><h3>${s.paused?'Streak paused at '+s.count+' day'+(s.count===1?'':'s'):s.count+'-day streak'}</h3><p class="muted">Best ${s.best} · ${s.restores} of 3 restores left. Open the app every day to keep it going.</p><p class="muted">Going on semester break? Tap Pause and your streak waits for you.</p></div><button class="btn sm" data-a="stPause">${s.paused?'Resume':'Pause'}</button></div>${s.paused?'<p class="muted">Paused for your break. Your streak is safe until you resume.</p>':''}</div>`;
}

/* ---------- guidelines for every Life section ---------- */
const GUIDE={
 water:['How much water?',['Adults need about 2.0 litres (women) to 2.5 litres (men) of water a day, counting all drinks and food. That is roughly 8 to 10 glasses.','Drink more in hot weather, when you exercise, and when you have fever or diarrhoea.','Pale yellow urine is a simple sign that you are drinking enough.'],'European Food Safety Authority (EFSA)'],
 food:['Eating well',['At least 400 g of fruit and vegetables a day, about 5 portions.','Less than 5 g of salt a day, about one teaspoon.','Free sugars under 10% of your energy, about 50 g or 12 teaspoons. Under 5% is better.','Fats under 30% of your energy. Prefer unsaturated fats.'],'World Health Organization (WHO), Healthy diet'],
 habits:['Building habits',['A new habit takes about 66 days on average to feel automatic. It ranged from 18 to 254 days in the study.','Missing one day does not undo your progress. Try not to miss two days in a row.','Start small and attach the habit to something you already do every day.'],'Lally and colleagues, European Journal of Social Psychology, 2010'],
 sleep:['How much sleep?',['Adults need 7 to 9 hours a night. Teenagers need 8 to 10.','Keep the same bedtime and wake time, even on weekends.','Avoid screens, heavy meals and caffeine close to bedtime.'],'American Academy of Sleep Medicine and National Sleep Foundation'],
 health:['When you are sick',['Take medicines exactly as prescribed. Follow your doctor on how long to take them.','Never take antibiotics without a prescription and never share them.','A temperature of 38 °C (100.4 °F) or more is a fever. See a doctor if it lasts more than three days, or sooner if you feel very unwell.','Rest and drink plenty of fluids.'],'WHO advice on antibiotics. Your doctor’s instructions always come first.'],
 acts:['How active should I be?',['Adults: 150 to 300 minutes of moderate activity a week, or 75 to 150 minutes of vigorous activity.','Add muscle-strengthening exercise on 2 or more days a week.','Sit less. Any movement is better than none.'],'World Health Organization (WHO), 2020 guidelines on physical activity'],
 money:['Managing money as a student',['A common rule is 50/30/20: about 50% on needs, 30% on wants and 20% saved.','Build an emergency fund that covers 3 to 6 months of basic costs.','Write down every expense for a month. Most people find one category they did not expect.'],'Widely used budgeting rules, not an official standard']
};
const guide=k=>{const g=GUIDE[k];return`<div class="card guide"><div class="row">${ill(k==='water'?'drop':k==='food'?'bowl':k==='sleep'?'moon':k==='habits'?'sprout':k==='health'?'pill':k==='money'?'wallet':'timer')}<div class="grow"><span class="pill">Guideline</span><h3>${g[0]}</h3></div></div><ul>${g[1].map(x=>`<li>${x}</li>`).join('')}</ul>${k==='water'?`<p>Your goal is ${S.settings.waterGoal} glasses of ${S.settings.glassMl} mL, which is <b>${(S.settings.waterGoal*S.settings.glassMl/1000).toFixed(1)} litres</b>.</p>`:''}<p class="muted">Source: ${g[2]}. General guidance for healthy adults, not personal medical advice.</p></div>`};
const NEEDS=['Food','Transport','Study','Mobile and internet','Health'];
const lifeExtra={
  acts:()=>{const d7=last7(),m=S.acts.filter(a=>d7.includes(a.date)).reduce((a,x)=>a+(+x.min||0),0);return`<div class="card c-pink"><div class="row between"><h3>Active minutes, last 7 days</h3><span class="pill">${m} / 150</span></div><div class="bar"><i style="width:${Math.min(100,m/150*100)}%"></i></div><p class="muted">${m>=150?'You have reached the weekly minimum.':'Add the minutes when you log an activity. '+(150-m)+' to go this week.'}</p></div>`},
  food:()=>{const n=S.fv[ui.foodDay]||0;return`<div class="card c-leaf"><div class="row between"><h3>Fruit and vegetables</h3><span class="pill">${n} / 5 portions</span></div><div class="bar"><i style="width:${Math.min(100,n/5*100)}%"></i></div><div class="row"><button class="btn sm" data-a="fvAdd" data-n="-1" aria-label="Remove one portion">−</button><button class="btn sm grow" data-a="fvAdd" data-n="1">${ic('plus')}I ate a portion</button></div><p class="muted">One portion is about a handful, or 80 g.</p></div>`},
  sleep:()=>{const got=last7().map(x=>S.sleep.find(l=>l.date===x)).filter(Boolean);if(!got.length)return'';const a=got.reduce((s,l)=>s+sleepMin(l),0)/got.length;return`<div class="card ${a>=420&&a<=540?'c-leaf':'c-sun'}"><h3>${a<420?'You are sleeping less than recommended':a>540?'You are sleeping more than the usual range':'Your sleep is in the healthy range'}</h3><p class="muted">Your 7-day average is ${dur(Math.round(a))}. The recommended range for adults is 7 to 9 hours.</p></div>`},
  money:()=>{
    const l=S.money.filter(m=>m.date.slice(0,7)===ui.month),inc=l.filter(m=>m.type==='in').reduce((a,m)=>a+m.amount,0)||num(S.settings.income),sp=l.filter(m=>m.type!=='in');
    const need=sp.filter(m=>NEEDS.includes(m.cat)).reduce((a,m)=>a+m.amount,0),want=sp.reduce((a,m)=>a+m.amount,0)-need,paid=S.billPaid[ui.month]||{},fixed=S.bills.reduce((a,b)=>a+(+b.amount||0),0);
    const row=(n,v,t)=>{const p=inc?v/inc*100:0;return`<div><div class="row between"><span class="t">${n}</span><span class="muted">${money(v)} · ${Math.round(p)}% of ${t}%</span></div><div class="bar"><i style="width:${Math.min(100,p/t*100)}%${p>t?';background:var(--bad)':''}"></i></div></div>`};
    let o=`<div class="card">${head('50 / 30 / 20 check',`<button class="btn sm" data-a="setIncome">${ic('edit')}Income</button>`)}${inc?row('Needs',need,50)+row('Wants',want,30)+row('Saved',Math.max(0,inc-need-want),20)+`<p class="muted">Based on ${money(inc)} received this month. Needs are food, transport, study, mobile and health. A full bar means you have reached that share.</p>`:'<p class="muted">Add what you receive each month, such as allowance or tuition income, to see how your spending splits into needs, wants and savings.</p>'}</div>`;
    o+=`<div class="card">${head('Monthly bills',addBtn('billAdd','Bill'))}${S.bills.length?`<div class="list">${S.bills.map(b=>`<div class="item${paid[b.id]?' done':''}">${chk(paid[b.id],'billTog',`data-id="${b.id}"`,'Paid')}<button class="tap" data-a="billEdit" data-id="${b.id}"><span class="t">${esc(b.name)}</span><span class="muted">${money(+b.amount||0)} · due on day ${+b.day||1}</span></button></div>`).join('')}</div><p class="muted">${money(fixed)} of fixed costs each month. Tick each one when you pay it and it is added to your spending. You get a reminder on the due day.</p>`:'<p class="muted">Rent, mess bill, internet, tuition instalment. Add them once and tick them off every month.</p>'}</div>`;
    o+=`<div class="card"><h3>Split a bill</h3><div class="row"><label class="grow">Total<input inputmode="decimal" data-c="split" id="sp_t"></label><label class="grow">People<input inputmode="numeric" data-c="split" id="sp_n"></label></div><p class="res" id="sp_r"></p></div>`;
    return o}
};
['water','food','habits','sleep','health','acts','money'].forEach(k=>{const f=EXT[k];EXT[k]=()=>(f?f():'')+(lifeExtra[k]?lifeExtra[k]():'')+guide(k)});
const _ag=agenda;
agenda=function(ds){const a=_ag(ds),paid=S.billPaid[ds.slice(0,7)]||{},dim=new Date(+ds.slice(0,4),+ds.slice(5,7),0).getDate();S.bills.forEach(b=>{if(Math.min(dim,+b.day||1)===+ds.slice(8)&&!paid[b.id])a.push({t:'09:00',title:'Pay '+b.name+' ('+money(+b.amount||0)+')',src:'Bill',key:'b-'+b.id})});return a.sort((x,y)=>x.t<y.t?-1:1)};

/* ---------- biochem bites: one for every day ---------- */
FACTS.push('Your body has about 30 trillion human cells and a similar number of bacteria living with them.','Red blood cells have no nucleus and live for about 120 days.','Catalase can break down millions of hydrogen peroxide molecules every second.','Proteins are built from 20 standard amino acids. Selenocysteine is often called the 21st.','Water makes up about 60% of an adult’s body weight.','Blood pH is held between 7.35 and 7.45, mainly by the bicarbonate buffer.','The DNA of any two people is about 99.9% identical.','Only about 1 to 2% of the human genome codes for proteins.','PCR was invented by Kary Mullis in 1983. It can copy one DNA molecule into billions within hours.','Green fluorescent protein (GFP) comes from the jellyfish Aequorea victoria.','Urease was the first enzyme to be crystallised, by James Sumner in 1926.','Watson and Crick described the double helix in 1953, using X-ray data from Rosalind Franklin.','One turn of B-DNA holds about 10.5 base pairs and is about 3.4 nm long.','A–T pairs have two hydrogen bonds and G–C pairs have three, so GC-rich DNA melts at a higher temperature.','The ribosome is a ribozyme: its peptide bonds are formed by RNA, not by protein.','Titin is the largest known human protein, with about 34,000 amino acids.','Collagen is the most abundant protein in the human body.','The Krebs cycle turns twice for every glucose molecule.','NADH absorbs light at 340 nm and NAD⁺ does not, which is how many enzyme assays are followed.','Lactose intolerance comes from low levels of the enzyme lactase.','Restriction enzymes are bacterial defences that cut foreign DNA at specific sequences.','EcoRI is named after Escherichia coli strain RY13.','Insulin has 51 amino acids in two chains joined by disulfide bonds.','The Human Genome Project was declared complete in 2003.','Dolly the sheep, born in 1996, was the first mammal cloned from an adult cell.','Golden Rice was engineered to make beta-carotene, which the body turns into vitamin A.','Bt crops carry a gene from Bacillus thuringiensis that makes a protein toxic to certain insects.','Agrobacterium tumefaciens naturally moves DNA into plant cells, and scientists use it to engineer plants.','Baker’s yeast was the first eukaryote to have its genome sequenced, in 1996.','An mRNA vaccine delivers instructions for a protein, and your own ribosomes make it.','Monoclonal antibodies were first made by Köhler and Milstein in 1975, using hybridoma cells.','Gram-positive bacteria hold the crystal violet stain because of their thick peptidoglycan wall.','Endospores of Bacillus and Clostridium survive boiling, which is why autoclaves run at 121 °C.','Your gut bacteria make vitamin K and some B vitamins.','Haemoglobin holds oxygen less tightly as pH falls. This is the Bohr effect.','Sickle cell disease comes from one amino acid change: glutamate to valine at position 6 of β-globin.','Phenylketonuria (PKU) results from a faulty phenylalanine hydroxylase enzyme.','Km is the substrate concentration at which an enzyme works at half its maximum speed.','A competitive inhibitor raises the apparent Km and leaves Vmax unchanged.','Alcohol is broken down mainly in the liver by alcohol dehydrogenase.','Brown fat makes heat using an uncoupling protein called thermogenin.','At rest the brain uses about 20% of the body’s energy, mostly from glucose.','Cholesterol is the starting material for steroid hormones, bile acids and vitamin D.','Insulin lowers blood glucose and glucagon raises it.','Luciferase, the enzyme that makes fireflies glow, is used in labs to measure ATP.','Thermus aquaticus was discovered in the hot springs of Yellowstone National Park.');

/* ---------- lab: more calculators ---------- */
CALC.push(
 {id:'stockm',g:'Solutions',t:'Molarity of a concentrated acid or base',f:[['p','Purity (% w/w)'],['d','Density (g/mL)'],['mw','Molecular weight (g/mol)']],fn:v=>v.p&&v.d&&v.mw?sig(v.p*v.d*10/v.mw)+' M':'',n:'M = % × density × 10 ÷ MW. HCl at 37% and 1.19 g/mL is about 12 M.'},
 {id:'norm',g:'Solutions',t:'Normality',f:[['m','Molarity (M)'],['n','H⁺ or OH⁻ per molecule (2 for H₂SO₄)']],fn:v=>v.m&&v.n?sig(v.m*v.n)+' N':'',n:'N = M × number of equivalents'},
 {id:'ppm',g:'Solutions',t:'Parts per million',f:[['mg','Solute (mg)'],['l','Solution volume (L)']],fn:v=>v.mg&&v.l?sig(v.mg/v.l)+' ppm (mg/L)':'',n:'For dilute water solutions, 1 ppm = 1 mg/L.'},
 {id:'dilf',g:'Solutions',t:'Dilution factor',f:[['s','Sample volume'],['d','Diluent volume']],fn:v=>v.s&&v.d?'1 in '+sig((v.s+v.d)/v.s)+' (dilution factor '+sig((v.s+v.d)/v.s)+')':'',n:'factor = (sample + diluent) ÷ sample'},
 {id:'od',g:'Microbiology',t:'OD600 to cell number (E. coli)',f:[['od','OD600 reading'],['df','Dilution factor (1 if undiluted)']],fn:v=>v.od?'About '+sci(v.od*(v.df||1)*8e8)+' cells/mL':'',n:'Rule of thumb: OD600 of 1.0 is about 8 × 10⁸ E. coli cells/mL. It differs between instruments and species.'},
 {id:'copies',g:'Molecular',t:'DNA copy number',f:[['ng','DNA amount (ng)'],['bp','Length (bp)']],fn:v=>v.ng&&v.bp?sci(v.ng*6.022e23/(v.bp*660*1e9))+' copies':'',n:'copies = ng × 6.022 × 10²³ ÷ (bp × 660 × 10⁹)'},
 {id:'oligo',g:'Molecular',t:'Dissolving a primer',f:[['n','Amount on the tube (nmol)'],['c','Stock you want (µM), usually 100']],fn:v=>v.n?'Add '+sig(v.n*1000/(v.c||100))+' µL of water or TE for a '+(v.c||100)+' µM stock.':'',n:'Dilute 1 in 10 for a 10 µM working stock.'},
 {id:'mm',g:'Analysis',t:'Michaelis–Menten rate',f:[['vm','Vmax'],['km','Km'],['s','Substrate [S]']],fn:v=>v.vm&&v.km&&v.s?'v = '+sig(v.vm*v.s/(v.km+v.s))+', which is '+Math.round(v.s/(v.km+v.s)*100)+'% of Vmax':'',n:'v = Vmax × [S] ÷ (Km + [S])'},
 {id:'ua',g:'Analysis',t:'Enzyme activity from an absorbance change',f:[['da','ΔA per minute'],['vt','Total assay volume (mL)'],['vs','Enzyme sample volume (mL)'],['e','ε (mM⁻¹ cm⁻¹), 6.22 for NADH'],['df','Dilution factor (1 if undiluted)']],fn:v=>v.da&&v.vt&&v.vs&&v.e?sig(v.da*v.vt*(v.df||1)/(v.e*v.vs))+' U/mL':'',n:'U/mL = ΔA/min × total volume × dilution ÷ (ε × path length 1 cm × sample volume)'},
 {id:'sa',g:'Analysis',t:'Specific activity and purification fold',f:[['u','Total activity (U)'],['p','Total protein (mg)'],['c','Specific activity of the crude extract (optional)']],fn:v=>v.u&&v.p?sig(v.u/v.p)+' U/mg'+(v.c?', purified '+sig(v.u/v.p/v.c)+'-fold':''):'',n:'specific activity = units ÷ mg protein'}
);
CALC.forEach(c=>{if(!c.g)c.g='Solutions'});

/* ---------- lab: sequence extras ---------- */
const RE=[['EcoRI','GAATTC'],['BamHI','GGATCC'],['HindIII','AAGCTT'],['XhoI','CTCGAG'],['NdeI','CATATG'],['NotI','GCGGCCGC'],['PstI','CTGCAG'],['SalI','GTCGAC'],['XbaI','TCTAGA'],['KpnI','GGTACC'],['SacI','GAGCTC'],['SmaI','CCCGGG'],['EcoRV','GATATC'],['NcoI','CCATGG'],['BglII','AGATCT']];
function seqMore(raw){
  const s=String(raw||'').toUpperCase().replace(/[^A-Z]/g,'').replace(/U/g,'T');if(!s||/[^ACGTN]/.test(s))return null;
  const sites=[];RE.forEach(r=>{const p=[];let i=s.indexOf(r[1]);while(i>=0){p.push(i+1);i=s.indexOf(r[1],i+1)}if(p.length)sites.push([r[0],r[1],p])});
  let best=null;for(let f=0;f<3;f++)for(let i=f;i+2<s.length;i+=3)if(s.substr(i,3)==='ATG')for(let j=i;j+2<s.length;j+=3){const c=s.substr(j,3);if(c==='TAA'||c==='TAG'||c==='TGA'){if(!best||j-i>best.len)best={start:i+1,end:j+3,len:j-i,frame:f+1};break}}
  return{sites:sites,orf:best};
}
function seqFull(raw){const q=seqMore(raw);if(!q)return seqOut(raw);
  return seqOut(raw)+`<p class="muted">Longest open reading frame</p><p class="seq">${q.orf?'Bases '+q.orf.start+' to '+q.orf.end+', frame '+q.orf.frame+', '+q.orf.len/3+' amino acids':'No ATG followed by a stop codon in the three forward frames'}</p><p class="muted">Restriction sites (15 common enzymes)</p>${q.sites.length?q.sites.map(x=>`<p class="seq">${x[0]} ${x[1]}: position ${x[2].join(', ')}</p>`).join(''):'<p class="seq">None of them cut this sequence</p>'}`}
const RM={G:57.05,A:71.08,S:87.08,P:97.12,V:99.13,T:101.1,C:103.14,L:113.16,I:113.16,N:114.1,D:115.09,Q:128.13,K:128.17,E:129.12,M:131.19,H:137.14,F:147.18,R:156.19,Y:163.18,W:186.21};
function protInfo(raw){const s=String(raw||'').toUpperCase().replace(/[^A-Z]/g,'');if(!s)return null;if([...s].some(c=>!RM[c]))return{err:true};let m=18.02;[...s].forEach(c=>m+=RM[c]);const n=c=>(s.match(new RegExp(c,'g'))||[]).length,e=5500*n('W')+1490*n('Y');return{n:s.length,mw:m,e:e,a:e/m}}
const protOut=raw=>{const p=protInfo(raw);if(!p)return'<p class="muted">Paste a protein sequence in one-letter code.</p>';if(p.err)return'<p class="muted">Use only the 20 standard one-letter amino acid codes.</p>';return`<div class="g3">${stat(p.n,'residues')}${stat((p.mw/1000).toFixed(2)+' kDa','molecular weight')}${stat(p.e||'–','ε at 280 nm')}</div><p class="muted">${p.e?'A 1 mg/mL solution should read about A280 = '+p.a.toFixed(2)+'. ':'No Trp or Tyr, so it barely absorbs at 280 nm. '}ε counts 5500 per Trp and 1490 per Tyr, in M⁻¹ cm⁻¹, with cysteines reduced.</p>`};
EXT.lab_seq=()=>`<div class="card"><h3>Protein from its sequence</h3><label>Protein sequence<textarea data-calc="prot" data-k="s" placeholder="MKWVTFISLLFLFSSAYS" autocapitalize="characters" autocomplete="off" spellcheck="false">${esc((ui.cv.prot||{}).s||'')}</textarea></label><div id="res_prot">${protOut((ui.cv.prot||{}).s)}</div></div>`;

/* ---------- lab: test guide, reference, protocols ---------- */
const TMIC=[['Catalase','Breaks down hydrogen peroxide','Bubbles at once with 3% H₂O₂'],['Oxidase','Cytochrome c oxidase','Purple within 10 to 30 seconds'],['Coagulase','Clots plasma','Clumping or a clot. Positive for Staphylococcus aureus'],['Indole','Tryptophan broken to indole','Red ring with Kovac’s reagent'],['Methyl red','Strong mixed-acid fermentation','Stays red after methyl red'],['Voges–Proskauer','Acetoin production','Pink to red with Barritt’s A and B'],['Citrate (Simmons)','Citrate as the only carbon source','Green slant turns blue'],['Urease','Urea split to ammonia','Yellow-orange turns bright pink'],['TSI or SIM, H₂S','Hydrogen sulfide production','Black precipitate'],['Nitrate reduction','Nitrate to nitrite','Red after reagents A and B'],['Starch hydrolysis','Amylase','Clear zone around growth after iodine'],['MacConkey agar','Lactose fermentation in Gram-negatives','Pink colonies ferment lactose, pale ones do not'],['Mannitol salt agar','Salt tolerance and mannitol use','Yellow zone for Staphylococcus aureus'],['Motility','Flagella','Growth spreads away from the stab line']];
const TBIO=[['Molisch','Any carbohydrate','Purple ring at the junction'],['Benedict','Reducing sugars','Green, yellow, then brick-red precipitate'],['Fehling','Reducing sugars','Red precipitate'],['Barfoed','Monosaccharides','Red precipitate within about 3 minutes'],['Seliwanoff','Ketoses such as fructose','Cherry red quickly'],['Bial','Pentoses','Blue-green'],['Iodine','Starch and glycogen','Blue-black for starch, red-brown for glycogen'],['Biuret','Peptide bonds (proteins)','Violet'],['Ninhydrin','Free amino acids','Purple. Proline gives yellow'],['Xanthoproteic','Aromatic amino acids','Yellow, turning orange with alkali'],['Millon','Tyrosine','Red'],['Sakaguchi','Arginine','Red'],['Hopkins–Cole','Tryptophan','Violet ring'],['Lead acetate','Sulfur amino acids','Black precipitate'],['Sudan III','Lipids','Red-stained droplets'],['Salkowski','Cholesterol','Red in the chloroform layer']];
const tlist=l=>`<div class="list">${l.map(x=>`<div class="item"><span class="grow"><b>${x[0]}</b><br><span class="muted">Detects: ${x[1]}</span><br>Positive: ${x[2]}</span></div>`).join('')}</div>`;
EXT.lab_tests=()=>`<input data-c="tq" placeholder="Search a test" aria-label="Search tests"><div class="card tg"><h2>Microbiology tests</h2>${tlist(TMIC)}</div><div class="card tg"><h2>Qualitative biochemistry tests</h2>${tlist(TBIO)}</div><p class="muted">Textbook colours and reactions. Reagents and timings differ between lab manuals, so follow yours.</p>`;
const RTAB=[['Wavelengths to read at',[['DNA and RNA','260 nm'],['Protein (direct)','280 nm'],['NADH and NADPH','340 nm'],['p-Nitrophenol','405 nm'],['DNS reducing sugar, Biuret','540 nm'],['BCA protein','562 nm'],['Bradford protein','595 nm'],['Bacterial culture density','600 nm'],['Lowry protein','750 nm']]],['Which micropipette',[['P10','0.5 to 10 µL'],['P20','2 to 20 µL'],['P200','20 to 200 µL'],['P1000','100 to 1000 µL']]],['Agarose gel strength',[['0.7%','0.8 to 12 kb'],['1.0%','0.5 to 10 kb'],['1.5%','0.2 to 3 kb'],['2.0%','0.1 to 2 kb']]],['SDS-PAGE gel strength',[['8%','about 25 to 200 kDa'],['10%','about 15 to 100 kDa'],['12%','about 10 to 70 kDa'],['15%','about 3 to 40 kDa']]]];
const SAFE=['Wear a lab coat, closed shoes and gloves. Tie back long hair.','No food, drink or phone on the bench.','Label every tube and plate with your name, date and contents.','Add acid to water, never water to acid.','Never pipette by mouth.','Flame loops before and after use, and work close to the flame.','Put used cultures and tips in the discard jar or biohazard bag for autoclaving.','If a chemical touches skin or eyes, rinse with running water for 15 minutes and tell your instructor.','Wash your hands before you leave the lab.'];
EXT.lab_ref=()=>RTAB.map(t=>`<div class="card"><h2>${t[0]}</h2><div class="list">${t[1].map(r=>`<div class="item"><span class="t grow">${r[0]}</span><span class="muted">${r[1]}</span></div>`).join('')}</div></div>`).join('')+`<div class="card c-tomato"><h2>Lab safety</h2><ul>${SAFE.map(x=>`<li>${x}</li>`).join('')}</ul></div><p class="muted">Ranges are approximate. Your lab’s own rules and manual come first.</p>`;
const PROTO=[{id:'p_gram',name:'Gram staining',steps:[['Prepare a thin smear and heat-fix it',0],['Flood with crystal violet',60],['Rinse gently with water',0],['Flood with Gram’s iodine',60],['Rinse with water',0],['Decolorise with 95% ethanol until the runoff is clear',15],['Rinse with water at once',0],['Counterstain with safranin',45],['Rinse, blot dry and view under oil immersion (100×)',0]]},{id:'p_spore',name:'Endospore staining',steps:[['Prepare a smear and heat-fix it',0],['Cover with malachite green and steam it, keeping it moist',300],['Cool, then rinse with water',0],['Counterstain with safranin',30],['Rinse, blot dry and view. Spores are green, cells are pink.',0]]},{id:'p_streak',name:'Streak plate for single colonies',steps:[['Label the base of the plate',0],['Flame the loop and let it cool',0],['Streak the sample over the first quadrant',0],['Flame, cool, then drag from quadrant 1 into quadrant 2',0],['Repeat for quadrants 3 and 4, flaming each time',0],['Incubate upside down at 37 °C for 18 to 24 hours',0]]},{id:'p_gel',name:'Agarose gel electrophoresis',steps:[['Dissolve agarose in 1× TAE or TBE by heating until clear',0],['Cool to about 55 °C and add the DNA stain',0],['Pour into the tray with the comb and let it set',1200],['Place in the tank and cover with running buffer',0],['Mix samples with loading dye. Load them beside a ladder',0],['Run at 80 to 120 V until the dye is two thirds down',2400],['View on the transilluminator with UV protection',0]]}];
const allProto=()=>PROTO.concat(S.protocols.map(p=>({id:p.id,name:p.name,mine:true,steps:String(p.steps||'').split('\n').map(l=>l.trim()).filter(Boolean).map(l=>{const a=l.split('|');return[a[0].trim(),Math.max(0,Math.round(num(a[1])))]})})));
const secs=n=>n>=60?(n%60?Math.floor(n/60)+' min '+n%60+' s':n/60+' min'):n+' s';
EXT.lab_protocols=()=>{
  const all=allProto(),p=all.find(x=>x.id===ui.pr);
  if(p){const dn=p.steps.filter((s,i)=>ui.prDone[i]).length;return`<button class="btn sm" data-a="prBack" style="align-self:flex-start">${ic('back')}Protocols</button><div class="card"><div class="row between"><h2>${esc(p.name)}</h2><span class="pill">${dn} / ${p.steps.length}</span></div><div class="bar"><i style="width:${p.steps.length?dn/p.steps.length*100:0}%"></i></div><div class="list">${p.steps.map((s,i)=>`<div class="item${ui.prDone[i]?' done':''}">${chk(ui.prDone[i],'prStep',`data-id="${i}"`,'Step '+(i+1))}<span class="t grow">${i+1}. ${esc(s[0])}</span>${s[1]?`<button class="btn sm" data-a="ltGo" data-n="${s[1]}" data-name="${esc(s[0].slice(0,40))}">${secs(s[1])}</button>`:''}</div>`).join('')}</div>${LT.length?'<div class="list">'+LT.map(x=>`<div class="item"><span class="t grow">${esc(x.name)}</span><span class="big" style="font-size:22px" id="lt_${x.id}">${ltLeft(x)}</span></div>`).join('')+'</div>':''}<p class="muted">Tick each step as you go. Tap a time to start its timer.${p.mine?'':' Timings follow common manuals. Use your own manual’s times if they differ.'}</p>${p.mine?`<button class="btn sm" data-a="prEdit" data-id="${p.id}" style="align-self:flex-start">${ic('edit')}Edit this protocol</button>`:''}</div>`}
  return`<div class="card">${head('Step-by-step protocols',addBtn('prAdd','My own'))}<p class="muted">Open one at the bench. It keeps your place and runs the timers.</p><div class="list">${all.map(x=>`<div class="item"><button class="tap" data-a="prOpen" data-id="${x.id}"><span class="t">${esc(x.name)}</span><span class="muted">${x.steps.length} steps${x.mine?' · mine':''}</span></button>${ic('next')}</div>`).join('')}</div></div>`};
const prF=[['name','Protocol name','text',R],['steps','Steps, one per line. Add | and seconds for a timed step','textarea',{req:true,tall:true,ph:'Add 500 µL lysis buffer\nIncubate at 65 °C | 600\nCentrifuge at 12000 × g | 300'}]];

/* ---------- curve tab: replicate statistics ---------- */
const _curveOut=curveOut;
curveOut=function(){
  if(ui.cmode!=='stats')return _curveOut();
  const x=(String((ui.cv.curve||{}).pts||'').match(/-?\d*\.?\d+(?:e-?\d+)?/gi)||[]).map(Number),n=x.length;
  if(n<2)return'<p class="muted">Type at least two readings, separated by spaces, commas or new lines.</p>';
  const m=x.reduce((a,b)=>a+b,0)/n,sd=Math.sqrt(x.reduce((a,b)=>a+(b-m)*(b-m),0)/(n-1));
  return`<div class="g3">${stat(n,'readings')}${stat(sci(m),'mean')}${stat(sci(sd),'SD')}${stat(sci(sd/Math.sqrt(n)),'SEM')}${stat(m?(sd/Math.abs(m)*100).toFixed(1)+'%':'–','CV')}${stat(sci(Math.min.apply(null,x))+' to '+sci(Math.max.apply(null,x)),'range')}</div><p class="res">Report as ${sci(m)} ± ${sci(sd)} (mean ± SD, n = ${n})</p><p class="muted">SD uses n − 1. A CV above about 10% between replicates usually means a pipetting or mixing problem.</p>`;
};

Object.assign(A,{
  stRestore(){const s=ST();if(s.lost&&s.restores>0){s.count=s.lost.count+1;s.restores--;delete s.lost;s.best=Math.max(s.best,s.count);save('streak');celebrate('Streak restored: '+s.count+' days')}render()},
  stFresh(){delete ST().lost;save('streak');render()},
  stPause(){const s=ST();if(s.paused){s.paused=0;s.last=today();if(!s.count)s.count=1}else s.paused=1;save('streak');render()},
  photoOff(){S.settings.photo='';save('settings');render()},
  fvAdd(d){S.fv[ui.foodDay]=Math.max(0,(S.fv[ui.foodDay]||0)+(+d.n));save('fv');render()},
  setIncome(){form('Monthly income',[['income','What I receive each month','number']],S.settings,v=>{S.settings.income=v.income;save('settings')})},
  billF:[['name','Bill','text',{req:true,ph:'Rent, mess, internet'}],['amount','Amount','number',R],['day','Due on day of month','number',R]],
  billAdd(){form('New monthly bill',A.billF,{day:1},v=>{v.day=Math.min(31,Math.max(1,Math.round(v.day)));upsert('bills',null,v)})},
  billEdit(d){const b=S.bills.find(x=>x.id===d.id);form('Edit bill',A.billF,b,v=>{v.day=Math.min(31,Math.max(1,Math.round(v.day)));upsert('bills',b.id,v)},()=>remove('bills',b.id))},
  billTog(d){const p=S.billPaid[ui.month]=S.billPaid[ui.month]||{},b=S.bills.find(x=>x.id===d.id);if(p[d.id])delete p[d.id];else{p[d.id]=1;if(b&&ui.month===today().slice(0,7)){S.money.push({id:uid(),date:today(),amount:+b.amount||0,type:'out',cat:'Other',note:b.name});save('money')}}save('billPaid');render()},
  prOpen(d){ui.pr=d.id;ui.prDone={};render();window.scrollTo(0,0)},
  prBack(){ui.pr=null;render()},
  prStep(d){ui.prDone[d.id]=!ui.prDone[d.id];render();if(Object.keys(ui.prDone).length&&allProto().find(x=>x.id===ui.pr).steps.every((s,i)=>ui.prDone[i]))celebrate('Protocol finished')},
  prAdd(){form('My protocol',prF,{},v=>upsert('protocols',null,v))},
  prEdit(d){const p=S.protocols.find(x=>x.id===d.id);form('Edit protocol',prF,p,v=>upsert('protocols',p.id,v),()=>{remove('protocols',p.id);ui.pr=null})}
});
document.addEventListener('input',e=>{
  const t=e.target,d=t.dataset||{};
  if(d.calc==='prot'){const r=document.getElementById('res_prot');if(r)r.innerHTML=protOut(t.value)}
  if(d.c==='tq'){const q=t.value.toLowerCase().trim();document.querySelectorAll('.tg .item').forEach(x=>{x.style.display=!q||x.textContent.toLowerCase().includes(q)?'':'none'})}
  if(d.c==='split'){const a=num((document.getElementById('sp_t')||{}).value),n=Math.round(num((document.getElementById('sp_n')||{}).value)),r=document.getElementById('sp_r');if(r)r.textContent=a>0&&n>0?'Each person pays '+money(Math.ceil(a/n))+(Math.ceil(a/n)*n-a>0?' ('+money(Math.ceil(a/n)*n-a)+' extra in total)':''):''}
});

/* ---------- motion: slide between tabs, numbers that count up ---------- */
let lastTabI=0,stDay='';
function countUp(){
  if(S.settings.motion==='off'||typeof requestAnimationFrame!=='function')return;
  document.querySelectorAll('#view .tile b,#view .big').forEach(el=>{
    const node=el.firstChild;if(!node||node.nodeType!==3)return;const m=/^(\D*?)(\d+)(.*)$/.exec(node.nodeValue);if(!m)return;const n=+m[2];if(n<2||n>99999)return;
    const t0=performance.now();(function step(now){const k=Math.min(1,(now-t0)/650),v=Math.round(n*(1-Math.pow(1-k,3)));node.nodeValue=m[1]+v+m[3];if(k<1)requestAnimationFrame(step)})(t0);
  });
}
const _ar6=window.afterRender;
window.afterRender=function(){
  if(cloud!=='loading'&&stDay!==today()){stDay=today();const b=JSON.stringify(S.streak);streakTick();if(JSON.stringify(S.streak)!==b){render();return}}
  const v=$('#view'),prev=lastKey;
  _ar6();
  const n=NAV.findIndex(x=>x[0]===ui.tab),i=n<0?99:n;
  if(v&&lastKey!==prev){v.classList.toggle('sr',i>lastTabI);v.classList.toggle('sl',i<lastTabI);countUp()}
  lastTabI=i;
};
const _look=EXT.look;
EXT.look=()=>`<div class="card"><h2>My photo</h2><div class="row">${avatar()}<div class="grow"><p class="muted">Tap the circle to choose a picture from your gallery. It shows at the top of the menu.</p>${okPhoto(S.settings.photo)?`<button class="btn sm" data-a="photoOff">Remove photo</button>`:''}</div></div>${said('photo')}</div>`+_look()+streakCard();
window.__v6={streakTick:streakTick,ST:ST,seqMore:seqMore,protInfo:protInfo,allProto:allProto,FACTS:FACTS,GUIDE:GUIDE};


/* ================= v7: cleaner top, soft edges, illustrated first-run setup, tap effects ================= */
ILL.cake='<rect x="8" y="24" width="32" height="18" rx="4" fill="var(--pink)"/><path d="M8 33c4 3 7-3 11 0s7-3 11 0 7-3 10 0M24 24v-7"/><path d="M24 7c2 3 3 4 3 5.500a3 3 0 0 1-6 0c0-1.500 1-2.500 3-5.500z" fill="var(--sun)"/>';
ILL.face='<circle cx="24" cy="24" r="18" fill="var(--sun)"/><circle cx="18" cy="21" r="1.600" fill="var(--ill)"/><circle cx="30" cy="21" r="1.600" fill="var(--ill)"/><path d="M17 29c4 4 10 4 14 0"/>';
const HM=['Muharram','Safar','Rabi‘ I','Rabi‘ II','Jumada I','Jumada II','Rajab','Sha‘ban','Ramadan','Shawwal','Dhul Qa‘dah','Dhul Hijjah'];
function hijriParts(){try{const p={};new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn',{day:'numeric',month:'numeric',year:'numeric'}).formatToParts(new Date()).forEach(x=>{p[x.type]=x.value});const m=+p.month,d=+p.day,y=parseInt(p.year,10);return m>=1&&m<=12&&d>=1&&d<=30&&y>1300&&y<1600?{d:d,m:m,y:y}:null}catch(e){return null}}
hijri=function(){const p=hijriParts();return p?p.d+' '+HM[p.m-1]+' '+p.y+' AH':''};
const hijriDay=()=>{const p=hijriParts();return p?p.d:0};

skyHero=function(){
  const t=today(),pt=ptimes(t),n=nowMin(),fj=toMin(pt.fajr),sr=toMin(pt.sunrise),mg=toMin(pt.maghrib),is=toMin(pt.isha),s=S.settings,h=new Date().getHours();
  const ph=n<fj||n>=is?'night':n<sr?'dawn':n<mg-45?'day':'dusk',G={night:['#10143F','#2C2F7A'],dawn:['#6F62D0','#FFB48A'],day:['#4DB4FF','#D4F0FF'],dusk:['#5546BD','#FF9A62']}[ph];
  const up=n>=sr&&n<mg,fr=up?(n-sr)/(mg-sr):((n-mg+1440)%1440)/(sr+1440-mg),x=186+146*fr,y=98-74*Math.sin(Math.PI*fr),dark=ph!=='day',bd=bday();
  let arc='';for(let i=0;i<=20;i++)arc+=(i?'L':'M')+(186+146*i/20).toFixed(1)+' '+(98-74*Math.sin(Math.PI*i/20)).toFixed(1);
  const stars=ph==='night'||ph==='dusk'?[[176,20],[214,46],[250,16],[292,40],[336,22],[150,58],[322,66]].map((p,i)=>`<circle class="star" style="animation-delay:${i*.35}s" cx="${p[0]}" cy="${p[1]}" r="1.800" fill="#fff"/>`).join(''):'';
  const clouds=ph==='day'||ph==='dawn'?`<g class="cloud" fill="#fff" opacity=".9"><ellipse cx="226" cy="58" rx="19" ry="7.500"/><ellipse cx="240" cy="52" rx="12" ry="7.500"/><ellipse cx="318" cy="34" rx="13" ry="5.500"/></g>`:'';
  const orb=up?`<g class="orb"><circle cx="${x}" cy="${y}" r="19" fill="#FFD23F" opacity=".35"/><circle cx="${x}" cy="${y}" r="12" fill="#FFD23F"/></g>`:`<g class="orb"><circle cx="${x}" cy="${y}" r="11" fill="#FFF3C4"/><circle cx="${x-3.500}" cy="${y-3}" r="2.200" fill="#E3D49A"/><circle cx="${x+4}" cy="${y+3.500}" r="1.600" fill="#E3D49A"/></g>`;
  const conf=bd===0?['#FF6B5E','#FFC83A','#3DCB82','#FF8CC3','#fff'].map((c,i)=>`<circle class="star" style="animation-delay:${i*.2}s" cx="${170+i*38}" cy="${24+(i%2)*22}" r="4" fill="${c}"/>`).join(''):'';
  const svg=`<svg viewBox="0 0 360 150" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="skg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${G[0]}"/><stop offset="1" stop-color="${G[1]}"/></linearGradient></defs><rect width="360" height="150" fill="url(#skg)"/>${stars}${clouds}<path d="${arc}" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="2" stroke-dasharray="2 7" stroke-linecap="round"/>${orb}${conf}
    <path d="M0 150v-24c40-13 84-13 124-4s92 11 132-2 76-8 104 4v26z" fill="${dark?'#1F8A5B':'#3DCB82'}"/>
    <path d="M249 127h10M249 115h10M249 101h10M249 89h10" stroke="#fff" stroke-opacity=".8" stroke-width="2" stroke-linecap="round"/><g fill="none" stroke-linecap="round" stroke-width="4"><path d="M246 134c0-13 16-13 16-26s-16-13-16-26" stroke="#A58BFF"/><path d="M262 134c0-13-16-13-16-26s16-13 16-26" stroke="#FFC83A"/></g>
    <g stroke="#fff" stroke-width="2.200" stroke-linejoin="round" stroke-linecap="round"><path d="M298 78h22M302 78v18l-17 28a5 5 0 0 0 4 8h40a5 5 0 0 0 4-8l-17-28V78z" fill="${dark?'#CFC8F7':'#F4F1FF'}"/><path d="M291 112h36l6 12a5 5 0 0 1-4 8h-40a5 5 0 0 1-4-8z" fill="#FF8CC3"/></g>
    <circle class="bubble" cx="305" cy="122" r="2.400" fill="#fff"/><circle class="bubble" style="animation-delay:.9s" cx="314" cy="124" r="1.800" fill="#fff"/><circle class="bubble" style="animation-delay:1.700s" cx="309" cy="120" r="2" fill="#fff"/></svg>`;
  const hi=bd===0?'Happy birthday':h<5?'Peaceful night':h<12?'Good morning':h<17?'Good afternoon':h<21?'Good evening':'Good night';
  return`<div class="sky ${ph}">${svg}<div class="skytext"><p>${hi}</p><h1>${esc(s.name||'Welcome')}</h1><p class="skydate">${fmt(t)}${bd&&bd<=7?' · birthday in '+bd+' day'+(bd>1?'s':''):''}</p></div>${streakPill()}</div>`;
};

/* ---------- first-run setup, one friendly question at a time ---------- */
let ob=null;
const OB=[
 {ill:'logo',c:'sun',t:'Welcome to Catalyst',p:'Small steps, big reactions. Answer a few quick questions and the app sets itself up for you.'},
 {ill:'face',c:'pink',t:'What should we call you?',p:'Add a photo too if you like. Tap the circle.',f:[['name','Your name','text']],photo:1},
 {ill:'cake',c:'tomato',t:'When is your birthday?',p:'The app will greet you on the day. You can leave this empty.',f:[['dob','Date of birth','date']]},
 {ill:'book',c:'grape',t:'Your studies',p:'Optional. Type your current CGPA and completed credits and you will never need to enter old semesters.',f:[['cgBase','Current CGPA','number'],['cgCred','Credits completed','number']]},
 {ill:'mosque',c:'leaf',t:'Where do you live?',p:'Your city sets the prayer times and the sky on the home screen.',f:[['city','City','select',Object.keys(CITY)],['asr','Asr time','select',['Hanafi','Shafi']]],deen:1},
 {ill:'drop',c:'sky',t:'Your daily health goals',p:'Adults need about 2 to 2.5 litres of water and 7 to 9 hours of sleep.',f:[['waterGoal','Glasses of water a day','number'],['sleepBed','Usual bedtime','time'],['sleepWake','Usual wake-up time','time']]},
 {ill:'flask',c:'grape',t:'Make it yours',p:'Pick a look. You can change it any time in Personalise.',look:1}
];
function obStart(){
  const s=S.settings;
  ob={i:0,back:false,err:'',v:{name:s.name||'',dob:s.dob||'',cgBase:s.cgBase||'',cgCred:s.cgCred||'',city:CITY[s.city]?s.city:'Dhaka',asr:s.asr,waterGoal:s.waterGoal,sleepBed:s.sleepBed,sleepWake:s.sleepWake,mode:s.mode,motion:s.motion,deenOff:s.deenOff?1:0}};
  ob.el=document.createElement('div');ob.el.id='onb';document.body.appendChild(ob.el);obDraw();
}
function obDraw(){
  if(!ob)return;const st=OB[ob.i],v=ob.v,last=ob.i===OB.length-1;
  const fld=f=>`<label>${f[1]}${f[2]==='select'?`<select data-ob="${f[0]}">${f[3].map(o=>`<option${String(v[f[0]])===o?' selected':''}>${o}</option>`).join('')}</select>`:`<input data-ob="${f[0]}" type="${f[2]==='number'?'text':f[2]}"${f[2]==='number'?' inputmode="decimal"':''} value="${esc(v[f[0]])}"${f[0]==='name'?' autocomplete="given-name"':''}>`}</label>`;
  const opt=(k,l)=>`<div class="chips">${l.map(x=>`<button class="chip${v[k]===x[0]?' on':''}" data-a="obPick" data-k="${k}" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>`;
  ob.el.innerHTML=`<div class="obc"><div class="obtop"><div class="obdots">${OB.map((x,i)=>`<i class="${i<=ob.i?'on':''}"></i>`).join('')}</div><button class="btn sm" data-a="obSkip">Skip</button></div>
    <div class="obstep ${ob.back?'bk':''}"><div class="obart b-${st.c}"><span class="obb1"></span><span class="obb2"></span><span class="obb3"></span>${st.ill==='logo'?'<img src="logo.png" alt="">':ill(st.ill)}</div>
    <h1>${st.t}</h1><p class="muted">${st.p}</p>
    ${st.photo?`<div class="row">${avatar()}<span class="muted">Tap to add your photo</span></div>`:''}
    ${(st.f||[]).map(fld).join('')}
    ${st.deen?`<div class="item">${chk(!v.deenOff,'obDeen','','Deen section')}<span class="t grow">Show prayers, Quran and duas</span></div>`:''}
    ${st.look?`<p class="muted">Light or dark</p>${opt('mode',[['auto','Match my phone'],['light','Light'],['dark','Dark']])}<p class="muted">Movement</p>${opt('motion',[['full','Lively'],['calm','Calm'],['off','Still']])}`:''}
    ${ob.err?`<p style="color:var(--bad)" role="alert">${ob.err}</p>`:''}</div>
    <div class="row obnav">${ob.i?`<button class="btn" data-a="obBack">${ic('back')}Back</button>`:''}<button class="btn pri grow" data-a="obNext">${last?'Start using Catalyst':ob.i?'Next':'Let’s begin'}</button></div></div>`;
}
function obDone(){
  const v=ob.v,s=S.settings;
  Object.assign(s,{name:String(v.name).trim(),dob:v.dob,cgBase:Math.min(4,num(v.cgBase)),cgCred:num(v.cgCred),city:v.city,asr:v.asr,waterGoal:Math.max(1,Math.round(num(v.waterGoal))||8),sleepBed:v.sleepBed||'23:30',sleepWake:v.sleepWake||'06:30',mode:v.mode,motion:v.motion,deenOff:v.deenOff?1:0,setup:1});
  if(CITY[v.city]){s.lat=CITY[v.city][0];s.lng=CITY[v.city][1]}
  save('settings');ob.el.remove();ob=null;render();celebrate('Welcome, '+s.name);
}
const _welcome=A.welcome;
Object.assign(A,{
  welcome(){if(S.settings.setup)_welcome();else if(!ob)obStart()},
  obNext(){if(OB[ob.i].photo&&!String(ob.v.name).trim()){ob.err='Please type your name.';obDraw();return}ob.err='';ob.back=false;if(ob.i===OB.length-1){obDone();return}ob.i++;obDraw()},
  obBack(){ob.err='';ob.back=true;ob.i=Math.max(0,ob.i-1);obDraw()},
  obSkip(){ob.el.remove();ob=null},
  obPick(d){ob.v[d.k]=d.v;const r=document.documentElement;if(d.k==='mode'){if(d.v==='auto')delete r.dataset.mode;else r.dataset.mode=d.v}if(d.k==='motion')r.dataset.motion=d.v;obDraw()},
  obDeen(){ob.v.deenOff=ob.v.deenOff?0:1;obDraw()},
  obAgain(){if(!ob)obStart()}
});
document.addEventListener('input',e=>{const k=e.target.dataset&&e.target.dataset.ob;if(k&&ob)ob.v[k]=e.target.value});
document.addEventListener('change',e=>{const t=e.target,k=t.dataset&&t.dataset.ob;if(k&&ob)ob.v[k]=t.value;if(t.id==='avup'&&ob){const b=S.settings.photo;let n=0;const w=setInterval(()=>{if(!ob||++n>20){clearInterval(w);return}if(S.settings.photo!==b){clearInterval(w);obDraw()}},200)}});

/* ---------- tap effects ---------- */
let tap=null,navTab='';
function burst(x,y){const b=document.createElement('div');b.className='burst';b.style.left=x+'px';b.style.top=y+'px';b.innerHTML=Array.from({length:8},(q,i)=>`<i style="--a:${i*45}deg;background:var(--${COLORS[i%6]})"></i>`).join('');document.body.appendChild(b);setTimeout(()=>b.remove(),700)}
document.addEventListener('click',e=>{const el=e.target.closest&&e.target.closest('[data-a]');if(!el)return;tap={a:el.dataset.a,id:el.dataset.id||'',d:el.dataset.d||''};if(S.settings.motion!=='off'&&el.matches('.check,.hp,.tplus,.mt')&&e.clientX)burst(e.clientX,e.clientY)},true);
const _ar7=window.afterRender;
window.afterRender=function(){
  _ar7();
  const nv=$('#nav');if(nv){nv.classList.toggle('navpop',navTab!==ui.tab);navTab=ui.tab}
  if(tap&&tap.id){try{const el=document.querySelector('#view [data-a="'+tap.a+'"][data-id="'+tap.id+'"]'+(tap.d?'[data-d="'+tap.d+'"]':''));if(el)el.classList.add('justnow')}catch(e){}}
  tap=null;
};
window.__v7={hijri:()=>hijri(),obState:()=>ob};


/* ================= v8: Android app bridge (notifications, files), layout fixes ================= */
if(!S.settings.tv){const o=Object.assign({},S.settings.tilesOff);delete o.quran;delete o.food;S.settings.tilesOff=o}
DEF_SET.tilesOff={};DEF_SET.tv=0;
const NV=(typeof window!=='undefined'&&window.CatalystNative)||null;
const MIME={pdf:'application/pdf',jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',gif:'image/gif',webp:'image/webp',txt:'text/plain',md:'text/markdown',csv:'text/csv',json:'application/json',mp4:'video/mp4',doc:'application/msword',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',ppt:'application/vnd.ms-powerpoint',pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',xls:'application/vnd.ms-excel',xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'};
async function nativeSave(o){
  const blob=o.data instanceof Blob?o.data:new Blob([o.data]),buf=new Uint8Array(await blob.arrayBuffer()),step=383997;
  NV.fileBegin(String(o.filename),MIME[ext(o.filename)]||blob.type||'application/octet-stream');
  for(let i=0;i<buf.length;i+=step){let s='';const part=buf.subarray(i,i+step);for(let j=0;j<part.length;j+=8192)s+=String.fromCharCode.apply(null,part.subarray(j,j+8192));NV.fileChunk(btoa(s))}
  const r=String(NV.fileEnd());if(r.indexOf('error')===0)throw{code:'native',message:r};return{status:'saved'};
}
if(NV&&NV.fileBegin)DL={save:nativeSave};
let lastSync='',syncT=0;
function nativeSync(){
  if(!NV||!NV.sync)return;
  const now=Date.now(),out=[];
  for(let d=0;d<7;d++){const ds=addDays(today(),d);agenda(ds).forEach(x=>{const dt=parse(ds),m=toMin(x.t);dt.setHours(Math.floor(m/60),m%60,0,0);if(dt.getTime()>now+5000)out.push({t:x.title,s:x.src,at:dt.getTime()})})}
  out.sort((a,b)=>a.at-b.at);const j=JSON.stringify(out.slice(0,140)),sig=j.length+':'+out.length+':'+(out[0]?out[0].at+out[0].t:'')+j.slice(-200);
  if(sig!==lastSync){lastSync=sig;try{NV.sync(j)}catch(e){}}
}
setInterval(nativeSync,60000);
loadPdf=function(){return new Promise((res,rej)=>{if(window.PDFLib)return res(window.PDFLib);const srcs=['pdf-lib.min.js','https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js'];(function next(i){if(i>=srcs.length)return rej(new Error('offline'));const s=document.createElement('script');s.src=srcs[i];s.onload=()=>window.PDFLib?res(window.PDFLib):next(i+1);s.onerror=()=>next(i+1);document.head.appendChild(s)})(0)})};
const _rem8=EXT.reminders;
EXT.reminders=()=>(NV?`<div class="card c-leaf"><h2>Phone notifications</h2><p class="muted">Your reminders, prayers, classes, medicines and bills for the next 7 days are set as real notifications on this phone. They ring even when the app is closed. Open the app at least once a week so it can set the following days.</p><div class="row wrap"><button class="btn sm" data-a="nvAsk">Allow notifications</button><button class="btn sm" data-a="nvTest">Send a test in 10 seconds</button></div>${said('nv')}</div>`:'')+_rem8();
Object.assign(A,{
  nvAsk(){try{NV.askPermission();say('nv','If your phone asks, tap Allow.')}catch(e){say('nv','Could not ask for permission.')}},
  nvTest(){try{NV.test();say('nv','Close the app now. A test notification arrives in 10 seconds.')}catch(e){say('nv','Could not send the test.')}}
});
const _ar8=window.afterRender;
window.afterRender=function(){_ar8();if(!S.settings.tv&&cloud!=='loading'){S.settings.tv=1;save('settings')}if(NV){clearTimeout(syncT);syncT=setTimeout(nativeSync,2500)}};


/* ================= v9: insights, caffeine, grades, attendance, reagents, citations, nudges, backup, semesters, compass, image tools ================= */
KEYS.push('caff','exps','reag','cites','semArch','gradeP','att');OBJ.push('gradeP','att');
Object.assign(DEF_SET,{attReq:75,lastBackup:0,nd:null,sem:''});
normalize();
Object.assign(ui,{attDay:today(),rest:null});
IC.cam='<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.500"/>';
ILL.cup='<path d="M9 16h24v12a10 10 0 0 1-10 10h-4A10 10 0 0 1 9 28z" fill="var(--sun)"/><path d="M33 19h3a5 5 0 0 1 0 10h-3M16 6c-2 3 2 4 0 7M23 6c-2 3 2 4 0 7"/>';
ILL.chart='<rect x="7" y="26" width="8" height="14" rx="2" fill="var(--sky)"/><rect x="20" y="16" width="8" height="24" rx="2" fill="var(--grape)"/><rect x="33" y="8" width="8" height="32" rx="2" fill="var(--pink)"/>';
SUB.life.splice(SUB.life.length,0,['caffeine','Caffeine'],['insights','Insights']);
SUB.study.push(['grades','Grade predictor'],['attend','Attendance'],['cite','Citations']);
SUB.lab.splice(SUB.lab.length-2,0,['stock','Reagents'],['image','Colony & gel']);
MENU.find(g=>g[0]==='Life')[1].push(['life','life','caffeine','Caffeine','sky'],['life','life','insights','Insights','sky']);
MENU.find(g=>g[0]==='Study')[1].push(['study','study','grades','Grade predictor','grape'],['study','study','attend','Attendance','grape'],['study','study','cite','Citations','grape']);
MENU.find(g=>g[0]==='Lab')[1].push(['lab','lab','stock','Reagents','sun',()=>{const n=reagIssues().length;return n?n+' alert'+(n>1?'s':''):''}],['lab','lab','image','Colony counter & gel notes','sun']);
const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:null;
function copyText(t,k){const ok=()=>say(k,'Copied.'),fall=()=>{try{const ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();const r=document.execCommand('copy');ta.remove();say(k,r?'Copied.':'Copying was blocked here.')}catch(e){say(k,'Copying was blocked here.')}};try{navigator.clipboard.writeText(t).then(ok,fall)}catch(e){fall()}}

/* ---------- caffeine ---------- */
const DRINKS=[['Milk tea (cha)',40],['Black tea',45],['Instant coffee',65],['Brewed coffee',95],['Espresso shot',63],['Cola, 250 mL',26],['Energy drink, 250 mL',80]];
const tsOf=(d,t)=>{const x=parse(d),m=toMin(t);x.setHours(Math.floor(m/60),m%60,0,0);return x.getTime()};
function caffAt(ts){let s=0;S.caff.forEach(c=>{const t0=tsOf(c.date,c.time);if(ts>=t0&&ts-t0<72*36e5)s+=(+c.mg||0)*Math.pow(.5,(ts-t0)/(5*36e5))});return s}
const caffDay=d=>S.caff.filter(c=>c.date===d).reduce((a,c)=>a+(+c.mg||0),0);
function bedTs(){const b=S.settings.sleepBed||'23:30';return tsOf(toMin(b)<720?addDays(today(),1):today(),b)}
EXT.caffeine=()=>{
  const t=today(),now=Date.now(),t0=tsOf(t,'06:00'),pts=[],tot=caffDay(t),atBed=caffAt(bedTs()),cur=caffAt(now),stop=hm(toMin(S.settings.sleepBed||'23:30')-360);
  for(let i=0;i<=96;i++)pts.push(caffAt(t0+i*15*6e4));
  const mx=Math.max(100,...pts),X=i=>20+i*(270/96),Y=v=>130-v/mx*110,bi=(bedTs()-t0)/(15*6e4),ni=(now-t0)/(15*6e4);
  const area='M'+X(0)+' 130 '+pts.map((v,i)=>'L'+X(i).toFixed(1)+' '+Y(v).toFixed(1)).join(' ')+' L'+X(96)+' 130Z';
  const svg=`<svg class="plot" viewBox="0 0 300 150" role="img" aria-label="Caffeine in your body today"><path d="M20 130h270" stroke="var(--muted)" stroke-width="1"/><path d="${area}" fill="color-mix(in srgb,var(--sun) 45%,transparent)" stroke="var(--tomato)" stroke-width="2"/>${bi>=0&&bi<=96?`<path d="M${X(bi)} 18V130" stroke="var(--grape)" stroke-width="2" stroke-dasharray="4 4"/><text x="${X(bi)}" y="14" text-anchor="middle" font-size="10" fill="var(--ink)">bedtime</text>`:''}${ni>=0&&ni<=96?`<circle cx="${X(ni)}" cy="${Y(cur)}" r="5" fill="var(--tomato)" stroke="var(--card)" stroke-width="2"/>`:''}${['6 AM','12 PM','6 PM','12 AM','6 AM'].map((l,i)=>`<text x="${X(i*24)}" y="145" text-anchor="middle" font-size="9" fill="var(--muted)">${l}</text>`).join('')}</svg>`;
  const l=S.caff.filter(c=>c.date===t).sort((a,b)=>a.time<b.time?-1:1);
  return`<div class="card c-sun"><div class="row between"><h2>Caffeine today</h2><span class="pill">${Math.round(tot)} of 400 mg</span></div><div class="g3">${stat(Math.round(cur)+' mg','in you now')}${stat(Math.round(atBed)+' mg','left at bedtime')}${stat(tfmt(stop),'last cup by')}</div>${svg}<p class="muted">${atBed>100?'That much at bedtime can delay sleep. Skip more caffeine today.':atBed>50?'Some caffeine will still be around at bedtime.':'Your bedtime should be mostly caffeine-free.'}</p></div>
    <div class="card"><h3>Add a drink now</h3><div class="chips" style="flex-wrap:wrap;overflow:visible">${DRINKS.map((x,i)=>`<button class="chip" data-a="cfQuick" data-id="${i}">${x[0]} · ${x[1]} mg</button>`).join('')}</div><button class="btn sm" data-a="cfAdd" style="align-self:flex-start">${ic('plus')}Other or another time</button>${l.length?'<div class="list">'+l.map(c=>`<div class="item"><button class="tap" data-a="cfEdit" data-id="${c.id}"><span class="t">${esc(c.what)}</span><span class="muted">${tfmt(c.time)} · ${c.mg} mg</span></button>${ic('edit')}</div>`).join('')+'</div>':''}<p class="muted">Amounts are typical values and vary by brand and cup size. The curve assumes caffeine is absorbed at once and halves every 5 hours, which differs from person to person.</p></div>`+guide('caff');
};
GUIDE.caff=['Caffeine and sleep',['Up to 400 mg a day is not linked with harm for most healthy adults, about 4 cups of brewed coffee.','Caffeine has a half-life of about 5 hours, so half of an afternoon coffee is still in you in the evening.','Stopping caffeine at least 6 hours before bed protects your sleep.'],'US Food and Drug Administration; Drake and colleagues, Journal of Clinical Sleep Medicine, 2013'];

/* ---------- insights: weekly summary, patterns, experiments ---------- */
const dayKeys=n=>{const a=[];for(let i=n-1;i>=0;i--)a.push(addDays(today(),-i));return a};
const M9={
 sleep:{l:'Sleep',f:d=>{const x=S.sleep.find(l=>l.date===d);return x?sleepMin(x)/60:null}},
 focus:{l:'Study time',u:'min',f:d=>S.focus.filter(x=>x.date===d).reduce((a,x)=>a+x.min,0)},
 tasks:{l:'Tasks finished',u:'tasks',f:d=>S.tasks.filter(x=>x.done&&x.doneAt===d).length},
 spend:{l:'Spending',f:d=>S.money.filter(m=>m.date===d&&m.type!=='in').reduce((a,m)=>a+m.amount,0),down:1},
 water:{l:'Water',u:'glasses',f:d=>S.water[d]||0},
 caff:{l:'Caffeine',u:'mg',f:d=>caffDay(d),down:1},
 active:{l:'Active time',u:'min',f:d=>S.acts.filter(a=>a.date===d).reduce((s,a)=>s+(+a.min||0),0)},
 prayers:{l:'Prayers',u:'of 5',f:d=>PR.filter(p=>(S.prayers[d]||{})[p[0]]).length}
};
const used=d=>!!(S.water[d]||S.prayers[d]||S.habitLog[d]||S.focus.some(x=>x.date===d)||S.money.some(m=>m.date===d)||S.meals.some(m=>m.date===d)||S.sleep.some(l=>l.date===d)||S.caff.some(c=>c.date===d)||S.tasks.some(x=>x.doneAt===d));
const val=(k,d)=>{const v=M9[k].f(d);if(v==null)return null;if(k!=='sleep'&&!used(d))return null;return v};
const fmtV=(k,v)=>k==='spend'?money(v):k==='sleep'?dur(Math.round(v*60)):(Math.round(v*10)/10)+(M9[k].u?' '+M9[k].u:'');
const RULES=[
 {a:'slept 7 hours or more',b:'other days',c:d=>{const v=val('sleep',d);return v==null?null:v>=7},k:'focus',w:'you studied'},
 {a:'had caffeine after 4 PM',b:'other days',c:d=>used(d)?S.caff.some(x=>x.date===d&&x.time>='16:00'):null,k:'sleep',o:d=>val('sleep',addDays(d,1)),w:'you slept that night'},
 {a:'ate breakfast',b:'days you skipped it',c:d=>used(d)?S.meals.some(m=>m.date===d&&m.meal==='Breakfast'):null,k:'spend',w:'you spent'},
 {a:'reached your water goal',b:'other days',c:d=>used(d)?(S.water[d]||0)>=S.settings.waterGoal:null,k:'focus',w:'you studied'},
 {a:'were active for 20 minutes or more',b:'other days',c:d=>used(d)?M9.active.f(d)>=20:null,k:'sleep',o:d=>val('sleep',addDays(d,1)),w:'you slept that night'},
 {a:'went to bed after 12:30 AM',b:'earlier nights',c:d=>{const l=S.sleep.find(x=>x.date===d);if(!l)return null;const m=toMin(l.bed);return m>=30&&m<300},k:'tasks',w:'you finished'},
 {a:'prayed all five prayers',b:'other days',c:d=>used(d)?PR.every(p=>(S.prayers[d]||{})[p[0]]):null,k:'focus',w:'you studied',deen:1}
];
function patterns(){
  const days=dayKeys(60),out=[];
  RULES.forEach(r=>{
    if(r.deen&&S.settings.deenOff)return;const of=r.o||(d=>val(r.k,d)),A=[],B=[];
    days.forEach(d=>{const c=r.c(d);if(c==null)return;const v=of(d);if(v==null)return;(c?A:B).push(v)});
    if(A.length<4||B.length<4)return;const ma=avg(A),mb=avg(B),base=Math.max(Math.abs(ma),Math.abs(mb));
    if(!base||Math.abs(ma-mb)/base<.15)return;out.push({r:r,ma:ma,mb:mb,na:A.length,nb:B.length,gap:Math.abs(ma-mb)/base});
  });
  return out.sort((x,y)=>y.gap-x.gap);
}
function weekStats(end){
  const ds=[];for(let i=6;i>=0;i--)ds.push(addDays(end,-i));const sum=k=>ds.reduce((a,d)=>a+(M9[k].f(d)||0),0),sl=ds.map(d=>M9.sleep.f(d)).filter(v=>v!=null),pl=ds.reduce((a,d)=>a+S.tasks.filter(x=>x.due===d).length,0);
  return{prayers:sum('prayers'),focus:sum('focus'),tasks:sum('tasks'),planned:pl,spend:sum('spend'),water:sum('water')/7,sleep:sl.length?avg(sl):null,caff:sum('caff')/7,active:sum('active')};
}
function weekCard(){
  const a=weekStats(today()),b=weekStats(addDays(today(),-7)),rows=[['Study time','focus',v=>dur(Math.round(v))],['Tasks finished','tasks',v=>Math.round(v)+(a.planned?' of '+a.planned+' planned':'')],['Average sleep','sleep',v=>v==null?'–':dur(Math.round(v*60))],['Water a day','water',v=>v.toFixed(1)+' glasses'],['Spent','spend',v=>money(v)],['Active time','active',v=>dur(Math.round(v))],['Caffeine a day','caff',v=>Math.round(v)+' mg']];
  if(!S.settings.deenOff)rows.unshift(['Prayers','prayers',v=>v+' of 35']);
  const arrow=(k,x,y)=>{if(x==null||y==null||x===y)return'<span class="muted">same</span>';const up=x>y,good=(M9[k].down?!up:up);return`<span class="trend ${good?'good':'bad'}">${up?'▲':'▼'}</span>`};
  return`<div class="card wk"><div class="row">${ill('chart')}<div class="grow"><h2>Your week</h2><p class="muted">${fmt(addDays(today(),-6))} to ${fmt(today())}, compared with the week before.</p></div></div><div class="list">${rows.map(r=>`<div class="item"><span class="grow muted">${r[0]}</span><span class="t">${r[2](a[r[1]])}</span>${arrow(r[1],a[r[1]],b[r[1]])}</div>`).join('')}</div></div>`;
}
const EXM=()=>['sleep','focus','tasks','spend','water','caff','active'].concat(S.settings.deenOff?[]:['prayers']);
function expRes(e){
  const n=+e.days||14,base=[],trial=[],end=addDays(e.start,n-1),last=today()<end?today():end;
  for(let i=1;i<=n;i++){const v=val(e.metric,addDays(e.start,-i));if(v!=null)base.push(v)}
  for(let d=e.start;d<=last;d=addDays(d,1)){const v=val(e.metric,d);if(v!=null)trial.push(v)}
  return{b:avg(base),t:avg(trial),nb:base.length,nt:trial.length,day:Math.max(0,Math.min(n,diffDays(today(),e.start)+1)),n:n,done:today()>end,future:today()<e.start};
}
function expCard(e){
  const r=expRes(e),k=e.metric,m=M9[k];let verdict='';
  if(r.b!=null&&r.t!=null&&r.nt>=3){const pct=r.b?(r.t-r.b)/Math.abs(r.b)*100:0,better=m.down?pct<0:pct>0;verdict=Math.abs(pct)<10?'No clear change so far.':(better?'Better':'Worse')+' by '+Math.abs(Math.round(pct))+'%'+(r.done?'.':' so far.')}
  return`<div class="card"><div class="row between"><button class="tap" data-a="exEdit" data-id="${e.id}"><h3>${esc(e.name)}</h3><span class="muted">Watching ${m.l.toLowerCase()} · ${r.n} days</span></button><span class="pill ${r.done?'col c-leaf':''}">${r.future?'Starts '+fmt(e.start):r.done?'Finished':'Day '+r.day+' of '+r.n}</span></div><div class="bar"><i style="width:${r.day/r.n*100}%"></i></div><div class="g3">${stat(r.b==null?'–':fmtV(k,r.b),'before ('+r.nb+' days)')}${stat(r.t==null?'–':fmtV(k,r.t),'during ('+r.nt+' days)')}${stat(verdict?verdict.split(' ')[0].replace('.',''):'–','result')}</div>${verdict?`<p class="res">${verdict}</p>`:''}<p class="muted">${r.nb<3?'There is little data from before the start, so the comparison will be rough.':'Keep logging '+m.l.toLowerCase()+' every day for a fair result.'}</p></div>`;
}
EXT.insights=()=>{
  const p=patterns(),dd=dayKeys(60).filter(used).length;
  return weekCard()+`<div class="card"><h2>Patterns in your days</h2>${p.length?'<div class="list">'+p.slice(0,5).map(x=>`<div class="item"><span class="grow">On days you ${x.r.a}, ${x.r.w} <b>${fmtV(x.r.k,x.ma)}</b> on average, compared with <b>${fmtV(x.r.k,x.mb)}</b> on ${x.r.b}.<br><span class="muted">Based on ${x.na} and ${x.nb} days.</span></span></div>`).join('')+'</div>':`<p class="muted">Patterns appear after about two weeks of logging sleep, water, study time, meals and spending. You have ${dd} day${dd===1?'':'s'} of data so far.</p>`}<p class="muted">These are links in your own data, not proof that one thing causes the other.</p></div>
  <div class="card">${head('Experiments on yourself',addBtn('exAdd','New'))}<p class="muted">Try one change, such as no phone after 11 PM, and compare the days before with the days during.</p></div>`+S.exps.slice().reverse().map(expCard).join('');
};

/* ---------- planned versus done ---------- */
function pvd(d){const p=S.tasks.filter(x=>x.due===d);return{p:p.length,dn:p.filter(x=>x.done).length,left:p.filter(x=>!x.done)}}
function pvdCard(night){
  const t=today(),a=pvd(t),d7=last7(),w=d7.map(pvd),wp=w.reduce((s,x)=>s+x.p,0),wd=w.reduce((s,x)=>s+x.dn,0);
  if(night&&(!a.p||!a.left.length))return'';
  return`<div class="card${night?' c-grape':''}"><div class="row between"><h3>${night?'How did today go?':'Planned versus done'}</h3><span class="pill">${a.dn} of ${a.p} today</span></div>${night?'':`<p class="muted">Last 7 days: you finished ${wd} of ${wp} planned tasks${wp?' ('+Math.round(wd/wp*100)+'%)':''}.</p>`+bars(w.map(x=>x.p?Math.round(x.dn/x.p*100):0),d7.map(x=>DAYS[parse(x).getDay()][0]),'grape',100)}${a.left.length?`<button class="btn sm" data-a="pvdMove" style="align-self:flex-start">Move ${a.left.length} unfinished to tomorrow</button>`:''}${night?'':'<p class="muted">Bars show the share of each day’s planned tasks you finished. If you often finish less than half, plan fewer tasks.</p>'}</div>`;
}
const _vp9=VIEWS.plan;
VIEWS.plan=()=>{const h=_vp9();return ui.plan==='tasks'?h.replace('<div class="card"><form class="quick" data-f="task2">',pvdCard(false)+'<div class="card"><form class="quick" data-f="task2">'):h};

/* ---------- grade predictor ---------- */
const NSUC=[['A',93],['A-',90],['B+',87],['B',83],['B-',80],['C+',77],['C',73],['D',60]];
const curCourses=()=>S.courses.filter(c=>!c.arch);
function gstat(g){let tw=0,dw=0,e=0;(g.items||[]).forEach(i=>{const w=num(i.w);tw+=w;if(String(i.s).trim()!==''&&num(i.m)>0){dw+=w;e+=w*num(i.s)/num(i.m)}});return{tw:tw,dw:dw,e:e,rem:tw-dw,cur:dw?e/dw*100:null}}
const needFor=(g,thr)=>{const s=gstat(g);if(!s.rem)return null;return(thr*s.tw/100-s.e)/s.rem*100};
EXT.grades=()=>{
  const cs=curCourses();if(!cs.length)return`<div class="card">${empty('Add your courses first','Each course gets a grade predictor once it is in the Courses list.')}</div>`;
  return`<p class="muted">Add each part of the course with its weight, such as Quiz 15%, Mid 30%, Final 40%. Fill in your marks as they come.</p>`+cs.map(c=>{
    const g=S.gradeP[c.id]||{items:[]},s=gstat(g),pred=s.cur!=null&&s.tw?(s.e+s.rem*s.cur/100)/s.tw*100:null,letter=pred==null?'':(NSUC.find(x=>pred>=x[1])||['F'])[0];
    return`<div class="card"><div class="row between"><h3>${esc(c.code||c.title)}</h3>${pred!=null?`<span class="pill col c-sun">Heading for ${letter}</span>`:''}</div>${g.items.length?'<div class="list">'+g.items.map(i=>`<div class="item"><button class="tap" data-a="gpEdit" data-c="${c.id}" data-id="${i.id}"><span class="t">${esc(i.n)}</span><span class="muted">${num(i.w)}% of the grade</span></button><span class="t">${String(i.s).trim()!==''?esc(i.s)+' / '+esc(i.m):'Pending'}</span></div>`).join('')+'</div>':''}<button class="btn sm" data-a="gpAdd" data-c="${c.id}" style="align-self:flex-start">${ic('plus')}Add a part</button>
    ${s.tw&&Math.abs(s.tw-100)>.5?`<p class="muted" style="color:var(--bad)">The weights add up to ${s.tw}%, not 100%. Check them.</p>`:''}
    ${s.dw?`<p>So far you have <b>${s.cur.toFixed(1)}%</b> on ${s.dw}% of the course.</p>`:''}
    ${s.rem>0&&s.dw?`<p class="muted">What you need on the remaining ${s.rem}%:</p><div class="list">${NSUC.slice(0,6).map(x=>{const n=needFor(g,x[1]);return`<div class="item"><span class="t" style="width:38px">${x[0]}</span><span class="grow muted">${x[1]}% overall</span><span class="t">${n>100?'Not reachable':n<=0?'Already secured':Math.ceil(n)+'%'}</span></div>`}).join('')}</div>`:''}
    ${s.dw&&!s.rem?`<p class="res">Final: ${(s.e/s.tw*100).toFixed(1)}%, which is ${letter} on the NSU scale.</p>`:''}</div>`}).join('')+`<p class="muted">Uses NSU’s usual cutoffs (A from 93%, A- from 90%, B+ from 87% and so on). If your instructor uses different ones, go by theirs.</p>`;
};

/* ---------- attendance ---------- */
const attKey=r=>r.courseId||('n:'+rName(r));
const attName=k=>k.indexOf('n:')===0?k.slice(2):cname(k)||'Class';
function attStats(){const o={};Object.keys(S.att).forEach(d=>{const day=S.att[d];Object.keys(day).forEach(rid=>{const e=day[rid];if(!e||!e.c)return;const s=o[e.c]=o[e.c]||{p:0,t:0};s.t++;if(e.s==='p')s.p++})});return o}
const attMsg=(s,req)=>{const pct=s.p/s.t*100;if(pct<req){const n=Math.ceil((req*s.t-100*s.p)/(100-req));return'Attend the next '+n+' class'+(n===1?'':'es')+' in a row to get back to '+req+'%.'}const m=Math.floor(s.p*100/req-s.t);return m>0?'You can miss '+m+' more and stay at '+req+'% or above.':'Do not miss the next class.'};
EXT.attend=()=>{
  const d=ui.attDay,cls=S.routine.filter(r=>+r.day===parse(d).getDay()).sort(byStart),day=S.att[d]||{},st=attStats(),req=+S.settings.attReq||75;
  const keys=Object.keys(st).filter(k=>k.indexOf('n:')===0||curCourses().some(c=>c.id===k));
  return`<div class="card">${dayNav('attDay',d)}${cls.length?'<div class="list">'+cls.map(r=>{const e=day[r.id];return`<div class="item"><span class="grow"><span class="t">${esc(rName(r))}</span><br><span class="muted">${tfmt(r.start)}${r.room?' · '+esc(r.room):''}</span></span><button class="chip${e&&e.s==='p'?' on':''}" data-a="attMark" data-id="${r.id}" data-v="p">Present</button><button class="chip${e&&e.s==='a'?' on bad':''}" data-a="attMark" data-id="${r.id}" data-v="a">Absent</button></div>`}).join('')+'</div>':'<p class="muted">No class in your routine on this day. Add classes in Plan, Class routine.</p>'}</div>
  <div class="card">${head('By course',`<button class="btn sm" data-a="attReq">Required ${req}%</button>`)}${keys.length?keys.map(k=>{const s=st[k],pct=s.p/s.t*100;return`<div><div class="row between"><span class="t">${esc(attName(k))}</span><span class="muted">${s.p} of ${s.t} · ${Math.round(pct)}%</span></div><div class="bar"><i style="width:${pct}%${pct<req?';background:var(--bad)':''}"></i></div><p class="muted">${attMsg(s,req)}</p></div>`}).join(''):'<p class="muted">Mark your classes above and each course’s attendance appears here.</p>'}<p class="muted">Set the required percentage to your university’s or course’s rule.</p></div>`;
};

/* ---------- reagents ---------- */
function reagState(r){const t=today(),o=[];if(r.exp){const n=diffDays(r.exp,t);if(n<0)o.push(['bad','Expired']);else if(n<=30)o.push(['warn','Expires in '+n+' day'+(n===1?'':'s')])}if(String(r.low).trim()!==''&&num(r.qty)<=num(r.low))o.push(['warn','Running low']);return o}
const reagIssues=()=>S.reag.filter(r=>reagState(r).length);
EXT.lab_stock=()=>{
  const l=S.reag.slice().sort((a,b)=>(reagState(b).length-reagState(a).length)||String(a.name).localeCompare(b.name));
  return`<div class="card">${head('Reagents and supplies',addBtn('rgAdd','Add'))}<p class="muted">Keep track of what your lab group has, where it is, and when it expires.</p></div>`+(l.length?`<input data-c="rq" placeholder="Search reagents" aria-label="Search reagents"><div class="card"><div class="list">${l.map(r=>`<div class="item rg" data-name="${esc(String(r.name).toLowerCase())}"><button class="tap" data-a="rgEdit" data-id="${r.id}"><span class="t">${esc(r.name)}</span><span class="muted">${esc([r.loc,r.exp?'expires '+fmt(r.exp):''].filter(Boolean).join(' · '))}</span><span class="row wrap" style="gap:5px">${reagState(r).map(s=>`<span class="pill ${s[0]==='bad'?'bad':'col c-sun'}">${s[1]}</span>`).join('')}</span></button><span class="t">${esc(sig(num(r.qty)))} ${esc(r.unit||'')}</span><button class="btn sm" data-a="rgUse" data-id="${r.id}">Use</button></div>`).join('')}</div></div>`:`<div class="card">${empty('Nothing listed yet','Add chemicals, media, kits and consumables. You get a nudge when something runs low or nears expiry.')}</div>`);
};
const rgF=[['name','Name','text',{req:true,ph:'Nutrient agar'}],['qty','Amount left','number',R],['unit','Unit','text',{ph:'g, mL, bottles, boxes'}],['low','Warn me when it falls to','number'],['exp','Expiry date','date'],['loc','Where it is kept','text',{ph:'Fridge 2, shelf B'}],['note','Notes','text']];

/* ---------- citations (APA 7) ---------- */
function apaAuthor(line){
  const s=String(line).trim();if(!s)return'';if(/^\[.*\]$/.test(s))return s.slice(1,-1);
  let last,given;if(s.indexOf(',')>=0){const p=s.split(',');last=p[0].trim();given=p.slice(1).join(' ').trim()}else{const p=s.split(/\s+/);last=p.pop();given=p.join(' ')}
  const ini=given.split(/\s+/).filter(Boolean).map(g=>g.split('-').map(x=>x.charAt(0).toUpperCase()+'.').join('-')).join(' ');
  return last+(ini?', '+ini:'');
}
function apaAuthors(txt){
  const a=String(txt||'').split(/\n|;/).map(apaAuthor).filter(Boolean);
  if(!a.length)return'';if(a.length===1)return a[0];if(a.length===2)return a[0]+', & '+a[1];
  if(a.length<=20)return a.slice(0,-1).join(', ')+', & '+a[a.length-1];
  return a.slice(0,19).join(', ')+', . . . '+a[a.length-1];
}
const endDot=s=>/[.?!]$/.test(s)?s:s+'.';
function apa(c){
  const au=apaAuthors(c.authors),yr='('+(String(c.year||'').trim()||'n.d.')+').',ti=String(c.title||'').trim(),it=x=>'<i>'+esc(x)+'</i>',link=String(c.doi||'').trim();
  const lk=!link?'':/^10\.\d+\//.test(link)?'https://doi.org/'+link:link;
  const h=[],t=[];const push=(html,text)=>{h.push(html);t.push(text)};
  const head=(tiHtml,tiText)=>{if(au){push(esc(endDot(au)),endDot(au));push(yr,yr);push(tiHtml,tiText)}else{push(tiHtml,tiText);push(yr,yr)}};
  if(c.type==='Book'){head(it(endDot(ti)),endDot(ti));if(c.source)push(esc(endDot(c.source)),endDot(c.source))}
  else if(c.type==='Website'){head(it(endDot(ti)),endDot(ti));if(c.source)push(esc(endDot(c.source)),endDot(c.source))}
  else{head(esc(endDot(ti)),endDot(ti));if(c.source){let sh=it(c.source),st=c.source;if(c.vol){sh+=', '+it(c.vol);st+=', '+c.vol}if(c.issue){sh+='('+esc(c.issue)+')';st+='('+c.issue+')'}if(c.pages){const pg=String(c.pages).replace(/-/g,'–');sh+=', '+esc(pg);st+=', '+pg}push(sh+'.',st+'.')}}
  if(lk)push(esc(lk),lk);
  return{html:h.join(' '),text:t.join(' ')};
}
const ctF=()=>[['type','Type','select',{opts:['Journal article','Book','Website']}],['authors','Authors, one per line','textarea',{ph:'Hossain, Md. Billal\nRahman, Sadia\nFor an organisation: [World Health Organization]'}],['year','Year (for websites: 2024, March 5)','text'],['title','Title','text',R],['source','Journal, publisher or website name','text'],['vol','Volume','text'],['issue','Issue','text'],['pages','Pages','text',{ph:'45-67'}],['doi','DOI or link','text',{ph:'10.1016/j.foodcont.2021.108123'}],['proj','Research project','select',{opts:[['','None']].concat(S.research.map(p=>[p.id,p.title]))}]];
const firstAu=c=>(apaAuthors(c.authors)||c.title||'').toLowerCase();
EXT.cite=()=>{
  const l=S.cites.slice().sort((a,b)=>firstAu(a).localeCompare(firstAu(b))),g={};l.forEach(c=>{const k=c.proj&&S.research.find(p=>p.id===c.proj)?c.proj:'';(g[k]=g[k]||[]).push(c)});
  return`<div class="card">${head('Reference list (APA 7)',addBtn('ctAdd','Add'))}<p class="muted">Type the details once and the app writes the reference in APA 7th edition style, sorted by author.</p>${said('cite')}</div>`+(l.length?Object.keys(g).map(k=>`<div class="card"><div class="row between"><h3>${k?esc(S.research.find(p=>p.id===k).title):'General'}</h3><button class="btn sm" data-a="ctCopy" data-id="${k}">Copy all</button></div><div class="list">${g[k].map(c=>`<div class="item"><button class="tap cite" data-a="ctEdit" data-id="${c.id}">${apa(c).html}</button><button class="btn sm" data-a="ctOne" data-id="${c.id}">Copy</button></div>`).join('')}</div></div>`).join(''):`<div class="card">${empty('No references yet','Add the papers you read for assignments, reports and your research.')}</div>`)+`<p class="muted">APA wants article titles in sentence case: capital letter only at the start, after a colon, and for names. Type titles that way. Copied text loses the italics, so re-apply them in Word or Docs.</p>`;
};

/* ---------- receipts and prescription photos on the phone ---------- */
window.rcBtn=m=>m.rc?(m.rc.asset?`<a class="btn sm rc on" href="/_blob/${esc(m.rc.asset)}" target="_blank" rel="noopener" aria-label="Open receipt">${ic('cam')}</a>`:`<button class="btn sm rc on" data-a="rcOpen" data-id="${m.id}" aria-label="Open receipt">${ic('cam')}</button>`):`<label class="btn sm filebtn rc" aria-label="Attach a receipt photo">${ic('cam')}<input type="file" accept="image/*,application/pdf" data-rc="${m.id}"></label>`;
async function openStored(o,name,k){try{if(!DL){say(k,'Opening files is not available here.');return}await DL.save({filename:name,data:await fileBlob(o)})}catch(e){say(k,e&&e.code==='gone'?'That file was kept on a different phone, or the app’s storage was cleared.':e&&e.code==='declined'?'Cancelled.':'Could not open that file.')}}

/* ---------- gentle nudges ---------- */
function nudges(){
  const t=today(),n=nowMin(),s=S.settings,out=[],add=(k,txt,go)=>out.push({k:k,t:txt,go:go});
  S.exams.filter(e=>e.date>=t&&diffDays(e.date,t)<=5).sort((a,b)=>a.date<b.date?-1:1).forEach(e=>{const dd=diffDays(e.date,t),w=dd===0?'today':dd===1?'tomorrow':'in '+dd+' days',f=e.courseId?S.focus.filter(x=>x.courseId===e.courseId&&diffDays(t,x.date)<7).reduce((a,x)=>a+x.min,0):-1;add('ex'+e.id,e.title+(e.courseId?' for '+cname(e.courseId):'')+' is '+w+'.'+(f===0?' You have not logged study time for it this week.':f>0?' You studied '+dur(f)+' for it this week.':''),['study','study','timer'])});
  const ov=S.tasks.filter(x=>!x.done&&x.due&&x.due<t).length;if(ov>=3)add('ov',ov+' tasks are overdue. Finish them or move them to a new day.',['plan','plan','tasks']);
  const ep=activeEp();if(ep){const late=doses(ep,t).filter(x=>!x.taken&&toMin(x.t)+30<n).length;if(late)add('med',late+' medicine dose'+(late>1?'s are':' is')+' still unticked today.',['life','life','health'])}
  if(S.sleep.length&&![0,1,2].some(i=>S.sleep.some(l=>l.date===addDays(t,-i))))add('sl','You have not logged your sleep for 3 days.',['life','life','sleep']);
  if(n>=960&&(S.water[t]||0)<s.waterGoal/2)add('wa','Only '+(S.water[t]||0)+' of '+s.waterGoal+' glasses of water so far today.',['life','life','water']);
  if(S.caff.some(c=>c.date===t)&&n<toMin(s.sleepBed||'23:30')){const b=caffAt(bedTs());if(b>100)add('cf','About '+Math.round(b)+' mg of caffeine will still be in you at bedtime. Skip more today.',['life','life','caffeine'])}
  if(s.budget){const mo=t.slice(0,7),sp=S.money.filter(m=>m.date.slice(0,7)===mo&&m.type!=='in').reduce((a,m)=>a+m.amount,0),d=new Date(),dim=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();if(d.getDate()>=5&&sp/d.getDate()*dim>s.budget)add('bu','At this pace you will pass your monthly budget of '+money(s.budget)+'.',['life','life','money'])}
  const paid=S.billPaid[t.slice(0,7)]||{};S.bills.forEach(b=>{const d=new Date(),dim=new Date(d.getFullYear(),d.getMonth()+1,0).getDate(),due=Math.min(dim,+b.day||1),left=due-d.getDate();if(!paid[b.id]&&left>=0&&left<=2)add('bi'+b.id,b.name+' ('+money(+b.amount||0)+') is due '+(left===0?'today':left===1?'tomorrow':'in 2 days')+'.',['life','life','money'])});
  const st=attStats(),req=+s.attReq||75;Object.keys(st).forEach(k=>{const x=st[k];if(x.t>=3&&x.p/x.t*100<req&&(k.indexOf('n:')===0||curCourses().some(c=>c.id===k)))add('at'+k,'Attendance in '+attName(k)+' is '+Math.round(x.p/x.t*100)+'%, below '+req+'%.',['study','study','attend'])});
  const ri=reagIssues();if(ri.length)add('rg',ri.length===1?ri[0].name+': '+reagState(ri[0])[0][1].toLowerCase()+'.':ri.length+' reagents are low or near expiry.',['lab','lab','stock']);
  if(n>=1260&&S.habits.length){const l=S.habitLog[t]||{},o=S.habits.filter(h=>!l[h.id]).length;if(o)add('hb',o+' habit'+(o>1?'s are':' is')+' still open today.',['life','life','habits'])}
  const items=S.tasks.length+S.money.length+S.notes.length+S.sleep.length;if(items>15&&Date.now()-(+s.lastBackup||0)>14*864e5)add('bk',s.lastBackup?'Your last backup was over 2 weeks ago. Back up to Google Drive.':'You have not backed up yet. Back up to Google Drive so nothing is lost.',['more','more','settings']);
  const dis=s.nd&&s.nd.d===t?s.nd.k||{}:{};return out.filter(x=>!dis[x.k]);
}
function nudgeCard(){const l=nudges();if(!l.length)return'';return`<div class="card nudge"><div class="row">${ill('sprout')}<h3 class="grow">Gentle nudges</h3></div><div class="list">${l.slice(0,3).map(x=>`<div class="item"><span class="grow">${esc(x.t)}</span><button class="btn sm" data-a="go" data-tab="${x.go[0]}" data-k="${x.go[1]}" data-v="${x.go[2]}">Open</button><button class="btn sm" data-a="ndis" data-id="${x.k}" aria-label="Dismiss for today">×</button></div>`).join('')}</div>${l.length>3?`<p class="muted">${l.length-3} more after these.</p>`:''}</div>`}
EXT.todayMid=()=>nudgeCard()+(nowMin()>=1140?pvdCard(true):'')+(new Date().getDay()===5?weekCard():'');
const _ag9=agenda;
agenda=function(ds){const a=_ag9(ds);if(ds===today()){const g=nudges();if(g.length)a.push({t:'18:00',title:g[0].t,src:'Nudge',key:'nudge'})}if(parse(ds).getDay()===5)a.push({t:'20:00',title:'Your week in Catalyst is ready',src:'Weekly summary',key:'week'});return a.sort((x,y)=>x.t<y.t?-1:1)};

/* ---------- Google Drive backup and restore ---------- */
async function sendFile(name,data,share){
  if(NV&&NV.fileBegin&&(share?NV.fileShareEnd:true)){
    const blob=data instanceof Blob?data:new Blob([data]),buf=new Uint8Array(await blob.arrayBuffer()),step=383997;
    NV.fileBegin(String(name),MIME[ext(name)]||'application/octet-stream');
    for(let i=0;i<buf.length;i+=step){let s='';const p=buf.subarray(i,i+step);for(let j=0;j<p.length;j+=8192)s+=String.fromCharCode.apply(null,p.subarray(j,j+8192));NV.fileChunk(btoa(s))}
    const r=String(share?NV.fileShareEnd():NV.fileEnd());if(r.indexOf('error')===0)throw{code:'native'};return;
  }
  if(!DL)throw{code:'none'};await DL.save({filename:name,data:data});
}
function restoreFrom(o){const old=S.notes.map(n=>'n_'+n.id);S=o;normalize();save.apply(null,KEYS.concat(old,S.notes.map(n=>'n_'+n.id)));ui.rest=null;render();celebrate('Backup restored')}
const _set9=EXT.settings;
EXT.settings=()=>{const lb=+S.settings.lastBackup||0;return`<div class="card c-sky"><div class="row">${ill('drop')}<div class="grow"><h2>Back up to Google Drive</h2><p class="muted">${lb?'Last backup: '+fmt(ymd(new Date(lb))):'No backup yet.'}</p></div></div><p class="muted">${NV?'Tap the button, then choose Drive in the menu that opens and save the file.':'This saves a backup file. Upload it to your Google Drive to keep it safe.'} Photos and files you uploaded are not inside the backup.</p><div class="row wrap"><button class="btn pri" data-a="bkNow">Back up now</button><label class="btn filebtn">Restore from a file<input type="file" id="bkup" accept=".json,application/json"></label></div>${said('bk')}${ui.rest?`<div class="card c-tomato"><p><b>Replace everything in the app with this backup?</b> What you have now will be lost.</p><div class="row"><button class="btn pri" data-a="bkYes">Replace my data</button><button class="btn" data-a="bkNo">Cancel</button></div></div>`:''}</div>`+_set9()};

/* ---------- semesters ---------- */
EXT.courses=()=>{
  const past={};S.courses.filter(c=>c.arch).forEach(c=>{(past[c.arch]=past[c.arch]||[]).push(c)});
  return`<div class="card c-grape"><div class="row between"><div><span class="pill">Current semester</span><h3>${esc(S.settings.sem||'Not named yet')}</h3></div><button class="btn sm" data-a="semNew">New semester</button></div><p class="muted">At the end of a semester, start a new one. Your old courses, notes and files move to Past semesters and stay saved.</p></div>`+
  Object.keys(past).map(k=>`<details class="card calc"><summary><span class="pill">Past</span><h3>${esc(k)}</h3></summary><div class="list">${past[k].map(c=>`<div class="item"><button class="tap" data-a="cOpen" data-id="${c.id}"><span class="t">${esc(c.code||c.title)}</span><span class="muted">${esc(c.title)} · ${S.notes.filter(n=>n.ref===c.id).length} notes · ${S.files.filter(f=>f.courseId===c.id).length} files</span></button>${ic('next')}</div>`).join('')}</div></details>`).join('');
};

/* ---------- Qibla compass ---------- */
let qOn=false,qLast=0,qBuzz=false;
function qHandler(e){let h=null;if(e.webkitCompassHeading!=null)h=e.webkitCompassHeading;else if(e.absolute&&e.alpha!=null)h=360-e.alpha;if(h==null)return;qLast=Date.now();const q=qibla(),dial=document.getElementById('qdial'),m=document.getElementById('qmsg'),diff=Math.abs(((q-h)%360+540)%360-180);if(dial)dial.style.transform='rotate('+(-h)+'deg)';if(m)m.textContent=diff<5?'You are facing the Qibla.':'Turn '+(((q-h)%360+360)%360<180?'right':'left')+' by about '+Math.round(diff)+'°.';const box=document.getElementById('qbox');if(box)box.classList.toggle('aligned',diff<5);if(diff<5&&!qBuzz){qBuzz=true;try{navigator.vibrate&&navigator.vibrate(60)}catch(x){}}if(diff>=8)qBuzz=false}
function qStop(){window.removeEventListener('deviceorientationabsolute',qHandler);window.removeEventListener('deviceorientation',qHandler);qOn=false}
const _pr9=EXT.prayer;
EXT.prayer=()=>(_pr9?_pr9():'')+`<div class="card"><div class="row between"><h3>Qibla compass</h3><button class="btn sm" data-a="qStart">${qOn?'Stop':'Start compass'}</button></div><div class="compass" id="qbox"><div class="dial" id="qdial"><b class="cn">N</b><b class="ce">E</b><b class="cs">S</b><b class="cw">W</b><div class="qarrow" style="transform:rotate(${qibla()}deg)"><i></i></div></div><span class="qtop"></span></div><p class="muted" id="qmsg">${qOn?'Hold the phone flat.':'Tap Start, lay the phone flat, and turn until the green arrow points to the top.'} The Qibla is ${qibla()}° from north.</p><p class="muted">Keep away from metal and magnets. If the arrow drifts, move the phone in a figure 8 to calibrate.</p></div>`;

/* ---------- colony counter and gel notes ---------- */
const IMG={im:null,url:'',marks:[],mode:'colony'};
function drawImg(){
  const c=document.getElementById('imgc');if(!c||!IMG.im||!c.getContext)return;const im=IMG.im,k=Math.min(1,1400/im.naturalWidth);
  c.width=Math.round(im.naturalWidth*k);c.height=Math.round(im.naturalHeight*k);const g=c.getContext('2d');g.drawImage(im,0,0,c.width,c.height);
  const r=Math.max(9,c.width/55);
  IMG.marks.forEach((m,i)=>{const x=m.x*c.width,y=m.y*c.height;
    if(IMG.mode==='colony'){g.lineWidth=r/3;g.strokeStyle='#FF2D8A';g.beginPath();g.arc(x,y,r,0,7);g.stroke();g.fillStyle='#fff';g.font='bold '+Math.round(r*.9)+'px sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText(String(i+1),x,y)}
    else{const fs=Math.max(14,c.width/28);g.font='bold '+fs+'px sans-serif';const w=g.measureText(m.t).width+fs*.8;g.fillStyle='#FFC83A';g.beginPath();g.arc(x,y,r*.45,0,7);g.fill();g.fillStyle='rgba(255,255,255,.92)';g.fillRect(x+r*.6,y-fs*.7,w,fs*1.4);g.fillStyle='#1F1A3D';g.textAlign='left';g.textBaseline='middle';g.fillText(m.t,x+r*.6+fs*.4,y)}});
}
EXT.lab_image=()=>{
  const cnt=IMG.marks.length;
  return`<div class="card"><div class="chips">${[['colony','Colony counter'],['gel','Gel notes']].map(x=>`<button class="chip${IMG.mode===x[0]?' on':''}" data-a="imMode" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><p class="muted">${IMG.mode==='colony'?'Photograph your plate from straight above. Tap each colony to mark it; tap a mark again to remove it.':'Photograph your gel. Tap a band or lane and type a label, such as Lane 3: 500 bp.'}</p><label class="btn pri filebtn" style="align-self:flex-start">${ic('cam')}${IMG.im?'Choose another photo':'Take or choose a photo'}<input type="file" id="imgup" accept="image/*"></label></div>`+
  (IMG.im?`<div class="card"><div class="row between"><h3>${IMG.mode==='colony'?cnt+' colon'+(cnt===1?'y':'ies'):cnt+' label'+(cnt===1?'':'s')}</h3><div class="row"><button class="btn sm" data-a="imUndo"${cnt?'':' disabled'}>Undo</button><button class="btn sm" data-a="imClear"${cnt?'':' disabled'}>Clear</button></div></div><canvas id="imgc" class="imgc" aria-label="Your photo. Tap to mark."></canvas><div class="row wrap">${IMG.mode==='colony'?`<button class="btn sm" data-a="imCfu"${cnt?'':' disabled'}>Use this count in CFU/mL</button>`:''}<button class="btn sm" data-a="imSave"${cnt?'':' disabled'}>Save marked photo to Files</button></div>${said('img')}${IMG.mode==='colony'&&cnt&&(cnt<30||cnt>300)?'<p class="muted">Counts outside 30 to 300 colonies are less reliable for CFU.</p>':''}</div>`:'');
};

/* ---------- pKa and pI ---------- */
const AAPK=[['Gly',2.34,9.60],['Ala',2.34,9.69],['Val',2.32,9.62],['Leu',2.36,9.60],['Ile',2.36,9.68],['Pro',1.99,10.96],['Phe',1.83,9.13],['Trp',2.38,9.39],['Met',2.28,9.21],['Ser',2.21,9.15],['Thr',2.11,9.62],['Asn',2.02,8.80],['Gln',2.17,9.13],['Tyr',2.20,9.11,10.07,'n'],['Cys',1.96,10.28,8.18,'a'],['Asp',1.88,9.60,3.65,'a'],['Glu',2.19,9.67,4.25,'a'],['His',1.82,9.17,6.00,'b'],['Lys',2.18,8.95,10.53,'b'],['Arg',2.17,9.04,12.48,'b']];
const pI=a=>a[4]==='a'?(a[1]+a[3])/2:a[4]==='b'?(a[2]+a[3])/2:(a[1]+a[2])/2;
const ACIDS=[['Phosphoric acid','2.15, 7.20, 12.35'],['Citric acid','3.13, 4.76, 6.40'],['Formic acid','3.75'],['Lactic acid','3.86'],['Acetic acid','4.76'],['Carbonic acid','6.35, 10.33'],['Ammonium ion','9.25'],['Tris','8.07']];
const _ref9=EXT.lab_ref;
EXT.lab_ref=()=>`<div class="card"><h2>Amino acid pKa and pI</h2><div class="pka"><b>AA</b><b>α-COOH</b><b>α-NH₃⁺</b><b>side chain</b><b>pI</b>${AAPK.map(a=>`<span>${a[0]}</span><span>${a[1].toFixed(2)}</span><span>${a[2].toFixed(2)}</span><span>${a[3]?a[3].toFixed(2):'–'}</span><span class="t">${pI(a).toFixed(2)}</span>`).join('')}</div><p class="muted">Free amino acids at 25 °C, Lehninger values. Side chains in a protein can shift by a unit or more.</p></div><div class="card"><h2>Common acids</h2><div class="list">${ACIDS.map(x=>`<div class="item"><span class="t grow">${x[0]}</span><span class="muted">${x[1]}</span></div>`).join('')}</div></div>`+(_ref9?_ref9():'');

/* ---------- actions ---------- */
const cfF=()=>[['what','Drink','select',{opts:DRINKS.map(x=>x[0]).concat('Other')}],['mg','Caffeine in mg (for Other)','number'],['date','Date','date',R],['time','Time','time',R]];
const cfVal=v=>{const p=DRINKS.find(x=>x[0]===v.what);v.mg=p&&!v.mg?p[1]:Math.max(0,num(v.mg))||(p?p[1]:0);return v};
const gpF=[['n','Part','text',{req:true,ph:'Quiz 1, Mid-term, Lab report'}],['w','Weight (% of the course grade)','number',R],['s','Your mark (leave empty if not done yet)','text'],['m','Out of','number']];
const exF=()=>[['name','What will you change?','text',{req:true,ph:'No phone after 11 PM'}],['metric','What to watch','select',{opts:EXM().map(k=>[k,M9[k].l])}],['days','How long','select',{opts:[['7','7 days'],['14','14 days'],['21','21 days']]}],['start','Start date','date',R]];
Object.assign(A,{
  cfQuick(d){const x=DRINKS[+d.id];S.caff.push({id:uid(),what:x[0],mg:x[1],date:today(),time:hm(nowMin())});save('caff');render()},
  cfAdd(){form('Add caffeine',cfF(),{what:DRINKS[0][0],date:today(),time:hm(nowMin())},v=>upsert('caff',null,cfVal(v)))},
  cfEdit(d){const c=S.caff.find(x=>x.id===d.id);form('Edit',cfF(),Object.assign({},c,DRINKS.some(x=>x[0]===c.what)?{mg:''}:{}),v=>upsert('caff',c.id,cfVal(v)),()=>remove('caff',c.id))},
  exAdd(){form('New experiment',exF(),{metric:'sleep',days:'14',start:today()},v=>upsert('exps',null,v))},
  exEdit(d){const e=S.exps.find(x=>x.id===d.id);form('Edit experiment',exF(),e,v=>upsert('exps',e.id,v),()=>remove('exps',e.id))},
  pvdMove(){const t=today(),n=addDays(t,1);S.tasks.forEach(x=>{if(!x.done&&x.due===t)x.due=n});save('tasks');render()},
  gpAdd(d){form('Add a part',gpF,{m:100},v=>{const g=S.gradeP[d.c]=S.gradeP[d.c]||{items:[]};g.items.push(Object.assign({id:uid()},v));save('gradeP')})},
  gpEdit(d){const g=S.gradeP[d.c],i=g.items.find(x=>x.id===d.id);form('Edit part',gpF,i,v=>{Object.assign(i,v);save('gradeP')},()=>{g.items=g.items.filter(x=>x.id!==i.id);save('gradeP')})},
  attDay(d){ui.attDay=addDays(ui.attDay,+d.n);render()},
  attMark(d){const r=S.routine.find(x=>x.id===d.id),day=S.att[ui.attDay]=S.att[ui.attDay]||{};if(day[d.id]&&day[d.id].s===d.v)delete day[d.id];else day[d.id]={s:d.v,c:attKey(r)};if(!Object.keys(day).length)delete S.att[ui.attDay];save('att');render()},
  attReq(){form('Required attendance',[['attReq','Required percentage','number',R]],S.settings,v=>{S.settings.attReq=Math.min(100,Math.max(1,Math.round(v.attReq)));save('settings')})},
  rgAdd(){form('Add a reagent',rgF,{},v=>upsert('reag',null,v))},
  rgEdit(d){const r=S.reag.find(x=>x.id===d.id);form('Edit reagent',rgF,r,v=>upsert('reag',r.id,v),()=>remove('reag',r.id))},
  rgUse(d){const r=S.reag.find(x=>x.id===d.id);form('Use '+esc(r.name),[['u','Amount used ('+(r.unit||'units')+')','number',R]],{},v=>{r.qty=Math.max(0,num(r.qty)-v.u);save('reag');if(reagState(r).some(s=>s[1]==='Running low'))toast({title:r.name+' is running low',src:'Reagents',t:hm(nowMin())})})},
  ctAdd(){form('Add a reference',ctF(),{type:'Journal article'},v=>upsert('cites',null,v))},
  ctEdit(d){const c=S.cites.find(x=>x.id===d.id);form('Edit reference',ctF(),c,v=>upsert('cites',c.id,v),()=>remove('cites',c.id))},
  ctOne(d){copyText(apa(S.cites.find(x=>x.id===d.id)).text,'cite')},
  ctCopy(d){copyText(S.cites.filter(c=>(c.proj&&S.research.some(p=>p.id===c.proj)?c.proj:'')===d.id).sort((a,b)=>firstAu(a).localeCompare(firstAu(b))).map(c=>apa(c).text).join('\n\n'),'cite')},
  rcOpen(d){const m=S.money.find(x=>x.id===d.id);if(m&&m.rc)openStored({asset:'',local:m.rc.local},m.rc.name||'receipt.jpg','rc')},
  rxOpen(d){openStored({asset:'',local:d.id.slice(6)},'prescription.jpg','rx')},
  ndis(d){const t=today(),s=S.settings;if(!s.nd||s.nd.d!==t)s.nd={d:t,k:{}};s.nd.k[d.id]=1;save('settings');render()},
  async bkNow(){try{await sendFile('catalyst-backup-'+today()+'.json',JSON.stringify(S),true);S.settings.lastBackup=Date.now();save('settings');say('bk',NV?'Choose Drive in the menu that opened.':'Backup file saved. Upload it to Google Drive.')}catch(e){say('bk',e&&e.code==='declined'?'Cancelled.':'Could not make the backup here. Use Copy backup further down.')}},
  bkYes(){if(ui.rest)restoreFrom(ui.rest)},
  bkNo(){ui.rest=null;render()},
  semNew(){form('Start a new semester',[['name','Name of the new semester','text',{req:true,ph:'Spring 2027'}],['old','Name of the semester that ended','text',{req:true,ph:'Fall 2026'}],['toCg','Add the finished courses to my CGPA list','select',{opts:[['1','Yes, so I can enter their grades'],['0','No']]}],['clear','Weekly class routine','select',{opts:[['1','Clear it for the new semester'],['0','Keep it']]}]],{old:S.settings.sem||''},v=>{
    const cur=curCourses();cur.forEach(c=>{c.arch=v.old});
    if(v.toCg==='1'&&cur.length)S.sems.push({id:uid(),name:v.old,items:cur.map(c=>({id:uid(),name:c.code||c.title,credits:num(c.credits)||3,grade:'',old:''}))});
    if(v.clear==='1'){S.semArch.push({name:v.old,routine:S.routine});S.routine=[]}
    S.settings.sem=v.name;save('courses','sems','routine','semArch','settings');setTimeout(()=>celebrate('Welcome to '+v.name),300)})},
  qStart(){if(qOn){qStop();render();return}const go=()=>{qOn=true;qLast=0;if('ondeviceorientationabsolute' in window)window.addEventListener('deviceorientationabsolute',qHandler);else window.addEventListener('deviceorientation',qHandler);render();setTimeout(()=>{if(qOn&&!qLast){const m=document.getElementById('qmsg');if(m)m.textContent='This phone is not sending compass readings here. It works in the Catalyst Android app. Use the angle above with any compass.'}},3500)};
    try{if(window.DeviceOrientationEvent&&typeof DeviceOrientationEvent.requestPermission==='function')DeviceOrientationEvent.requestPermission().then(p=>{if(p==='granted')go();else{const m=document.getElementById('qmsg');if(m)m.textContent='Compass permission was not given.'}},go);else go()}catch(e){go()}},
  imMode(d){IMG.mode=d.v;IMG.marks=[];render()},
  imUndo(){IMG.marks.pop();render()},
  imClear(){IMG.marks=[];render()},
  imCfu(){ui.cv.cfu=Object.assign({},ui.cv.cfu,{n:String(IMG.marks.length)});ui.lab='calc';ui.lcat='Microbiology';render();window.scrollTo(0,0)},
  imSave(){const c=document.getElementById('imgc');if(!c||!c.toBlob)return;c.toBlob(b=>{if(!b){say('img','Could not save the picture.');return}const name=(IMG.mode==='colony'?'colony-count-':'gel-')+today()+'.png';putFiles([new File([b],name,{type:'image/png'})],'img',(r,f)=>{S.files.push({id:uid(),courseId:'',name:f.name,type:'image/png',size:r.sizeBytes,asset:r.id||'',local:r.local||'',added:today()});save('files')})},'image/png')}
});
document.addEventListener('change',e=>{
  const t=e.target;
  if(t.dataset&&t.dataset.rc&&t.files.length){const m=S.money.find(x=>x.id===t.dataset.rc);if(m)putFiles([t.files[0]],'rc',(r,f)=>{m.rc={asset:r.id||'',local:r.local||'',name:f.name};save('money')})}
  if(t.id==='bkup'&&t.files.length){const fr=new FileReader();fr.onload=()=>{let o=null;try{o=JSON.parse(fr.result)}catch(x){}if(!o||typeof o!=='object'||!o.settings){say('bk','That file is not a Catalyst backup. Nothing was changed.');return}ui.rest=o;render()};fr.readAsText(t.files[0])}
  if(t.id==='imgup'&&t.files.length){const u=URL.createObjectURL(t.files[0]),im=new Image();im.onload=()=>{if(IMG.url)URL.revokeObjectURL(IMG.url);IMG.im=im;IMG.url=u;IMG.marks=[];render()};im.onerror=()=>say('img','That photo could not be opened.');im.src=u}
});
document.addEventListener('input',e=>{if(e.target.dataset&&e.target.dataset.c==='rq'){const q=e.target.value.toLowerCase().trim();document.querySelectorAll('.rg').forEach(x=>{x.style.display=!q||x.dataset.name.includes(q)?'':'none'})}});
document.addEventListener('click',e=>{
  const c=e.target;if(!c||c.id!=='imgc')return;const b=c.getBoundingClientRect(),x=(e.clientX-b.left)/b.width,y=(e.clientY-b.top)/b.height;if(x<0||x>1||y<0||y>1)return;
  if(IMG.mode==='colony'){const r=Math.max(9,c.width/55)/c.width,i=IMG.marks.findIndex(m=>Math.hypot((m.x-x),(m.y-y)*c.height/c.width)<r*1.3);if(i>=0)IMG.marks.splice(i,1);else IMG.marks.push({x:x,y:y});render()}
  else form('Label',[['t','Label text','text',{req:true,ph:'Lane 3: 500 bp'}]],{},v=>{IMG.marks.push({x:x,y:y,t:String(v.t).slice(0,40)})});
});
const _ar9=window.afterRender;
window.afterRender=function(){_ar9();if(ui.tab==='lab'&&ui.lab==='image')drawImg();if(qOn&&!(ui.tab==='deen'&&ui.deen==='prayer'))qStop()};
window.__v9={apa:apa,apaAuthors:apaAuthors,gstat:gstat,needFor:needFor,attStats:attStats,attMsg:attMsg,caffAt:caffAt,tsOf:tsOf,patterns:patterns,expRes:expRes,weekStats:weekStats,nudges:nudges,reagState:reagState,pI:pI,AAPK:AAPK,restoreFrom:restoreFrom,IMG:IMG};


/* ================= v10: alarms, livelier home ================= */
Object.assign(DEF_SET,{alFajr:0,alMeds:0});normalize();
IC.bell='<path d="M6 17h12l-1.500-2V11a4.500 4.500 0 0 0-9 0v4zM10 20a2 2 0 0 0 4 0"/>';
IC.alarm='<circle cx="12" cy="13" r="7"/><path d="M12 9.500V13l2.500 1.500M4 6l3-2.500M20 6l-3-2.500"/>';
const isAl=v=>v===1||v==='1'||v===true;
const alSel=['alarm','Alert type','select',{opts:[['0','Notification'],['1','Alarm (rings until you stop it)']]}];
const tF=()=>[['title','Task','text',R],['due','Due date','date'],['time','Time (needed for a notification or alarm)','time'],alSel,['cat','Category','select',{opts:['','Academic','University','Research','Personal','Home']}],['pri','Priority','select',{opts:['Normal','High']}]];
const remF=()=>[['title','Remind me to','text',R],['time','Time','time',R],alSel,['repeat','Repeat','select',{opts:['Once','Every day','Sun to Thu','Every week']}],['day','Day (for every week)','select',{opts:WEEK.map(w=>[w,DAYSL[w]])}],['date','Date (for once)','date']];
const evF=[['title','Event','text',R],['date','Date','date',R],['time','Time','time'],alSel,['note','Note','text']];

/* agenda: timed tasks, and alarm flags on everything that asks for one */
const _ag10=agenda;
agenda=function(ds){
  const a=_ag10(ds),s=S.settings;
  S.tasks.forEach(t=>{if(!t.done&&t.due===ds&&t.time)a.push({t:t.time,title:t.title,src:'Task',key:'t-'+t.id,alarm:isAl(t.alarm)})});
  a.forEach(x=>{const k=x.key||'';
    if(k.indexOf('r-')===0){const r=S.reminders.find(y=>'r-'+y.id===k);if(r&&isAl(r.alarm))x.alarm=true}
    else if(k.indexOf('e-')===0){const e=S.events.find(y=>'e-'+y.id===k);if(e&&isAl(e.alarm))x.alarm=true}
    else if(k==='p-fajr'&&+s.alFajr)x.alarm=true;
    else if(k.indexOf('m-')===0&&+s.alMeds)x.alarm=true});
  return a.sort((x,y)=>x.t<y.t?-1:1);
};
nativeSync=function(){
  if(!NV||!NV.sync)return;const now=Date.now(),out=[];
  for(let d=0;d<7;d++){const ds=addDays(today(),d);agenda(ds).forEach(x=>{const at=tsOf(ds,x.t);if(at>now+5000)out.push({t:x.title,s:x.src,at:at,a:x.alarm?1:0})})}
  out.sort((a,b)=>a.at-b.at);const j=JSON.stringify(out.slice(0,140));if(j!==lastSync){lastSync=j;try{NV.sync(j)}catch(e){}}
};

/* in-app alarm screen (rings while the app is open; the Android app also rings when closed) */
let alLoop=0,alSnz=0;
function alarmScreen(x){
  if(document.getElementById('alarmx'))return;
  const el=document.createElement('div');el.id='alarmx';el.setAttribute('role','alertdialog');
  el.innerHTML=`<div class="alring"><span></span><span></span><span></span>${'<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">'+IC.alarm+'</svg>'}</div><p class="altime">${tfmt(x.t)}</p><h1>${esc(x.title)}</h1><p>${esc(x.src)}</p><div class="row"><button class="btn" data-a="alSnooze">Snooze 5 min</button><button class="btn pri grow" data-a="alStop">Stop</button></div>`;
  el.dataset.t=x.title;el.dataset.s=x.src;document.body.appendChild(el);
  clearInterval(alLoop);beep();alLoop=setInterval(()=>{beep();try{navigator.vibrate&&navigator.vibrate([400,200,400])}catch(e){}},1300);
}
function alarmStop(){clearInterval(alLoop);const el=document.getElementById('alarmx');if(el)el.remove()}
const _toast10=toast;
toast=function(x){if(x&&x.alarm){if(NV&&NV.sync)return;alarmScreen(x);return}_toast10(x)};

/* reminders screen: alarms first */
const _rem10=EXT.reminders;
EXT.reminders=()=>{
  const t=today(),al=agenda(t).filter(x=>x.alarm&&toMin(x.t)>=nowMin()),mine=S.reminders.filter(r=>isAl(r.alarm));
  return`<div class="card c-tomato"><div class="row between"><div class="row">${'<svg class="icon" viewBox="0 0 24 24" aria-hidden="true" style="width:30px;height:30px">'+IC.alarm+'</svg>'}<h2>Alarms</h2></div><button class="btn sm" data-a="alAdd">${ic('plus')}New alarm</button></div><p class="muted">An alarm rings and keeps ringing until you tap Stop or Snooze${NV?', even when the app is closed.':'. In this web version it rings only while the app is open; the Android app rings even when closed.'} Any task, event or reminder can be an alarm: choose Alarm when you add it.</p>
  ${al.length?'<div class="list">'+al.map(x=>`<div class="item"><span class="pill">${tfmt(x.t)}</span><span class="t grow">${esc(x.title)}</span><span class="muted">${x.src}</span></div>`).join('')+'</div>':'<p class="muted">No more alarms today.</p>'}
  <div class="list"><div class="item">${chk(+S.settings.alFajr,'flag','data-id="alFajr"','Fajr alarm')}<span class="t grow">Wake me for Fajr with an alarm</span></div><div class="item">${chk(+S.settings.alMeds,'flag','data-id="alMeds"','Medicine alarms')}<span class="t grow">Ring medicine doses as alarms when I am sick</span></div></div>
  ${mine.length?`<p class="muted">Your alarms</p><div class="list">${mine.map(r=>`<div class="item">${chk(r.on!==0,'remTog',`data-id="${r.id}"`,'On')}<button class="tap" data-a="remEdit" data-id="${r.id}"><span class="t">${esc(r.title)}</span><span class="muted">${tfmt(r.time)} · ${esc(r.repeat)}</span></button></div>`).join('')}</div>`:''}<button class="btn sm" data-a="alTest" style="align-self:flex-start">Test an alarm in 10 seconds</button>${said('al')}</div>`+_rem10();
};

/* ---------- home: day timeline, living hero, helix fact card, quick-add button ---------- */
const SRCC={Prayer:'leaf',Class:'grape',Reminder:'sun',Event:'sky',Task:'tomato',Medicine:'pink',Bill:'sun',Sleep:'grape',Water:'sky',Nudge:'leaf','Weekly summary':'pink'};
function timeline(){
  const n=nowMin(),items=agenda(today()).filter(x=>x.src!=='Water'&&x.src!=='Nudge');if(!items.length)return'';
  let nowPut=false,html='';
  items.forEach(x=>{const m=toMin(x.t);if(!nowPut&&m>=n){html+=`<div class="tl now" id="tlnow"><b>Now</b><i></i><span>${tfmt(hm(n))}</span></div>`;nowPut=true}
    html+=`<div class="tl ${m<n?'past':''} t-${SRCC[x.src]||'sky'}"><b>${tfmt(x.t)}</b><i>${x.alarm?'<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">'+IC.alarm+'</svg>':''}</i><span>${esc(x.title.length>34?x.title.slice(0,32)+'…':x.title)}</span><em>${x.src}</em></div>`});
  if(!nowPut)html+=`<div class="tl now" id="tlnow"><b>Now</b><i></i><span>${tfmt(hm(n))}</span></div>`;
  const left=items.filter(x=>toMin(x.t)>=n).length;
  return`<div class="card tlcard"><div class="row between"><h3>Your day</h3><span class="pill">${left?left+' coming up':'All done for today'}</span></div><div class="tlrow" id="tlrow">${html}</div></div>`;
}
function helixCard(){return`<div class="card bite"><div class="helix" aria-hidden="true">${Array.from({length:10},(x,i)=>`<i style="--d:${i*-.18}s"></i>`).join('')}</div><div class="grow"><span class="pill">Biochem bite of the day</span><p>${esc(factToday())}</p></div></div>`}
const _today10=VIEWS.today;
VIEWS.today=()=>{
  let h=_today10();
  h=h.replace(/<div class="card"><div class="row between"><h2>Up next<\/h2>[^]*?<\/div><\/div><\/div>/,'');
  h=h.replace(/<div class="card"><div class="row"><svg class="ill" viewBox="0 0 48 48" aria-hidden="true"><path d="M15 5c0 12[^]*?<\/div><\/div><\/div>/,'');
  const i=h.indexOf('<div class="tiles">');if(i>=0)h=h.slice(0,i)+timeline()+h.slice(i);
  return h+helixCard();
};
/* hero: drifting molecules, tap the flask for bubbles */
const _sky10=skyHero;
skyHero=function(){
  const mol=[[176,30,.7,0],[226,92,.55,3],[150,104,.6,6]].map(m=>`<g class="mol" style="animation-delay:-${m[3]}s" transform="translate(${m[0]} ${m[1]}) scale(${m[2]})"><path d="M10 0l8.660 5v10L10 20l-8.660-5V5z" fill="none" stroke="#fff" stroke-opacity=".45" stroke-width="1.600"/><circle cx="10" cy="10" r="4.500" fill="none" stroke="#fff" stroke-opacity=".35" stroke-width="1.200"/></g>`).join('');
  return _sky10().replace('<rect width="360" height="150" fill="url(#skg)"/>','<rect width="360" height="150" fill="url(#skg)"/>'+mol).replace('</svg><div class="skytext">','<rect x="282" y="70" width="58" height="66" fill="transparent" data-a="flaskPop" style="cursor:pointer"/></svg><div class="skytext">');
};
/* quick-add button */
const FABI=[['task','Task','tasks','tomato'],['water','Water','drop','sky'],['money','Expense','wallet','leaf'],['caff','Caffeine','cup','sun'],['note','Note','book','grape'],['alarm','Alarm','moon','pink']];
function fab(){
  let f=document.getElementById('fab');
  if(!f){f=document.createElement('div');f.id='fab';f.innerHTML=`<div class="fabmenu">${FABI.map((x,i)=>`<button class="fabi" data-a="fabGo" data-v="${x[0]}" style="--i:${i}"><b>${x[1]}</b><span class="fabic t-${x[3]}">${ill(x[2])}</span></button>`).join('')}</div><button class="fabbtn" data-a="fabTog" aria-label="Quick add">${ic('plus')}</button>`;document.body.appendChild(f)}
  f.classList.toggle('hide',!!document.getElementById('onb'));
}
Object.assign(A,{
  tEdit(d){const t=S.tasks.find(x=>x.id===d.id);form('Edit task',tF(),Object.assign({alarm:'0'},t),v=>upsert('tasks',t.id,v),()=>remove('tasks',t.id))},
  tNew(){form('New task',tF(),{due:today(),alarm:'0',pri:'Normal'},v=>upsert('tasks',null,v,{done:false}))},
  remAdd(){form('New reminder',remF(),{repeat:'Every day',alarm:'0',day:new Date().getDay(),date:today()},v=>upsert('reminders',null,v,{on:1}))},
  remEdit(d){const r=S.reminders.find(x=>x.id===d.id);form(isAl(r.alarm)?'Edit alarm':'Edit reminder',remF(),Object.assign({alarm:'0'},r),v=>upsert('reminders',r.id,v),()=>remove('reminders',r.id))},
  alAdd(){form('New alarm',remF(),{repeat:'Once',alarm:'1',day:new Date().getDay(),date:today(),time:hm(nowMin()+60)},v=>upsert('reminders',null,v,{on:1}))},
  eAdd(){form('New event',evF,{date:ui.day,alarm:'0'},v=>upsert('events',null,v))},
  eEdit(d){const e=S.events.find(x=>x.id===d.id);form('Edit event',evF,Object.assign({alarm:'0'},e),v=>upsert('events',e.id,v),()=>remove('events',e.id))},
  alTest(){if(NV&&NV.testAlarm){try{NV.testAlarm();say('al','Close the app. The alarm rings in 10 seconds.')}catch(e){say('al','Could not set the test alarm.')}}else{say('al','The alarm rings in 10 seconds. Keep the app open.');setTimeout(()=>alarmScreen({t:hm(nowMin()),title:'Test alarm',src:'Alarm'}),10000)}},
  alStop(){alarmStop()},
  alSnooze(){const el=document.getElementById('alarmx'),x={t:hm(nowMin()+5),title:el?el.dataset.t:'Alarm',src:'Snoozed'};alarmStop();clearTimeout(alSnz);alSnz=setTimeout(()=>alarmScreen(x),5*6e4)},
  flaskPop(d,el){const r=el.getBoundingClientRect();for(let i=0;i<3;i++)setTimeout(()=>burst(r.left+r.width*(.3+Math.random()*.4),r.top+r.height*(.2+Math.random()*.5)),i*120)},
  fabTog(){const f=document.getElementById('fab');if(f)f.classList.toggle('open')},
  fabGo(d){const f=document.getElementById('fab');if(f)f.classList.remove('open');
    if(d.v==='task')A.tNew();else if(d.v==='water'){A.water({n:1});toast({title:'Water added: '+(S.water[today()]||0)+' of '+S.settings.waterGoal,src:'Water',t:hm(nowMin())})}
    else if(d.v==='money')A.mAdd();else if(d.v==='caff')A.cfAdd();else if(d.v==='note')A.nAdd({ref:''});else A.alAdd()}
});
document.addEventListener('click',e=>{const f=document.getElementById('fab');if(f&&f.classList.contains('open')&&(e.target===f||!e.target.closest('#fab')))f.classList.remove('open')});
const _ar10=window.afterRender;
window.afterRender=function(){_ar10();fab();if(ui.tab==='today'){const r=document.getElementById('tlrow'),n=document.getElementById('tlnow');if(r&&n&&r.scrollTo)r.scrollTo({left:Math.max(0,n.offsetLeft-24),behavior:'auto'})}};
setInterval(()=>{const ae=document.activeElement;if(ui.tab==='today'&&!F&&!document.getElementById('onb')&&!document.getElementById('alarmx')&&!(ae&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))){const r=document.getElementById('tlrow'),k=r?r.scrollLeft:0;render();const r2=document.getElementById('tlrow');if(r2)r2.scrollLeft=k}},60000);
window.__v10={timeline:timeline,isAl:isAl};


/* ================= Round 2: Bangla language ================= */
DEF_SET.lang='en';normalize();
const BN={
'Today':'আজ','Plan':'পরিকল্পনা','Study':'পড়াশোনা','Lab':'ল্যাব','Deen':'দ্বীন','Life':'জীবন','More':'আরও','Keep':'সংরক্ষণ','My day':'আমার দিন',
'Tasks':'কাজ','Task':'কাজ','Calendar':'ক্যালেন্ডার','Class routine':'ক্লাস রুটিন','Courses':'কোর্স','Course':'কোর্স','Exams':'পরীক্ষা','Timer':'টাইমার','Research':'গবেষণা','Files':'ফাইল','PDF tools':'PDF টুলস','Grade predictor':'গ্রেড প্রেডিক্টর','Attendance':'উপস্থিতি','Citations':'সাইটেশন',
'Calculators':'ক্যালকুলেটর','Curves':'কার্ভ','Microbes':'জীবাণু','Recipes':'রেসিপি','Test guide':'টেস্ট গাইড','Protocols':'প্রোটোকল','Reagents':'রিএজেন্ট','Colony & gel':'কলোনি ও জেল','Sequence':'সিকোয়েন্স','Reference':'রেফারেন্স','Timers':'টাইমার','Notebook':'নোটবুক',
'Prayer':'নামাজ','Quran':'কুরআন','Duas':'দোয়া','Tasbih':'তাসবিহ','Hadith':'হাদিস',
'Water':'পানি','Food':'খাবার','Habits':'অভ্যাস','Sleep':'ঘুম','Health':'স্বাস্থ্য','Activities':'কার্যকলাপ','Money':'টাকা','Caffeine':'ক্যাফেইন','Insights':'বিশ্লেষণ',
'Reminders':'রিমাইন্ডার','Links':'লিংক','Notes':'নোট','Mail':'মেইল','History':'ইতিহাস','Feedback':'মতামত','Personalise':'নিজের মতো সাজান','Settings':'সেটিংস','Settings and backup':'সেটিংস ও ব্যাকআপ',
'Saved':'সংরক্ষিত','Saving…':'সংরক্ষণ হচ্ছে…','Loading…':'লোড হচ্ছে…','Saved on this phone only':'শুধু এই ফোনে সংরক্ষিত','Offline · saved on phone':'অফলাইন · ফোনে সংরক্ষিত',
'Open menu':'মেনু খুলুন','Close':'বন্ধ করুন','Save':'সংরক্ষণ','Delete':'মুছুন','Tap again to delete':'মুছতে আবার চাপুন','Edit':'সম্পাদনা','Add':'যোগ করুন','Open':'খুলুন','Back':'পেছনে','Next':'পরবর্তী','Skip':'বাদ দিন','Done':'সম্পন্ন','Undo':'ফিরিয়ে নিন','Clear':'মুছে ফেলুন','Copy':'কপি','Copy all':'সব কপি','Change':'পরিবর্তন','Start':'শুরু','Pause':'বিরতি','Resume':'আবার শুরু','Reset':'রিসেট','Upload':'আপলোড','Read':'পড়ুন','Yes':'হ্যাঁ','No':'না','None':'কোনোটি নয়','Other':'অন্যান্য','All':'সব','OK':'ঠিক আছে','Cancel':'বাতিল','Stop':'থামান','Snooze 5 min':'৫ মিনিট পরে',
'Good morning':'শুভ সকাল','Good afternoon':'শুভ অপরাহ্ন','Good evening':'শুভ সন্ধ্যা','Good night':'শুভ রাত্রি','Peaceful night':'শান্তিময় রাত','Happy birthday':'শুভ জন্মদিন','Welcome':'স্বাগতম','Assalamu alaikum':'আসসালামু আলাইকুম',
'Fajr':'ফজর','Dhuhr':'যোহর','Asr':'আসর','Maghrib':'মাগরিব','Isha':'এশা','Sunrise':'সূর্যোদয়',
'Your day':'আপনার দিন','All done for today':'আজকের সব শেষ','Now':'এখন','Due now':'এখন করণীয়','All tasks':'সব কাজ','Add a task for today':'আজকের জন্য একটি কাজ লিখুন','New task for today':'আজকের নতুন কাজ','Add task':'কাজ যোগ করুন','Biochem bite of the day':'আজকের বায়োকেম তথ্য','Gentle nudges':'ছোট্ট মনে করিয়ে দেওয়া','Dismiss for today':'আজকের জন্য সরান','How did today go?':'আজকের দিন কেমন গেল?','Your week':'আপনার সপ্তাহ',
'All clear':'সব শেষ','Tasks due':'বাকি কাজ','Spent today':'আজ খরচ','No class today':'আজ ক্লাস নেই','Classes over':'ক্লাস শেষ','Sleep not logged':'ঘুম লেখা হয়নি','Slept':'ঘুমিয়েছেন','Study time':'পড়ার সময়','No exam set':'কোনো পরীক্ষা নেই','Bench tools':'ল্যাব টুলস','Timers running':'টাইমার চলছে','Ayahs today':'আজকের আয়াত','Meals logged':'খাবার লেখা হয়েছে','Doses left':'বাকি ডোজ','Medicine done':'ওষুধ খাওয়া শেষ','Add one glass':'এক গ্লাস যোগ করুন','Add money entry':'খরচ যোগ করুন',
'Quick add':'দ্রুত যোগ','Expense':'খরচ','Note':'নোট','Alarm':'অ্যালার্ম','Alarms':'অ্যালার্ম','New alarm':'নতুন অ্যালার্ম','Alert type':'সতর্কতার ধরন','Notification':'নোটিফিকেশন','Alarm (rings until you stop it)':'অ্যালার্ম (বন্ধ না করা পর্যন্ত বাজবে)','No more alarms today.':'আজ আর কোনো অ্যালার্ম নেই।','Wake me for Fajr with an alarm':'ফজরের জন্য অ্যালার্ম দিয়ে জাগান','Ring medicine doses as alarms when I am sick':'অসুস্থ থাকলে ওষুধের সময় অ্যালার্ম বাজান','Your alarms':'আপনার অ্যালার্ম','Fajr alarm':'ফজরের অ্যালার্ম','Medicine alarms':'ওষুধের অ্যালার্ম',
'Streak':'ধারাবাহিকতা','Restore my streak':'ধারাবাহিকতা ফিরিয়ে আনুন','Start fresh':'নতুন করে শুরু',
'New task':'নতুন কাজ','Edit task':'কাজ সম্পাদনা','Due date':'শেষ তারিখ','Time (needed for a notification or alarm)':'সময় (নোটিফিকেশন বা অ্যালার্মের জন্য দরকার)','Category':'বিভাগ','Priority':'অগ্রাধিকার','Normal':'সাধারণ','High':'জরুরি','Academic':'একাডেমিক','University':'বিশ্ববিদ্যালয়','Personal':'ব্যক্তিগত','Home':'বাসা',
'Planned versus done':'পরিকল্পনা বনাম সম্পন্ন','Previous week':'আগের সপ্তাহ','Next week':'পরের সপ্তাহ','Previous day':'আগের দিন','Next day':'পরের দিন','Previous month':'আগের মাস','Next month':'পরের মাস','New event':'নতুন ইভেন্ট','Edit event':'ইভেন্ট সম্পাদনা','Event':'ইভেন্ট','Date':'তারিখ','Time':'সময়','A free day':'একটি ফাঁকা দিন','Weekly classes':'সাপ্তাহিক ক্লাস','New class':'নতুন ক্লাস','Edit class':'ক্লাস সম্পাদনা','Class':'ক্লাস','Or type a name':'অথবা নাম লিখুন','Day':'দিন','Starts':'শুরু','Ends':'শেষ','Room':'রুম','No course':'কোর্স নেই','No classes yet':'এখনো কোনো ক্লাস নেই',
'Saturday':'শনিবার','Sunday':'রবিবার','Monday':'সোমবার','Tuesday':'মঙ্গলবার','Wednesday':'বুধবার','Thursday':'বৃহস্পতিবার','Friday':'শুক্রবার',
'New course':'নতুন কোর্স','Edit course':'কোর্স সম্পাদনা','Course title':'কোর্সের নাম','Course code':'কোর্স কোড','Teacher':'শিক্ষক','Credits':'ক্রেডিট','Add your first course':'প্রথম কোর্স যোগ করুন','Current semester':'চলতি সেমিস্টার','New semester':'নতুন সেমিস্টার','Start a new semester':'নতুন সেমিস্টার শুরু করুন','Name of the new semester':'নতুন সেমিস্টারের নাম','Name of the semester that ended':'যে সেমিস্টার শেষ হলো তার নাম','Add the finished courses to my CGPA list':'শেষ হওয়া কোর্সগুলো CGPA তালিকায় যোগ করুন','Yes, so I can enter their grades':'হ্যাঁ, গ্রেড লিখতে চাই','Weekly class routine':'সাপ্তাহিক ক্লাস রুটিন','Clear it for the new semester':'নতুন সেমিস্টারের জন্য মুছে দিন','Keep it':'রেখে দিন','Not named yet':'এখনো নাম দেওয়া হয়নি','Past':'পুরোনো',
'Exams and deadlines':'পরীক্ষা ও ডেডলাইন','Coming up':'আসছে','New exam or deadline':'নতুন পরীক্ষা বা ডেডলাইন','Nothing scheduled':'কিছু নির্ধারিত নেই','Nothing upcoming.':'সামনে কিছু নেই।','What':'কী','Type':'ধরন','Quiz':'কুইজ','Mid-term':'মিড-টার্ম','Final':'ফাইনাল','Assignment':'অ্যাসাইনমেন্ট','Presentation':'প্রেজেন্টেশন','Lab report':'ল্যাব রিপোর্ট','Viva':'ভাইভা','Tomorrow':'আগামীকাল',
'Focus':'মনোযোগ','Studying':'যা পড়ছি','Stop and log':'থামিয়ে লিখে রাখুন','Skip break':'বিরতি বাদ দিন','Last 7 days':'গত ৭ দিন','Log study time by hand':'নিজে পড়ার সময় লিখুন','Log study time':'পড়ার সময় লিখুন','Minutes':'মিনিট',
'Where I stand now':'আমি এখন কোথায়','Target':'লক্ষ্য','My target':'আমার লক্ষ্য','CGPA I want':'যে CGPA চাই','Credits still to take':'যত ক্রেডিট বাকি','Current CGPA':'বর্তমান CGPA','Credits completed':'সম্পন্ন ক্রেডিট','When I retake a course, count':'কোর্স রিটেক করলে গণনা হবে','Latest grade':'সর্বশেষ গ্রেড','Better grade':'ভালো গ্রেড','Semester':'সেমিস্টার','New semester ':'নতুন সেমিস্টার','Course grade':'কোর্সের গ্রেড','Add grade':'গ্রেড যোগ করুন','Edit grade':'গ্রেড সম্পাদনা','Grade':'গ্রেড','Is this a retake?':'এটি কি রিটেক?','No, first attempt':'না, প্রথমবার','NSU grading scale':'NSU গ্রেডিং স্কেল','North South University scale':'নর্থ সাউথ ইউনিভার্সিটি স্কেল','Semester name':'সেমিস্টারের নাম','Add a part':'একটি অংশ যোগ করুন','Edit part':'অংশ সম্পাদনা','Part':'অংশ','Weight (% of the course grade)':'গুরুত্ব (কোর্স গ্রেডের %)','Your mark (leave empty if not done yet)':'আপনার নম্বর (না হলে ফাঁকা রাখুন)','Out of':'মোট নম্বর','Pending':'বাকি','Add your courses first':'আগে কোর্স যোগ করুন',
'By course':'কোর্স অনুযায়ী','Present':'উপস্থিত','Absent':'অনুপস্থিত','Required attendance':'প্রয়োজনীয় উপস্থিতি','Required percentage':'প্রয়োজনীয় শতাংশ',
'Reference list (APA 7)':'রেফারেন্স তালিকা (APA 7)','Add a reference':'রেফারেন্স যোগ করুন','Edit reference':'রেফারেন্স সম্পাদনা','No references yet':'এখনো কোনো রেফারেন্স নেই','General':'সাধারণ','Authors, one per line':'লেখক, প্রতি লাইনে একজন','Title':'শিরোনাম','Volume':'ভলিউম','Issue':'ইস্যু','Pages':'পৃষ্ঠা','DOI or link':'DOI বা লিংক','Research project':'গবেষণা প্রকল্প','Journal article':'জার্নাল আর্টিকেল','Book':'বই','Website':'ওয়েবসাইট','Journal, publisher or website name':'জার্নাল, প্রকাশক বা ওয়েবসাইটের নাম',
'Study files':'পড়ার ফাইল','Put new uploads in':'নতুন ফাইল রাখুন','Keep new files':'নতুন ফাইল রাখুন','In my account':'আমার অ্যাকাউন্টে','On this phone':'এই ফোনে','No files yet':'এখনো কোনো ফাইল নেই','File':'ফাইল','Name':'নাম',
'Merge PDFs':'PDF একসাথে করুন','Merge into one':'একটিতে মেলান','Split a PDF':'PDF ভাগ করুন','Extract pages':'পৃষ্ঠা বের করুন','Pages to keep':'যে পৃষ্ঠাগুলো রাখবেন','Photos to PDF':'ছবি থেকে PDF','Make PDF':'PDF বানান','Save to phone':'ফোনে সংরক্ষণ','Keep in Files':'ফাইলে রাখুন','Word counter':'শব্দ গণনা','Word or PowerPoint to PDF':'Word বা PowerPoint থেকে PDF',
'New research project':'নতুন গবেষণা প্রকল্প','Edit project':'প্রকল্প সম্পাদনা','Project title':'প্রকল্পের নাম','Stage':'ধাপ','Summary':'সারসংক্ষেপ','To-do':'করণীয়','Next step':'পরের ধাপ','Papers and references':'পেপার ও রেফারেন্স','Idea':'ধারণা','Proposal':'প্রস্তাবনা','Literature review':'সাহিত্য পর্যালোচনা','Data collection':'তথ্য সংগ্রহ','Analysis':'বিশ্লেষণ','Writing':'লেখা','Submitted':'জমা দেওয়া হয়েছে',
'Lab bench':'ল্যাব বেঞ্চ','Calculators, sequences and quick reference':'ক্যালকুলেটর, সিকোয়েন্স ও দ্রুত রেফারেন্স','Search calculators':'ক্যালকুলেটর খুঁজুন','Solutions':'দ্রবণ','Microbiology':'মাইক্রোবায়োলজি','Molecular':'মলিকুলার','Lab calculators':'ল্যাব ক্যালকুলেটর','Standard curves':'স্ট্যান্ডার্ড কার্ভ','Bacteria finder':'ব্যাকটেরিয়া শনাক্তকারী','Media and buffers':'মিডিয়া ও বাফার','Quick reference':'দ্রুত রেফারেন্স','Lab timers':'ল্যাব টাইমার','Lab notebook':'ল্যাব নোটবুক','Colony counter & gel notes':'কলোনি গণনা ও জেল নোট','Colony counter':'কলোনি গণনা','Gel notes':'জেল নোট','Take or choose a photo':'ছবি তুলুন বা বেছে নিন','Choose another photo':'অন্য ছবি বেছে নিন','Save marked photo to Files':'চিহ্নিত ছবি ফাইলে রাখুন','Use this count in CFU/mL':'এই গণনা CFU/mL-এ ব্যবহার করুন','Label':'লেবেল','Label text':'লেবেলের লেখা',
'Reagents and supplies':'রিএজেন্ট ও সরঞ্জাম','Search reagents':'রিএজেন্ট খুঁজুন','Add a reagent':'রিএজেন্ট যোগ করুন','Edit reagent':'রিএজেন্ট সম্পাদনা','Use':'ব্যবহার','Amount left':'বাকি পরিমাণ','Unit':'একক','Warn me when it falls to':'এর নিচে নামলে জানাবেন','Expiry date':'মেয়াদ শেষের তারিখ','Where it is kept':'কোথায় রাখা','Notes ':'নোট','Running low':'কমে আসছে','Expired':'মেয়াদ শেষ','Nothing listed yet':'এখনো কিছু তালিকায় নেই',
'Fit a line to your data':'আপনার ডেটায় লাইন বসান','Standard curve':'স্ট্যান্ডার্ড কার্ভ','Enzyme kinetics':'এনজাইম কাইনেটিক্স','Replicates':'রেপ্লিকেট','Reading of your unknown':'অজানা নমুনার রিডিং','Your replicate readings':'আপনার রেপ্লিকেট রিডিং',
'Volume I want to make (mL)':'কত mL বানাবেন','Step-by-step protocols':'ধাপে ধাপে প্রোটোকল','My own':'নিজের','My protocol':'আমার প্রোটোকল','Edit protocol':'প্রোটোকল সম্পাদনা','Protocol name':'প্রোটোকলের নাম','Protocols ':'প্রোটোকল','Search a test':'টেস্ট খুঁজুন','Microbiology tests':'মাইক্রোবায়োলজি টেস্ট','Qualitative biochemistry tests':'গুণগত বায়োকেমিস্ট্রি টেস্ট','Lab safety':'ল্যাব নিরাপত্তা','Bench notes':'বেঞ্চ নোট','Common acids':'সাধারণ অ্যাসিড','Amino acids':'অ্যামিনো অ্যাসিড','Wavelengths to read at':'যে তরঙ্গদৈর্ঘ্যে পড়বেন','Which micropipette':'কোন মাইক্রোপিপেট','Codon table':'কোডন টেবিল','Sequence tools':'সিকোয়েন্স টুলস','Protein from its sequence':'সিকোয়েন্স থেকে প্রোটিন','Custom':'নিজের মতো','Custom timer':'নিজের টাইমার','What is it for?':'কীসের জন্য?','No timer is running.':'কোনো টাইমার চলছে না।','New practical':'নতুন প্র্যাকটিক্যাল','Practical':'প্র্যাকটিক্যাল',
'Prayer times':'নামাজের সময়','This week':'এই সপ্তাহ','Qaza prayers':'কাযা নামাজ','Missed prayers still to make up':'যে নামাজগুলো কাযা করা বাকি','Fasting':'রোজা','I am fasting today':'আজ আমি রোজা রেখেছি','this month':'এই মাসে','Qibla':'কিবলা','Qibla compass':'কিবলা কম্পাস','Start compass':'কম্পাস চালু করুন','You are facing the Qibla.':'আপনি কিবলার দিকে আছেন।','Prayer settings':'নামাজের সেটিংস','City':'শহর','Asr time':'আসরের সময়','Hanafi':'হানাফি','Shafi':'শাফেয়ি','Tap a box to mark a prayer you offered.':'যে নামাজ পড়েছেন তার ঘরে চাপুন।','Sunnah for today':'আজকের সুন্নাহ','Jumu‘ah Mubarak':'জুমা মোবারক',
'Daily recitation':'দৈনিক তিলাওয়াত','Daily goal':'দৈনিক লক্ষ্য','Daily Quran goal':'দৈনিক কুরআনের লক্ষ্য','Ayahs per day':'প্রতিদিন আয়াত','Bookmark':'বুকমার্ক','Set a bookmark':'বুকমার্ক রাখুন','Move bookmark':'বুকমার্ক সরান','Continue reading':'পড়া চালিয়ে যান','Surahs':'সূরা','Surah':'সূরা','Ayah':'আয়াত','Tick a surah when you finish it.':'সূরা শেষ হলে টিক দিন।',
'Daily duas':'দৈনিক দোয়া','Morning and evening':'সকাল ও সন্ধ্যা','After each prayer':'প্রতি নামাজের পর','Through the day':'সারাদিন','Before sleep':'ঘুমানোর আগে','My duas':'আমার দোয়া','Add your own dua':'নিজের দোয়া যোগ করুন','Add a dua':'দোয়া যোগ করুন','New dua':'নতুন দোয়া','Edit dua':'দোয়া সম্পাদনা','Name of the dua':'দোয়ার নাম','Arabic or Bangla text':'আরবি বা বাংলা লেখা','Meaning':'অর্থ','When to recite':'কখন পড়বেন','Times per day':'দিনে কতবার','Meaning in English':'ইংরেজিতে অর্থ','Read on Quran.com':'Quran.com-এ পড়ুন','Short hadith to live by':'জীবনের জন্য ছোট হাদিস',
'Water goal':'পানির লক্ষ্য','I drank a glass':'এক গ্লাস খেয়েছি','Remove one glass':'এক গ্লাস কমান','How much water?':'কতটা পানি?','Guideline':'নির্দেশিকা',
'Log a meal':'খাবার লিখুন','Edit meal':'খাবার সম্পাদনা','Breakfast':'সকালের নাস্তা','Lunch':'দুপুরের খাবার','Dinner':'রাতের খাবার','Snack':'হালকা খাবার','Not logged':'লেখা হয়নি','What did you eat?':'কী খেয়েছেন?','Meal':'খাবার','Where from':'কোথা থেকে','Homemade':'বাসার','Hall or canteen':'হল বা ক্যান্টিন','Restaurant':'রেস্টুরেন্ট','Junk food':'জাঙ্ক ফুড','Cost':'দাম','Fruit and vegetables':'ফল ও সবজি','I ate a portion':'এক পরিবেশন খেয়েছি','Eating well':'ভালোভাবে খাওয়া','breakfasts eaten':'দিন নাস্তা','junk meals':'বার জাঙ্ক ফুড','spent on food':'খাবারে খরচ',
'Daily habits':'দৈনিক অভ্যাস','New habit':'নতুন অভ্যাস','Edit habit':'অভ্যাস সম্পাদনা','Habit':'অভ্যাস','Build':'গড়ে তোলা','Quit':'ছেড়ে দেওয়া','Days per week':'সপ্তাহে কত দিন','Build a routine':'একটি রুটিন গড়ুন','Last 30 days':'গত ৩০ দিন','Building habits':'অভ্যাস গড়ে তোলা',
'Going to bed now':'এখন ঘুমাতে যাচ্ছি','I am awake. Log my sleep':'জেগে উঠেছি, ঘুম লিখুন','Log by hand':'নিজে লিখুন','Log sleep':'ঘুম লিখুন','Edit sleep':'ঘুম সম্পাদনা','Schedule':'সময়সূচি','Sleep schedule':'ঘুমের সময়সূচি','Bedtime':'ঘুমানোর সময়','Wake-up time':'ওঠার সময়','Sleep cycles':'ঘুমের চক্র','last night':'গত রাতে','7-day average':'৭ দিনের গড়','sleep debt':'ঘুমের ঘাটতি','Morning of':'যে সকালের','Went to bed':'ঘুমাতে গেছি','Woke up':'উঠেছি','How was it?':'কেমন ছিল?','Good':'ভালো','Okay':'মোটামুটি','Poor':'খারাপ','How much sleep?':'কতটা ঘুম দরকার?','Last 7 nights':'গত ৭ রাত','To wake at':'উঠতে চাইলে','If you sleep now, wake at':'এখন ঘুমালে উঠুন',
'Feeling well':'সুস্থ আছি','I am sick':'আমি অসুস্থ','I have recovered':'আমি সুস্থ হয়েছি','Health history':'স্বাস্থ্যের ইতিহাস','Prescription':'প্রেসক্রিপশন','Add medicine':'ওষুধ যোগ করুন','Edit medicine':'ওষুধ সম্পাদনা','Medicine':'ওষুধ','Dose':'ডোজ','When':'কখন','With food':'খাবারের সাথে','After food':'খাবারের পরে','Before food':'খাবারের আগে','Any time':'যেকোনো সময়','For how many days':'কত দিন','Starting':'শুরু','Doses today':'আজকের ডোজ','Medicine today':'আজকের ওষুধ','Photo of prescription':'প্রেসক্রিপশনের ছবি','Symptoms and temperature':'উপসর্গ ও তাপমাত্রা','Log how you feel':'কেমন লাগছে লিখুন','Symptoms':'উপসর্গ','Temperature in °F':'তাপমাত্রা (°F)','What is wrong?':'কী সমস্যা?','Doctor':'ডাক্তার','Since':'কবে থেকে','Notes':'নোট','When you are sick':'অসুস্থ হলে','Morning':'সকাল','Night':'রাত','Morning and night':'সকাল ও রাত','Morning, noon and night':'সকাল, দুপুর ও রাত','Custom times':'নিজের সময়','No doses on this day.':'এই দিনে কোনো ডোজ নেই।',
'Log an activity':'কার্যকলাপ লিখুন','Edit activity':'কার্যকলাপ সম্পাদনা','What did you do?':'কী করেছেন?','Sports':'খেলাধুলা','Exercise':'ব্যায়াম','Club':'ক্লাব','Social':'সামাজিক','Family':'পরিবার','Hobby':'শখ','Nothing logged':'কিছু লেখা হয়নি','How active should I be?':'কতটা সক্রিয় থাকা উচিত?',
'Add entry':'এন্ট্রি যোগ করুন','Money entry':'টাকার হিসাব','Edit entry':'এন্ট্রি সম্পাদনা','Amount':'পরিমাণ','Kind':'ধরন','Spent':'খরচ','Received':'পেয়েছি','Entries':'হিসাব','Where it went':'কোথায় খরচ হলো','No entries this month':'এই মাসে কোনো হিসাব নেই','Insights':'বিশ্লেষণ','per day':'প্রতিদিন','month forecast':'মাসের অনুমান','vs last month':'গত মাসের তুলনায়','Savings goals':'সঞ্চয়ের লক্ষ্য','New savings goal':'নতুন সঞ্চয়ের লক্ষ্য','Saving for':'কীসের জন্য সঞ্চয়','Target amount':'লক্ষ্যের পরিমাণ','Saved so far':'এ পর্যন্ত জমেছে','Lent and borrowed':'ধার দেওয়া ও নেওয়া','Lent or borrowed':'ধার দেওয়া বা নেওয়া','Person':'ব্যক্তি','Which way':'কোন দিকে','I lent':'আমি ধার দিয়েছি','I borrowed':'আমি ধার নিয়েছি','Settled':'পরিশোধিত','Monthly bills':'মাসিক বিল','New monthly bill':'নতুন মাসিক বিল','Bill':'বিল','Due on day of month':'মাসের কত তারিখে','Paid':'পরিশোধিত','Split a bill':'বিল ভাগ করুন','Total':'মোট','People':'জন','Monthly income':'মাসিক আয়','What I receive each month':'প্রতি মাসে যা পাই','Income':'আয়','Managing money as a student':'ছাত্র হিসেবে টাকা সামলানো','50 / 30 / 20 check':'৫০ / ৩০ / ২০ হিসাব','Needs':'প্রয়োজন','Wants':'চাওয়া','Saved ':'সঞ্চয়','Food ':'খাবার','Transport':'যাতায়াত','Mobile and internet':'মোবাইল ও ইন্টারনেট','Shopping':'কেনাকাটা','Fun':'বিনোদন','Attach a receipt photo':'রসিদের ছবি যুক্ত করুন','Open receipt':'রসিদ খুলুন',
'Caffeine today':'আজকের ক্যাফেইন','in you now':'এখন শরীরে','left at bedtime':'ঘুমানোর সময় থাকবে','last cup by':'শেষ কাপ এর মধ্যে','Add a drink now':'এখন একটি পানীয় যোগ করুন','Other or another time':'অন্যটি বা অন্য সময়','Add caffeine':'ক্যাফেইন যোগ করুন','Drink':'পানীয়','Caffeine in mg (for Other)':'ক্যাফেইন mg (অন্যটির জন্য)','Milk tea (cha)':'দুধ চা','Black tea':'রং চা','Instant coffee':'ইনস্ট্যান্ট কফি','Brewed coffee':'ব্রিউড কফি','Caffeine and sleep':'ক্যাফেইন ও ঘুম','Your bedtime should be mostly caffeine-free.':'ঘুমানোর সময় শরীরে ক্যাফেইন প্রায় থাকবে না।',
'Patterns in your days':'আপনার দিনের প্যাটার্ন','Experiments on yourself':'নিজের ওপর পরীক্ষা','New experiment':'নতুন পরীক্ষা','Edit experiment':'পরীক্ষা সম্পাদনা','What will you change?':'কী পরিবর্তন করবেন?','What to watch':'কী লক্ষ্য করবেন','How long':'কত দিন','Start date':'শুরুর তারিখ','Finished':'শেষ','result':'ফলাফল','Study time ':'পড়ার সময়','Tasks finished':'শেষ করা কাজ','Average sleep':'গড় ঘুম','Water a day':'দিনে পানি','Active time':'সক্রিয় সময়','Caffeine a day':'দিনে ক্যাফেইন','Prayers':'নামাজ','Spending':'খরচ','same':'একই',
'Alerts':'সতর্কতা','Test alert':'টেস্ট অ্যালার্ট','Try phone notifications':'ফোনের নোটিফিকেশন চালু করুন','My reminders':'আমার রিমাইন্ডার','New reminder':'নতুন রিমাইন্ডার','Edit reminder':'রিমাইন্ডার সম্পাদনা','Edit alarm':'অ্যালার্ম সম্পাদনা','Remind me to':'মনে করিয়ে দিন','Repeat':'পুনরাবৃত্তি','Once':'একবার','Every day':'প্রতিদিন','Sun to Thu':'রবি থেকে বৃহস্পতি','Every week':'প্রতি সপ্তাহে','Day (for every week)':'দিন (সাপ্তাহিক হলে)','Date (for once)':'তারিখ (একবার হলে)','Automatic alerts':'স্বয়ংক্রিয় সতর্কতা','Prayer times ':'নামাজের সময়','Medicine doses when I am sick':'অসুস্থ থাকলে ওষুধের ডোজ','Water nudges':'পানির কথা মনে করানো','Off':'বন্ধ','Every hour':'প্রতি ঘণ্টায়','Phone notifications':'ফোনের নোটিফিকেশন','Allow notifications':'নোটিফিকেশন চালু করুন',
'One place for every link':'সব লিংক এক জায়গায়','Search links':'লিংক খুঁজুন','New link':'নতুন লিংক','Edit link':'লিংক সম্পাদনা','Link':'লিংক','Quick notes':'দ্রুত নোট','New note':'নতুন নোট','No notes yet.':'এখনো কোনো নোট নেই।','Untitled note':'শিরোনামহীন নোট',
'My email':'আমার ইমেইল','Add my email':'ইমেইল যোগ করুন','Open inbox':'ইনবক্স খুলুন','Write a mail':'মেইল লিখুন','People I mail':'যাদের মেইল করি','Contact':'যোগাযোগ','New contact':'নতুন যোগাযোগ','Ready-made mails':'তৈরি মেইল','Leave application':'ছুটির আবেদন','Assignment submission':'অ্যাসাইনমেন্ট জমা','Ask for an appointment':'সাক্ষাতের অনুরোধ','Ask for an extension':'সময় বাড়ানোর অনুরোধ',
'Help improve Catalyst':'Catalyst-কে আরও ভালো করতে সাহায্য করুন','Tell the developer what to add, change or fix.':'ডেভেলপারকে জানান কী যোগ, পরিবর্তন বা ঠিক করতে হবে।','Your name':'আপনার নাম','What is it about?':'বিষয় কী?','New feature':'নতুন ফিচার','Change something':'কিছু পরিবর্তন','Something is broken':'কিছু কাজ করছে না','Your feedback':'আপনার মতামত','Send with Gmail':'Gmail দিয়ে পাঠান','Other mail app':'অন্য মেইল অ্যাপ',
'Appearance':'চেহারা','Light or dark':'লাইট বা ডার্ক','Match my phone':'ফোনের মতো','Light':'লাইট','Dark':'ডার্ক','Movement of icons and screens':'আইকন ও স্ক্রিনের নড়াচড়া','Lively':'প্রাণবন্ত','Calm':'শান্ত','Still':'স্থির','Text size':'লেখার আকার','Large':'বড়','Opening':'শুরুর দৃশ্য','Play the logo intro when the app opens':'অ্যাপ খুললে লোগো দেখান','Change my name and details':'নাম ও তথ্য পরিবর্তন','Run the welcome setup again':'শুরুর সেটআপ আবার চালান','Home screen':'হোম স্ক্রিন','Choose what appears on Today.':'আজ পাতায় কী দেখাবে বেছে নিন।','Row of the five prayers':'পাঁচ ওয়াক্ত নামাজের সারি','Sections':'বিভাগ','Show the Deen section':'দ্বীন বিভাগ দেখান','My photo':'আমার ছবি','Remove photo':'ছবি সরান','Language':'ভাষা',
'About me':'আমার সম্পর্কে','Birthday':'জন্মদিন','City for prayer times':'নামাজের সময়ের জন্য শহর','Back up to Google Drive':'Google Drive-এ ব্যাকআপ','Back up now':'এখনই ব্যাকআপ','Restore from a file':'ফাইল থেকে ফিরিয়ে আনুন','No backup yet.':'এখনো ব্যাকআপ নেই।','Replace my data':'আমার ডেটা প্রতিস্থাপন করুন','Memory':'মেমোরি','Permissions':'অনুমতি','Your settings':'আপনার সেটিংস','Edit ':'সম্পাদনা','Backup':'ব্যাকআপ','Copy backup':'ব্যাকআপ কপি','Restore from backup':'ব্যাকআপ থেকে ফিরিয়ে আনুন','Not set':'ঠিক করা হয়নি','Monthly budget':'মাসিক বাজেট','Currency':'মুদ্রা','Water goal ':'পানির লক্ষ্য','Study timer':'পড়ার টাইমার',
'Welcome to Catalyst':'Catalyst-এ স্বাগতম','Let’s begin':'শুরু করা যাক','What should we call you?':'আপনাকে কী নামে ডাকব?','Add a photo too if you like. Tap the circle.':'চাইলে একটি ছবিও দিন। বৃত্তে চাপুন।','Tap to add your photo':'ছবি দিতে চাপুন','When is your birthday?':'আপনার জন্মদিন কবে?','Date of birth':'জন্ম তারিখ','Your studies':'আপনার পড়াশোনা','Where do you live?':'আপনি কোথায় থাকেন?','Your daily health goals':'আপনার দৈনিক স্বাস্থ্য লক্ষ্য','Glasses of water a day':'দিনে কত গ্লাস পানি','Usual bedtime':'সাধারণত কখন ঘুমান','Usual wake-up time':'সাধারণত কখন ওঠেন','Make it yours':'নিজের মতো করে নিন','Movement':'নড়াচড়া','Start using Catalyst':'Catalyst ব্যবহার শুরু করুন','Show prayers, Quran and duas':'নামাজ, কুরআন ও দোয়া দেখান',
'App developed by':'অ্যাপটি তৈরি করেছেন','Undergraduate Student, Department of Biochemistry & Biotechnology, North South University':'স্নাতক শিক্ষার্থী, বায়োকেমিস্ট্রি ও বায়োটেকনোলজি বিভাগ, নর্থ সাউথ ইউনিভার্সিটি','My Daybook':'Catalyst',
'Nothing here':'এখানে কিছু নেই','Nothing logged.':'কিছু লেখা হয়নি।','Nothing was recorded on this day.':'এই দিনে কিছু লেখা হয়নি।','Done ':'সম্পন্ন','Due now ':'এখন করণীয়','Later':'পরে','Overdue':'সময় পেরিয়েছে','Well done':'চমৎকার','Test':'পরীক্ষা','Nudge':'মনে করানো','Reminder':'রিমাইন্ডার','Weekly summary':'সাপ্তাহিক সারাংশ','Water ':'পানি','Sleep ':'ঘুম','Bill ':'বিল','Lab timer':'ল্যাব টাইমার','Snoozed':'পরে বাজবে','Test alarm':'টেস্ট অ্যালার্ম',
'Prayer row':'নামাজের সারি','Exam, or medicine when sick':'পরীক্ষা, বা অসুস্থ হলে ওষুধ','Next class':'পরের ক্লাস','Meals':'খাবার','Deen section':'দ্বীন বিভাগ','Play the logo intro':'লোগো ইন্ট্রো দেখান','Choose my photo':'আমার ছবি বেছে নিন','Change my photo':'ছবি পরিবর্তন','English':'English','বাংলা':'বাংলা','feeling well':'সুস্থ আছেন','sick mode on':'অসুস্থ মোড চালু','no exam set':'কোনো পরীক্ষা নেই','Calculators, sequences and quick reference ':'','Timers running ':'','Reminders ':'রিমাইন্ডার'
};
const MON_BN={Jan:'জানু',Feb:'ফেব্রু',Mar:'মার্চ',Apr:'এপ্রিল',May:'মে',Jun:'জুন',Jul:'জুলাই',Aug:'আগস্ট',Sep:'সেপ্টে',Oct:'অক্টো',Nov:'নভে',Dec:'ডিসে'},DAY_BN={Sat:'শনি',Sun:'রবি',Mon:'সোম',Tue:'মঙ্গল',Wed:'বুধ',Thu:'বৃহস্পতি',Fri:'শুক্র'};
const DATE_RE=/\b(Sat|Sun|Mon|Tue|Wed|Thu|Fri), (\d{1,2}) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b/g;
const BNP=[
 [/^(\d+) ayahs$/,'$1 আয়াত'],[/^(\d+) steps$/,'$1 ধাপ'],[/^(\d+) days?$/,'$1 দিন'],[/^(\d+) minutes?$/,'$1 মিনিট'],[/^(\d+) min$/,'$1 মিনিট'],
 [/^(\d+) days? left$/,'$1 দিন বাকি'],[/^(\d+) coming up$/,'আরও $1টি আসছে'],[/^(\d+) of (\d+) today$/,'আজ $2টির মধ্যে $1টি'],[/^(\d+) of (\d+) glasses$/,'$2 গ্লাসের মধ্যে $1'],
 [/^(\d+)-day streak$/,'$1 দিনের ধারাবাহিকতা'],[/^(\d+) days?$/,'$1 দিন'],[/^Day (\d+) of (\d+)$/,'$2 দিনের $1তম দিন'],[/^(\d+) tasks? due$/,'$1টি কাজ বাকি'],
 [/^In (\d+) days$/,'$1 দিন পরে'],[/^Starts (.+)$/,'শুরু $1'],[/^Required (\d+)%$/,'প্রয়োজন $1%'],[/^GPA (.+)$/,'GPA $1'],[/^Later · (\d+)$/,'পরে · $1'],[/^Due now · (\d+)$/,'এখন করণীয় · $1'],[/^Done · (\d+)$/,'সম্পন্ন · $1'],
 [/^Detects: (.+)$/,'শনাক্ত করে: $1'],[/^Positive: (.+)$/,'পজিটিভ: $1'],[/^Add (Breakfast|Lunch|Dinner|Snack)$/,m=>'যোগ করুন: '+BN[m.slice(4)]],
 [/^(Fajr|Dhuhr|Asr|Maghrib|Isha) prayer time$/,m=>BN[m.split(' ')[0]]+' নামাজের সময়'],[/^(Fajr|Dhuhr|Asr|Maghrib|Isha) prayed$/,m=>BN[m.split(' ')[0]]+' পড়া হয়েছে'],[/^Next: (Fajr|Dhuhr|Asr|Maghrib|Isha)$/,m=>'পরবর্তী: '+BN[m.slice(6)]],
 [/^(Fajr|Dhuhr|Asr|Maghrib|Isha) at (.+) · in (.+)$/,(m,a,b,c)=>BN[a]+' '+b+' · '+c+' পরে'],[/^Hi, (.+)$/,'হাই, $1'],[/^Welcome, (.+)$/,'স্বাগতম, $1'],
 [/^(\d+) habits? (is|are) still open today\.$/,'আজ $1টি অভ্যাস এখনো বাকি।'],[/^Only (\d+) of (\d+) glasses of water so far today\.$/,'আজ এখন পর্যন্ত $2 গ্লাসের মধ্যে মাত্র $1 গ্লাস পানি।'],
 [/^You have not logged your sleep for 3 days\.$/,'৩ দিন ধরে ঘুম লেখা হয়নি।'],[/^(\d+) tasks are overdue\. Finish them or move them to a new day\.$/,'$1টি কাজের সময় পেরিয়ে গেছে। শেষ করুন বা অন্য দিনে সরান।'],
 [/^Move (\d+) unfinished to tomorrow$/,'বাকি $1টি কাল সরান'],[/^Water added: (\d+) of (\d+)$/,'পানি যোগ হলো: $2-এর মধ্যে $1'],[/^Best (\d+) · (\d+) of 3 restores left\. Open the app every day to keep it going\.$/,'সেরা $1 · ৩টির মধ্যে $2টি রিস্টোর বাকি। ধারাবাহিকতা ধরে রাখতে প্রতিদিন অ্যাপ খুলুন।'],
 [/^Going on semester break\? Tap Pause and your streak waits for you\.$/,'সেমিস্টার ব্রেকে যাচ্ছেন? বিরতিতে চাপুন, ধারাবাহিকতা আপনার জন্য অপেক্ষা করবে।'],[/^Streak paused at (\d+) days?$/,'ধারাবাহিকতা $1 দিনে থামানো আছে'],
 [/^Paused for your break\. Your streak is safe until you resume\.$/,'বিরতিতে থামানো। আবার শুরু না করা পর্যন্ত ধারাবাহিকতা নিরাপদ।'],[/^Paused$/,'বিরতিতে']
];
const SKIP_SEL='script,style,textarea,.seq,.ar,.cite,.note-body,code';
function bnText(t){
  if(BN[t]!=null)return BN[t];
  if(t.indexOf(' · ')>0){const p=t.split(' · '),q=p.map(x=>BN[x]!=null?BN[x]:bnPat(x));if(q.some((x,i)=>x!==p[i]))return q.join(' · ')}
  const r=bnPat(t);return r;
}
function bnPat(t){for(const p of BNP){if(p[0].test(t))return t.replace(p[0],p[1])}if(DATE_RE.test(t)){DATE_RE.lastIndex=0;return t.replace(DATE_RE,(m,d,n,mo)=>DAY_BN[d]+', '+n+' '+MON_BN[mo])}DATE_RE.lastIndex=0;return t}
let LANG=null;
const curLang=()=>LANG||S.settings.lang||'en';
function bnNode(root){
  if(curLang()!=='bn'||!root||!document.createTreeWalker)return;
  if(root.nodeType===3){bnTextNode(root);return}
  if(root.nodeType!==1||root.closest&&root.closest(SKIP_SEL))return;
  const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let n;const list=[];while((n=w.nextNode()))list.push(n);list.forEach(bnTextNode);
  const els=root.querySelectorAll?[root].concat([...root.querySelectorAll('[placeholder],[aria-label],[title]')]):[];
  els.forEach(e=>{['placeholder','aria-label','title'].forEach(a=>{const v=e.getAttribute&&e.getAttribute(a);if(v){const tv=v.trim(),x=bnText(tv);if(x!==tv)e.setAttribute(a,x)}})});
}
function bnTextNode(n){const p=n.parentElement;if(!p||p.closest(SKIP_SEL))return;const v=n.nodeValue,t=v.trim();if(!t||!/[A-Za-z]/.test(t))return;const x=bnText(t);if(x!==t)n.nodeValue=v.replace(t,x)}
let bnObs=null;
function bnApply(){
  const on=curLang()==='bn';document.documentElement.lang=on?'bn':'en';
  if(on&&!bnObs&&typeof MutationObserver!=='undefined'){bnObs=new MutationObserver(ms=>{if(curLang()!=='bn')return;ms.forEach(m=>{m.addedNodes.forEach(bnNode);if(m.type==='characterData')bnTextNode(m.target)})});bnObs.observe(document.body,{childList:true,subtree:true})}
  if(on)bnNode(document.body);
}
const _ar11=window.afterRender;
window.afterRender=function(){_ar11();bnApply()};
const _look11=EXT.look;
EXT.look=()=>`<div class="card"><h2>Language · ভাষা</h2><div class="chips">${[['en','English'],['bn','বাংলা']].map(x=>`<button class="chip${(S.settings.lang||'en')===x[0]?' on':''}" data-a="setLang" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><p class="muted">Menus, buttons and the main screens switch to Bangla. Science terms stay in English.</p></div>`+_look11();
const _obDraw=obDraw;
obDraw=function(){_obDraw();if(ob&&ob.i===0&&ob.el&&ob.el.querySelector){const st=ob.el.querySelector('.obstep');if(st&&!st.querySelector('.oblang')){const d=document.createElement('div');d.className='oblang';d.innerHTML=`<p class="muted">Choose your language · ভাষা বেছে নিন</p><div class="chips">${[['en','English'],['bn','বাংলা']].map(x=>`<button class="chip${curLang()===x[0]?' on':''}" data-a="obLang" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>`;st.appendChild(d)}}if(ob)bnApply()};
const _obDone=obDone;
obDone=function(){const l=ob&&ob.v.lang;if(l)S.settings.lang=l;LANG=null;_obDone()};
Object.assign(A,{
  setLang(d){S.settings.lang=d.v;save('settings');if(d.v==='en'){document.documentElement.lang='en'}render();const sh=document.getElementById('sheet');if(d.v==='bn')bnNode(document.body)},
  obLang(d){ob.v.lang=d.v;LANG=d.v;if(d.v==='en'){ob.el.remove();ob.el=document.createElement('div');ob.el.id='onb';document.body.appendChild(ob.el)}obDraw()}
});
window.__bn={bnText:bnText,BN:BN};


/* ================= v12: recently deleted, reset, multi-day classes, best-of grading, Ramadan, semester undo ================= */
KEYS.push('trash','ram');OBJ.push('ram');
Object.assign(DEF_SET,{ramOn:'auto',alSehri:0,sehriMin:45,ramIftar:1});
normalize();
SUB.more.splice(SUB.more.length-1,0,['trash','Recently deleted']);
SUB.deen.splice(1,0,['ramadan','Ramadan']);
MENU[MENU.length-1][1].push(['more','more','trash','Recently deleted','pink',()=>S.trash.length||'']);
{const g=MENU.find(x=>x[0]==='Deen');if(g)g[1].splice(1,0,['deen','deen','ramadan','Ramadan','leaf',()=>isRam()?'On':''])}
ILL.trash='<path d="M10 14h28l-2.500 26a3 3 0 0 1-3 2.700H15.500a3 3 0 0 1-3-2.700z" fill="var(--soft)"/><path d="M7 14h34M19 14V9h10v5M20 22v14M28 22v14"/>';
ILL.lantern='<path d="M24 4v5M18 9h12l3 6H15z" fill="var(--sun)"/><path d="M15 15h18v20a6 6 0 0 1-6 6h-6a6 6 0 0 1-6-6z" fill="var(--grape)"/><path d="M24 21c3 4 3 8 0 11-3-3-3-7 0-11z" fill="var(--sun)"/><path d="M19 41h10v3H19z"/>';

/* ---------- recently deleted ---------- */
const KL={tasks:'Task',events:'Event',routine:'Class',courses:'Course',exams:'Exam',sems:'Semester',research:'Research project',links:'Link',habits:'Habit',acts:'Activity',money:'Money entry',reminders:'Reminder',meals:'Meal',sleep:'Sleep log',sick:'Health record',goals:'Savings goal',debts:'Lent or borrowed',duas:'Dua',bills:'Bill',protocols:'Protocol',caff:'Caffeine',exps:'Experiment',reag:'Reagent',cites:'Reference',contacts:'Contact',focus:'Study time',files:'File',notes:'Note'};
const itemLabel=x=>String(x.title||x.name||x.text||x.person||x.what||x.note||x.cat||x.code||'Item');
function purgeTrash(){const keep=[],now=Date.now();(S.trash||[]).forEach(t=>{if(now-t.at<30*864e5)keep.push(t);else dropFiles(t)});if(keep.length!==(S.trash||[]).length){S.trash=keep;save('trash')}}
function dropFiles(t){const fs=t.key==='files'?[t.data]:t.kind==='reset'&&t.data.keys&&t.data.keys.files?t.data.keys.files:[];fs.forEach(f=>{try{if(f.asset&&AS)AS.delete(f.asset).catch(()=>{});else if(f.local)idbDo('readwrite',s=>s.delete(f.local)).catch(()=>{})}catch(e){}})}
function trashPut(label,kind,key,data){
  const j=JSON.stringify(data);if(j.length>180000)return false;
  S.trash.unshift({id:uid(),at:Date.now(),label:String(label).slice(0,90),kind:kind,key:key,data:JSON.parse(j)});
  while(S.trash.length>1&&JSON.stringify(S.trash).length>230000)dropFiles(S.trash.pop());
  save('trash');return true;
}
const _remove12=remove;
remove=function(key,id){const it=(S[key]||[]).find(x=>x.id===id);if(it)trashPut(key==='routine'?rName(it):itemLabel(it),KL[key]||key,key,it);_remove12(key,id)};
function restoreT(t){
  if(t.kind==='reset'){const d=t.data;Object.keys(d.keys||{}).forEach(k=>{const v=d.keys[k];if(Array.isArray(v)){const ids=new Set((S[k]||[]).map(x=>x.id));S[k]=(S[k]||[]).concat(v.filter(x=>!ids.has(x.id)))}else if(v&&typeof v==='object')S[k]=Object.assign({},v,S[k]);save(k)});
    (d.notes||[]).forEach(n=>{if(!S.notes.some(x=>x.id===n.id)){S.notes.push(n);save('n_'+n.id)}});if(d.settings){Object.assign(S.settings,d.settings);save('settings')}}
  else if(t.key==='notes'){if(!S.notes.some(x=>x.id===t.data.id)){S.notes.push(t.data);save('n_'+t.data.id)}}
  else if(Array.isArray(S[t.key])&&!S[t.key].some(x=>x.id===t.data.id)){S[t.key].push(t.data);save(t.key)}
  S.trash=S.trash.filter(x=>x.id!==t.id);save('trash');
}
EXT.trash=()=>{purgeTrash();const l=S.trash;return`<div class="card"><div class="row">${ill('trash')}<div class="grow"><h2>Recently deleted</h2><p class="muted">Anything you delete or reset waits here for 30 days. Restore it, or delete it for good.</p></div></div>${l.length?`<button class="btn sm danger" data-a="trEmpty" style="align-self:flex-start">Empty the bin</button>`:''}</div>`+(l.length?`<div class="card"><div class="list">${l.map(t=>{const left=30-Math.floor((Date.now()-t.at)/864e5);return`<div class="item"><div class="grow"><span class="t">${esc(t.label)}</span><br><span class="muted">${t.kind==='reset'?'Reset section':esc(t.kind)} · deleted ${fmt(ymd(new Date(t.at)))} · ${left} day${left===1?'':'s'} left</span></div><button class="btn sm" data-a="trRestore" data-id="${t.id}">Restore</button><button class="btn sm danger" data-a="trDel" data-id="${t.id}" aria-label="Delete for good">×</button></div>`}).join('')}</div></div>`:`<div class="card">${empty('The bin is empty','Deleted items will appear here.')}</div>`)};

/* ---------- confirm sheet ---------- */
let CF=null;
function confirmSheet(title,text,btn,fn){CF=fn;F={fields:[],onSave:()=>{}};$('#sheet').innerHTML=`<div class="row between"><h2>${esc(title)}</h2><button class="btn sm" data-a="close">Close</button></div><p>${text}</p><div class="row"><button class="btn" data-a="close">Cancel</button><button class="btn pri grow danger-pri" data-a="cfmYes">${esc(btn)}</button></div>`;$('#shade').classList.add('open')}

/* ---------- reset any section ---------- */
const RS={
 'plan.tasks':['tasks',['tasks']],'plan.cal':['calendar events',['events']],'plan.routine':['class routine',['routine']],
 'study.courses':['courses',['courses'],'courses'],'study.exams':['exams and deadlines',['exams']],'study.timer':['study time log',['focus']],'study.cgpa':['CGPA',['sems'],null,['cgBase','cgCred','cgTarget','cgRemain']],'study.research':['research projects',['research']],'study.files':['files',['files']],'study.grades':['grade predictor',['gradeP']],'study.attend':['attendance',['att']],'study.cite':['citations',['cites']],
 'lab.stock':['reagents',['reag']],'lab.protocols':['my protocols',['protocols']],'lab.book':['lab notebook',[],'lab'],
 'deen.prayer':['prayer and fasting log',['prayers','fasts'],null,['qaza']],'deen.ramadan':['Ramadan log',['ram']],'deen.quran':['Quran progress',['quran']],'deen.duas':['dua and tasbih counts',['dhikr','duas']],
 'life.water':['water history',['water']],'life.food':['meals',['meals','fv']],'life.habits':['habits',['habits','habitLog']],'life.sleep':['sleep logs',['sleep']],'life.health':['health records',['sick']],'life.acts':['activities',['acts']],'life.money':['money',['money','goals','debts','bills','billPaid']],'life.caffeine':['caffeine log',['caff']],'life.insights':['experiments',['exps']],
 'more.reminders':['reminders and alarms',['reminders']],'more.links':['links',['links']],'more.notes':['quick notes',[],''],'more.mail':['mail contacts',['contacts']]
};
const rsKey=()=>ui.tab+'.'+(ui[ui.tab]||'');
function resetRow(){if((ui.tab==='study'&&(ui.course||ui.proj))||(ui.tab==='life'&&ui.ep)||(ui.tab==='lab'&&ui.pr))return'';const r=RS[rsKey()];return r?`<div class="resetrow"><button class="btn sm ghost" data-a="rsAsk" data-k="${rsKey()}">Reset ${r[0]}</button></div>`:''}
function doReset(k){
  const r=RS[k],snap={keys:{},notes:[],settings:{}};
  r[1].forEach(key=>{snap.keys[key]=S[key];S[key]=Array.isArray(S[key])?[]:{}});
  if(r[2]!=null){const ids=r[2]==='courses'?new Set((snap.keys.courses||[]).map(c=>c.id)):null;snap.notes=S.notes.filter(n=>ids?ids.has(n.ref):(n.ref||'')===r[2]);snap.notes.forEach(n=>{S.notes=S.notes.filter(x=>x.id!==n.id);save('n_'+n.id)})}
  (r[3]||[]).forEach(s=>{snap.settings[s]=S.settings[s];S.settings[s]=DEF_SET[s]});
  const kept=trashPut('Reset: '+r[0],'reset',null,snap);
  r[1].forEach(key=>save(key));if(r[3])save('settings');
  return kept;
}
const RSV=['plan','study','lab','deen','life','more'];
RSV.forEach(tab=>{const v=VIEWS[tab];VIEWS[tab]=()=>v()+(ui.tab===tab?resetRow():'')});
function resetAll(){
  const keepS={};['name','dob','photo','city','lat','lng','asr','lang','mode','motion','big','setup','intro','deenOff','tilesOff','tv','fstore','currency','waterGoal','glassMl','sleepBed','sleepWake'].forEach(k=>{if(S.settings[k]!=null)keepS[k]=S.settings[k]});
  const snap={keys:{},notes:S.notes.slice(),settings:Object.assign({},S.settings)};delete snap.settings.photo;KEYS.forEach(k=>{if(k!=='settings'&&k!=='trash')snap.keys[k]=S[k]});
  const kept=trashPut('Reset: whole app','reset',null,snap);const tr=S.trash;
  S.notes.forEach(n=>save('n_'+n.id));
  KEYS.forEach(k=>{if(k!=='settings'&&k!=='trash')S[k]=OBJ.includes(k)?{}:[]});S.notes=[];S.settings=Object.assign({},DEF_SET,keepS);S.trash=kept?tr:[];normalize();
  save.apply(null,KEYS);return kept;
}

/* ---------- classes on several days ---------- */
const dayOpt=WEEK.map(w=>[String(w),DAYSL[w]]);
const rF=()=>[['courseId','Course','select',{opts:courseOpts()}],['title','Or type a name','text',{ph:'Lab, tutorial, seminar'}],['day','First day','select',{opts:dayOpt}],['day2','Second day (theory classes usually meet twice)','select',{opts:[['','None']].concat(dayOpt)}],['day3','Third day','select',{opts:[['','None']].concat(dayOpt)}],['start','Starts','time',R],['end','Ends','time'],['room','Room','text']];
const sibs=r=>r?(r.grp?S.routine.filter(x=>x.grp===r.grp):[r]):[];
function saveClass(r,v){
  const old=sibs(r),grp=(r&&r.grp)||uid(),days=[...new Set([v.day,v.day2,v.day3].filter(x=>x!==''&&x!=null).map(Number))],base={courseId:v.courseId,title:v.title,start:v.start,end:v.end,room:v.room,grp:grp};
  days.forEach(d=>{const ex=old.find(x=>+x.day===d);if(ex)Object.assign(ex,base,{day:d});else S.routine.push(Object.assign({id:uid(),day:d},base))});
  old.filter(x=>!days.includes(+x.day)).forEach(x=>{S.routine=S.routine.filter(y=>y.id!==x.id)});save('routine');
}

/* ---------- grade predictor: best few of several ---------- */
function partPct(i){
  if(i.kind==='best'){const k=Math.max(1,Math.round(num(i.best))||1),ps=String(i.scores||'').split(/[,;\n]+/).map(x=>x.trim()).filter(Boolean).map(x=>{const a=x.split('/'),g=num(a[0]),o=a.length>1?num(a[1]):(num(i.m)||100);return o>0?g/o*100:null}).filter(v=>v!=null).sort((a,b)=>b-a),top=ps.slice(0,k);return{f:top.length/k,sum:top.reduce((a,b)=>a+b,0)/k,list:ps,k:k,avg:top.length?top.reduce((a,b)=>a+b,0)/top.length:null}}
  if(String(i.s).trim()!==''&&num(i.m)>0)return{f:1,sum:num(i.s)/num(i.m)*100};return{f:0,sum:0};
}
gstat=function(g){let tw=0,dw=0,e=0;(g.items||[]).forEach(i=>{const w=num(i.w),p=partPct(i);tw+=w;dw+=w*p.f;e+=w*p.sum/100});return{tw:tw,dw:Math.round(dw*100)/100,e:e,rem:Math.round((tw-dw)*100)/100,cur:dw?e/dw*100:null}};
const gpF2=[['n','Part','text',{req:true,ph:'Quizzes, Mid-term, Final'}],['w','Weight (% of the course grade)','number',R],['kind','How is it counted?','select',{opts:[['one','One mark'],['best','Best few of several, such as best 3 of 5 quizzes']]}],['s','Your mark (one mark; leave empty if not done yet)','text'],['m','Out of','number'],['scores','Marks so far, separated by commas (best few)','text',{ph:'8/10, 9/10, 6/10'}],['best','Count the best how many? (best few)','number']];
const partTxt=i=>{if(i.kind==='best'){const p=partPct(i);return p.list.length?`best ${p.k} of ${p.list.length} so far · ${p.avg.toFixed(0)}%`:`best ${p.k} will count · no marks yet`}return String(i.s).trim()!==''?esc(i.s)+' / '+esc(i.m):'Pending'};
EXT.grades=()=>{
  const cs=curCourses();if(!cs.length)return`<div class="card">${empty('Add your courses first','Each course gets a grade predictor once it is in the Courses list.')}</div>`;
  return`<p class="muted">Add each part of the course with its weight, such as Quizzes 15%, Mid 30%, Final 40%. For quizzes where only the best few count, choose “Best few of several”.</p>`+cs.map(c=>{
    const g=S.gradeP[c.id]||{items:[]},s=gstat(g),pred=s.cur!=null&&s.tw?(s.e+s.rem*s.cur/100)/s.tw*100:null,letter=pred==null?'':(NSUC.find(x=>pred>=x[1])||['F'])[0];
    return`<div class="card"><div class="row between"><h3>${esc(c.code||c.title)}</h3>${pred!=null?`<span class="pill col c-sun">Heading for ${letter}</span>`:''}</div>${g.items.length?'<div class="list">'+g.items.map(i=>`<div class="item"><button class="tap" data-a="gpEdit" data-c="${c.id}" data-id="${i.id}"><span class="t">${esc(i.n)}</span><span class="muted">${num(i.w)}% of the grade</span></button><span class="t gp">${partTxt(i)}</span></div>`).join('')+'</div>':''}<button class="btn sm" data-a="gpAdd" data-c="${c.id}" style="align-self:flex-start">${ic('plus')}Add a part</button>
    ${s.tw&&Math.abs(s.tw-100)>.5?`<p class="muted" style="color:var(--bad)">The weights add up to ${s.tw}%, not 100%. Check them.</p>`:''}
    ${s.dw?`<p>So far you have <b>${s.cur.toFixed(1)}%</b> on ${Math.round(s.dw*10)/10}% of the course.</p>`:''}
    ${s.rem>0&&s.dw?`<p class="muted">What you need on the remaining ${Math.round(s.rem*10)/10}%:</p><div class="list">${NSUC.slice(0,6).map(x=>{const n=needFor(g,x[1]);return`<div class="item"><span class="t" style="width:38px">${x[0]}</span><span class="grow muted">${x[1]}% overall</span><span class="t">${n>100?'Not reachable':n<=0?'Already secured':Math.ceil(n)+'%'}</span></div>`}).join('')}</div>`:''}
    ${s.dw&&s.rem<=0?`<p class="res">Final: ${(s.e/s.tw*100).toFixed(1)}%, which is ${letter} on the NSU scale.</p>`:''}</div>`}).join('')+`<p class="muted">Uses NSU’s usual cutoffs (A from 93%, A- from 90%, B+ from 87% and so on). If your instructor uses different ones, go by theirs.</p>`;
};

/* ---------- Ramadan ---------- */
function hijriOf(d){try{const p={};new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn',{day:'numeric',month:'numeric',year:'numeric'}).formatToParts(parse(d)).forEach(x=>{p[x.type]=x.value});const r={d:+p.day,m:+p.month,y:parseInt(p.year,10)};return r.m>=1&&r.m<=12?r:null}catch(e){return null}}
function isRam(d){const s=S.settings.ramOn;if(S.settings.deenOff)return false;if(s==='on')return true;if(s==='off')return false;const h=hijriOf(d||today());return!!h&&h.m===9}
const RAM=()=>{const r=S.ram;r.tar=r.tar||{};r.juz=r.juz||{};r.sad=r.sad||[];return r};
function ramDays(){const t=today(),h=hijriOf(t);let start=t;if(h&&h.m===9)start=addDays(t,-(h.d-1));const a=[];for(let i=0;i<30;i++){const d=addDays(start,i),hh=hijriOf(d);if(i>=29&&hh&&hh.m!==9)break;a.push(d)}return a}
const RDUA=[['Dua for breaking the fast','ذَهَبَ الظَّمَأُ وَابْتَلَّتِ الْعُرُوقُ وَثَبَتَ الْأَجْرُ إِنْ شَاءَ اللَّهُ','যাহাবায যামাউ ওয়াবতাল্লাতিল উরূকু ওয়া সাবাতাল আজরু ইনশাআল্লাহ।','পিপাসা দূর হলো, শিরাগুলো সিক্ত হলো এবং ইনশাআল্লাহ প্রতিদান নিশ্চিত হলো।','Thirst is gone, the veins are moist, and the reward is certain, if Allah wills.','Abu Dawud 2357'],['Dua for Laylatul Qadr','اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي','আল্লাহুম্মা ইন্নাকা আফুউন তুহিব্বুল আফওয়া ফা‘ফু আন্নী।','হে আল্লাহ, তুমি ক্ষমাশীল, ক্ষমা করতে ভালোবাসো, অতএব আমাকে ক্ষমা করো।','O Allah, You are forgiving and love to forgive, so forgive me.','Tirmidhi 3513']];
function ramCount(){const t=today(),pt=ptimes(t),n=nowMin(),f=toMin(pt.fajr),m=toMin(pt.maghrib);if(n<f)return['Sehri ends in',dur(f-n),tfmt(pt.fajr)];if(n<m)return['Iftar in',dur(m-n),tfmt(pt.maghrib)];const f2=toMin(ptimes(addDays(t,1)).fajr);return['Sehri ends in',dur(f2+1440-n),tfmt(ptimes(addDays(t,1)).fajr)]}
EXT.ramadan=()=>{
  const t=today(),on=isRam(t),h=hijriOf(t),r=RAM(),pt=ptimes(t),c=ramCount(),days=ramDays(),s=S.settings,real=h&&h.m===9,juz=Object.keys(r.juz).length,sad=r.sad.reduce((a,x)=>a+num(x.amt),0);
  let o=`<div class="card ram"><div class="row">${ill('lantern')}<div class="grow"><h2>${on?'Ramadan Mubarak':'Ramadan mode'}</h2><p class="muted">${real?'Day '+h.d+' of Ramadan '+h.y+' AH':on?'Switched on by you':'Turns on by itself when Ramadan begins.'}</p></div></div><div class="chips">${[['auto','Automatic'],['on','On now'],['off','Off']].map(x=>`<button class="chip${s.ramOn===x[0]?' on':''}" data-a="ramMode" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><p class="muted">The start date follows the Umm al-Qura calendar, which can differ by a day from moon sighting in Bangladesh. Use “On now” or “Off” to match your local announcement.</p></div>`;
  if(!on)return o;
  o+=`<div class="card c-grape"><div class="g3">${stat(tfmt(pt.fajr),'Sehri ends')}${stat(tfmt(pt.maghrib),'Iftar')}${stat(c[1],c[0].toLowerCase())}</div><p class="muted">Sehri ends at Fajr time and iftar is at Maghrib, calculated for ${esc(s.city)}. Follow your local mosque or the Islamic Foundation calendar if it differs.</p>
    <div class="list"><div class="item">${chk(+s.alSehri,'flag','data-id="alSehri"','Sehri alarm')}<span class="t grow">Wake me for sehri with an alarm</span></div>${+s.alSehri?`<div class="chips">${[30,45,60,90].map(m=>`<button class="chip${+s.sehriMin===m?' on':''}" data-a="ramSehri" data-n="${m}">${m} min before</button>`).join('')}</div>`:''}<div class="item">${chk(+s.ramIftar,'flag','data-id="ramIftar"','Iftar notification')}<span class="t grow">Notify me at iftar time</span></div></div></div>`;
  o+=`<div class="card"><div class="row between"><h3>Fasts and taraweeh</h3><span class="pill">${days.filter(d=>S.fasts[d]).length} fasts · ${days.filter(d=>r.tar[d]).length} taraweeh</span></div><div class="ramgrid">${days.map((d,i)=>`<div class="rd${d===t?' now':''}${d>t?' future':''}"><b>${i+1}</b><button class="${S.fasts[d]?'on':''}" data-a="ramFast" data-d="${d}" aria-label="Fasted on day ${i+1}">${S.fasts[d]?'✓':''}</button><button class="tar${r.tar[d]?' on':''}" data-a="ramTar" data-d="${d}" aria-label="Taraweeh on night ${i+1}">${r.tar[d]?'☾':''}</button></div>`).join('')}</div><p class="muted">Top row: fast kept. Bottom row: taraweeh prayed.</p></div>`;
  o+=`<div class="card"><div class="row between"><h3>Finish the Quran this Ramadan</h3><span class="pill">${juz} of 30 juz</span></div><div class="bar"><i style="width:${juz/30*100}%"></i></div><div class="juz">${Array.from({length:30},(x,i)=>`<button class="${r.juz[i+1]?'on':''}" data-a="ramJuz" data-n="${i+1}">${i+1}</button>`).join('')}</div><p class="muted">One juz a day finishes the Quran in 30 days. Tap a juz when you complete it.</p></div>`;
  if(real&&h.d>=20)o+=`<div class="card c-leaf"><h3>The last ten nights</h3><p>Seek Laylatul Qadr in the odd nights: the 21st, 23rd, 25th, 27th and 29th. Each night begins at Maghrib the evening before.</p></div>`;
  o+=`<div class="card"><h3>Ramadan duas</h3>${RDUA.map(d=>`<div class="dua"><h3>${d[0]}</h3><p class="ar" lang="ar">${d[1]}</p><p><b>উচ্চারণ:</b> ${d[2]}</p><p>${S.settings.dl==='en'?d[4]:'<b>অর্থ:</b> '+d[3]}</p><p class="muted">${d[5]}</p></div>`).join('')}<p class="muted">Entered by hand. Confirm the wording with your teacher or Hisnul Muslim.</p></div>`;
  o+=`<div class="card">${head('Sadaqah this Ramadan',addBtn('sadAdd','Add'))}<div class="big">${money(sad)}</div>${r.sad.length?'<div class="list">'+r.sad.slice().reverse().map(x=>`<div class="item"><span class="grow"><span class="t">${money(num(x.amt))}</span><br><span class="muted">${fmt(x.date)}${x.note?' · '+esc(x.note):''}</span></span><button class="btn sm" data-a="sadDel" data-id="${x.id}" aria-label="Remove">×</button></div>`).join('')+'</div>':''}</div>`;
  return o;
};
const _ag12=agenda;
agenda=function(ds){const a=_ag12(ds),s=S.settings;if(isRam(ds)){const pt=ptimes(ds);if(+s.alSehri)a.push({t:hm(toMin(pt.fajr)-(+s.sehriMin||45)),title:'Time for sehri. Sehri ends at '+tfmt(pt.fajr),src:'Ramadan',key:'ram-s',alarm:true});if(+s.ramIftar)a.push({t:pt.maghrib,title:'Iftar time',src:'Ramadan',key:'ram-i'})}return a.sort((x,y)=>x.t<y.t?-1:1)};
const _mid12=EXT.todayMid;
EXT.todayMid=()=>{let o='';if(isRam()){const c=ramCount();o=`<div class="card ram rammini" role="button" tabindex="0" data-a="go" data-tab="deen" data-k="deen" data-v="ramadan">${ill('lantern')}<div class="grow"><span class="muted">${c[0]}</span><b>${c[1]}</b><span class="muted">at ${c[2]}</span></div>${chk(S.fasts[today()],'ramFast','data-d="'+today()+'"','Fasting today')}</div>`}return o+_mid12()};

/* ---------- semesters: rename, undo, move back, delete ---------- */
EXT.courses=()=>{
  const past={};S.courses.filter(c=>c.arch).forEach(c=>{(past[c.arch]=past[c.arch]||[]).push(c)});const last=S.semArch[S.semArch.length-1];
  return`<div class="card c-grape"><div class="row between"><div><span class="pill">Current semester</span><h3>${esc(S.settings.sem||'Not named yet')}</h3></div><div class="row wrap"><button class="btn sm" data-a="semRename">Rename</button><button class="btn sm" data-a="semNew">New semester</button></div></div><p class="muted">At the end of a semester, start a new one. Your old courses, notes and files move to Past semesters and stay saved.</p>${Object.keys(past).length||last?`<button class="btn sm" data-a="semUndo" style="align-self:flex-start">Undo the last new semester</button>`:''}</div>`+
  Object.keys(past).map(k=>`<details class="card calc"><summary><span class="pill">Past</span><h3>${esc(k)}</h3></summary><div class="list">${past[k].map(c=>`<div class="item"><button class="tap" data-a="cOpen" data-id="${c.id}"><span class="t">${esc(c.code||c.title)}</span><span class="muted">${esc(c.title)} · ${S.notes.filter(n=>n.ref===c.id).length} notes · ${S.files.filter(f=>f.courseId===c.id).length} files</span></button><button class="btn sm" data-a="cBackCur" data-id="${c.id}">Make current</button></div>`).join('')}</div><div class="row wrap"><button class="btn sm" data-a="semBack" data-v="${esc(k)}">Move all back to current</button><button class="btn sm danger" data-a="semDel" data-v="${esc(k)}">Delete this semester</button></div></details>`).join('');
};

/* ---------- actions ---------- */
Object.assign(A,{
  trRestore(d){const t=S.trash.find(x=>x.id===d.id);if(t){restoreT(t);toast({title:'Restored: '+t.label,src:'Recently deleted',t:hm(nowMin())})}render()},
  trDel(d){const t=S.trash.find(x=>x.id===d.id);if(!t)return;confirmSheet('Delete for good?','“'+esc(t.label)+'” will be gone and cannot be restored.','Delete for good',()=>{dropFiles(t);S.trash=S.trash.filter(x=>x.id!==t.id);save('trash')})},
  trEmpty(){confirmSheet('Empty the bin?','Everything in Recently deleted will be gone for good.','Empty the bin',()=>{S.trash.forEach(dropFiles);S.trash=[];save('trash')})},
  cfmYes(){const fn=CF;CF=null;closeSheet();if(fn)fn();render()},
  rsAsk(d){const r=RS[d.k];if(!r)return;confirmSheet('Reset '+r[0]+'?','Everything in '+esc(r[0])+' will be cleared. It moves to Recently deleted for 30 days, so you can restore it.','Reset',()=>{if(!doReset(d.k))setTimeout(()=>toast({title:'That was too large for Recently deleted, so it was cleared for good',src:'Reset',t:hm(nowMin())}),300);else toast({title:'Reset done. You can restore it from Recently deleted.',src:'Reset',t:hm(nowMin())})})},
  rsAll(){confirmSheet('Reset the whole app?','All your tasks, notes, logs and records will be cleared. Your name, look and language stay. If everything fits, it goes to Recently deleted for 30 days; if not, it is gone for good, so back up first.','Reset everything',()=>{const k=resetAll();ui.tab='today';toast({title:k?'App reset. You can restore it from Recently deleted.':'App reset',src:'Reset',t:hm(nowMin())})})},
  nEdit(d){const n=S.notes.find(x=>x.id===d.id);form('Note',A.nFields,n,v=>{Object.assign(n,v,{updated:Date.now()});save('n_'+n.id)},()=>{trashPut(n.title||'Note','Note','notes',n);S.notes=S.notes.filter(x=>x.id!==n.id);save('n_'+n.id)})},
  fEdit(d){const f=S.files.find(x=>x.id===d.id);form('File',[['name','Name','text',R],['courseId','Course','select',{opts:courseOpts()}]],f,v=>{if(ext(v.name)!==ext(f.name))v.name+='.'+ext(f.name);upsert('files',f.id,v)},()=>{trashPut(f.name,'File','files',f);_remove12('files',f.id)})},
  rAdd(){form('New class',rF(),{day:String(new Date().getDay()),day2:'',day3:''},v=>saveClass(null,v))},
  rEdit(d){const r=S.routine.find(x=>x.id===d.id),ss=sibs(r).map(x=>String(x.day)).sort((a,b)=>WEEK.indexOf(+a)-WEEK.indexOf(+b));form(ss.length>1?'Edit class ('+ss.length+' days)':'Edit class',rF(),Object.assign({},r,{day:ss[0],day2:ss[1]||'',day3:ss[2]||''}),v=>saveClass(r,v),()=>{sibs(r).forEach(x=>remove('routine',x.id))})},
  gpAdd(d){form('Add a part',gpF2,{m:100,kind:'one',best:2},v=>{const g=S.gradeP[d.c]=S.gradeP[d.c]||{items:[]};g.items.push(Object.assign({id:uid()},v));save('gradeP')})},
  gpEdit(d){const g=S.gradeP[d.c],i=g.items.find(x=>x.id===d.id);form('Edit part',gpF2,Object.assign({kind:'one',best:2},i),v=>{Object.assign(i,v);save('gradeP')},()=>{g.items=g.items.filter(x=>x.id!==i.id);save('gradeP')})},
  ramMode(d){S.settings.ramOn=d.v;save('settings');render()},
  ramSehri(d){S.settings.sehriMin=+d.n;save('settings');render()},
  ramFast(d){if(S.fasts[d.d])delete S.fasts[d.d];else S.fasts[d.d]=1;save('fasts');render()},
  ramTar(d){const r=RAM();if(r.tar[d.d])delete r.tar[d.d];else r.tar[d.d]=1;save('ram');render()},
  ramJuz(d){const r=RAM();if(r.juz[d.n])delete r.juz[d.n];else r.juz[d.n]=1;save('ram');render();if(Object.keys(r.juz).length===30&&r.juz[d.n])celebrate('Quran completed this Ramadan')},
  sadAdd(){form('Sadaqah',[['amt','Amount','number',R],['note','To whom or what for','text'],['date','Date','date',R]],{date:today()},v=>{RAM().sad.push(Object.assign({id:uid()},v));save('ram')})},
  sadDel(d){const r=RAM();r.sad=r.sad.filter(x=>x.id!==d.id);save('ram');render()},
  semRename(){form('Rename semester',[['sem','Semester name','text',{req:true,ph:'Spring 2027'}]],S.settings,v=>{S.settings.sem=v.sem;save('settings')})},
  semUndo(){const last=S.semArch[S.semArch.length-1],names=[...new Set(S.courses.filter(c=>c.arch).map(c=>c.arch))],old=last?last.name:names[names.length-1];if(!old)return;
    confirmSheet('Undo the new semester?','Courses from '+esc(old)+' come back as current, the class routine is restored, and the semester name goes back to '+esc(old)+'.','Undo',()=>{
      S.courses.forEach(c=>{if(c.arch===old)delete c.arch});if(last&&last.name===old){S.routine=last.routine.concat(S.routine.filter(r=>!last.routine.some(x=>x.id===r.id)));S.semArch.pop()}
      const si=S.sems.findIndex(x=>x.name===old&&x.items.every(i=>!i.grade));if(si>=0)S.sems.splice(si,1);S.settings.sem=old;save('courses','routine','semArch','sems','settings')})},
  cBackCur(d){const c=course(d.id);if(c){delete c.arch;save('courses');render()}},
  semBack(d){S.courses.forEach(c=>{if(c.arch===d.v)delete c.arch});save('courses');render()},
  semDel(d){const cs=S.courses.filter(c=>c.arch===d.v);confirmSheet('Delete '+d.v+'?',cs.length+' course'+(cs.length===1?'':'s')+' and their notes move to Recently deleted for 30 days.','Delete semester',()=>{const snap={keys:{courses:cs},notes:S.notes.filter(n=>cs.some(c=>c.id===n.ref)),settings:{}};trashPut('Semester: '+d.v,'reset',null,snap);snap.notes.forEach(n=>{S.notes=S.notes.filter(x=>x.id!==n.id);save('n_'+n.id)});S.courses=S.courses.filter(c=>c.arch!==d.v);save('courses')})}
});
const _set12=EXT.settings;
EXT.settings=()=>_set12()+`<div class="card c-tomato"><h2>Reset the whole app</h2><p class="muted">Clears all your records but keeps your name, look and language. Back up first to be safe.</p><button class="btn danger" data-a="rsAll" style="align-self:flex-start">Reset everything</button></div>`;

/* keep the selected chip in view, without the bar jumping */
const _ar12=window.afterRender;
window.afterRender=function(){_ar12();document.querySelectorAll('#view .chips').forEach(c=>{const on=c.querySelector('.chip.on');if(on&&c.scrollWidth>c.clientWidth){const x=on.getBoundingClientRect().left-c.getBoundingClientRect().left+c.scrollLeft-(c.clientWidth-on.offsetWidth)/2;c.scrollLeft=Math.max(0,x)}})};
purgeTrash();
window.__v12={partPct:partPct,gstat:()=>gstat,saveClass:saveClass,doReset:doReset,restoreT:restoreT,isRam:isRam,hijriOf:hijriOf,ramDays:ramDays,trashPut:trashPut};

Object.assign(BN,{'Recently deleted':'সম্প্রতি মুছে ফেলা','Restore':'ফিরিয়ে আনুন','Empty the bin':'বিন খালি করুন','The bin is empty':'বিন খালি','Delete for good':'চিরতরে মুছুন','Reset section':'রিসেট করা বিভাগ','Ramadan':'রমজান','Ramadan mode':'রমজান মোড','Ramadan Mubarak':'রমজান মোবারক','Automatic':'স্বয়ংক্রিয়','On now':'এখন চালু','Sehri ends':'সেহরির শেষ সময়','Iftar':'ইফতার','sehri ends in':'সেহরি শেষ হতে','iftar in':'ইফতার হতে','Sehri ends in':'সেহরি শেষ হতে','Iftar in':'ইফতার হতে','Wake me for sehri with an alarm':'সেহরির জন্য অ্যালার্ম দিয়ে জাগান','Notify me at iftar time':'ইফতারের সময় জানান','Fasts and taraweeh':'রোজা ও তারাবিহ','Finish the Quran this Ramadan':'এই রমজানে কুরআন খতম','Ramadan duas':'রমজানের দোয়া','Sadaqah this Ramadan':'এই রমজানের সদকা','Sadaqah':'সদকা','The last ten nights':'শেষ দশ রাত','Iftar time':'ইফতারের সময়','Reset everything':'সব রিসেট করুন','Reset the whole app':'পুরো অ্যাপ রিসেট','Rename':'নাম পরিবর্তন','Rename semester':'সেমিস্টারের নাম পরিবর্তন','Undo the last new semester':'শেষ নতুন সেমিস্টার বাতিল','Undo':'বাতিল','Make current':'চলতি করুন','Move all back to current':'সব চলতিতে ফেরান','Delete this semester':'এই সেমিস্টার মুছুন','Delete semester':'সেমিস্টার মুছুন','First day':'প্রথম দিন','Second day (theory classes usually meet twice)':'দ্বিতীয় দিন (থিওরি ক্লাস সাধারণত সপ্তাহে দুবার)','Third day':'তৃতীয় দিন','How is it counted?':'কীভাবে গণনা হবে?','One mark':'একটি নম্বর','Best few of several, such as best 3 of 5 quizzes':'কয়েকটির মধ্যে সেরাগুলো, যেমন ৫টি কুইজের সেরা ৩টি','Count the best how many? (best few)':'সেরা কয়টি গণনা হবে?','Marks so far, separated by commas (best few)':'এ পর্যন্ত নম্বর, কমা দিয়ে আলাদা করে','Your mark (one mark; leave empty if not done yet)':'আপনার নম্বর (না হলে ফাঁকা রাখুন)','Reset':'রিসেট'});
BNP.push([/^Reset: (.+)$/,'রিসেট: $1'],[/^Reset (.+)$/,'রিসেট: $1'],[/^Day (\d+) of Ramadan (\d+) AH$/,'রমজানের $1তম দিন, $2 হিজরি']);


/* ================= v13: molecules, payment methods, badges, levels, challenges, heatmap, exam day, wrapped, lab buddy ================= */
KEYS.push('badges','chal','examChk','wraps');OBJ.push('badges','chal','examChk');
Object.assign(DEF_SET,{payBal:{},semStart:''});normalize();
Object.assign(ui,{mol:null,examFull:false,buddy:null,bdIn:''});
SUB.lab.splice(SUB.lab.length-3,0,['mol','Molecules'],['buddy','Lab buddy']);
SUB.more.splice(1,0,['badges','Badges']);
MENU.find(g=>g[0]==='Lab')[1].push(['lab','lab','mol','Molecule of the day','sun'],['lab','lab','buddy','Lab buddy','sun']);
MENU[0][1].push(['more','more','badges','Badges','pink',()=>Object.keys(S.badges).length||'']);
ILL.medal='<path d="M16 4l5 12M32 4l-5 12" stroke-width="3"/><circle cx="24" cy="30" r="12" fill="var(--sun)"/><path d="M24 23l2 4.500 4.800.500-3.600 3.200 1 4.800L24 33.500 19.800 36l1-4.800-3.600-3.200 4.800-.500z" fill="var(--card)"/>';
ILL.swap='<path d="M8 18h28l-6-6M40 30H12l6 6" stroke-width="3"/>';
const DAY0=d=>Math.floor(parse(d).getTime()/864e5);

/* ---------- molecule of the day ---------- */
const MOLS=[{"id":"water","name":"Water","f":"H₂O","mw":18.02,"role":"The solvent of life. Its bent shape makes it polar, so it forms hydrogen bonds and dissolves salts, sugars and proteins.","atoms":[["O",0,0,0],["H",0.759,-0.588,0],["H",-0.759,-0.588,0]],"bonds":[[0,1,1],[0,2,1]]},{"id":"ethanol","name":"Ethanol","f":"C₂H₆O","mw":46.07,"role":"Made by yeast during fermentation. Used in the lab to disinfect at 70% and to precipitate DNA.","atoms":[["C",0,0,0],["C",1.53,0,0],["O",2.007,1.348,0],["H",-0.363,-1.028,0.0],["H",-0.363,0.514,-0.89],["H",-0.363,0.514,0.89],["H",1.893,-0.514,-0.89],["H",1.893,-0.514,0.89],["H",1.26,1.952,0.0]],"bonds":[[0,1,1],[1,2,1],[0,3,1],[0,4,1],[0,5,1],[1,6,1],[1,7,1],[2,8,1]]},{"id":"urea","name":"Urea","f":"CH₄N₂O","mw":60.06,"role":"How your body gets rid of extra nitrogen. The liver makes it in the urea cycle and the kidneys pass it out in urine.","atoms":[["C",0,0,0],["O",0,1.25,0],["N",1.169,-0.675,0],["N",-1.169,-0.675,0],["H",1.169,-1.685,0.0],["H",2.044,-0.17,0.0],["H",-2.044,-0.17,0.0],["H",-1.169,-1.685,0.0]],"bonds":[[0,1,2],[0,2,1],[0,3,1],[2,4,1],[2,5,1],[3,6,1],[3,7,1]]},{"id":"glycine","name":"Glycine","f":"C₂H₅NO₂","mw":75.07,"role":"The smallest amino acid, with only H as its side chain. Its flexibility lets collagen fold into a tight triple helix.","atoms":[["C",0,0,0],["N",-1.47,0,0],["C",0.51,1.442,0.0],["H",0.363,-0.514,-0.89],["H",0.363,-0.514,0.89],["O",0.718,2.031,1.083],["O",0.718,2.031,-1.083],["H",-1.807,-0.952,0.0],["H",-1.807,0.476,-0.825],["H",-1.807,0.476,0.825]],"bonds":[[0,1,1],[0,2,1],[0,3,1],[0,4,1],[2,5,2],[2,6,1],[1,7,1],[1,8,1],[1,9,1]]},{"id":"alanine","name":"L-Alanine","f":"C₃H₇NO₂","mw":89.09,"role":"A small amino acid with a methyl side chain. Muscles send it to the liver to make glucose (the glucose–alanine cycle).","atoms":[["C",0,0,0],["N",-1.47,0,0],["C",0.51,1.442,0.0],["C",0.51,-0.721,-1.249],["H",0.363,-0.514,0.89],["H",1.47,-0.299,-1.546],["H",-0.208,-0.596,-2.059],["H",0.631,-1.782,-1.032],["O",0.718,2.031,1.083],["O",0.718,2.031,-1.083],["H",-1.807,-0.952,0.0],["H",-1.807,0.476,-0.825],["H",-1.807,0.476,0.825]],"bonds":[[0,1,1],[0,2,1],[0,3,1],[0,4,1],[3,5,1],[3,6,1],[3,7,1],[2,8,2],[2,9,1],[1,10,1],[1,11,1],[1,12,1]]},{"id":"uracil","name":"Uracil","f":"C₄H₄N₂O₂","mw":112.09,"role":"A base found only in RNA, where it pairs with adenine. DNA uses thymine in its place.","atoms":[["N",0.0,1.39,0],["C",1.204,0.695,0],["N",1.204,-0.695,0],["C",0.0,-1.39,0],["C",-1.204,-0.695,0],["C",-1.204,0.695,0],["O",2.269,1.31,0.0],["O",0.0,-2.62,0.0]],"bonds":[[0,1,1],[1,2,1],[2,3,1],[3,4,1],[4,5,2],[5,0,1],[1,6,2],[3,7,2]]},{"id":"thymine","name":"Thymine","f":"C₅H₆N₂O₂","mw":126.11,"role":"A DNA base that pairs with adenine through two hydrogen bonds. It is uracil with an extra methyl group.","atoms":[["N",0.0,1.39,0],["C",1.204,0.695,0],["N",1.204,-0.695,0],["C",0.0,-1.39,0],["C",-1.204,-0.695,0],["C",-1.204,0.695,0],["O",2.269,1.31,0.0],["O",0.0,-2.62,0.0],["C",-2.503,-1.445,0.0]],"bonds":[[0,1,1],[1,2,1],[2,3,1],[3,4,1],[4,5,2],[5,0,1],[1,6,2],[3,7,2],[4,8,1]]},{"id":"cytosine","name":"Cytosine","f":"C₄H₅N₃O","mw":111.1,"role":"Pairs with guanine through three hydrogen bonds. Methylated cytosine helps switch genes off.","atoms":[["N",0.0,1.39,0],["C",1.204,0.695,0],["N",1.204,-0.695,0],["C",0.0,-1.39,0],["C",-1.204,-0.695,0],["C",-1.204,0.695,0],["O",2.269,1.31,0.0],["N",0.0,-2.73,0.0]],"bonds":[[0,1,1],[1,2,1],[2,3,2],[3,4,1],[4,5,2],[5,0,1],[1,6,2],[3,7,1]]},{"id":"adenine","name":"Adenine","f":"C₅H₅N₅","mw":135.13,"role":"A purine base in DNA and RNA, and the core of ATP, NAD⁺ and coenzyme A.","atoms":[["N",0.0,1.39,0],["C",1.204,0.695,0],["N",1.204,-0.695,0],["C",0.0,-1.39,0],["C",-1.204,-0.695,0],["C",-1.204,0.695,0],["N",-2.237,-1.625,0],["C",-1.671,-2.895,0],["N",-0.289,-2.75,0],["N",-2.365,1.365,0.0]],"bonds":[[0,1,2],[1,2,1],[2,3,2],[3,4,1],[4,5,1],[5,0,1],[4,6,1],[6,7,2],[7,8,1],[8,3,1],[5,9,1]]},{"id":"guanine","name":"Guanine","f":"C₅H₅N₅O","mw":151.13,"role":"A purine base that pairs with cytosine. GTP powers protein synthesis and G-protein signalling.","atoms":[["N",0.0,1.39,0],["C",1.204,0.695,0],["N",1.204,-0.695,0],["C",0.0,-1.39,0],["C",-1.204,-0.695,0],["C",-1.204,0.695,0],["N",-2.237,-1.625,0],["C",-1.671,-2.895,0],["N",-0.289,-2.75,0],["O",-2.269,1.31,0.0],["N",2.365,1.365,0.0]],"bonds":[[0,1,1],[1,2,1],[2,3,2],[3,4,2],[4,5,1],[5,0,1],[4,6,1],[6,7,2],[7,8,1],[8,3,1],[5,9,2],[1,10,1]]},{"id":"caffeine","name":"Caffeine","f":"C₈H₁₀N₄O₂","mw":194.19,"role":"A trimethylxanthine. It keeps you alert by blocking adenosine receptors in the brain.","atoms":[["N",0.0,1.39,0],["C",1.204,0.695,0],["N",1.204,-0.695,0],["C",0.0,-1.39,0],["C",-1.204,-0.695,0],["C",-1.204,0.695,0],["N",-2.237,-1.625,0],["C",-1.671,-2.895,0],["N",-0.289,-2.75,0],["O",-2.269,1.31,0.0],["O",2.269,1.31,0.0],["C",0.0,2.86,0.0],["C",2.477,-1.43,0.0],["C",-3.675,-1.319,0.0]],"bonds":[[0,1,1],[1,2,1],[2,3,2],[3,4,2],[4,5,1],[5,0,1],[4,6,1],[6,7,2],[7,8,1],[8,3,1],[5,9,2],[1,10,2],[0,11,1],[2,12,1],[6,13,1]]},{"id":"nicotinamide","name":"Nicotinamide","f":"C₆H₆N₂O","mw":122.12,"role":"The working part of vitamin B3. In NAD⁺ it carries electrons in glycolysis and the Krebs cycle.","atoms":[["N",0.0,1.39,0],["C",1.204,0.695,0],["C",1.204,-0.695,0],["C",0.0,-1.39,0],["C",-1.204,-0.695,0],["C",-1.204,0.695,0],["C",2.503,-1.445,0.0],["O",3.577,-0.825,0.0],["N",2.503,-2.785,0.0]],"bonds":[[0,1,2],[1,2,1],[2,3,2],[3,4,1],[4,5,2],[5,0,1],[2,6,1],[6,7,2],[6,8,1]]},{"id":"pyruvate","name":"Pyruvic acid","f":"C₃H₄O₃","mw":88.06,"role":"The end product of glycolysis. It enters mitochondria to become acetyl-CoA, or turns into lactate when oxygen is short.","atoms":[["C",0,0,0],["C",1.52,0,0],["C",2.27,1.299,0],["O",2.125,-1.048,0],["O",-0.605,1.048,0],["O",-0.655,-1.134,0]],"bonds":[[0,1,1],[1,2,1],[1,3,2],[0,4,2],[0,5,1]]},{"id":"glucose","name":"β-D-Glucose","f":"C₆H₁₂O₆","mw":180.16,"role":"The main fuel of cells. In its β form every OH group sits in the roomy equatorial position, which makes it very stable.","atoms":[["C",1.44,0.0,0.25],["C",0.72,1.247,-0.25],["C",-0.72,1.247,0.25],["C",-1.44,0.0,-0.25],["C",-0.72,-1.247,0.25],["O",0.72,-1.247,-0.25],["O",2.784,0.0,-0.238],["O",1.392,2.411,0.238],["O",-1.392,2.411,-0.238],["O",-2.784,0.0,0.238],["C",-1.434,-2.484,-0.269],["O",-0.49,-3.546,-0.432]],"bonds":[[0,1,1],[1,2,1],[2,3,1],[3,4,1],[4,5,1],[5,0,1],[0,6,1],[1,7,1],[2,8,1],[3,9,1],[4,10,1],[10,11,1]]}];
const molToday=()=>MOLS[(DAY0(today())+5)%MOLS.length];
const EC={C:'#5B5674',O:'#FF5A4E',N:'#4D7CFF',H:'#F2F1F7'},ERAD={C:.42,O:.40,N:.40,H:.24};
const molOf=id=>MOLS.find(m=>m.id===id)||molToday();
function molPrep(m){if(m._c)return m;const n=m.atoms.length,c=[0,1,2].map(k=>m.atoms.reduce((a,x)=>a+x[k+1],0)/n);m._p=m.atoms.map(x=>[x[1]-c[0],x[2]-c[1],x[3]-c[2]]);m._r=Math.max(...m._p.map(p=>Math.hypot(p[0],p[1],p[2])))+.6;m._c=1;return m}
let molInk='#9A95B8';const MANG={};
function molDraw(cv){
  const m=molPrep(molOf(cv.dataset.mol)),g=cv.getContext&&cv.getContext('2d');if(!g)return;const w=cv.width,h=cv.height,s=Math.min(w,h)/(2*m._r),ay=cv._ay||0,ax=cv._ax==null?.35:cv._ax,cy=Math.cos(ay),sy=Math.sin(ay),cx=Math.cos(ax),sx=Math.sin(ax);
  const P=m._p.map(p=>{const x1=p[0]*cy+p[2]*sy,z1=-p[0]*sy+p[2]*cy,y2=p[1]*cx-z1*sx,z2=p[1]*sx+z1*cx,f=1/(1-z2/(m._r*5));return[w/2+x1*s*f,h/2-y2*s*f,z2,f]});
  g.clearRect(0,0,w,h);g.lineCap='round';
  m.bonds.slice().sort((a,b)=>(P[a[0]][2]+P[a[1]][2])-(P[b[0]][2]+P[b[1]][2])).forEach(b=>{const p=P[b[0]],q=P[b[1]],lw=Math.max(1.5,s*.13*(p[3]+q[3])/2);g.strokeStyle=molInk;g.lineWidth=lw;
    if(b[2]===2){const dx=q[0]-p[0],dy=q[1]-p[1],L=Math.hypot(dx,dy)||1,ox=-dy/L*lw*.9,oy=dx/L*lw*.9;[1,-1].forEach(k=>{g.beginPath();g.moveTo(p[0]+ox*k,p[1]+oy*k);g.lineTo(q[0]+ox*k,q[1]+oy*k);g.stroke()})}
    else{g.beginPath();g.moveTo(p[0],p[1]);g.lineTo(q[0],q[1]);g.stroke()}});
  m.atoms.map((a,i)=>i).sort((i,j)=>P[i][2]-P[j][2]).forEach(i=>{const e=m.atoms[i][0],p=P[i],r=Math.max(3,s*ERAD[e]*p[3]),gr=g.createRadialGradient(p[0]-r*.35,p[1]-r*.35,r*.15,p[0],p[1],r);gr.addColorStop(0,'#fff');gr.addColorStop(.35,EC[e]||'#888');gr.addColorStop(1,EC[e]||'#888');g.fillStyle=gr;g.beginPath();g.arc(p[0],p[1],r,0,7);g.fill();if(e==='H'){g.strokeStyle='rgba(0,0,0,.15)';g.lineWidth=1;g.stroke()}});
}
let molRaf=0,molLast=0;
function molLoop(t){molRaf=0;const cs=document.querySelectorAll('canvas.molc');if(!cs.length)return;const dt=Math.min(64,t-(molLast||t));molLast=t;const spin=S.settings.motion!=='off';cs.forEach(c=>{if(spin&&!c._drag)c._ay=(c._ay||0)+dt*.0006;MANG[c.dataset.mol]=c._ay;molDraw(c)});if(spin)molRaf=requestAnimationFrame(molLoop)}
function molStart(){if(typeof requestAnimationFrame!=='function')return;try{molInk=getComputedStyle(document.documentElement).getPropertyValue('--muted').trim()||molInk}catch(e){}document.querySelectorAll('canvas.molc').forEach(c=>{if(c._ay==null)c._ay=MANG[c.dataset.mol]||0;const r=c.getBoundingClientRect(),k=window.devicePixelRatio||1;if(r.width){c.width=Math.round(r.width*k);c.height=Math.round(r.height*k)}molDraw(c)});molLast=0;if(!molRaf&&S.settings.motion!=='off')molRaf=requestAnimationFrame(molLoop)}
let molDrag=null;
document.addEventListener('pointerdown',e=>{const c=e.target;if(c&&c.classList&&c.classList.contains('molc')&&c.classList.contains('big')){molDrag={c:c,x:e.clientX,y:e.clientY,ay:c._ay||0,ax:c._ax==null?.35:c._ax};c._drag=1;try{c.setPointerCapture(e.pointerId)}catch(x){}}});
document.addEventListener('pointermove',e=>{if(!molDrag)return;const c=molDrag.c;c._ay=molDrag.ay+(e.clientX-molDrag.x)*.012;c._ax=Math.max(-1.4,Math.min(1.4,molDrag.ax+(e.clientY-molDrag.y)*.012));molDraw(c)});
document.addEventListener('pointerup',()=>{if(molDrag){molDrag.c._drag=0;molDrag=null}});
const molLegend='<div class="molkey">'+[['C','Carbon'],['O','Oxygen'],['N','Nitrogen'],['H','Hydrogen']].map(x=>`<span><i style="background:${EC[x[0]]}"></i>${x[1]}</span>`).join('')+'</div>';
function molCard(){const m=molToday();return`<div class="card molcard" role="button" tabindex="0" data-a="go" data-tab="lab" data-k="lab" data-v="mol"><canvas class="molc" data-mol="${m.id}" aria-label="3D model of ${esc(m.name)}"></canvas><div class="grow"><span class="pill">Molecule of the day</span><h3>${esc(m.name)}</h3><p class="muted">${m.f} · ${m.mw} g/mol</p><p class="mrole">${esc(m.role)}</p></div></div>`}
EXT.lab_mol=()=>{const m=molOf(ui.mol||molToday().id),isT=m.id===molToday().id;return`<div class="card"><div class="row between"><span class="pill${isT?' col c-sun':''}">${isT?'Molecule of the day':'Molecule'}</span><span class="muted">Drag to turn it</span></div><canvas class="molc big" data-mol="${m.id}" aria-label="3D model of ${esc(m.name)}. Drag to rotate."></canvas>${molLegend}<h2>${esc(m.name)}</h2><div class="g3">${stat(m.f,'formula')}${stat(m.mw,'g/mol')}${stat(m.atoms.length,'atoms shown')}</div><p>${esc(m.role)}</p><p class="muted">A simplified ball-and-stick model with idealised bond lengths and angles. Ring molecules show only their heavy atoms.</p></div><div class="card"><h3>All molecules</h3><div class="chips" style="flex-wrap:wrap;overflow:visible">${MOLS.map(x=>`<button class="chip${x.id===m.id?' on':''}" data-a="molPick" data-v="${x.id}">${esc(x.name)}</button>`).join('')}</div></div>`};

/* ---------- payment methods ---------- */
const PAY=['Cash','bKash','Nagad','Rocket','Card','Bank'];
A.mFields=[['amount','Amount','number',R],['type','Kind','select',{opts:[['out','Spent'],['in','Received']]}],['cat','Category','select',{opts:MCAT}],['pay','Paid with','select',{opts:PAY}],['note','Note','text'],['date','Date','date',R]];
function payBal(p){const b=(S.settings.payBal||{})[p];if(!b)return null;let v=num(b.amt);S.money.forEach(m=>{if((m.pay||'Cash')===p&&m.date>=b.date)v+=m.type==='in'?m.amount:-m.amount});return v}
function payCard(){
  const l=S.money.filter(m=>m.date.slice(0,7)===ui.month),out=l.filter(m=>m.type!=='in'),tot=out.reduce((a,m)=>a+m.amount,0),by={};out.forEach(m=>{const p=m.pay||'Cash';by[p]=(by[p]||0)+m.amount});
  const ks=PAY.filter(p=>by[p]||payBal(p)!=null);
  return`<div class="card">${head('By payment method',`<button class="btn sm" data-a="payBalSet">Set a balance</button>`)}${ks.length?ks.map(p=>{const b=payBal(p);return`<div><div class="row between"><span class="t">${p}</span><span class="muted">${money(by[p]||0)} spent${b!=null?' · balance '+money(b):''}</span></div><div class="bar"><i class="pay-${p.toLowerCase()}" style="width:${tot?(by[p]||0)/tot*100:0}%"></i></div></div>`}).join(''):'<p class="muted">Choose how you paid when you add an expense: Cash, bKash, Nagad, Rocket, Card or Bank.</p>'}<p class="muted">Set a balance once, such as what is in your bKash today, and the app keeps it up to date from your entries.</p></div>`;
}
const _m13=EXT.money;EXT.money=()=>payCard()+_m13();

/* ---------- XP, levels, badges, daily challenge ---------- */
const LVN=['Atom','Molecule','Monomer','Polymer','Enzyme','Organelle','Cell','Tissue','Organ','Organism','Ecosystem','Biosphere'];
function runMax(dates){const s=[...new Set(dates)].sort();let best=0,run=0,prev=null;s.forEach(d=>{run=prev&&diffDays(d,prev)===1?run+1:1;best=Math.max(best,run);prev=d});return best}
function bstats(){
  const t=today(),focus=S.focus.reduce((a,f)=>a+(+f.min||0),0),five=Object.keys(S.prayers).filter(d=>PR.every(p=>S.prayers[d][p[0]])),q=QN(),hab=S.habits.map(h=>runMax(Object.keys(S.habitLog).filter(d=>S.habitLog[d][h.id])));
  return{streak:ST().best||0,water:Object.values(S.water).reduce((a,b)=>a+(+b||0),0),focusH:focus/60,focus:focus,tasks:S.tasks.filter(x=>x.done).length,five:five.length,quran:Math.max(Object.keys(q.done||{}).length/114,Object.keys((S.ram||{}).juz||{}).length/30),
    sleep7:S.sleep.filter(l=>sleepMin(l)>=420).length,habit:Math.max(0,...hab),moneyDays:new Set(S.money.map(m=>m.date)).size,goal:S.goals.filter(g=>num(g.saved)>=num(g.target)&&num(g.target)>0).length,
    reag:S.reag.length,cites:S.cites.length,lab:S.notes.filter(n=>n.ref==='lab').length,chal:Object.values(S.chal).filter(c=>c&&c.done).length,early:S.sleep.filter(l=>toMin(l.wake)<360&&toMin(l.wake)>180).length,
    prayers:Object.values(S.prayers).reduce((a,o)=>a+Object.keys(o||{}).length,0),ticks:Object.values(S.habitLog).reduce((a,o)=>a+Object.keys(o||{}).length,0)};
}
const BADGES=[
 ['spark','Spark','Open the app 3 days in a row','flame','tomato',s=>[s.streak,3]],['fire','On fire','A 7-day streak','flame','tomato',s=>[s.streak,7]],['unstop','Unstoppable','A 30-day streak','flame','tomato',s=>[s.streak,30]],['centurion','Centurion','A 100-day streak','flame','tomato',s=>[s.streak,100]],
 ['hydrated','Hydrated','Drink 100 glasses of water','drop','sky',s=>[s.water,100]],['ocean','Ocean','Drink 1,000 glasses of water','drop','sky',s=>[s.water,1000]],
 ['focused','Focused','Study for 10 hours','timer','pink',s=>[Math.floor(s.focusH),10]],['scholar','Scholar','Study for 50 hours','book','grape',s=>[Math.floor(s.focusH),50]],['prof','Professor','Study for 150 hours','book','grape',s=>[Math.floor(s.focusH),150]],
 ['doer','Doer','Finish 25 tasks','tasks','tomato',s=>[s.tasks,25]],['machine','Machine','Finish 200 tasks','tasks','tomato',s=>[s.tasks,200]],
 ['steady','Steadfast','All five prayers on 7 days','mosque','leaf',s=>[s.five,7],1],['devoted','Devoted','All five prayers on 30 days','mosque','leaf',s=>[s.five,30],1],['khatam','Khatam','Finish the whole Quran','quran','leaf',s=>[Math.floor(s.quran*100),100],1],
 ['rested','Well rested','7 nights of 7 hours or more','moon','grape',s=>[s.sleep7,7]],['early','Early bird','Wake before 6 AM 7 times','moon','sun',s=>[s.early,7]],['habit','Habit builder','Keep one habit for 21 days in a row','sprout','leaf',s=>[s.habit,21]],
 ['books','Bookkeeper','Log money on 30 different days','wallet','leaf',s=>[s.moneyDays,30]],['saver','Saver','Reach a savings goal','wallet','sun',s=>[s.goal,1]],
 ['labbie','Lab organiser','List 10 reagents','flask','grape',s=>[s.reag,10]],['refs','Referencer','Save 10 citations','book','sky',s=>[s.cites,10]],['bench','Bench scientist','Write 5 lab notebook entries','scope','sky',s=>[s.lab,5]],
 ['chal','Challenger','Complete 10 daily challenges','medal','sun',s=>[s.chal,10]]
];
const activeBadges=()=>BADGES.filter(b=>!(b[6]&&S.settings.deenOff));
function xpOf(s){return Math.round(s.focus/10+s.tasks*5+s.water*.5+s.prayers+s.ticks*2+s.chal*15+Object.keys(S.badges).length*25)}
function level(xp){let lv=1,need=200,x=xp;while(x>=need&&lv<99){x-=need;lv++;need=Math.round(need*1.4)}return{lv:lv,name:LVN[Math.min(lv,LVN.length)-1],cur:x,need:need,xp:xp}}
let LV=level(0),badgeT=0;try{LV=level(xpOf(bstats()))}catch(e){}
function badgeCheck(force){
  const now=Date.now();if(!force&&now-badgeT<4000)return;badgeT=now;const s=bstats(),fresh=[];
  activeBadges().forEach(b=>{const p=b[5](s);if(p[0]>=p[1]&&!S.badges[b[0]]){S.badges[b[0]]=today();fresh.push(b)}});
  LV=level(xpOf(s));
  if(fresh.length){save('badges');if(fresh.length<=2)fresh.forEach((b,i)=>setTimeout(()=>celebrate('Badge unlocked: '+b[1]),400+i*900));else setTimeout(()=>celebrate('You unlocked '+fresh.length+' badges'),400)}
}
const lvlBar=()=>`<div class="lvl"><div class="row between"><b>Level ${LV.lv} · ${LV.name}</b><span>${LV.cur} / ${LV.need} XP</span></div><div class="bar"><i style="width:${LV.cur/LV.need*100}%"></i></div></div>`;
EXT.badges=()=>{badgeCheck(true);const s=bstats(),l=activeBadges(),got=l.filter(b=>S.badges[b[0]]).length;
  return`<div class="card c-grape lvcard">${lvlBar()}<p class="muted">You earn XP for studying, finishing tasks, drinking water, prayers, habits, challenges and badges. Next level: ${LVN[Math.min(LV.lv,LVN.length-1)]}.</p></div>
  <div class="card"><div class="row between"><h2>Badges</h2><span class="pill">${got} of ${l.length}</span></div><div class="badges">${l.map(b=>{const p=b[5](s),on=!!S.badges[b[0]];return`<div class="bdg${on?' on':''} t-${b[4]}"><span class="bico">${ill(b[3])}</span><b>${b[1]}</b><span>${b[2]}</span>${on?`<em>Earned ${fmt(S.badges[b[0]])}</em>`:`<div class="bar"><i style="width:${Math.min(100,p[0]/p[1]*100)}%"></i></div><em>${Math.min(p[0],p[1])} / ${p[1]}</em>`}</div>`}).join('')}</div></div>`};
const CHAL=[['Drink 2 glasses of water before 10 AM'],['Study 25 minutes with your phone in another room'],['Read the abstract of one research paper'],['Walk for 15 minutes today'],['Pray all five prayers on time',1],['Write tomorrow’s top 3 tasks before bed'],['No sugary drinks today'],['Explain one biochemical pathway out loud in 2 minutes'],['Sleep before 12 tonight'],['Eat one fruit and one vegetable portion'],['Tidy your desk for 5 minutes'],['Call or message a family member'],['Revise yesterday’s class notes for 10 minutes'],['Draw one amino acid structure from memory'],['Do 20 squats'],['Spend nothing on snacks today'],['Read 10 ayahs with their meaning',1],['Finish one task you have been putting off'],['Write one line about what went well today'],['Recite the morning adhkar',1],['Learn one new lab technique from a video'],['Drink your full water goal today'],['Help a classmate with one question']];
const chalList=()=>CHAL.map((c,i)=>[i,c[0],c[1]]).filter(c=>!(c[2]&&S.settings.deenOff));
function chalToday(){const t=today(),c=S.chal[t],l=chalList();if(c&&l.some(x=>x[0]===c.i))return c;const i=l[(DAY0(t)*7)%l.length][0];return{i:i,done:0,sw:0}}
function chalCard(){const c=chalToday(),txt=CHAL[c.i][0];return`<div class="card chal${c.done?' done':''}"><div class="row">${ill('medal')}<div class="grow"><span class="pill">Today’s challenge · +15 XP</span><p class="t">${esc(txt)}</p></div></div><div class="row">${c.done?'<span class="muted grow">Done. Nice work.</span>':`<button class="btn sm pri" data-a="chalDone">I did it</button>${c.sw?'':`<button class="btn sm" data-a="chalSwap">Give me another</button>`}`}</div></div>`}

/* ---------- study heatmap ---------- */
function heatCard(){
  const t=today(),end=t,dEnd=parse(end).getDay(),last=addDays(end,(5-dEnd+7)%7),weeks=18,start=addDays(last,-(weeks*7-1)),mins={};
  S.focus.forEach(f=>{mins[f.date]=(mins[f.date]||0)+(+f.min||0)});
  const lv=m=>!m?0:m<30?1:m<60?2:m<120?3:4;let cols='';
  for(let w=0;w<weeks;w++){let c='';for(let d=0;d<7;d++){const ds=addDays(start,w*7+d),m=mins[ds]||0,fut=ds>t;c+=`<i class="h${fut?'f':lv(m)}${ds===t?' now':''}" title="${fmt(ds)}: ${m} min"></i>`}cols+=`<div>${c}</div>`}
  const days=Object.keys(mins).filter(d=>mins[d]>0).sort(),best=days.reduce((a,d)=>mins[d]>(mins[a]||0)?d:a,''),total=days.filter(d=>d>=start).reduce((a,d)=>a+mins[d],0);
  let cur=0;for(let d=t;mins[d]>0||(d===t&&mins[addDays(t,-1)]>0);d=addDays(d,-1)){if(mins[d]>0)cur++;if(cur>400)break}
  return`<div class="card"><div class="row between"><h2>Study heatmap</h2><span class="pill">${dur(total)} in 18 weeks</span></div><div class="heat"><div class="hdays">${['S','S','M','T','W','T','F'].map(x=>`<span>${x}</span>`).join('')}</div><div class="hgrid">${cols}</div></div><div class="row between"><span class="muted">Less</span><div class="hleg">${[0,1,2,3,4].map(i=>`<i class="h${i}"></i>`).join('')}</div><span class="muted">More</span></div><div class="g3">${stat(cur+' day'+(cur===1?'':'s'),'study streak')}${stat(best?dur(mins[best]):'–','best day')}${stat(best?fmt(best).replace(/^\w+, /,''):'–','on')}</div></div>`;
}
EXT.timer=()=>heatCard();

/* ---------- exam day mode ---------- */
A.xFields=()=>[['title','What','text',{req:true,ph:'Mid-term, Quiz 2, Lab report'}],['type','Type','select',{opts:XK}],['courseId','Course','select',{opts:courseOpts()}],['date','Date','date',R],['time','Time','time'],['room','Room','text',{ph:'NAC 501'}]];
const ECHK=['Admit card','Student ID card','Calculator','Pens and pencils','Eraser and ruler','Water bottle','Watch'];
const examsToday=()=>S.exams.filter(e=>e.date===today()).sort((a,b)=>(a.time||'')<(b.time||'')?-1:1);
const examLive=e=>!e.time||nowMin()<toMin(e.time)+180;
function examCard(e){
  const ck=S.examChk[e.id]=S.examChk[e.id]||{},items=ECHK.concat(ck._x||[]),left=e.time?toMin(e.time)-nowMin():null,dx=DX.ilm;
  return`<div class="card examday"><span class="pill">Exam day</span><h1>${esc(e.title)}</h1><p class="muted">${esc([e.type,cname(e.courseId)].filter(Boolean).join(' · '))}</p><div class="g3">${stat(e.time?tfmt(e.time):'–','starts')}${stat(esc(e.room||'–'),'room')}${stat(left==null?'Today':left>0?dur(left):'Now','to go')}</div></div>
  <div class="card"><div class="row between"><h3>Bring with you</h3><span class="pill">${items.filter(x=>ck[x]).length} of ${items.length}</span></div><div class="list">${items.map(x=>`<div class="item">${chk(ck[x],'exChk',`data-id="${e.id}" data-v="${esc(x)}"`,x)}<span class="t grow">${esc(x)}</span></div>`).join('')}</div><form class="quick" data-f="exItem" data-id="${e.id}"><input id="q_exitem" placeholder="Add something else" aria-label="Add a checklist item"><button class="btn pri" aria-label="Add">${ic('plus')}</button></form></div>
  <div class="card calmcard"><h3>Take a calm minute</h3><div class="breathe"><i></i><span id="brtx">Breathe in</span></div><p class="muted">Breathe in for 4, hold for 4, out for 4. Three rounds settle your nerves.</p><ul><li>Arrive 20 minutes early.</li><li>Read every question first, then start with the ones you know.</li><li>Keep 10 minutes at the end to check your answers.</li></ul></div>`+
  (S.settings.deenOff?'':`<div class="card"><h3>Dua before you begin</h3><p class="ar" lang="ar">${dx[0]}</p><p><b>উচ্চারণ:</b> ${dx[1]}</p><p>${S.settings.dl==='en'?'My Lord, increase me in knowledge. My Lord, open my heart for me and make my task easy for me.':'<b>অর্থ:</b> '+dx[2]}</p><p class="muted">Quran 20:114 and 20:25-26</p></div>`);
}
const _today13=VIEWS.today;
VIEWS.today=()=>{const ex=examsToday().filter(examLive);if(ex.length&&!ui.examFull)return skyHero()+ex.map(examCard).join('')+`<button class="btn" data-a="exFull" style="align-self:center">Show my full day</button>`;return _today13()+(ex.length?`<button class="btn sm" data-a="exFocus" style="align-self:center">Back to exam mode</button>`:'')+molCard()};
let brT=0;function breathe(){const el=document.getElementById('brtx');if(!el){clearInterval(brT);brT=0;return}const k=Math.floor(Date.now()/4000)%3;el.textContent=['Breathe in','Hold','Breathe out'][k]}
const _ag13=agenda;
agenda=function(ds){const a=_ag13(ds);S.exams.filter(e=>e.date===ds).forEach(e=>{a.push({t:'07:00',title:'Exam today: '+e.title+(e.time?' at '+tfmt(e.time):'')+(e.room?', '+e.room:''),src:'Exam',key:'x-'+e.id});if(e.time&&toMin(e.time)>=480)a.push({t:hm(toMin(e.time)-60),title:e.title+' starts in 1 hour'+(e.room?' in '+e.room:''),src:'Exam',key:'x1-'+e.id})});return a.sort((x,y)=>x.t<y.t?-1:1)};

/* ---------- semester wrapped ---------- */
function firstDate(){const ds=[].concat(S.focus.map(f=>f.date),S.money.map(m=>m.date),S.sleep.map(l=>l.date),Object.keys(S.water),Object.keys(S.prayers),S.tasks.map(t=>t.doneAt).filter(Boolean)).filter(Boolean).sort();return ds[0]||today()}
function wrapStats(a,b){
  const inR=d=>d&&d>=a&&d<=b,f=S.focus.filter(x=>inR(x.date)),byC={},byD={};f.forEach(x=>{byC[x.courseId||'']=(byC[x.courseId||'']||0)+x.min;byD[x.date]=(byD[x.date]||0)+x.min});
  const topC=Object.keys(byC).filter(k=>k).sort((x,y)=>byC[y]-byC[x])[0],sp=S.money.filter(m=>inR(m.date)&&m.type!=='in'),cat={},pay={};sp.forEach(m=>{cat[m.cat]=(cat[m.cat]||0)+m.amount;const p=m.pay||'Cash';pay[p]=(pay[p]||0)+m.amount});
  const sl=S.sleep.filter(l=>inR(l.date)),q=QN(),days=Math.max(1,diffDays(b,a)+1);
  return{a:a,b:b,days:days,focus:f.reduce((s,x)=>s+x.min,0),topCourse:topC?cname(topC):'',topMin:topC?byC[topC]:0,bestDay:Object.values(byD).reduce((m,x)=>Math.max(m,x),0),tasks:S.tasks.filter(x=>x.done&&inR(x.doneAt)).length,exams:S.exams.filter(e=>inR(e.date)).length,
    prayers:Object.keys(S.prayers).filter(inR).reduce((s,d)=>s+Object.keys(S.prayers[d]).length,0),ayahs:Object.keys(q.log||{}).filter(inR).reduce((s,d)=>s+(q.log[d]||0),0),fasts:Object.keys(S.fasts).filter(inR).length,
    glasses:Object.keys(S.water).filter(inR).reduce((s,d)=>s+(+S.water[d]||0),0),sleep:sl.length?sl.reduce((s,l)=>s+sleepMin(l),0)/sl.length:0,active:S.acts.filter(x=>inR(x.date)).reduce((s,x)=>s+(+x.min||0),0),
    spent:sp.reduce((s,m)=>s+m.amount,0),topCat:Object.keys(cat).sort((x,y)=>cat[y]-cat[x])[0]||'',topPay:Object.keys(pay).sort((x,y)=>pay[y]-pay[x])[0]||'',streak:ST().best||0,badges:Object.keys(S.badges).filter(k=>inR(S.badges[k])).length};
}
let WR=null,wrT=0;
function wrapSlides(name,s){
  const sl=[];
  sl.push(['w1',`<p class="wk">Your semester, wrapped</p><h1>${esc(name)}</h1><p>${fmt(s.a)} to ${fmt(s.b)} · ${s.days} days</p><img src="logo.png" alt="" class="wlogo">`]);
  sl.push(['w2',`<p class="wk">You studied for</p><h1 class="wn" data-n="${Math.round(s.focus/60)}">${Math.round(s.focus/60)}</h1><p>hours</p>${s.topCourse?`<p>Most of it on <b>${esc(s.topCourse)}</b>: ${dur(s.topMin)}.</p>`:''}${s.bestDay?`<p>Your biggest day: ${dur(s.bestDay)}.</p>`:''}`]);
  sl.push(['w3',`<p class="wk">You finished</p><h1 class="wn" data-n="${s.tasks}">${s.tasks}</h1><p>tasks</p><p>and faced ${s.exams} exam${s.exams===1?'':'s'} and deadline${s.exams===1?'':'s'}.</p>`]);
  if(!S.settings.deenOff)sl.push(['w4',`<p class="wk">You prayed</p><h1 class="wn" data-n="${s.prayers}">${s.prayers}</h1><p>prayers</p><p>${s.ayahs?s.ayahs+' ayahs recited. ':''}${s.fasts?s.fasts+' days fasted.':''}</p>`]);
  sl.push(['w5',`<p class="wk">You drank</p><h1 class="wn" data-n="${Math.round(s.glasses*S.settings.glassMl/1000)}">${Math.round(s.glasses*S.settings.glassMl/1000)}</h1><p>litres of water</p><p>${s.sleep?'Average sleep: '+dur(Math.round(s.sleep))+'. ':''}${s.active?'Active for '+dur(s.active)+'.':''}</p>`]);
  sl.push(['w6',`<p class="wk">You spent</p><h1>${money(s.spent)}</h1><p>${s.topCat?'Mostly on '+esc(s.topCat).toLowerCase()+'.':''}${s.topPay?' Most paid with '+esc(s.topPay)+'.':''}</p>`]);
  sl.push(['w7',`<p class="wk">Your best streak</p><h1 class="wn" data-n="${s.streak}">${s.streak}</h1><p>days in a row</p><p>${s.badges?'and '+s.badges+' badge'+(s.badges===1?'':'s')+' earned.':''}</p>`]);
  sl.push(['w8',`<p class="wk">That was ${esc(name)}</p><h1>Small steps, big reactions.</h1><div class="wsum">${[['Study',Math.round(s.focus/60)+' h'],['Tasks',s.tasks],!S.settings.deenOff&&['Prayers',s.prayers],['Water',Math.round(s.glasses*S.settings.glassMl/1000)+' L'],['Spent',money(s.spent)],['Best streak',s.streak+' days']].filter(Boolean).map(x=>`<span><b>${x[1]}</b>${x[0]}</span>`).join('')}</div><div class="row"><button class="btn" data-a="wrShare">${NV&&NV.shareText?'Share':'Copy summary'}</button><button class="btn pri" data-a="wrClose">Done</button></div>`]);
  return sl;
}
function wrapOpen(name,s){WR={name:name,s:s,i:0,sl:wrapSlides(name,s)};let el=document.getElementById('wrapx');if(!el){el=document.createElement('div');el.id='wrapx';document.body.appendChild(el)}wrapDraw()}
function wrapDraw(){
  const el=document.getElementById('wrapx');if(!el||!WR)return;const sl=WR.sl[WR.i];
  el.className='wr '+sl[0];el.innerHTML=`<div class="wbars">${WR.sl.map((x,i)=>`<i class="${i<WR.i?'done':i===WR.i?'cur':''}"></i>`).join('')}</div><button class="wclose" data-a="wrClose" aria-label="Close">×</button><div class="wbody">${sl[1]}</div><button class="wprev" data-a="wrPrev" aria-label="Previous"></button><button class="wnext" data-a="wrNext" aria-label="Next"></button>`;
  el.querySelectorAll('.wn').forEach(n=>{const to=+n.dataset.n;if(!(to>1)||S.settings.motion==='off')return;const t0=performance.now();(function st(now){const k=Math.min(1,(now-t0)/900);n.textContent=Math.round(to*(1-Math.pow(1-k,3)));if(k<1)requestAnimationFrame(st)})(t0)});
  clearTimeout(wrT);if(WR.i<WR.sl.length-1)wrT=setTimeout(()=>{if(WR&&WR.i<WR.sl.length-1){WR.i++;wrapDraw()}},6000);
  if(curLang()==='bn')bnNode(el);
}
const wrapText=()=>{const s=WR.s;return`My ${WR.name} on Catalyst: ${Math.round(s.focus/60)} hours of study, ${s.tasks} tasks done${S.settings.deenOff?'':', '+s.prayers+' prayers'}, ${Math.round(s.glasses*S.settings.glassMl/1000)} litres of water, best streak ${s.streak} days. Small steps, big reactions.`};
const _cour13=EXT.courses;
EXT.courses=()=>{const h=_cour13();return`<div class="card wrapcta" role="button" tabindex="0" data-a="wrNow"><div class="row">${ill('medal')}<div class="grow"><h3>${esc(S.settings.sem||'This semester')}, wrapped</h3><p class="muted">Your semester so far as a short animated story.</p></div>${ic('next')}</div></div>`+h.replace(/<button class="btn sm" data-a="semBack" data-v="([^"]*)">/g,(m,v)=>((S.wraps||[]).some(w=>esc(w.name)===v)?`<button class="btn sm" data-a="wrPast" data-v="${v}">Wrapped</button>`:'')+m)};

/* ---------- lab buddy ---------- */
const enc=o=>'CATALYST:'+btoa(unescape(encodeURIComponent(JSON.stringify(o))))+':END';
function dec(txt){const m=String(txt||'').match(/CATALYST:([A-Za-z0-9+/=\s]+?):END/);if(!m)return null;try{const o=JSON.parse(decodeURIComponent(escape(atob(m[1].replace(/\s+/g,'')))));return o&&o.v===1&&o.t?o:null}catch(e){return null}}
function shareOut(o,label){ui.buddy={code:enc(o),label:label};render()}
EXT.lab_buddy=()=>{
  const mine=S.protocols,nb=S.notes.filter(n=>n.ref==='lab').sort((a,b)=>(b.updated||0)-(a.updated||0)).slice(0,8),inc=dec(ui.bdIn);
  let o=`<div class="card c-sky"><div class="row">${ill('flask')}<div class="grow"><h2>Lab buddy</h2><p class="muted">Send your reagent list, a protocol or a notebook entry to your lab partner as a code. They paste it into their Catalyst. No account or internet sharing needed.</p></div></div></div>`;
  if(ui.buddy)o+=`<div class="card"><div class="row between"><h3>Code ready: ${esc(ui.buddy.label)}</h3><button class="btn sm" data-a="bdClear">Close</button></div><textarea readonly class="code" aria-label="Share code">${esc(ui.buddy.code)}</textarea><div class="row wrap">${NV&&NV.shareText?'<button class="btn pri" data-a="bdSend">Send by WhatsApp or other app</button>':''}<button class="btn${NV&&NV.shareText?'':' pri'}" data-a="bdCopy">Copy code</button></div>${said('bd')}</div>`;
  o+=`<div class="card"><h3>Share</h3><div class="list">${S.reag.length?`<div class="item"><span class="t grow">My reagent list (${S.reag.length})</span><button class="btn sm" data-a="bdReag">Share</button></div>`:''}${mine.map(p=>`<div class="item"><span class="t grow">Protocol: ${esc(p.name)}</span><button class="btn sm" data-a="bdProto" data-id="${p.id}">Share</button></div>`).join('')}${nb.map(n=>`<div class="item"><span class="t grow">Notebook: ${esc(n.title||'Untitled')}</span><button class="btn sm" data-a="bdNote" data-id="${n.id}">Share</button></div>`).join('')}</div>${S.reag.length||mine.length||nb.length?'':'<p class="muted">Add reagents, your own protocols or lab notebook entries first.</p>'}</div>`;
  o+=`<div class="card"><h3>Receive</h3><textarea data-c="bdIn" placeholder="Paste the code your buddy sent" aria-label="Paste a code">${esc(ui.bdIn)}</textarea>${inc?`<div class="card c-leaf"><p><b>${inc.t==='reag'?'Reagent list, '+inc.d.length+' items':inc.t==='proto'?'Protocol: '+esc(inc.d.name):'Notebook entry: '+esc(inc.d.title||'Untitled')}</b>${inc.from?' from '+esc(inc.from):''}</p><button class="btn pri" data-a="bdImport">Add to my app</button></div>`:ui.bdIn.trim()?'<p class="muted" style="color:var(--bad)">That is not a Catalyst code. Ask your buddy to copy it again.</p>':''}${said('bdi')}</div>`;
  return o;
};

/* ---------- actions ---------- */
Object.assign(A,{
  molPick(d){ui.mol=d.v;render()},
  payBalSet(){form('Set a balance',[['pay','Account','select',{opts:PAY}],['amt','Balance right now','number',R]],{pay:'bKash'},v=>{const b=Object.assign({},S.settings.payBal);b[v.pay]={amt:v.amt,date:today()};S.settings.payBal=b;save('settings')})},
  chalDone(){const t=today(),c=chalToday();S.chal[t]={i:c.i,done:1,sw:c.sw};save('chal');render();celebrate('Challenge complete: +15 XP')},
  chalSwap(){const t=today(),c=chalToday(),l=chalList(),k=l.findIndex(x=>x[0]===c.i);S.chal[t]={i:l[(k+3)%l.length][0],done:0,sw:1};save('chal');render()},
  exFull(){ui.examFull=true;render();window.scrollTo(0,0)},
  exFocus(){ui.examFull=false;render();window.scrollTo(0,0)},
  exChk(d){const ck=S.examChk[d.id]=S.examChk[d.id]||{};if(ck[d.v])delete ck[d.v];else ck[d.v]=1;save('examChk');render()},
  wrNow(){const a=S.settings.semStart||firstDate();wrapOpen(S.settings.sem||'This semester',wrapStats(a,today()))},
  wrPast(d){const w=(S.wraps||[]).find(x=>x.name===d.v);if(w)wrapOpen(w.name,w.stats)},
  wrNext(){if(!WR)return;if(WR.i<WR.sl.length-1){WR.i++;wrapDraw()}},
  wrPrev(){if(!WR)return;if(WR.i>0){WR.i--;wrapDraw()}},
  wrClose(){clearTimeout(wrT);WR=null;const el=document.getElementById('wrapx');if(el)el.remove()},
  wrShare(){const t=wrapText();if(NV&&NV.shareText){try{NV.shareText(t)}catch(e){}}else copyText(t,'wr')},
  semNew(){form('Start a new semester',[['name','Name of the new semester','text',{req:true,ph:'Spring 2027'}],['old','Name of the semester that ended','text',{req:true,ph:'Fall 2026'}],['toCg','Add the finished courses to my CGPA list','select',{opts:[['1','Yes, so I can enter their grades'],['0','No']]}],['clear','Weekly class routine','select',{opts:[['1','Clear it for the new semester'],['0','Keep it']]}]],{old:S.settings.sem||''},v=>{
    const a=S.settings.semStart||firstDate(),st=wrapStats(a,today());S.wraps=(S.wraps||[]).filter(w=>w.name!==v.old).concat([{name:v.old,start:a,end:today(),stats:st}]);
    const cur=curCourses();cur.forEach(c=>{c.arch=v.old});
    if(v.toCg==='1'&&cur.length)S.sems.push({id:uid(),name:v.old,items:cur.map(c=>({id:uid(),name:c.code||c.title,credits:num(c.credits)||3,grade:'',old:''}))});
    if(v.clear==='1'){S.semArch.push({name:v.old,routine:S.routine});S.routine=[]}
    S.settings.sem=v.name;S.settings.semStart=today();save('courses','sems','routine','semArch','settings','wraps');setTimeout(()=>wrapOpen(v.old,st),400)})},
  bdReag(){shareOut({v:1,t:'reag',from:S.settings.name||'',d:S.reag.map(r=>({name:r.name,qty:r.qty,unit:r.unit,low:r.low,exp:r.exp,loc:r.loc,note:r.note}))},'reagent list')},
  bdProto(d){const p=S.protocols.find(x=>x.id===d.id);shareOut({v:1,t:'proto',from:S.settings.name||'',d:{name:p.name,steps:p.steps}},p.name)},
  bdNote(d){const n=S.notes.find(x=>x.id===d.id);shareOut({v:1,t:'note',from:S.settings.name||'',d:{title:n.title,body:n.body}},n.title||'notebook entry')},
  bdClear(){ui.buddy=null;render()},
  bdCopy(){copyText(ui.buddy.code,'bd')},
  bdSend(){try{NV.shareText('Catalyst lab buddy code ('+ui.buddy.label+'). Open Catalyst > Lab > Lab buddy and paste it:\n'+ui.buddy.code)}catch(e){say('bd','Could not open the share menu. Use Copy code.')}},
  bdImport(){const o=dec(ui.bdIn);if(!o)return;let msg='';
    if(o.t==='reag'){let add=0,skip=0;(o.d||[]).forEach(r=>{if(!r||!r.name)return;if(S.reag.some(x=>String(x.name).toLowerCase()===String(r.name).toLowerCase())){skip++;return}S.reag.push(Object.assign({id:uid()},r,{note:[r.note,o.from?'from '+o.from:''].filter(Boolean).join(' · ')}));add++});save('reag');msg='Added '+add+' reagent'+(add===1?'':'s')+(skip?', skipped '+skip+' you already have':'')+'.'}
    else if(o.t==='proto'){S.protocols.push({id:uid(),name:String(o.d.name||'Protocol').slice(0,80),steps:String(o.d.steps||'')});save('protocols');msg='Protocol added. Find it in Lab, Protocols.'}
    else if(o.t==='note'){const n={id:uid(),ref:'lab',title:String(o.d.title||'From my lab buddy').slice(0,120),body:String(o.d.body||''),updated:Date.now()};S.notes.push(n);save('n_'+n.id);msg='Added to your lab notebook.'}
    ui.bdIn='';render();say('bdi',msg);celebrate('Received from your lab buddy')}
});
Q.exItem=()=>{const f=document.querySelector('form[data-f="exItem"]'),v=$('#q_exitem').value.trim();if(!f||!v)return;const ck=S.examChk[f.dataset.id]=S.examChk[f.dataset.id]||{};ck._x=(ck._x||[]).concat(v.slice(0,40));save('examChk')};
document.addEventListener('input',e=>{if(e.target.dataset&&e.target.dataset.c==='bdIn'){ui.bdIn=e.target.value;clearTimeout(window.__bdT);window.__bdT=setTimeout(()=>{const ae=document.activeElement,pos=ae&&ae.selectionStart;render();const t=document.querySelector('[data-c="bdIn"]');if(t){t.focus();try{t.setSelectionRange(pos,pos)}catch(x){}}},400)}});
document.addEventListener('keydown',e=>{if(!WR)return;if(e.key==='ArrowRight')A.wrNext();else if(e.key==='ArrowLeft')A.wrPrev();else if(e.key==='Escape')A.wrClose()});

/* level on the hero and in the menu */
const _sky13=skyHero;
skyHero=function(){const h=_sky13();return h.replace(/<\/div>$/,`<span class="pill lvlpill" role="button" tabindex="0" data-a="go" data-tab="more" data-k="more" data-v="badges">Lv ${LV.lv} · ${LV.name}</span></div>`)};
const _dd13=drawDrawer;
drawDrawer=function(){_dd13();const h=document.querySelector('#drawer .dhead div:last-child');if(h&&!h.querySelector('.lvl'))h.insertAdjacentHTML('beforeend',`<span class="dlv">Level ${LV.lv} · ${LV.name}</span>`)};
const _mid13=EXT.todayMid;EXT.todayMid=()=>_mid13()+chalCard();
const _ar13=window.afterRender;
window.afterRender=function(){badgeCheck();_ar13();molStart();if(document.getElementById('brtx')&&!brT){breathe();brT=setInterval(breathe,1000)}};
Object.assign(BN,{'Badges':'ব্যাজ','Molecules':'অণু','Molecule of the day':'আজকের অণু','Lab buddy':'ল্যাব বাডি','Drag to turn it':'ঘোরাতে টানুন','All molecules':'সব অণু','By payment method':'পেমেন্টের মাধ্যম অনুযায়ী','Set a balance':'ব্যালান্স সেট করুন','Paid with':'যেভাবে পরিশোধ','Account':'অ্যাকাউন্ট','Balance right now':'এখনকার ব্যালান্স','Cash':'নগদ','Card':'কার্ড','Bank':'ব্যাংক','Study heatmap':'পড়ার হিটম্যাপ','Less':'কম','study streak':'পড়ার ধারাবাহিকতা','best day':'সেরা দিন','Exam day':'পরীক্ষার দিন','Bring with you':'সাথে নিন','Take a calm minute':'এক মিনিট শান্ত হোন','Breathe in':'শ্বাস নিন','Hold':'ধরে রাখুন','Breathe out':'শ্বাস ছাড়ুন','Show my full day':'পুরো দিন দেখান','Back to exam mode':'পরীক্ষার মোডে ফিরুন','Dua before you begin':'শুরুর আগে দোয়া','I did it':'করেছি','Give me another':'আরেকটি দিন','Share':'শেয়ার','Receive':'গ্রহণ','Add to my app':'আমার অ্যাপে যোগ করুন','Copy code':'কোড কপি','Send by WhatsApp or other app':'WhatsApp বা অন্য অ্যাপে পাঠান','Done.':'সম্পন্ন।','Wrapped':'র‍্যাপড','starts':'শুরু','room':'রুম','to go':'বাকি'});
BNP.push([/^Level (\d+) · (.+)$/,'লেভেল $1 · $2'],[/^Lv (\d+) · (.+)$/,'লেভেল $1 · $2'],[/^Today’s challenge · \+15 XP$/,'আজকের চ্যালেঞ্জ · +১৫ XP'],[/^Badge unlocked: (.+)$/,'নতুন ব্যাজ: $1']);
window.__v13={MOLS:MOLS,bstats:bstats,level:level,payBal:payBal,dec:dec,enc:enc,wrapStats:wrapStats,chalToday:chalToday,heatCard:heatCard,examsToday:examsToday,badgeCheck:badgeCheck,xpOf:xpOf};


/* ================= v14: Catalyst account (Firebase sign-in and sync) and app updates ================= */
const FB_CFG={apiKey:"AIzaSyCXikzs_2w4SKUH8xUvPEstKzOwG6Ztx8s",authDomain:"catalyst-73816.firebaseapp.com",projectId:"catalyst-73816",storageBucket:"catalyst-73816.firebasestorage.app",messagingSenderId:"515403537987",appId:"1:515403537987:web:d25418db0a3edd2cb77ef6"};
const FBV='10.12.2';
let fbApp=null,fbUser=null,fbState='off',fbErr='',fbLast=0,fbBusy=false,fbPending=null;
SUB.more.splice(1,0,['account','Account']);
MENU[MENU.length-1][1].unshift(['more','more','account','Account and sync','pink',()=>fbUser?'On':'']);
function loadScript(srcs){return new Promise((res,rej)=>{(function next(i){if(i>=srcs.length)return rej(new Error('offline'));const s=document.createElement('script');s.src=srcs[i];s.onload=()=>res();s.onerror=()=>{s.remove();next(i+1)};document.head.appendChild(s)})(0)})}
async function fbLoad(){if(window.firebase&&window.firebase.firestore&&window.firebase.auth)return window.firebase;for(const n of['app','auth','firestore'])await loadScript(['fb/firebase-'+n+'-compat.js','https://www.gstatic.com/firebasejs/'+FBV+'/firebase-'+n+'-compat.js','https://cdn.jsdelivr.net/npm/firebase@'+FBV+'/firebase-'+n+'-compat.js']);return window.firebase}
async function fbInit(){
  if(fbApp||cloud==='on'||cloud==='loading'||fbState==='loading')return;
  fbState='loading';
  try{const F=await fbLoad();fbApp=F.apps.length?F.app():F.initializeApp(FB_CFG);fbState='ready';
    F.auth().onAuthStateChanged(u=>{fbUser=u;if(u)fbConnect(u);else fbOff();render()})}
  catch(e){fbState='unavailable';fbApp=null}
  render();
}
function fbOff(){if(cloud==='fb'){col=null;cloud='local'}if(fbState!=='unavailable')fbState='ready';setStatus()}
const hasLocalData=()=>S.tasks.length+S.money.length+S.notes.length+S.focus.length+S.sleep.length+Object.keys(S.water).length+S.courses.length>0;
async function fbConnect(u,choice){
  if(fbBusy)return;fbBusy=true;fbErr='';fbState='syncing';render();
  const c=window.firebase.firestore().collection('users').doc(u.uid).collection('data');
  try{
    const snap=await c.get(),remote={};snap.forEach(d=>{try{remote[d.id]=JSON.parse(d.data().j)}catch(x){}});
    const rk=Object.keys(remote),known=S.settings._fbUid===u.uid;
    if(!choice&&!known&&rk.length&&hasLocalData()){fbBusy=false;fbState='choose';fbPending=u;render();fbChoose();return}
    if(choice==='remote'||(!known&&rk.length&&!hasLocalData()))dirty.clear();
    if(rk.length&&choice!=='local'){
      const notes=[];rk.forEach(k=>{const b=remote[k];if(!b||dirty.has(k))return;if(k.indexOf('n_')===0)notes.push(Object.assign({},b));else if(KEYS.includes(k)&&b.v!=null)S[k]=b.v});
      S.notes=notes.concat(S.notes.filter(n=>dirty.has('n_'+n.id)));normalize();
    }else{KEYS.forEach(k=>dirty.add(k));S.notes.forEach(n=>dirty.add('n_'+n.id))}
    col={doc:k=>({set:b=>c.doc(k).set({j:JSON.stringify(b),t:Date.now()}),delete:()=>c.doc(k).delete()})};
    cloud='fb';S.settings._fbUid=u.uid;dirty.add('settings');saveErr='';if(S.settings.setup&&ob&&ob.el){ob.el.remove();ob=null}
    [...dirty].forEach(k=>{tries[k]=0;flush(k)});fbState='on';fbLast=Date.now();lsSave();
  }catch(e){fbState='error';fbErr=e&&e.code==='permission-denied'?'The account database refused access. Check that the Firestore rules were published.':'Could not reach your account. It will try again when you are online.'}
  fbBusy=false;render();
}
function fbChoose(){confirmSheet('This account already has data','You have records on this phone and in your Catalyst account. Which should Catalyst keep? The other set is replaced.','Use my account’s data',()=>{const u=fbPending;fbPending=null;fbConnect(u,'remote')});
  const row=document.querySelector('#sheet .row:last-child');if(row)row.insertAdjacentHTML('afterbegin','<button class="btn" data-a="fbKeepLocal">Keep this phone’s data</button>')}
const FBE={'auth/email-already-in-use':'An account with this email already exists. Sign in instead.','auth/invalid-email':'That email address does not look right.','auth/weak-password':'Use a password of at least 6 characters.','auth/invalid-credential':'Wrong email or password.','auth/wrong-password':'Wrong email or password.','auth/user-not-found':'No account uses this email. Create one first.','auth/network-request-failed':'No internet connection. Try again when you are online.','auth/too-many-requests':'Too many tries. Wait a few minutes and try again.','auth/missing-password':'Type your password.'};
const fbMsg=e=>FBE[e&&e.code]||'Something went wrong. Try again.';
EXT.account=()=>{
  const lb=fbLast?Math.round((Date.now()-fbLast)/6e4):null;
  if(cloud==='on')return`<div class="card"><h2>Account</h2><p>You are using Catalyst inside Claude, so your data already saves to your Claude account.</p><p class="muted">Catalyst accounts are for the Android app. Sign in there to keep your data safe and use it on more than one phone.</p></div>`;
  if(fbState==='unavailable'||fbState==='off'||fbState==='loading')return`<div class="card"><h2>Catalyst account</h2><p class="muted">${fbState==='loading'?'Connecting…':'Signing in needs an internet connection the first time.'}</p>${fbState==='loading'?'':'<button class="btn pri" data-a="fbRetry" style="align-self:flex-start">Try again</button>'}</div>`;
  if(!fbUser)return`<div class="card c-sky"><div class="row">${ill('drop')}<div class="grow"><h2>Keep your data safe</h2><p class="muted">With a free Catalyst account your data syncs online. Get it back on a new phone, and use it on more than one device. The app keeps working offline and syncs when you reconnect.</p></div></div><div class="row wrap"><button class="btn pri" data-a="fbUp">Create an account</button><button class="btn" data-a="fbIn">Sign in</button></div>${said('fb')}</div><div class="card"><p class="muted">Files and photos you upload stay on this phone. Back them up separately.</p></div>`;
  return`<div class="card c-leaf"><div class="row between"><div><span class="pill">Signed in</span><h3>${esc(fbUser.email||'')}</h3></div></div><p>${fbState==='syncing'?'Syncing…':fbState==='error'?esc(fbErr):'Synced'+(lb!=null?(lb<1?' just now':' '+lb+' min ago'):'')+'. Changes upload automatically.'}</p><div class="row wrap"><button class="btn" data-a="fbSync">Sync now</button><button class="btn" data-a="fbReset">Change password</button><button class="btn danger" data-a="fbOut">Sign out</button></div>${said('fb')}<p class="muted">Signing out keeps your data on this phone but stops syncing. Files and photos you upload stay on this phone.</p></div>`;
};
const _nud14=nudges;
nudges=function(){const a=_nud14();if(cloud==='local'&&fbState==='ready'&&!fbUser&&S.tasks.length+S.money.length+S.notes.length+S.sleep.length>10){const dis=S.settings.nd&&S.settings.nd.d===today()?S.settings.nd.k||{}:{};if(!dis.acct)a.push({k:'acct',t:'Create a free Catalyst account so your data is safe if you lose or change your phone.',go:['more','more','account']})}return a};
Object.assign(A,{
  fbRetry(){fbState='off';fbInit()},
  fbUp(){form('Create your Catalyst account',[['email','Email','email',R],['pw','Password (at least 6 characters)','password',R]],{},v=>{window.firebase.auth().createUserWithEmailAndPassword(v.email,v.pw).then(()=>{say('fb','');celebrate('Account created. Your data is syncing.')},e=>say('fb',fbMsg(e)))})},
  fbIn(){form('Sign in',[['email','Email','email',R],['pw','Password','password',R]],{},v=>{window.firebase.auth().signInWithEmailAndPassword(v.email,v.pw).then(()=>say('fb',''),e=>{say('fb',fbMsg(e)+(e&&/credential|password/.test(e.code)?' Forgot it? Use Change password after signing in, or ask for a reset below.':''));setTimeout(()=>{const s=document.querySelector('#view [data-a="fbIn"]');if(s&&!document.querySelector('[data-a="fbForgot"]'))s.insertAdjacentHTML('afterend','<button class="btn" data-a="fbForgot">Forgot password</button>')},50)})})},
  fbForgot(){form('Reset your password',[['email','Your account email','email',R]],{},v=>{window.firebase.auth().sendPasswordResetEmail(v.email).then(()=>say('fb','Check your email for a link to set a new password.'),e=>say('fb',fbMsg(e)))})},
  fbReset(){if(fbUser&&fbUser.email)window.firebase.auth().sendPasswordResetEmail(fbUser.email).then(()=>say('fb','We sent a link to '+fbUser.email+' to set a new password.'),e=>say('fb',fbMsg(e)))},
  fbOut(){confirmSheet('Sign out?','Your data stays on this phone, but it stops syncing until you sign in again.','Sign out',()=>{window.firebase.auth().signOut()})},
  fbSync(){if(fbUser)fbConnect(fbUser)},
  fbKeepLocal(){const u=fbPending;fbPending=null;closeSheet();fbConnect(u,'local')}
});
/* start the account after the app has loaded, and refresh when the app comes back to the screen */
(function wait(){if(cloud==='loading')return setTimeout(wait,500);if(cloud==='local')fbInit()})();
window.addEventListener('online',()=>{if(fbState==='unavailable'){fbState='off';fbInit()}else if(fbUser&&fbState==='error')fbConnect(fbUser)});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&fbUser&&cloud==='fb'&&Date.now()-fbLast>60000&&!dirty.size)fbConnect(fbUser)});
/* app updates (Android app) */
window.onAppUpdate=function(v){let b=document.getElementById('updbar');if(!b){b=document.createElement('div');b.id='updbar';document.body.appendChild(b)}b.innerHTML=`<span class="grow"><b>Catalyst updated</b><br>Version ${+v} is ready.</span><button class="btn sm" data-a="updLater">Later</button><button class="btn sm pri" data-a="updNow">Restart now</button>`;if(curLang()==='bn')bnNode(b)};
Object.assign(A,{updNow(){try{NV.reloadApp()}catch(e){location.reload()}},updLater(){const b=document.getElementById('updbar');if(b)b.remove()}});
const _set14=EXT.settings;
EXT.settings=()=>{let v='';try{v=NV&&NV.appVersion?NV.appVersion():''}catch(e){}return _set14()+(v?`<div class="card"><h3>App version</h3><p>Version ${esc(String(v))}. Catalyst checks for updates each time it opens with internet and installs them by itself.</p></div>`:'')};
Object.assign(BN,{'Account':'অ্যাকাউন্ট','Account and sync':'অ্যাকাউন্ট ও সিঙ্ক','Keep your data safe':'আপনার ডেটা নিরাপদ রাখুন','Create an account':'অ্যাকাউন্ট খুলুন','Sign in':'সাইন ইন','Sign out':'সাইন আউট','Sign out?':'সাইন আউট করবেন?','Signed in':'সাইন ইন করা আছে','Sync now':'এখনই সিঙ্ক','Change password':'পাসওয়ার্ড পরিবর্তন','Forgot password':'পাসওয়ার্ড ভুলে গেছি','Create your Catalyst account':'Catalyst অ্যাকাউন্ট খুলুন','Email':'ইমেইল','Password':'পাসওয়ার্ড','Password (at least 6 characters)':'পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)','Syncing…':'সিঙ্ক হচ্ছে…','Try again':'আবার চেষ্টা করুন','Restart now':'এখনই আবার চালু করুন','Catalyst updated':'Catalyst আপডেট হয়েছে','Use my account’s data':'অ্যাকাউন্টের ডেটা ব্যবহার করুন','Keep this phone’s data':'এই ফোনের ডেটা রাখুন','This account already has data':'এই অ্যাকাউন্টে আগে থেকেই ডেটা আছে','App version':'অ্যাপের সংস্করণ'});
window.__v14={fbConnect:fbConnect,EXTacc:()=>EXT.account()};


/* ================= v15: Keep on top, sign-up during setup, level journey, ATP and biochem touches ================= */
/* ---------- side menu: Keep first ---------- */
(function(){const i=MENU.findIndex(g=>g[0]==='Keep');if(i>0)MENU.unshift(MENU.splice(i,1)[0])})();
const _dd15=drawDrawer;
drawDrawer=function(){_dd15();const s=document.querySelector('#drawer .dlv');if(s&&!s.dataset.a){s.setAttribute('role','button');s.tabIndex=0;s.dataset.a='go';s.dataset.tab='more';s.dataset.k='more';s.dataset.v='levels'}};

/* ---------- ATP instead of XP ---------- */
const atp=h=>String(h).replace(/\bXP\b/g,'ATP');
const _cel15=celebrate;celebrate=function(m){_cel15(atp(m))};
const _chal15=chalCard;chalCard=function(){return atp(_chal15())};
const _bdg15=EXT.badges;EXT.badges=()=>atp(_bdg15());

/* ---------- levels: 40 steps from Atom to Nobel Laureate ---------- */
const LVD=[
 ['Atom','atom','Everything starts here. Carbon, hydrogen, oxygen and nitrogen make up about 96% of your body mass.'],
 ['Ion','ion','Na⁺ and K⁺ gradients power every nerve impulse.'],
 ['Molecule','co2','Atoms sharing electrons. Covalent bonds hold life together.'],
 ['Water','water','About 60% of an adult’s body is water. Hydrogen bonds make it life’s solvent.'],
 ['Sugar','sugar','Glucose, C₆H₁₂O₆, is the cell’s favourite fuel.'],
 ['Amino acid','amino','Twenty standard amino acids build every protein you make.'],
 ['Nucleotide','nucleo','A sugar, a phosphate and a base: the letters of the genetic code.'],
 ['Fatty acid','fatty','Long carbon chains. Fat stores about 9 kcal per gram, sugar about 4.'],
 ['Peptide','chain','Amino acids joined by peptide bonds. Insulin has 51 of them.'],
 ['Lipid bilayer','bilayer','Two layers of phospholipids wrap every cell you have.'],
 ['Protein','protein','A folded chain whose shape decides its job.'],
 ['Enzyme','enzyme','Speeds reactions by millions of times without being used up.'],
 ['Coenzyme','coenz','NAD⁺ and FAD are helpers made from vitamins B3 and B2.'],
 ['ATP','atp','The cell’s energy currency. You recycle roughly your body weight of it every day.'],
 ['RNA','rna','Messenger, adaptor and the core of the ribosome.'],
 ['DNA','dna','About 2 metres of DNA folds into each nucleus.'],
 ['Gene','gene','Humans have about 20,000 protein-coding genes.'],
 ['Plasmid','plasmid','Small DNA rings bacteria share. A biotech workhorse.'],
 ['Chromosome','chromo','46 in each human body cell, in 23 pairs.'],
 ['Ribosome','ribo','The protein factory, reading mRNA three bases at a time.'],
 ['Golgi body','golgi','Packs, labels and ships proteins.'],
 ['Mitochondrion','mito','Makes most of your ATP and carries its own DNA.'],
 ['Chloroplast','chloro','Turns sunlight, water and CO₂ into sugar.'],
 ['Nucleus','nucleus','Keeps the genome safe and runs the cell.'],
 ['Cell','cell','The smallest unit of life. You are made of about 37 trillion.'],
 ['Bacterium','bact','Simple, fast and everywhere. E. coli can divide every 20 minutes.'],
 ['Stem cell','stem','Can become many different kinds of cell.'],
 ['Neuron','neuron','Sends signals at up to about 120 metres per second.'],
 ['Tissue','tissue','Similar cells working together.'],
 ['Organ','organ','Tissues joined for one job. Your heart beats about 100,000 times a day.'],
 ['Organ system','system','Organs working as a team, like digestion.'],
 ['Organism','person','A complete living thing. That is you.'],
 ['Population','pop','Many of one species in one place.'],
 ['Community','comm','Different species living side by side.'],
 ['Ecosystem','eco','Living things and their surroundings, cycling energy and matter.'],
 ['Biosphere','globe','Every ecosystem on Earth together.'],
 ['Researcher','flask','Asking questions and testing them.'],
 ['Professor','cap','Teaching the next generation.'],
 ['Pioneer','scope','Opening a field nobody explored before.'],
 ['Nobel Laureate','medal','The top of the ladder. Small steps, big reactions.']
];
const LVA={
 atom:'<ellipse cx="24" cy="24" rx="19" ry="7.5"/><ellipse cx="24" cy="24" rx="19" ry="7.5" transform="rotate(60 24 24)"/><ellipse cx="24" cy="24" rx="19" ry="7.5" transform="rotate(-60 24 24)"/><circle cx="24" cy="24" r="5" fill="var(--tomato)"/>',
 ion:'<ellipse cx="22" cy="26" rx="16" ry="6.5"/><ellipse cx="22" cy="26" rx="16" ry="6.5" transform="rotate(60 22 26)"/><ellipse cx="22" cy="26" rx="16" ry="6.5" transform="rotate(-60 22 26)"/><circle cx="22" cy="26" r="4.5" fill="var(--sky)"/><circle cx="39" cy="9" r="7" fill="var(--sun)"/><path d="M39 5.5v7M35.5 9h7"/>',
 co2:'<path d="M12 21h24M12 27h24"/><circle cx="9" cy="24" r="6" fill="var(--tomato)"/><circle cx="24" cy="24" r="6" fill="var(--grape)"/><circle cx="39" cy="24" r="6" fill="var(--tomato)"/>',
 water:'<path d="M11 33 24 20l13 13"/><circle cx="24" cy="20" r="9" fill="var(--tomato)"/><circle cx="11" cy="33" r="5.5" fill="var(--card)"/><circle cx="37" cy="33" r="5.5" fill="var(--card)"/>',
 sugar:'<path d="M24 7l15 8.5v17L24 41 9 32.5v-17z" fill="var(--sun)"/><circle cx="24" cy="7" r="4" fill="var(--tomato)"/><path d="M9 32.5 4 36M39 32.5l5 3.5"/>',
 amino:'<path d="M24 18V9M18 24H9M30 24h9M24 30v9"/><circle cx="24" cy="24" r="6" fill="var(--grape)"/><circle cx="24" cy="8" r="3.5" fill="var(--card)"/><circle cx="8" cy="24" r="4.5" fill="var(--sky)"/><circle cx="40" cy="24" r="4.5" fill="var(--tomato)"/><circle cx="24" cy="40" r="4.5" fill="var(--leaf)"/>',
 nucleo:'<circle cx="9" cy="14" r="5" fill="var(--sun)"/><path d="M13 17l5 4"/><path d="M18 20l7-5 7 5-2.5 8h-9z" fill="var(--pink)"/><path d="M32 22l4 4"/><rect x="34" y="24" width="10" height="16" rx="3" fill="var(--leaf)"/>',
 fatty:'<circle cx="8" cy="24" r="5.5" fill="var(--tomato)"/><path d="M13.5 24l5-6 5 6 5-6 5 6 5-6 5 6"/>',
 chain:'<path d="M8 30 18 18 30 30 40 18"/><circle cx="8" cy="30" r="5" fill="var(--grape)"/><circle cx="18" cy="18" r="5" fill="var(--sky)"/><circle cx="30" cy="30" r="5" fill="var(--sun)"/><circle cx="40" cy="18" r="5" fill="var(--leaf)"/>',
 bilayer:'<g fill="var(--sky)"><circle cx="8" cy="9" r="4"/><circle cx="19" cy="9" r="4"/><circle cx="30" cy="9" r="4"/><circle cx="41" cy="9" r="4"/><circle cx="8" cy="39" r="4"/><circle cx="19" cy="39" r="4"/><circle cx="30" cy="39" r="4"/><circle cx="41" cy="39" r="4"/></g><path d="M7 13v9M9 13v9M18 13v9M20 13v9M29 13v9M31 13v9M40 13v9M42 13v9M7 26v9M9 26v9M18 26v9M20 26v9M29 26v9M31 26v9M40 26v9M42 26v9"/>',
 protein:'<path d="M7 32c3-16 13-16 14-5s10 12 13-2 6-14 8-5" stroke="var(--grape)" stroke-width="5"/><path d="M7 32c3-16 13-16 14-5s10 12 13-2 6-14 8-5"/><circle cx="7" cy="32" r="3.5" fill="var(--sun)"/><circle cx="42" cy="20" r="3.5" fill="var(--sun)"/>',
 enzyme:'<path d="M23 24 39 13A18 18 0 1 0 39 35z" fill="var(--grape)"/><circle cx="14" cy="17" r="2.5" fill="var(--line)"/><circle cx="42" cy="24" r="4.5" fill="var(--sun)"/>',
 coenz:'<path d="M22 24 37 14A17 17 0 1 0 37 34z" fill="var(--pink)"/><path d="M33 19l5.5 3v6L33 31l-5.5-3v-6z" fill="var(--sun)"/><circle cx="13" cy="17" r="2.5" fill="var(--line)"/>',
 atp:'<path d="M27 4 12 27h11l-3 17 16-24H25z" fill="var(--sun)"/>',
 rna:'<path d="M6 30c6-14 12-14 18 0s12 14 18 0"/><path d="M12 22v-8M18 19v-9M30 33v9M36 36v-6" stroke="var(--tomato)" stroke-width="3.5"/>',
 dna:'<path d="M17 8h14M15 18h18M15 30h18M17 40h14"/><path d="M14 4c0 10 20 10 20 20s-20 10-20 20" stroke="var(--grape)" stroke-width="4"/><path d="M34 4c0 10-20 10-20 20s20 10 20 20" stroke="var(--sun)" stroke-width="4"/>',
 gene:'<path d="M14 4c0 10 20 10 20 20s-20 10-20 20" stroke="var(--grape)" stroke-width="4"/><path d="M34 4c0 10-20 10-20 20s20 10 20 20" stroke="var(--grape)" stroke-width="4"/><rect x="9" y="17" width="30" height="14" rx="4" fill="var(--sun)" fill-opacity=".85"/>',
 plasmid:'<circle cx="24" cy="24" r="15" stroke="var(--sky)" stroke-width="6"/><path d="M24 9a15 15 0 0 1 13 7.5" stroke="var(--tomato)" stroke-width="6"/><circle cx="24" cy="24" r="18"/><circle cx="24" cy="24" r="12"/>',
 chromo:'<path d="M13 7c7 7 7 27 0 34M35 7c-7 7-7 27 0 34" stroke="var(--grape)" stroke-width="8"/><circle cx="24" cy="24" r="4" fill="var(--sun)"/>',
 ribo:'<ellipse cx="24" cy="17" rx="15" ry="9" fill="var(--grape)"/><ellipse cx="24" cy="32" rx="11" ry="7" fill="var(--pink)"/><path d="M4 26h40" stroke="var(--tomato)" stroke-width="3"/>',
 golgi:'<path d="M8 12c10-5 22-5 32 0M10 20c9-4 19-4 28 0M12 28c8-3 16-3 24 0M14 36c7-3 13-3 20 0" stroke="var(--pink)" stroke-width="4.5"/><circle cx="42" cy="34" r="3.5" fill="var(--sun)"/>',
 mito:'<ellipse cx="24" cy="24" rx="20" ry="13" fill="var(--tomato)"/><path d="M8 24c3-8 5 8 8 0s5 8 8 0 5 8 8 0 5 8 8 0"/>',
 chloro:'<ellipse cx="24" cy="24" rx="20" ry="13" fill="var(--leaf)"/><g fill="var(--sun)"><rect x="11" y="16" width="7" height="16" rx="2"/><rect x="21" y="16" width="7" height="16" rx="2"/><rect x="31" y="16" width="7" height="16" rx="2"/></g>',
 nucleus:'<circle cx="24" cy="24" r="19" fill="var(--sky)"/><circle cx="24" cy="24" r="10" fill="var(--grape)"/><circle cx="27" cy="21" r="3" fill="var(--sun)"/>',
 cell:'<path d="M24 5c12 0 19 8 19 19s-8 19-19 19S5 36 5 24 12 5 24 5z" fill="var(--pink)"/><circle cx="22" cy="23" r="7" fill="var(--grape)"/><ellipse cx="35" cy="31" rx="4" ry="2.5" fill="var(--tomato)"/><circle cx="13" cy="32" r="2" fill="var(--sun)"/>',
 bact:'<rect x="6" y="15" width="32" height="18" rx="9" fill="var(--leaf)"/><path d="M38 24c4 0 3 6 7 6M38 20c3-4 6-2 7-6"/><path d="M14 22c3 4 9-4 12 0"/>',
 stem:'<circle cx="24" cy="24" r="10" fill="var(--sun)"/><path d="M24 14V5M34 24h9M24 34v9M14 24H5"/><circle cx="24" cy="5" r="3.5" fill="var(--tomato)"/><circle cx="43" cy="24" r="3.5" fill="var(--grape)"/><circle cx="24" cy="43" r="3.5" fill="var(--sky)"/><circle cx="5" cy="24" r="3.5" fill="var(--leaf)"/>',
 neuron:'<circle cx="16" cy="18" r="8" fill="var(--grape)"/><path d="M16 10V3M9 14 4 10M9 23l-5 4M22 23l18 17M30 31l4-3M36 37l4-3"/>',
 tissue:'<g fill="var(--pink)"><rect x="5" y="6" width="17" height="11" rx="3"/><rect x="26" y="6" width="17" height="11" rx="3"/><rect x="5" y="19" width="17" height="11" rx="3"/><rect x="26" y="19" width="17" height="11" rx="3"/><rect x="5" y="32" width="17" height="11" rx="3"/><rect x="26" y="32" width="17" height="11" rx="3"/></g><g fill="var(--grape)"><circle cx="13" cy="11.5" r="2"/><circle cx="34" cy="24.5" r="2"/><circle cx="13" cy="37.5" r="2"/></g>',
 organ:'<path d="M24 41S6 30 6 17a9 9 0 0 1 18-3 9 9 0 0 1 18 3c0 13-18 24-18 24z" fill="var(--tomato)"/>',
 system:'<path d="M18 6c-6 0-8 6-4 10s12 2 14 8-6 8-10 6-8 2-6 6 12 6 18 2" stroke="var(--pink)" stroke-width="5"/><path d="M18 6c-6 0-8 6-4 10s12 2 14 8-6 8-10 6-8 2-6 6 12 6 18 2"/>',
 person:'<circle cx="24" cy="12" r="7" fill="var(--sun)"/><path d="M10 43c0-11 6-19 14-19s14 8 14 19z" fill="var(--sky)"/>',
 pop:'<g fill="var(--sun)"><circle cx="12" cy="13" r="5"/><circle cx="36" cy="13" r="5"/><circle cx="24" cy="25" r="5"/></g><g fill="var(--sky)"><path d="M4 30c0-6 4-10 8-10s8 4 8 10zM28 30c0-6 4-10 8-10s8 4 8 10zM16 43c0-6 4-10 8-10s8 4 8 10z"/></g>',
 comm:'<circle cx="13" cy="16" r="6" fill="var(--sun)"/><path d="M4 36c0-7 4-12 9-12s9 5 9 12z" fill="var(--sky)"/><path d="M34 42V26"/><path d="M34 30c0-8-6-11-12-11 0 7 4 11 12 11z" fill="var(--leaf)"/><path d="M34 26c0-7 5-10 11-10 0 6-4 10-11 10z" fill="var(--leaf)"/>',
 eco:'<path d="M3 40c8-6 14-6 21 0s13 6 21 0" stroke="var(--sky)" stroke-width="4"/><path d="M14 34V20"/><path d="M14 24c-8 0-9-8-9-12 6 0 9 4 9 12z" fill="var(--leaf)"/><path d="M14 22c0-8 5-12 11-12 0 6-4 12-11 12z" fill="var(--leaf)"/><circle cx="37" cy="12" r="6" fill="var(--sun)"/>',
 globe:'<circle cx="24" cy="24" r="19" fill="var(--sky)"/><path d="M12 13c5 1 7 5 4 9s2 7 6 6 4 6 0 9M33 9c-3 4 0 7 4 7s6 4 4 8" fill="none"/><path d="M14 14c4 0 6 4 3 8s2 6 6 5 4 6 0 9c-6-1-13-8-13-16 0-3 1-5 4-6zM32 10c5 2 9 7 10 13-4 0-6-4-9-4s-5-6-1-9z" fill="var(--leaf)"/>',
 flask:'<path d="M18 6h12M20 6v12L9 37a4 4 0 0 0 3.5 6h23A4 4 0 0 0 39 37L28 18V6z" fill="var(--card)"/><path d="M14 30h20l5 7a4 4 0 0 1-3.5 6h-23A4 4 0 0 1 9 37z" fill="var(--pink)"/>',
 cap:'<path d="M3 18 24 9l21 9-21 9z" fill="var(--grape)"/><path d="M12 22v10c4 4 20 4 24 0V22" fill="var(--grape)"/><path d="M43 19v12"/><circle cx="43" cy="33" r="2.5" fill="var(--sun)"/>',
 scope:'<path d="M18 6l8 0 2 18h-12z" fill="var(--sky)"/><path d="M12 40h26M22 24v8M16 32h18c0-6-4-9-8-9" /><path d="M30 34a10 10 0 0 0 6-12"/><rect x="10" y="40" width="30" height="4" rx="2" fill="var(--grape)"/>',
 medal:'<path d="M15 4h8l3 14h-8zM33 4h-8l-3 14h8z" fill="var(--tomato)"/><circle cx="24" cy="31" r="12" fill="var(--sun)"/><path d="M24 24l2 4.5 5 .5-3.8 3.3 1.2 4.9L24 34.6l-4.4 2.6 1.2-4.9L17 29l5-.5z" fill="var(--card)"/>'
};
const lvArt=i=>`<svg class="ill" viewBox="0 0 48 48" aria-hidden="true">${LVA[LVD[Math.max(0,Math.min(LVD.length-1,i))][1]]}</svg>`;
LVN.length=0;LVD.forEach(x=>LVN.push(x[0]));
const LVMAX=LVD.length,lvNeed=lv=>200+(lv-1)*120,lvStart=lv=>{let s=0;for(let k=1;k<lv;k++)s+=lvNeed(k);return s};
level=function(xp){let lv=1,x=xp;while(lv<LVMAX&&x>=lvNeed(lv)){x-=lvNeed(lv);lv++}const max=lv>=LVMAX;return{lv:lv,name:LVN[lv-1],cur:max?lvNeed(lv):x,need:lvNeed(lv),xp:xp,max:max}};
try{LV=level(xpOf(bstats()))}catch(e){}
const _sky15=skyHero;
skyHero=function(){return _sky15().replace('data-v="badges">Lv','data-v="levels" aria-label="Your level. Tap to see the level journey">Lv')};
SUB.more.splice(SUB.more.findIndex(x=>x[0]==='badges')+1,0,['levels','Levels']);
EXT.levels=()=>{
  badgeCheck(true);const i=LV.lv-1,pct=LV.max?100:LV.cur/LV.need*100;
  let o=`<div class="card lvhero"><div class="row">${lvArt(i)}<div class="grow"><span class="pill">Level ${LV.lv} of ${LVMAX}</span><h1>${LV.name}</h1><p class="muted">${LVD[i][2]}</p></div></div>
  <div class="bar lvbar"><i style="width:${pct}%"></i></div><p class="muted">${LV.max?'You reached the top. Your ATP keeps counting.':`${LV.cur} of ${LV.need} ATP to <b>${LVN[LV.lv]}</b>`} · ${LV.xp} ATP in total</p></div>
  <div class="card"><h3>How you earn ATP</h3><div class="atpl">${[['Finish a task','5'],['10 minutes of focus','1'],['Daily challenge','15'],['Habit ticked','2'],['Prayer marked','1',1],['Glass of water','0.5'],['Badge earned','25']].filter(x=>!(x[2]&&S.settings.deenOff)).map(x=>`<span><b>+${x[1]}</b>${x[0]}</span>`).join('')}</div></div>
  <div class="card"><h2>Your journey</h2><div class="lvpath">`;
  LVD.forEach((d,k)=>{const n=k+1,st=n<LV.lv?'done':n===LV.lv?'now':'lock';
    o+=`<div class="lvstep ${st}"><span class="lvdot">${lvArt(k)}</span><div class="grow"><b>${n}. ${d[0]}</b>${st==='done'?' <span class="pill sm">Reached</span>':st==='now'?' <span class="pill sm">You are here</span>':''}<p class="muted">${st==='lock'&&n>LV.lv+1?'Unlocks at '+lvStart(n).toLocaleString()+' ATP':d[2]}</p></div></div>`});
  return o+`</div></div>`;
};

/* ---------- loader: DNA unzipping ---------- */
const dnaLoad=(t)=>`<div class="dnaload" role="status">${Array.from({length:8},(x,i)=>`<i style="--d:${i*-.15}s"></i>`).join('')}<span>${t}</span></div>`;
const _acc15=EXT.account;
EXT.account=()=>{let h=_acc15();if(fbState==='loading')h=h.replace('<p class="muted">Connecting…</p>',dnaLoad('Connecting…'));if(fbState==='syncing')h=h.replace('<p>Syncing…</p>',dnaLoad('Syncing…'));return h};

/* ---------- account: on sign-in, sign-out ---------- */
const _fbc15=fbConnect;
fbConnect=async function(u,c){await _fbc15(u,c);if(fbState==='on'&&!S.settings.acct){S.settings.acct=1;save('settings')}};
const _fbOff15=fbOff;
fbOff=function(){_fbOff15();if(S.settings.acct&&fbState==='ready'){S.settings.acct=0;save('settings')}};

/* ---------- first-run setup: account step ---------- */
OB.splice(1,0,{ill:'mail',c:'sky',t:'Keep your data safe',p:'A free Catalyst account saves everything online, so nothing is lost if you change or lose your phone. Catalyst still works offline.',acct:1});
const _obd15=obDraw;
obDraw=function(){
  if(!ob)return;const st=OB[ob.i];
  if(st.acct&&cloud==='on'){ob.i+=ob.back?-1:1;return obDraw()}
  _obd15();if(!st.acct||!ob.el.querySelector)return;
  const box=ob.el.querySelector('.obstep'),nav=ob.el.querySelector('.obnav'),v=ob.v,back=`<button class="btn" data-a="obBack">${ic('back')}Back</button>`,skip='<button class="btn" data-a="obAcctSkip">Skip for now</button>';
  let body='',btns='';
  if(fbUser&&!ob.busy){body=`<div class="card c-leaf"><span class="pill">Signed in</span><h3>${esc(fbUser.email||'')}</h3><p class="muted">Your data is syncing.</p></div>`;btns=back+'<button class="btn pri grow" data-a="obNext">Next</button>'}
  else if(ob.busy){body=dnaLoad(ob.am==='in'?'Bringing back your data…':'Creating your account…');btns=''}
  else if(fbState==='off'||fbState==='loading'){body=dnaLoad('Connecting…');btns=back+skip}
  else if(fbState==='unavailable'){body=`<p class="muted">You are offline right now. Skip for now and create your account later from More → Account. Catalyst will remind you.</p>`;btns=back+'<button class="btn" data-a="fbRetry">Try again</button>'+skip.replace('class="btn"','class="btn pri grow"')}
  else{const inn=ob.am==='in';
    body=`<div class="chips"><button class="chip${inn?'':' on'}" data-a="obAm" data-v="up">I am new</button><button class="chip${inn?' on':''}" data-a="obAm" data-v="in">I have an account</button></div>
    <label>Email<input data-ob="email" type="email" autocomplete="email" value="${esc(v.email||'')}"></label><label>${inn?'Password':'Choose a password (at least 6 characters)'}<input data-ob="pw" type="password" autocomplete="${inn?'current-password':'new-password'}" value="${esc(v.pw||'')}"></label>
    ${inn?'<p class="muted">Signing in brings back everything from your other phone.</p>':''}${inn?'<button class="btn sm" data-a="obForgot" style="align-self:flex-start">Forgot password</button>':''}`;
    btns=back+skip+`<button class="btn pri grow" data-a="obAcct">${inn?'Sign in':'Create account'}</button>`}
  const err=box.querySelector('[role="alert"]');box.insertAdjacentHTML('beforeend',body);if(err)box.appendChild(err);
  if(ob.note)box.insertAdjacentHTML('beforeend',`<p class="muted" role="status">${esc(ob.note)}</p>`);
  nav.innerHTML=btns;if(curLang()==='bn')bnNode(ob.el);
};
let obFs='';setInterval(()=>{if(ob&&OB[ob.i]&&OB[ob.i].acct&&!ob.busy){const k=fbState+(fbUser?1:0);if(k!==obFs){obFs=k;obDraw()}}},600);
Object.assign(A,{
  obAm(d){ob.am=d.v;ob.err='';ob.note='';obDraw()},
  obAcctSkip(){ob.err='';ob.note='';ob.back=false;ob.i++;obDraw()},
  obForgot(){const e=String(ob.v.email||'').trim();if(!e){ob.err='Type your email first.';obDraw();return}window.firebase.auth().sendPasswordResetEmail(e).then(()=>{ob.err='';ob.note='Check your email for a link to set a new password.';obDraw()},x=>{ob.err=fbMsg(x);obDraw()})},
  obAcct(){
    const e=String(ob.v.email||'').trim(),p=String(ob.v.pw||''),inn=ob.am==='in';
    if(!e||!p){ob.err='Type your email and a password.';obDraw();return}
    ob.err='';ob.note='';ob.busy=1;obDraw();const au=window.firebase.auth();
    (inn?au.signInWithEmailAndPassword(e,p):au.createUserWithEmailAndPassword(e,p)).then(()=>{
      const t0=Date.now();(function w(){
        if(fbState!=='on'&&fbState!=='error'&&Date.now()-t0<20000)return setTimeout(w,300);
        if(!ob){celebrate('Welcome back'+(S.settings.name?', '+S.settings.name:''));return}
        ob.busy=0;ob.v.pw='';const s=S.settings;
        if(inn&&s.setup){ob.el.remove();ob=null;render();celebrate('Welcome back'+(s.name?', '+s.name:''));return}
        if(inn)Object.assign(ob.v,{name:s.name||ob.v.name,dob:s.dob||ob.v.dob});
        ob.back=false;ob.i++;obDraw();
      })();
    },x=>{ob.busy=0;ob.err=fbMsg(x);obDraw()});
  }
});

/* ---------- sign-up reminders until an account exists ---------- */
const ACCN=['Your Catalyst data is saved on this phone only. Create a free account so you keep it when you change phones.','Back up your streak, notes and study history. Create your free Catalyst account in More → Account.','If you lose this phone, your Catalyst data goes with it. A free account keeps it safe.'];
const needAcct=()=>S.settings.setup&&!S.settings.acct&&cloud!=='on'&&cloud!=='fb';
const _ag15=agenda;
agenda=function(ds){const a=_ag15(ds);if(needAcct()&&DAY0(ds)%2===0){a.push({t:'20:30',title:ACCN[Math.floor(DAY0(ds)/2)%ACCN.length],src:'Nudge',key:'acct-'+ds});a.sort((x,y)=>x.t<y.t?-1:1)}return a};
const _nud15=nudges;
nudges=function(){const a=_nud15();if(needAcct()&&!a.some(x=>x.k==='acct')){const dis=S.settings.nd&&S.settings.nd.d===today()?S.settings.nd.k||{}:{};if(!dis.acct)a.push({k:'acct',t:'Your data is on this phone only. Create a free Catalyst account so you don’t lose it when you switch phones.',go:['more','more','account']})}return a};

/* ---------- PCR focus timer ---------- */
const PCRP=[['Denature','95 °C','The strands separate','den'],['Anneal','55 °C','Primers bind','ann'],['Extend','72 °C','Polymerase copies the strand','ext']];
function pcrPhase(){if(T.mode!=='focus')return['Hold','4 °C','Break time. The sample rests.','hold'];const f=1-tLeft()/Math.max(1,tFull());return PCRP[Math.min(2,Math.floor(f*3))]}
const wkKey=d=>Math.floor((DAY0(d)-2)/7);
const pcrWeeks=()=>{const w={};S.focus.forEach(f=>{if((+f.min||0)>=10){const k=wkKey(f.date);w[k]=(w[k]||0)+1}});return w};
const big2=n=>{const v=Math.pow(2,n);return v<1e3?String(v):v<1e6?(v/1e3).toFixed(v<1e4?1:0)+' thousand':v<1e9?(v/1e6).toFixed(v<1e7?1:0)+' million':v<1e12?(v/1e9).toFixed(v<1e10?1:0)+' billion':'over a trillion'};
function pcrCard(){
  const p=pcrPhase(),w=pcrWeeks(),n=w[wkKey(today())]||0,tot=S.focus.filter(f=>(+f.min||0)>=10).length;
  return`<div class="card pcr"><div class="row between"><h2>PCR mode</h2><span class="pill">${n} / 30 cycles this week</span></div>
  <div class="pcrbox ph-${p[3]}${T.running?' run':''}" id="pcrbox"><svg viewBox="0 0 200 54" aria-hidden="true"><g class="s1"><path d="M10 20h180" stroke="var(--grape)" stroke-width="4" stroke-linecap="round"/></g><g class="s2"><path d="M10 34h180" stroke="var(--sun)" stroke-width="4" stroke-linecap="round"/></g><g class="pr"><path d="M30 28h26" stroke="var(--tomato)" stroke-width="4" stroke-linecap="round"/></g><g class="nw"><path d="M56 28h120" stroke="var(--leaf)" stroke-width="4" stroke-linecap="round"/></g><g class="rungs">${Array.from({length:12},(x,i)=>`<path d="M${18+i*15} 22v10" stroke="var(--line)" stroke-width="2" stroke-linecap="round"/>`).join('')}</g></svg>
  <div class="row between"><b id="pcrph">${p[0]} · ${p[1]}</b><span class="muted" id="pcrtx">${p[2]}</span></div></div>
  <p class="muted">Each focus session of 10 minutes or more is one PCR cycle. Every cycle doubles your DNA: ${n} cycle${n===1?'':'s'} this week makes ${big2(n)} copies. ${tot} cycles so far.</p></div>`;
}
setInterval(()=>{const b=document.getElementById('pcrbox');if(!b)return;const p=pcrPhase(),h=document.getElementById('pcrph'),t=document.getElementById('pcrtx');b.className='pcrbox ph-'+p[3]+(T.running?' run':'');if(h)h.textContent=p[0]+' · '+p[1];if(t)t.textContent=p[2];if(curLang()==='bn')bnNode(b)},1000);
const _tim15=EXT.timer;EXT.timer=()=>pcrCard()+_tim15();

/* ---------- habits as a metabolic pathway ---------- */
const allHab=d=>S.habits.length&&S.habits.every(h=>(S.habitLog[d]||{})[h.id]);
function pathCard(){
  if(!S.habits.length)return'';const t=today(),l=S.habitLog[t]||{},n=S.habits.filter(h=>l[h.id]).length,all=n===S.habits.length;
  return`<div class="card pathway${all?' full':''}"><div class="row between"><h2>Today’s pathway</h2><span class="pill">${n} of ${S.habits.length} steps</span></div>
  <div class="pw"><span class="pwn sub">Start</span>${S.habits.map((h,i)=>`<span class="pwa${l[h.id]?' on':''}"></span><button class="pwn${l[h.id]?' on':''}" data-a="hDay" data-id="${h.id}" data-d="${t}"><small>Enzyme ${i+1}</small>${esc(h.name)}</button>`).join('')}<span class="pwa${all?' on':''}"></span><span class="pwn prod${all?' on':''}">${all?'ATP made':'Product'}</span></div>
  <p class="muted">Each habit is one enzyme step. Tick them all and the whole pathway lights up.</p></div>`;
}
const _hab15=EXT.habits;EXT.habits=()=>pathCard()+_hab15();
const _hDay15=A.hDay;A.hDay=function(d){const was=allHab(d.d);_hDay15(d);if(!was&&allHab(d.d)&&d.d===today())setTimeout(()=>celebrate('Pathway complete. Every habit done today'),250)};

/* ---------- Krebs cycle: goal days ---------- */
const KREBS=[['Citrate','Cit'],['Isocitrate','Iso'],['α-Ketoglutarate','αKG'],['Succinyl-CoA','SCoA'],['Succinate','Suc'],['Fumarate','Fum'],['Malate','Mal'],['Oxaloacetate','OAA']];
function goalParts(d){
  const fm=S.focus.filter(f=>f.date===d).reduce((a,f)=>a+(+f.min||0),0),s=S.settings,p=[
   ['Water goal',(S.water[d]||0)>=s.waterGoal],['25 minutes of focus',fm>=25],['A task finished',S.tasks.some(x=>x.done&&x.doneAt===d)]];
  if(S.habits.length)p.push(['All habits',!!allHab(d)]);
  if(!s.deenOff)p.push(['All five prayers',PR.every(q=>(S.prayers[d]||{})[q[0]])]);
  return p;
}
const goalDay=d=>goalParts(d).filter(x=>x[1]).length>=3;
const goalDays=n=>{const o=[];for(let i=n-1;i>=0;i--){const d=addDays(today(),-i);if(goalDay(d))o.push(d)}return o};
function krebsCard(){
  const days=[];for(let i=7;i>=0;i--)days.push(addDays(today(),-i));const lit=days.filter(goalDay).length,full=lit===8,gp=goalParts(today());
  const cx=60,cy=60,r=42,nodes=KREBS.map((k,i)=>{const a=-Math.PI/2+i*Math.PI/4,x=cx+r*Math.cos(a),y=cy+r*Math.sin(a),on=i<lit;return`<g class="kn${on?' on':''}" style="--i:${i}"><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="11"/><text x="${x.toFixed(1)}" y="${(y+3).toFixed(1)}">${k[1]}</text></g>`}).join('');
  return`<div class="card krebs${full?' full':''}"><div class="row"><svg viewBox="0 0 120 120" class="kc" role="img" aria-label="Krebs cycle, ${lit} of 8 steps"><circle cx="60" cy="60" r="42" class="kring"/><path class="kprog" d="M60 18a42 42 0 1 1 -0.01 0" style="stroke-dasharray:${(lit/8*264).toFixed(1)} 264"/>${nodes}<text x="60" y="58" class="kt">${lit}/8</text><text x="60" y="70" class="ks">steps</text></svg>
  <div class="grow"><span class="pill">Krebs cycle</span><h3>${full?'Full turn. Brilliant.':KREBS[Math.max(0,lit-1)][0]+(lit?'':' next')}</h3><p class="muted">Each goal day in the last 8 days adds one step. Meet 3 goals in a day to count it.</p></div></div>
  <div class="kgoals">${gp.map(x=>`<span class="${x[1]?'on':''}">${x[1]?'✓ ':''}${x[0]}</span>`).join('')}</div></div>`;
}

/* ---------- daily lab term ---------- */
const TERMS=[
 ['Molarity','Moles of solute per litre of solution (mol/L).'],['Buffer','A solution that resists change in pH when a little acid or base is added.'],['pKa','The pH at which an acid is half dissociated.'],
 ['Km','The substrate concentration at which an enzyme works at half its maximum speed.'],['Vmax','The fastest rate an enzyme reaches when fully saturated with substrate.'],['Isoelectric point (pI)','The pH at which a molecule carries no net charge.'],
 ['Denaturation','Loss of a protein’s shape, and so its function, by heat, pH or chemicals.'],['Primer','A short DNA strand that gives polymerase a starting point.'],['Annealing','Primers binding to their matching template sequence as the temperature drops.'],
 ['Gel electrophoresis','Separating DNA or proteins by size as they move through a gel in an electric field.'],['SDS-PAGE','Electrophoresis that separates proteins by mass after SDS unfolds them.'],['Western blot','Detecting one protein with an antibody after separating proteins on a gel.'],
 ['ELISA','An antibody test that detects a molecule through a colour change.'],['Centrifugation','Spinning samples so denser parts settle at the bottom.'],['Supernatant','The liquid above the pellet after centrifugation.'],
 ['Aseptic technique','Working in a way that keeps cultures free of contamination.'],['Autoclave','Sterilises with steam at 121 °C under pressure, usually for 15 minutes or more.'],['CFU','Colony-forming unit: an estimate of living microbes in a sample.'],
 ['Serial dilution','Diluting a sample step by step by the same factor, often 10-fold.'],['Absorbance','How much light a sample absorbs. Used with Beer–Lambert law to find concentration.'],['Beer–Lambert law','A = εcl. Absorbance rises in step with concentration and path length.'],
 ['Spectrophotometer','An instrument that measures how much light a sample absorbs at a chosen wavelength.'],['Restriction enzyme','An enzyme that cuts DNA at a specific short sequence.'],['Ligase','An enzyme that joins DNA fragments together.'],
 ['Plasmid vector','A DNA ring used to carry a gene into a host cell.'],['Transformation','Getting a cell to take up foreign DNA.'],['Transfection','Delivering nucleic acids into animal cells.'],
 ['Competent cells','Cells treated so they take up DNA easily.'],['Housekeeping gene','A gene expressed steadily in most cells, used as a reference.'],['Ct value','The qPCR cycle at which signal crosses the threshold. Lower Ct, more target.'],
 ['Allosteric site','A site away from the active site where a molecule changes enzyme activity.'],['Competitive inhibitor','Competes with substrate for the active site. Raises apparent Km.'],['Coenzyme','A small organic helper molecule an enzyme needs, often made from a vitamin.'],
 ['Oxidative phosphorylation','Making ATP using energy from the electron transport chain.'],['Glycolysis','Splitting glucose into two pyruvate, with a net gain of 2 ATP.'],['Gluconeogenesis','Making new glucose from non-sugar sources such as lactate and amino acids.'],
 ['β-oxidation','Breaking fatty acids into acetyl-CoA, two carbons at a time.'],['Transamination','Moving an amino group from an amino acid to a keto acid.'],['Hydrophobic effect','Non-polar parts cluster together in water. It drives protein folding.'],
 ['Chromatography','Separating mixtures by how strongly each part sticks to a stationary phase.'],['Rf value','Distance moved by a spot divided by distance moved by the solvent.'],['Standard curve','A graph from known concentrations used to find unknown ones.'],
 ['Negative control','A sample expected to give no result. It shows the test is not giving false positives.'],['Positive control','A sample expected to give a result. It shows the test works.'],['Replicate','Repeating a measurement to check how consistent results are.'],
 ['Standard deviation','How spread out values are around the mean.'],['Lyophilisation','Freeze-drying: removing water by freezing then lowering pressure.'],['Bioreactor','A vessel that grows cells or microbes under controlled conditions.'],
 ['CRISPR-Cas9','A guide RNA leads the Cas9 enzyme to cut DNA at a chosen site.'],['Recombinant protein','A protein made from a gene put into another organism, such as insulin in E. coli.']
];
function termCard(){const x=TERMS[(DAY0(today())*3+1)%TERMS.length];return`<div class="card term"><span class="pill">Lab term of the day</span><h3>${esc(x[0])}</h3><p>${esc(x[1])}</p></div>`}

/* ---------- home ---------- */
const _today15=VIEWS.today;
VIEWS.today=()=>{const h=_today15();if(h.indexOf('class="card examday"')>=0&&!ui.examFull)return h;return h+krebsCard()+termCard()};
/* hero: more floating molecules */
const _sky15b=skyHero;
skyHero=function(){const mol=`<g class="mol" style="animation-delay:-2s" transform="translate(196 18) scale(.75)"><path d="M0 12 10 4l10 8" stroke="#fff" stroke-opacity=".5" stroke-width="1.6" fill="none"/><circle cx="10" cy="4" r="4.2" fill="#fff" fill-opacity=".45"/><circle cx="0" cy="12" r="2.6" fill="#fff" fill-opacity=".4"/><circle cx="20" cy="12" r="2.6" fill="#fff" fill-opacity=".4"/></g><g class="mol" style="animation-delay:-5s" transform="translate(150 40) scale(.6)"><path d="M0 10h10l6-8M10 10l6 8M16 18h10" stroke="#fff" stroke-opacity=".45" stroke-width="1.8" fill="none"/><circle cx="0" cy="10" r="3" fill="#fff" fill-opacity=".4"/><circle cx="16" cy="2" r="3" fill="#fff" fill-opacity=".4"/><circle cx="26" cy="18" r="3" fill="#fff" fill-opacity=".4"/></g>`;
  return _sky15b().replace('<rect width="360" height="150" fill="url(#skg)"/>','<rect width="360" height="150" fill="url(#skg)"/>'+mol)};

/* ---------- sleep: circadian clock ---------- */
function circCard(){
  const s=S.settings,b=toMin(s.sleepBed),w=toMin(s.sleepWake),n=nowMin(),R=46,C=60,pt=(m,r)=>{const a=m/1440*2*Math.PI-Math.PI/2;return[(C+r*Math.cos(a)).toFixed(1),(C+r*Math.sin(a)).toFixed(1)]};
  const len=(w-b+1440)%1440,big=len>720?1:0,p0=pt(b,R),p1=pt(w,R),mk=(m,c,l)=>{const p=pt(m,R);return`<circle cx="${p[0]}" cy="${p[1]}" r="4.5" fill="var(--${c})" stroke="var(--line)" stroke-width="1.5"><title>${l}</title></circle>`},hn=pt(n,R-12);
  const tick=[0,6,12,18].map(h=>{const p=pt(h*60,R+9);return`<text x="${p[0]}" y="${(+p[1]+3).toFixed(1)}">${h===0?'12a':h===12?'12p':h<12?h+'a':(h-12)+'p'}</text>`}).join('');
  const mel=(b-120+1440)%1440,cor=(w+40)%1440,dip=13*60+30;
  return`<div class="card circ"><div class="row"><svg viewBox="0 0 120 120" class="cc" role="img" aria-label="24 hour body clock"><circle cx="60" cy="60" r="${R}" class="cring"/><path d="M${p0[0]} ${p0[1]}A${R} ${R} 0 ${big} 1 ${p1[0]} ${p1[1]}" class="csleep"/>${tick}${mk(mel,'grape','Melatonin rises')}${mk(cor,'sun','Cortisol peak')}${mk(dip,'sky','Afternoon dip')}<path d="M60 60L${hn[0]} ${hn[1]}" class="chand"/><circle cx="60" cy="60" r="3.5" fill="var(--line)"/></svg>
  <div class="grow"><span class="pill">Body clock</span><h3>${n>=mel&&(n<b||b<mel)?'Melatonin is rising. Dim the lights.':'Sleep window '+tfmt(s.sleepBed)+' to '+tfmt(s.sleepWake)}</h3><div class="clegend"><span><i style="background:var(--grape)"></i>Melatonin rises · ${tfmt(hm(mel))}</span><span><i style="background:var(--sun)"></i>Cortisol peak · ${tfmt(hm(cor))}</span><span><i style="background:var(--sky)"></i>Afternoon dip · ${tfmt(hm(dip))}</span></div></div></div>
  <p class="muted">Going to bed and waking at the same times, even on weekends, keeps your circadian clock steady. Morning daylight helps reset it.</p></div>`;
}
const _slp15=EXT.sleep;EXT.sleep=()=>circCard()+_slp15();

/* ---------- scientist badges ---------- */
const pathDays=()=>Object.keys(S.habitLog).filter(d=>allHab(d)).length;
BADGES.push(
 ['sanger','Sanger','Finish 50 tasks. Fred Sanger sequenced insulin and DNA, winning two Nobel Prizes.','tasks','tomato',s=>[s.tasks,50]],
 ['franklin','Franklin','Study for 25 hours. Rosalind Franklin’s X-ray images revealed DNA’s helix.','book','grape',s=>[Math.floor(s.focusH),25]],
 ['krebs','Krebs','Complete a full Krebs cycle: 8 goal days in a row. Hans Krebs mapped the cycle.','medal','sun',s=>[runMax(goalDays(400)),8]],
 ['mullis','Mullis','Run 30 PCR cycles in one week. Kary Mullis invented PCR.','timer','pink',s=>[Math.max(0,...Object.values(pcrWeeks())),30]],
 ['menten','Michaelis–Menten','Complete your whole habit pathway on 7 days. Maud Menten co-wrote enzyme kinetics.','sprout','leaf',s=>[pathDays(),7]],
 ['pauling','Pauling','Reach level 11, Protein. Linus Pauling found the α-helix.','flask','grape',s=>[LV.lv,11]],
 ['mcclintock','McClintock','Write 20 notes. Barbara McClintock discovered jumping genes.','book','sky',s=>[S.notes.length,20]],
 ['hodgkin','Hodgkin','Log sleep on 30 nights. Dorothy Hodgkin solved the structures of penicillin and vitamin B12.','moon','grape',s=>[S.sleep.length,30]],
 ['bose','J. C. Bose','Meet your water goal on 30 days. Jagadish Chandra Bose, born in Bengal, measured how plants respond.','drop','sky',s=>[Object.keys(S.water).filter(d=>(S.water[d]||0)>=S.settings.waterGoal).length,30]],
 ['khorana','Khorana','Save 25 citations. Har Gobind Khorana helped crack the genetic code.','book','sun',s=>[s.cites,25]]
);

/* ---------- little reactions: enzyme on task done, pipette on water ---------- */
function fx(x,y,cls,html,ms){if(S.settings.motion==='off')return;const b=document.createElement('div');b.className='fx '+cls;b.style.left=x+'px';b.style.top=y+'px';b.innerHTML=html;document.body.appendChild(b);setTimeout(()=>b.remove(),ms)}
document.addEventListener('click',e=>{
  const el=e.target.closest&&e.target.closest('[data-a]');if(!el||!e.clientX)return;const a=el.dataset.a;
  if(a==='tTog'){const t=S.tasks.find(x=>x.id===el.dataset.id);if(t&&!t.done)fx(e.clientX,e.clientY,'fxenz','<svg viewBox="0 0 60 40" aria-hidden="true"><circle class="sub" cx="50" cy="20" r="6" fill="var(--sun)" stroke="var(--line)" stroke-width="2"/><g class="enz"><path class="top" d="M20 20 34 10A16 16 0 0 0 4 20z" fill="var(--grape)" stroke="var(--line)" stroke-width="2" stroke-linejoin="round"/><path class="bot" d="M20 20 34 30A16 16 0 0 1 4 20z" fill="var(--grape)" stroke="var(--line)" stroke-width="2" stroke-linejoin="round"/></g><circle class="p1" cx="20" cy="20" r="4" fill="var(--leaf)"/><circle class="p2" cx="20" cy="20" r="4" fill="var(--tomato)"/></svg>',1300)}
  if(a==='water'&&+(el.dataset.n||1)>0)fx(e.clientX,e.clientY,'fxpip','<svg viewBox="0 0 30 70" aria-hidden="true"><g class="pip"><rect x="11" y="2" width="8" height="14" rx="3" fill="var(--grape)" stroke="var(--line)" stroke-width="2"/><path d="M12 16h6l-1 22-2 6-2-6z" fill="var(--card)" stroke="var(--line)" stroke-width="2" stroke-linejoin="round"/></g><path class="drop" d="M15 46c3 4 4 6 4 8a4 4 0 0 1-8 0c0-2 1-4 4-8z" fill="var(--sky)" stroke="var(--line)" stroke-width="1.5"/><ellipse class="rip" cx="15" cy="66" rx="9" ry="2.5" fill="none" stroke="var(--sky)" stroke-width="2"/></svg>',1100);
},true);

/* ---------- Bangla ---------- */
Object.assign(BN,{'Levels':'লেভেল','Your journey':'আপনার যাত্রা','How you earn ATP':'কীভাবে ATP পাবেন','Reached':'পৌঁছেছেন','You are here':'আপনি এখানে','Finish a task':'একটি কাজ শেষ','10 minutes of focus':'১০ মিনিট মনোযোগ','Daily challenge':'আজকের চ্যালেঞ্জ','Habit ticked':'অভ্যাস পূরণ','Prayer marked':'নামাজ চিহ্নিত','Glass of water':'এক গ্লাস পানি','Badge earned':'ব্যাজ অর্জন',
 'I am new':'আমি নতুন','I have an account':'আমার অ্যাকাউন্ট আছে','Skip for now':'এখন বাদ দিন','Create account':'অ্যাকাউন্ট খুলুন','Connecting…':'সংযোগ হচ্ছে…','Creating your account…':'অ্যাকাউন্ট খোলা হচ্ছে…','Bringing back your data…':'আপনার ডেটা ফিরিয়ে আনা হচ্ছে…','Next':'পরবর্তী',
 'PCR mode':'PCR মোড','Today’s pathway':'আজকের pathway','Body clock':'দেহঘড়ি','Lab term of the day':'আজকের ল্যাব টার্ম','Krebs cycle':'Krebs cycle','Water goal':'পানির লক্ষ্য','25 minutes of focus':'২৫ মিনিট মনোযোগ','A task finished':'একটি কাজ শেষ','All habits':'সব অভ্যাস','All five prayers':'পাঁচ ওয়াক্ত নামাজ','Start':'শুরু','Product':'Product','ATP made':'ATP তৈরি'});
BNP.push([/^(\d+) \/ 30 cycles this week$/,'এই সপ্তাহে $1 / ৩০ cycle'],[/^(\d+) of (\d+) steps$/,'$2টির মধ্যে $1টি ধাপ'],[/^Level (\d+) of (\d+)$/,'লেভেল $1 / $2']);
window.__v15={ag:d=>agenda(d),nb:()=>BADGES.length,dd:()=>drawDrawer(),level:x=>level(x),krebs:()=>krebsCard(),pcr:()=>pcrCard(),path:()=>pathCard(),circ:()=>circCard(),term:()=>termCard(),goalParts:goalParts,needAcct:needAcct};


/* ================= v16: swipe tabs, chip hints, faster forms, one-line add, notification actions, widget, weekly review, tips ================= */

/* ---------- swipe between bottom tabs ---------- */
function swBlocked(el){
  if(!el||!el.closest)return true;
  if(el.closest('input,textarea,select,canvas,.chips,.chipw,.tlcard,.heat,.pw,[data-noswipe],#sheet,#drawer,#onb,#revx,#tut,#wrapx,#alarmx'))return true;
  for(let n=el;n&&n.id!=='view'&&n!==document.body;n=n.parentElement){if(n.scrollWidth>n.clientWidth+2){const o=getComputedStyle(n).overflowX;if(o==='auto'||o==='scroll')return true}}
  return !el.closest('#view');
}
let sw=null,swBusy=false;
const navTabs=()=>[...document.querySelectorAll('#nav [data-tab]')].map(b=>b.dataset.tab);
const swStyle=(v,x,o,tr)=>{v.style.transition=tr||'none';v.style.transform=x?`translate3d(${x}px,0,0)`:'';v.style.opacity=o==null?'':o};
document.addEventListener('touchstart',e=>{
  sw=null;if(swBusy||e.touches.length!==1||swBlocked(e.target)||document.body.classList.contains('dopen')||document.querySelector('#shade.open'))return;
  const t=e.touches[0];sw={x:t.clientX,y:t.clientY,t:Date.now(),mode:0,dx:0};
},{passive:true});
document.addEventListener('touchmove',e=>{
  if(!sw||e.touches.length!==1)return;const t=e.touches[0],dx=t.clientX-sw.x,dy=t.clientY-sw.y,v=$('#view');if(!v)return;
  if(!sw.mode){if(Math.abs(dx)<12&&Math.abs(dy)<12)return;sw.mode=Math.abs(dx)>Math.abs(dy)*1.3?1:-1;if(sw.mode===1){sw.tabs=navTabs();sw.i=sw.tabs.indexOf(ui.tab);v.classList.remove('enter','swl','swr');v.style.willChange='transform,opacity'}}
  if(sw.mode!==1)return;
  const edge=(dx>0&&sw.i<=0)||(dx<0&&sw.i>=sw.tabs.length-1),x=edge?dx*.22:dx;sw.dx=dx;sw.edge=edge;
  swStyle(v,x,1-Math.min(.4,Math.abs(x)/innerWidth*.7));
},{passive:true});
function swEnd(){
  const s=sw;sw=null;const v=$('#view');if(!s||s.mode!==1||!v)return;
  const w=innerWidth,dt=Date.now()-s.t,go=!s.edge&&(Math.abs(s.dx)>w*.25||(Math.abs(s.dx)>45&&dt<260));
  if(!go){swStyle(v,0,1,'transform .22s cubic-bezier(.2,.8,.3,1),opacity .22s');setTimeout(()=>{v.style.transition='';v.style.willChange=''},240);return}
  const dir=s.dx<0?1:-1,next=s.tabs[s.i+dir],still=S.settings.motion==='off';swBusy=true;
  swStyle(v,-dir*w*.45,0,still?'none':'transform .16s ease-in,opacity .16s ease-in');
  setTimeout(()=>{
    A.tab({tab:next});v.classList.remove('enter','sr');
    swStyle(v,dir*w*.3,0);void v.offsetWidth;
    requestAnimationFrame(()=>{swStyle(v,0,1,still?'none':'transform .26s cubic-bezier(.2,.8,.3,1),opacity .22s');setTimeout(()=>{v.style.transition='';v.style.transform='';v.style.opacity='';v.style.willChange='';swBusy=false},280)});
  },still?0:150);
}
document.addEventListener('touchend',swEnd,{passive:true});
document.addEventListener('touchcancel',swEnd,{passive:true});

/* ---------- category chips: show there is more to the right ---------- */
const chipSeen={};
function chipHints(){
  document.querySelectorAll('#view .chips').forEach(c=>{
    if(c.scrollWidth<=c.clientWidth+8)return;
    let w=c.parentElement;
    if(!w.classList.contains('chipw')){w=document.createElement('div');w.className='chipw';c.parentNode.insertBefore(w,c);w.appendChild(c);w.insertAdjacentHTML('beforeend','<button class="chipnav prev" aria-label="Show earlier options" tabindex="-1">‹</button><button class="chipnav next" aria-label="Show more options">›</button>');c.addEventListener('scroll',()=>chipEdge(w,c),{passive:true})}
    const on=c.querySelector('.chip.on');
    if(on){c.style.scrollBehavior='auto';c.scrollLeft=Math.max(0,on.offsetLeft-c.offsetLeft-(c.clientWidth-on.offsetWidth)/2);c.style.scrollBehavior=''}
    chipEdge(w,c);
    const k=ui.tab+'/'+(c.querySelector('[data-k]')||{dataset:{}}).dataset.k;
    if(!chipSeen[k]&&S.settings.motion!=='off'){chipSeen[k]=1;setTimeout(()=>{if(c.scrollLeft<4){c.scrollTo({left:56,behavior:'smooth'});setTimeout(()=>c.scrollTo({left:0,behavior:'smooth'}),520)}},450)}
  });
}
function chipEdge(w,c){w.classList.toggle('atstart',c.scrollLeft<6);w.classList.toggle('atend',c.scrollLeft+c.clientWidth>=c.scrollWidth-6)}
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('.chipnav');if(!b)return;const c=b.parentElement.querySelector('.chips');if(c)c.scrollBy({left:(b.classList.contains('next')?1:-1)*c.clientWidth*.7,behavior:'smooth'})});

/* ---------- faster forms ---------- */
const QAMT=[20,50,100,200,500,1000];
const fmem=()=>S.settings.fmem||(S.settings.fmem={});
const recKey=t=>'catalyst.recent.'+t;
const recGet=t=>{try{return JSON.parse(localStorage.getItem(recKey(t))||'[]')||[]}catch(e){return[]}};
const optsOf=f=>((f[3]||{}).opts||[]).map(o=>Array.isArray(o)?o:[o,o]);
const isAmt=k=>/^(amount|cost|target|saved|price|income|budget)$/.test(k);
function recLabel(f,r){const tx=f.find(x=>(x[2]||'text')==='text'&&r[x[0]]),am=f.find(x=>isAmt(x[0])&&r[x[0]]);return[tx?String(r[tx[0]]).slice(0,22):'',am?money(+r[am[0]]):''].filter(Boolean).join(' · ')}
form=function(title,fields,val,onSave,onDel){
  const isNew=!onDel&&!(val&&val.id),mem=isNew?(fmem()[title]||{}):{};
  F={fields:fields,onSave:onSave,onDel:onDel,armed:false,args:[title,fields,val,onSave,onDel],title:title,isNew:isNew};
  val=Object.assign({},val||{});
  fields.forEach(f=>{const k=f[0];if(isNew&&f[2]==='select'&&(val[k]==null||val[k]==='')&&mem[k]!=null&&optsOf(f).some(a=>String(a[0])===String(mem[k])))val[k]=mem[k]});
  const rec=isNew?recGet(title).filter(r=>recLabel(fields,r)):[],dIn=n=>addDays(today(),n),soon=hm(Math.min(1435,Math.ceil((nowMin()+60)/5)*5));
  const qc=(k,v,l,on)=>`<button type="button" class="qc${on?' on':''}" data-a="fSet" data-k="${k}" data-v="${esc(v)}">${l}</button>`;
  $('#sheet').innerHTML=`<div class="fhead"><span class="fgrab"></span><div class="row between"><h2>${title}</h2><button class="btn sm" data-a="close">Close</button></div></div>`+
   (rec.length?`<div class="frec"><span class="muted">Recent</span><div class="qcs">${rec.map((r,i)=>`<button type="button" class="qc rec" data-a="fRecent" data-i="${i}">${esc(recLabel(fields,r))}</button>`).join('')}</div></div>`:'')+
   `<form id="f" novalidate>`+fields.map(f=>{
    const k=f[0],type=f[2]||'text',x=f[3]||{},v=val[k]==null?'':val[k];let inp,extra='';
    if(type==='select'){const o=optsOf(f),chips=o.length>1&&((o.length<=8&&o.every(a=>String(a[1]).length<=24))||(o.length<=16&&o.every(a=>String(a[1]).length<=6)));
      inp='<select id="f_'+k+'"'+(chips?' class="fhide" tabindex="-1" aria-hidden="true"':'')+'>'+o.map(a=>'<option value="'+esc(a[0])+'"'+(String(v)===String(a[0])?' selected':'')+'>'+esc(a[1])+'</option>').join('')+'</select>';
      if(chips){const cur=v===''&&o.length?String(o[0][0]):String(v);extra=`<div class="qcs big">${o.map(a=>qc(k,a[0],a[1]===''?'None':esc(a[1]),String(a[0])===cur)).join('')}</div>`}}
    else if(type==='textarea')inp='<textarea id="f_'+k+'" placeholder="'+esc(x.ph||'')+'"'+(x.tall?' style="min-height:220px"':'')+'>'+esc(v)+'</textarea>';
    else{inp='<input id="f_'+k+'" type="'+type+'" value="'+esc(v)+'" placeholder="'+esc(x.ph||'')+'"'+(type==='number'?' inputmode="decimal" step="any" min="0"':'')+(type==='email'?' autocomplete="email"':'')+'>';
      if(type==='date')extra=`<div class="qcs">${[[dIn(0),'Today'],[dIn(1),'Tomorrow'],[dIn(2),'In 2 days'],[dIn(7),'Next week']].map(a=>qc(k,a[0],a[1],String(v)===a[0])).join('')}</div>`;
      else if(type==='time')extra=`<div class="qcs">${[[hm(Math.floor(nowMin()/5)*5),'Now'],[soon,'In 1 hour'],['08:00','8 AM'],['14:00','2 PM'],['20:00','8 PM']].map(a=>qc(k,a[0],a[1],String(v)===a[0])).join('')}</div>`;
      else if(type==='number'&&isAmt(k))extra=`<div class="qcs">${QAMT.map(n=>qc(k,n,money(n),+v===n)).join('')}</div>`}
    return'<label class="fld"><span>'+f[1]+(x.req?' <span class="req">*</span>':'')+'</span>'+inp+'</label>'+extra;
   }).join('')+`<p class="muted" id="ferr" style="color:var(--bad)" role="alert"></p><div class="fbar">${onDel?'<button type="button" class="btn danger" data-a="del">Delete</button>':''}${isNew?'<button type="button" class="btn" data-a="fAgain">Save and add another</button>':''}<button class="btn pri grow">Save</button></div></form>`;
  $('#shade').classList.add('open');
  const first=$('#sheet input:not([type=date]):not([type=time]),#sheet textarea');if(first&&!val.id&&!rec.length)setTimeout(()=>{try{first.focus()}catch(e){}},60);
  if(curLang()==='bn')bnNode($('#sheet'));
};
const _sub16=submitForm;
submitForm=function(){
  if(!F)return;const info={title:F.title,isNew:F.isNew,again:F.again,args:F.args,fields:F.fields},vals={};F.again=0;
  info.fields.forEach(f=>{const el=document.getElementById('f_'+f[0]);if(el)vals[f[0]]=el.value});
  _sub16();if(F)return;
  if(info.isNew){
    const m=fmem()[info.title]=fmem()[info.title]||{};let ch=false;info.fields.forEach(f=>{if(f[2]==='select'&&m[f[0]]!==vals[f[0]]){m[f[0]]=vals[f[0]];ch=true}});if(ch)save('settings');
    if(recLabel(info.fields,vals)&&!info.fields.some(f=>f[2]==='password')){const r=[vals].concat(recGet(info.title).filter(x=>recLabel(info.fields,x)!==recLabel(info.fields,vals))).slice(0,5);try{localStorage.setItem(recKey(info.title),JSON.stringify(r))}catch(e){}}
  }
  if(info.again){toast({title:'Saved. Add the next one.',src:info.title,t:hm(nowMin())});form.apply(null,info.args)}
};
Object.assign(A,{
  fSet(d){const el=document.getElementById('f_'+d.k);if(!el)return;el.value=d.v;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));document.querySelectorAll('#sheet .qc[data-k="'+d.k+'"]').forEach(b=>b.classList.toggle('on',b.dataset.v===String(d.v)))},
  fRecent(d){if(!F)return;const r=recGet(F.title).filter(x=>recLabel(F.fields,x))[+d.i];if(!r)return;F.fields.forEach(f=>{const el=document.getElementById('f_'+f[0]);if(!el||r[f[0]]==null)return;el.value=f[2]==='date'?today():r[f[0]];document.querySelectorAll('#sheet .qc[data-k="'+f[0]+'"]').forEach(b=>b.classList.toggle('on',b.dataset.v===String(el.value)))});document.querySelectorAll('#sheet .qc.rec').forEach((b,i)=>b.classList.toggle('on',i===+d.i))},
  fAgain(){if(!F)return;F.again=1;submitForm()}
});

/* ---------- type it in one line ---------- */
const DOWN=['sunday','monday','tuesday','wednesday','thursday','friday','saturday'],MON=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
const PAYW={bkash:'bKash',nagad:'Nagad',rocket:'Rocket',card:'Card',bank:'Bank',cash:'Cash'};
const CATW=[['Transport',/\b(rickshaw|bus|uber|pathao|cng|train|metro|fare|transport|bike)\b/],['Study',/\b(book|books|print|printing|photocopy|xerox|pen|notebook|lab coat|stationery)\b/],['Mobile and internet',/\b(recharge|internet|data|mb|gb|wifi|flexiload)\b/],['Health',/\b(medicine|doctor|pharmacy|clinic|test)\b/],['Fun',/\b(movie|game|cinema|outing|netflix)\b/],['Shopping',/\b(shirt|shoes|clothes|shopping|bag)\b/],['Food',/\b(tea|cha|coffee|snack|food|biriyani|khichuri|burger|pizza|fuchka|juice|lunch|dinner|breakfast)\b/]];
const XKW=[['Quiz',/\bquiz\b/],['Mid-term',/\b(mid|mids|midterm|mid-term)\b/],['Final',/\bfinals?\b/],['Assignment',/\bassignment\b/],['Presentation',/\bpresentation\b/],['Lab report',/\blab report\b/],['Viva',/\bviva\b/]];
function pDate(L){
  let m;
  if(/\b(today|aj|ajke)\b/.test(L))return[today(),RegExp.lastMatch];
  if(/\b(tomorrow|tmrw|tmr|kal|kalke)\b/.test(L))return[addDays(today(),1),RegExp.lastMatch];
  if(/\bnext week\b/.test(L))return[addDays(today(),7),'next week'];
  if((m=L.match(/\b(sun|mon|tue|tues|wed|thu|thur|thurs|fri|sat)(day|nesday|sday|urday)?\b/))){const i=['sun','mon','tue','wed','thu','fri','sat'].indexOf(m[1].slice(0,3)),c=new Date().getDay();return[addDays(today(),(i-c+7)%7),m[0]]}
  if((m=L.match(/\b(\d{1,2})\s*(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\b/))||(m=L.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s*(\d{1,2})\b/))){const d=+(/\d/.test(m[1])?m[1]:m[2]),mo=MON.indexOf((/\d/.test(m[1])?m[2]:m[1]).slice(0,3));let y=new Date().getFullYear(),s=ymd(new Date(y,mo,d));if(s<today())s=ymd(new Date(y+1,mo,d));return[s,m[0]]}
  if((m=L.match(/\b(\d{1,2})[\/.-](\d{1,2})\b/))){const d=+m[1],mo=+m[2]-1;if(mo<12&&d<=31){let y=new Date().getFullYear(),s=ymd(new Date(y,mo,d));if(s<today())s=ymd(new Date(y+1,mo,d));return[s,m[0]]}}
  return null;
}
function pTime(L){let m=L.match(/\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/);if(m){let h=+m[1]%12;if(m[3]==='pm')h+=12;return[hm(h*60+(+m[2]||0)),m[0]]}m=L.match(/\bat\s+(\d{1,2}):(\d{2})\b/)||L.match(/\b(\d{1,2}):(\d{2})\b/);if(m&&+m[1]<24)return[hm(+m[1]*60+ +m[2]),m[0]];return null}
const strip=(t,parts)=>{let s=t;parts.filter(Boolean).forEach(p=>{s=s.replace(new RegExp(p.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'i'),' ')});return s.replace(/\s+/g,' ').trim().replace(/^(at|on|by|for)\s+|\s+(at|on|by|for)$/i,'').trim()};
function parseLine(txt){
  const t=String(txt||'').trim(),L=t.toLowerCase();if(!t)return null;let m;
  if((m=L.match(/^(?:note|নোট)[:\s]+(.+)/)))return{type:'note',title:t.slice(t.length-m[1].length)};
  if((m=L.match(/(\d+)\s*(glass(?:es)?|gl|গ্লাস)\b/))||/^(water|pani|পানি)$/.test(L))return{type:'water',glasses:m?Math.min(20,+m[1]):1};
  const pr=PR.find(p=>new RegExp('\\b'+p[0]+'\\b').test(L)||L.indexOf(p[1].toLowerCase())>=0);
  if(pr&&(L.split(/\s+/).length<=3||/\b(prayed|done|porlam|porechi)\b/.test(L)))return{type:'prayer',name:pr[0]};
  const hb=S.habits.find(h=>L.indexOf(h.name.toLowerCase())>=0);if(hb&&/\b(done|did|✓|complete)\b/.test(L))return{type:'habit',title:hb.name};
  const d=pDate(L),tm=pTime(L);
  if((m=t.match(/^remind(?:\s+me)?(?:\s+to)?\s+(.+)/i))&&tm)return{type:'reminder',title:strip(m[1],[d&&d[1],tm[1]]),time:tm[0],date:d?d[0]:today()};
  const xk=XKW.find(x=>x[1].test(L));
  if(xk&&d){const cc=t.match(/\b([A-Za-z]{3})\s?(\d{3}[A-Za-z]?)\b/),title=strip(t,[d[1],tm&&tm[1],cc&&cc[0]]);return{type:'exam',title:cc?(cc[1].toUpperCase()+' '+cc[2]+' '+xk[0]):title||xk[0],kind:xk[0],date:d[0],time:tm?tm[0]:'',course:cc?cc[1]+cc[2]:''}}
  const am=t.match(/(?:৳|tk\.?\s*|taka\s*)?(\d+(?:\.\d+)?)\s*(?:৳|tk\b|taka\b|টাকা)?/i);
  if(am&&!tm&&!xk){
    const n=+am[1],pw=Object.keys(PAYW).find(k=>new RegExp('\\b'+k+'\\b').test(L)),note=strip(t,[am[0],pw]).replace(/\b(spent|paid|for|on|via|by|with|দিয়ে)\b/gi,' ').replace(/\s+/g,' ').trim();
    if(/\b(got|received|salary|income|tuition|pocket money|stipend|scholarship)\b/.test(L))return{type:'income',amount:n,note:note,pay:pw?PAYW[pw]:''};
    const meal=['breakfast','lunch','dinner'].find(w=>L.indexOf(w)>=0);
    if(meal)return{type:'meal',meal:meal[0].toUpperCase()+meal.slice(1),title:note||meal,cost:n,pay:pw?PAYW[pw]:''};
    const cat=(CATW.find(c=>c[1].test(L))||['Other'])[0];return{type:'expense',amount:n,cat:cat,note:note,pay:pw?PAYW[pw]:''};
  }
  if(tm&&!d&&/\b(remind|alarm)\b/.test(L))return{type:'reminder',title:strip(t,[tm[1]]).replace(/\b(remind me( to)?|alarm)\b/i,'').trim()||'Reminder',time:tm[0],date:today()};
  return{type:'task',title:strip(t,[d&&d[1]]).replace(/^(todo|task)[:\s]+/i,'')||t,due:d?d[0]:''};
}
function lineDesc(i){if(!i)return'';const P=i.pay?' · '+i.pay:'';return{note:'Note: '+i.title,water:i.glasses+' glass'+(i.glasses>1?'es':'')+' of water',prayer:(PR.find(p=>p[0]===i.name)||['',''])[1]+' prayer done',habit:'Habit done: '+i.title,reminder:'Reminder: '+i.title+' · '+tfmt(i.time)+(i.date!==today()?' · '+fmt(i.date):''),exam:i.kind+': '+i.title+' · '+fmt(i.date)+(i.time?' · '+tfmt(i.time):''),income:'Income '+money(i.amount)+P,meal:i.meal+' “'+i.title+'” '+money(i.cost)+P,expense:'Spent '+money(i.amount)+' · '+i.cat+(i.note?' · '+i.note:'')+P,task:'Task: '+i.title+(i.due?' · due '+fmt(i.due):'')}[i.type]||''}
const oneLine=()=>`<div class="card oneline"><form class="quick" data-f="ol"><input id="olin" placeholder="Type it in one line: lunch 120 bkash" aria-label="Add anything in one line" autocomplete="off"><button class="btn pri" aria-label="Add">${ic('plus')}</button></form><p class="muted" id="olprev">Try “2 glasses”, “quiz BBT423 tue 10am”, “remind me to call Ammu at 9pm”, “prayed asr”.</p></div>`;
Q.ol=function(){
  const el=document.getElementById('olin');if(!el||!el.value.trim())return;const i=parseLine(el.value);if(!i)return;
  const before=S.money.length,out=applyItems([i]);
  if(i.pay&&S.money.length>before){S.money[S.money.length-1].pay=i.pay;save('money')}
  toast({title:out.length?'Added: '+out.join(', '):'Nothing added',src:'One line',t:hm(nowMin())});el.value='';
};
document.addEventListener('input',e=>{if(e.target.id!=='olin')return;const p=document.getElementById('olprev');if(!p)return;const v=e.target.value.trim();p.textContent=v?'Will add → '+lineDesc(parseLine(v)):'Try “2 glasses”, “quiz BBT423 tue 10am”, “remind me to call Ammu at 9pm”, “prayed asr”.';p.classList.toggle('olok',!!v)});

/* ---------- weekly review (Friday and Saturday) ---------- */
const revFri=()=>{const d=new Date().getDay();return d===5?today():d===6?addDays(today(),-1):''};
let RV=null;
function revCard(){const f=revFri();if(!f||S.settings.revFri===f)return'';return`<div class="card revcta" role="button" tabindex="0" data-a="revOpen"><div class="row">${ill('exam')}<div class="grow"><span class="pill">2-minute weekly review</span><h3>Look back, then plan next week</h3><p class="muted">See your week, note what worked, and set 3 goals.</p></div>${ic('next')}</div></div>`}
function revStats(){const d7=dayKeys(7),sum=(k)=>d7.reduce((a,d)=>a+(+M9[k].f(d)||0),0),sl=d7.map(d=>M9.sleep.f(d)).filter(x=>x!=null);return[['Studied',dur(sum('focus'))],['Tasks done',sum('tasks')],['Water',Math.round(sum('water')/7*10)/10+' glasses a day'],['Sleep',sl.length?dur(Math.round(sl.reduce((a,b)=>a+b,0)/sl.length*60))+' a night':'not logged'],!S.settings.deenOff&&['Prayers',sum('prayers')+' of 35'],['Spent',money(sum('spend'))],['Goal days',goalDays(7).length+' of 7']].filter(Boolean)}
function revDraw(){
  let el=document.getElementById('revx');if(!el){el=document.createElement('div');el.id='revx';document.body.appendChild(el)}
  const st=RV.i,dots=`<div class="obdots">${[0,1,2].map(i=>`<i class="${i<=st?'on':''}"></i>`).join('')}</div>`;let b='';
  if(st===0)b=`<h1>Your week</h1><div class="revg">${revStats().map(x=>`<div><b>${x[1]}</b><span>${x[0]}</span></div>`).join('')}</div>`;
  if(st===1)b=`<h1>Look back</h1><label>What went well this week?<textarea id="rv_good" placeholder="Finished the lab report early">${esc(RV.good)}</textarea></label><label>What will you do differently?<textarea id="rv_fix" placeholder="Sleep before 12 on weekdays">${esc(RV.fix)}</textarea></label>`;
  if(st===2)b=`<h1>Next week’s top 3</h1><p class="muted">They become high-priority tasks due in 7 days.</p>${[0,1,2].map(i=>`<label>Goal ${i+1}<input id="rv_g${i}" value="${esc(RV.g[i]||'')}" placeholder="${['Revise BBT423 chapter 5','Gym three times','Start the survey'][i]}"></label>`).join('')}`;
  el.innerHTML=`<div class="revc"><div class="row between">${dots}<button class="btn sm" data-a="revClose">Close</button></div><div class="revb">${b}</div><div class="row obnav">${st?'<button class="btn" data-a="revBack">Back</button>':''}<button class="btn pri grow" data-a="revNext">${st===2?'Finish review':'Next'}</button></div></div>`;
  if(curLang()==='bn')bnNode(el);
}
const revGrab=()=>{const g=id=>{const e=document.getElementById(id);return e?e.value:null};if(g('rv_good')!=null){RV.good=g('rv_good');RV.fix=g('rv_fix')}if(g('rv_g0')!=null)RV.g=[0,1,2].map(i=>g('rv_g'+i).trim())};
Object.assign(A,{
  revOpen(){RV={i:0,good:'',fix:'',g:[]};revDraw()},
  revClose(){const e=document.getElementById('revx');if(e)e.remove();RV=null},
  revBack(){revGrab();RV.i--;revDraw()},
  revNext(){revGrab();if(RV.i<2){RV.i++;revDraw();return}
    const f=revFri()||today(),due=addDays(today(),7),gs=RV.g.filter(Boolean);
    gs.forEach(g=>S.tasks.push({id:uid(),title:g,due:due,cat:'Personal',pri:'High',done:false}));if(gs.length)save('tasks');
    if(RV.good||RV.fix||gs.length){const n={id:uid(),ref:'',title:'Weekly review · '+fmt(f),body:revStats().map(x=>x[0]+': '+x[1]).join('\n')+'\n\nWent well: '+(RV.good||'-')+'\nDo differently: '+(RV.fix||'-')+'\nNext week: '+(gs.join('; ')||'-'),updated:Date.now()};S.notes.push(n);save('n_'+n.id)}
    S.settings.revFri=f;save('settings');A.revClose();render();celebrate('Week reviewed. '+gs.length+' goal'+(gs.length===1?'':'s')+' set')}
});

/* ---------- home additions ---------- */
const _today16=VIEWS.today;
VIEWS.today=()=>{const h=_today16();if(h.indexOf('class="card examday"')>=0&&!ui.examFull)return h;const i=h.indexOf('<div class="tiles">'),add=revCard()+oneLine();return i>=0?h.slice(0,i)+add+h.slice(i):add+h};

/* ---------- attendance: ask when class ends ---------- */
const _ag16=agenda;
agenda=function(ds){const a=_ag16(ds);if(S.settings.attAsk!==0){const dow=parse(ds).getDay(),day=S.att[ds]||{};S.routine.filter(r=>+r.day===dow&&r.start&&!day[r.id]).forEach(r=>{const e=r.end?toMin(r.end):toMin(r.start)+75;a.push({t:hm(Math.min(1439,e+2)),title:'Did you attend '+rName(r)+'?',src:'Attendance',key:'att-'+r.id})});a.sort((x,y)=>x.t<y.t?-1:1)}return a};
const _att16=EXT.attend;
EXT.attend=()=>_att16()+`<div class="card"><div class="list"><div class="item">${chk(S.settings.attAsk!==0,'attAskTog','','Ask after class')}<span class="t grow">Ask me after each class<br><span class="muted">A notification with Attended and Missed buttons fills this in for you.</span></span></div></div></div>`;
A.attAskTog=()=>{S.settings.attAsk=S.settings.attAsk===0?1:0;save('settings');render()};
SRCC.Attendance='grape';

/* ---------- phone: notification buttons, bench timers, widget ---------- */
function nkind(x,ds){const k=x.key||'';if(x.src==='Water')return['water',''];if(k.indexOf('t-')===0)return['task',k.slice(2)];if(k.indexOf('p-')===0)return['prayer',k.slice(2)+'|'+ds];if(k.indexOf('att-')===0)return['attend',k.slice(4)+'|'+ds];return['','']}
function widgetData(){
  const t=today(),n=nowMin(),np=S.settings.deenOff?null:nextPrayer(),dow=new Date().getDay(),c=S.routine.filter(r=>+r.day===dow&&r.start&&toMin(r.start)>=n-10).sort((a,b)=>a.start<b.start?-1:1)[0];
  const due=S.tasks.filter(x=>!x.done&&x.due&&x.due<=t),rest=S.tasks.filter(x=>!x.done&&!x.due);
  return{pr:np?np.name+' at '+tfmt(np.t)+' · in '+dur(np.mins):'',cls:c?'Next class: '+rName(c)+' · '+tfmt(c.start)+(c.room?' · '+c.room:''):'No more classes today',w:S.water[t]||0,wg:S.settings.waterGoal,tasks:due.concat(rest).slice(0,3).map(x=>x.title)};
}
let lastW='';
nativeSync=function(){
  if(!NV||!NV.sync)return;const now=Date.now(),out=[];
  for(let d=0;d<7;d++){const ds=addDays(today(),d);agenda(ds).forEach(x=>{const at=tsOf(ds,x.t);if(at>now+5000){const k=nkind(x,ds);out.push({t:x.title,s:x.src,at:at,a:x.alarm?1:0,k:k[0],d:k[1]})}})}
  LT.forEach(x=>{if(x.end>now+3000)out.push({t:x.name+' is done',s:'Bench timer',at:x.end,a:1,k:'timer',d:x.id})});
  out.sort((a,b)=>a.at-b.at);const j=JSON.stringify(out.slice(0,140));if(j!==lastSync){lastSync=j;try{NV.sync(j)}catch(e){}}
  if(NV.widget){const w=JSON.stringify(widgetData());if(w!==lastW){lastW=w;try{NV.widget(w)}catch(e){}}}
};
function applyPending(){
  if(!NV||!NV.pending)return;let l=[];try{l=JSON.parse(NV.pending()||'[]')}catch(e){return}if(!l.length)return;const keys=new Set(),msg=[];
  l.forEach(x=>{const a=String(x.a||''),p=String(x.d||'').split('|'),ds=x.at?ymd(new Date(x.at)):today();
    if(a==='water'){S.water[ds]=(S.water[ds]||0)+1;keys.add('water');msg.push('a glass of water')}
    else if(a==='task'){const t=S.tasks.find(y=>y.id===p[0]);if(t&&!t.done){t.done=true;t.doneAt=ds;keys.add('tasks');msg.push('“'+t.title+'” done')}}
    else if(a==='prayer'&&PR.some(q=>q[0]===p[0])){const d=p[1]||ds;(S.prayers[d]=S.prayers[d]||{})[p[0]]=1;keys.add('prayers');msg.push(p[0]+' prayer')}
    else if(a.indexOf('attend:')===0){const r=S.routine.find(y=>y.id===p[0]);if(r){const d=p[1]||ds;(S.att[d]=S.att[d]||{})[r.id]={s:a.slice(7),c:attKey(r)};keys.add('att');msg.push(rName(r)+(a.slice(7)==='p'?' attended':' missed'))}}
  });
  if(keys.size){save.apply(null,[...keys]);render();toast({title:'From your notifications: '+msg.join(', '),src:'Catalyst',t:hm(nowMin())})}
}
setInterval(applyPending,4000);setTimeout(applyPending,1500);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')applyPending()});
const _lab16=VIEWS.lab;
VIEWS.lab=()=>{let h=_lab16();if(NV&&NV.sync)h=h.replace('They ring while the app is open.','They ring even when the app is closed, like an alarm.');return h};

/* ---------- protocol runner: big current step, screen stays on ---------- */
const _prot16=EXT.lab_protocols;
EXT.lab_protocols=()=>{
  const h=_prot16();if(!ui.pr)return h;const p=allProto().find(x=>x.id===ui.pr);if(!p)return h;const i=p.steps.findIndex((s,k)=>!ui.prDone[k]);
  const run=i<0?`<div class="card prrun done"><span class="pill">Finished</span><h2>All ${p.steps.length} steps done</h2></div>`:`<div class="card prrun"><span class="pill">Step ${i+1} of ${p.steps.length}</span><h2>${esc(p.steps[i][0])}</h2><div class="row wrap">${p.steps[i][1]?`<button class="btn" data-a="ltGo" data-n="${p.steps[i][1]}" data-name="${esc(p.steps[i][0].slice(0,40))}">Start ${secs(p.steps[i][1])}</button>`:''}<button class="btn pri grow" data-a="prStep" data-id="${i}">Done, next step</button></div>${NV&&NV.keepOn?'<p class="muted">The screen stays on while a protocol is open.</p>':''}</div>`;
  const k=h.indexOf('</button>');return k>=0?h.slice(0,k+9)+run+h.slice(k+9):run+h;
};

/* ---------- first-time tips ---------- */
const ADD='#view [data-a$="Add"],#view .btn.pri';
const TUT={
 'today':[['.sky','Your day at a glance','The banner follows the real sky. Your streak is on the left. Tap your level to see your journey.'],['.oneline','Type it in one line','Write things like “lunch 120 bkash” or “quiz BBT423 tue 10am” and Catalyst files it in the right place.'],['.tiles','Quick tiles','Tap a tile to open it. The + adds water or spending in one tap.'],['#fab','Add from anywhere','This button adds a task, water, an expense, a note or an alarm from any page.'],[null,'Swipe to move','Swipe left or right anywhere on a page to move between tabs.']],
 'plan/tasks':[[null,'Tasks','Add what you need to do, with a date and time if it matters. Due tasks show on Today and remind you.'],[ADD,'Add a task','Tap here. Quick buttons fill in Today, Tomorrow and common times.']],
 'plan/cal':[[null,'Calendar','See tasks, events, exams and classes day by day. Tap a day to see it.']],
 'plan/routine':[[null,'Class routine','Add each course once with all its days. Catalyst reminds you before class and asks after class if you attended.'],[ADD,'Add a class','Start here.']],
 'study/courses':[[null,'Courses','Each course keeps its notes, files, exams and grades together.'],[ADD,'Add a course','Add your courses for this semester.']],
 'study/exams':[[null,'Exams','Quizzes, mids, finals and deadlines with countdowns. On exam day the home screen switches to exam mode.']],
 'study/timer':[[null,'Focus timer','Study in focused blocks. Each session runs as a PCR cycle and counts toward your heatmap and ATP.']],
 'study/cgpa':[[null,'CGPA','Follows NSU’s 4.00 system. Add retakes and see what you need to reach your target.']],
 'study/grades':[[null,'Grade predictor','Enter marks so far, including best-of quizzes, and see the grade you are heading for.']],
 'study/attend':[[null,'Attendance','Mark each class, or tap Attended in the notification after class. It tells you how many more you can miss.']],
 'study/cite':[[null,'Citations','Save references once and copy them in APA style when you write.']],
 'study/files':[[null,'Files','Keep PDFs, slides and photos for each course on your phone.']],
 'study/tools':[[null,'PDF tools','Merge, split and convert files without leaving the app.']],
 'study/research':[[null,'Research','Plan a project step by step, with notes and links in one place.']],
 'lab/calc':[['#view .chips','Lab bench','Calculators for molarity, dilutions, centrifuges and more. Slide the categories to see them all.'],['#view input','Search','Type what you need, like “dilution” or “OD”.']],
 'lab/timers':[[null,'Bench timers','Run several timers at once for incubation, staining or spinning. They ring like an alarm, even when the app is closed.']],
 'lab/protocols':[[null,'Protocols','Open a protocol at the bench. It shows one step at a time, runs the timers and keeps the screen on.']],
 'lab/book':[[null,'Lab notebook','Write what you did, with the date. Share an entry with your lab partner through Lab buddy.']],
 'lab/mol':[[null,'Molecules','Spin 3D models with your finger. A new molecule of the day appears on Today.']],
 'lab/buddy':[[null,'Lab buddy','Send a protocol, reagent list or notebook entry to a classmate as a code. No account needed.']],
 'deen/prayer':[[null,'Prayer','Times for your city. Tick each prayer. You can turn on a Fajr alarm in Reminders.']],
 'deen/quran':[[null,'Quran','Read with Arabic, pronunciation and meaning. Your place is kept.']],
 'deen/duas':[[null,'Daily duas','Morning, evening and everyday duas with pronunciation and meaning.']],
 'deen/tasbih':[[null,'Tasbih','Tap anywhere on the counter. It vibrates at each 33.']],
 'deen/ramadan':[[null,'Ramadan','Sehri and iftar times, fasts and juz tracking.']],
 'life/water':[[null,'Water','Tap + for each glass. Reminders come through the day until you reach your goal.']],
 'life/food':[[null,'Food','Log meals with what they cost. See your breakfast habit and junk-food days.']],
 'life/habits':[[null,'Habits','Tick habits each day. Together they form your pathway. Finish them all to light it up.'],[ADD,'Add a habit','Start with one or two.']],
 'life/sleep':[[null,'Sleep','Tap “Going to bed now” at night and “I am awake” in the morning. The body clock shows your rhythm.']],
 'life/health':[[null,'Health','Only when you are sick: add your prescription and Catalyst reminds you of each dose.']],
 'life/money':[[null,'Money','Log spending in seconds. Recent entries repeat in one tap, and insights warn you before you pass your budget.'],[ADD,'Add an expense','Try the quick amount buttons.']],
 'more/reminders':[[null,'Reminders and alarms','Set reminders and alarms that ring until you stop them, even when the app is closed.']],
 'more/account':[[null,'Account','Sign in so your data is safe online and comes back on a new phone.']],
 'more/badges':[[null,'Badges','Earn badges for streaks, study hours, water and more, including ones named after great biochemists.']],
 'more/levels':[[null,'Levels','Everything you do earns ATP. Climb 40 levels from Atom to Nobel Laureate.']],
 'more/notes':[[null,'Notes','Quick notes. Course notes live inside each course.']],
 'more/settings':[[null,'Settings and backup','Change your details, back up your data, and turn tips on or off.']]
};
let tutOpen=null,tutT=0;
const tutKey=()=>ui.tab+(ui[ui.tab]?'/'+ui[ui.tab]:'');
function tutCheck(){
  clearTimeout(tutT);const s=S.settings;if(tutOpen&&tutOpen.k!==tutKey())tutClose(false);
  if(s.tutOff||!s.setup||tutOpen)return;const k=tutKey();if(!TUT[k]||(s.tut||{})[k])return;
  tutT=setTimeout(()=>{if(tutKey()!==k||document.getElementById('onb')||document.querySelector('#shade.open')||document.getElementById('revx')||document.getElementById('wrapx')||document.body.classList.contains('dopen'))return;tutOpen={k:k,i:0};tutDraw()},700);
}
function tutDraw(){
  const st=TUT[tutOpen.k],x=st[tutOpen.i],last=tutOpen.i===st.length-1;let el=document.getElementById('tut');
  if(!el){el=document.createElement('div');el.id='tut';document.body.appendChild(el)}
  let tg=null;if(x[0])try{tg=[...document.querySelectorAll(x[0])].find(e=>e.offsetParent!==null)}catch(e){}
  let ring='',top=false;
  if(tg){tg.scrollIntoView({block:'center',behavior:'instant'});const r=tg.getBoundingClientRect(),p=8;ring=`<div class="tutring" style="left:${r.left-p}px;top:${r.top-p}px;width:${r.width+2*p}px;height:${r.height+2*p}px"></div>`;top=r.top+r.height/2>innerHeight*.55}
  el.className=(tg?'has':'')+(top?' top':'');
  el.innerHTML=`${ring}<div class="tutbox" role="dialog" aria-label="${esc(x[1])}"><div class="row between"><span class="pill">Tip ${tutOpen.i+1} of ${st.length}</span><button class="btn sm" data-a="tutOff">Turn off tips</button></div><h3>${esc(x[1])}</h3><p>${esc(x[2])}</p><div class="row"><button class="btn" data-a="tutSkip">Skip</button><button class="btn pri grow" data-a="tutNext">${last?'Got it':'Next'}</button></div></div>`;
  if(curLang()==='bn')bnNode(el);
}
function tutClose(mark){if(tutOpen&&mark){const s=S.settings;(s.tut=s.tut||{})[tutOpen.k]=1;save('settings')}tutOpen=null;const e=document.getElementById('tut');if(e)e.remove()}
Object.assign(A,{
  tutNext(){if(!tutOpen)return;if(tutOpen.i<TUT[tutOpen.k].length-1){tutOpen.i++;tutDraw()}else tutClose(true)},
  tutSkip(){tutClose(true)},
  tutOff(){S.settings.tutOff=1;save('settings');tutClose(false);toast({title:'Tips are off. Turn them back on in Settings.',src:'Tips',t:hm(nowMin())})},
  tutReset(){S.settings.tut={};S.settings.tutOff=0;save('settings');render();toast({title:'Tips will show again on each page.',src:'Tips',t:hm(nowMin())})}
});
window.addEventListener('resize',()=>{if(tutOpen)tutDraw()});
const _set16=EXT.settings;
EXT.settings=()=>_set16()+`<div class="card"><h3>Tips</h3><p class="muted">Short tips appear the first time you open each page.</p><div class="row wrap"><button class="btn sm" data-a="tutReset">Show all tips again</button>${S.settings.tutOff?'':'<button class="btn sm" data-a="tutOff">Turn off tips</button>'}</div></div>`;

/* ---------- after each screen ---------- */
const _ar16=window.afterRender;
window.afterRender=function(){
  _ar16();chipHints();tutCheck();
  if(NV&&NV.keepOn){const on=ui.tab==='lab'&&ui.lab==='protocols'&&!!ui.pr;if(on!==window.__keep){window.__keep=on;try{NV.keepOn(on)}catch(e){}}}
};

/* ---------- Bangla ---------- */
Object.assign(BN,{'Recent':'সাম্প্রতিক','Save and add another':'সেভ করে আরেকটি যোগ করুন','Today':'আজ','Tomorrow':'আগামীকাল','In 2 days':'২ দিন পরে','Next week':'আগামী সপ্তাহ','Now':'এখন','In 1 hour':'১ ঘণ্টা পরে','None':'কিছু না',
 'Look back, then plan next week':'পেছনে তাকান, তারপর আগামী সপ্তাহ সাজান','Your week':'আপনার সপ্তাহ','Look back':'পেছনে তাকান','Next week’s top 3':'আগামী সপ্তাহের সেরা ৩','Finish review':'রিভিউ শেষ','Close':'বন্ধ','Back':'পেছনে',
 'Turn off tips':'টিপস বন্ধ','Skip':'বাদ দিন','Got it':'বুঝেছি','Tips':'টিপস','Show all tips again':'সব টিপস আবার দেখান','Done, next step':'শেষ, পরের ধাপ','Ask me after each class':'প্রতিটি ক্লাসের পরে জিজ্ঞেস করুন'});
BNP.push([/^Tip (\d+) of (\d+)$/,'টিপ $1 / $2'],[/^Step (\d+) of (\d+)$/,'ধাপ $1 / $2']);
window.__v16={parse:parseLine,desc:lineDesc,wd:()=>widgetData(),applyPending:applyPending,ag:d=>agenda(d),tut:()=>tutOpen,TUT:TUT};


/* ================= v17: BBT course map, degree progress, CGPA from the map, citation from DOI ================= */
const GEDOPT=['POL101','POL104','ECO101','ECO104','SOC101','ANT101'];
const DGT={g:['University GED','leaf'],s:['School core','sky'],m:['Major required','tomato'],e:['Electives','grape']};
const ELECT=['BBT418','BBT419','BBT421','BBT423','BBT425','BBT426','BBT427'];
/* [code, type, prerequisites, suggested semester] */
const BBTMAP=[
 ['ENG102','g',[],1],['ENG103','g',['ENG102'],2],['BIO103','g',[],1],['CHE101','s',[],1],
 ['ENG105','g',['ENG103'],2],['MAT116','g',[],2],['BEN205','g',[],2],['CHE101L','g',[],2],['BIO103L','g',[],2],
 ['CHE201','s',['CHE101'],3],['BIO201','s',['BIO103'],3],['BIO201L','s',['BIO103L'],3],['MIS107','g',[],3],['GED','g',[],3],
 ['BUS172','g',[],4],['CHE202','s',['CHE101'],4],['CHE202L','s',['CHE101L'],4],['HIS103','g',[],4],
 ['BIO202','s',['BIO103'],5],['BBT221','m',['BIO201'],5],['CHE203','s',['BIO201','CHE202'],5],['CHE203L','s',['BIO201L','CHE202L'],5],['BBT230','s',['BIO201','BUS172'],5],
 ['BBT312','m',['CHE203'],6],['BBT312L','m',['CHE203L'],6],['BBT314','m',['CHE201','CHE203'],6],['BBT314L','m',['CHE203L'],6],['BBT315','m',['CHE203'],6],['BIO202L','s',['BIO103L'],6],
 ['BBT316','m',['BBT221','BBT314'],7],['BBT316L','m',['BBT314L'],7],['BBT317','m',['BBT312'],7],['BBT335','m',['BBT315'],7],
 ['BBT318','m',['BBT221','BBT312','BBT315'],8],['BBT413','m',['BBT312','BBT315'],8],['BBT413L','m',['BBT312L'],8],['BBT423','e',['BBT335'],8],
 ['BBT415','m',['BBT317'],9],['BBT416','m',['BBT230','BBT317'],9],['BBT419','e',['BBT335'],9],
 ['BBT415L','m',['BBT312L','BBT314L'],10],['BBT417','m',['BBT318'],10],['BBT418','e',['BBT415'],10],['BBT424','m',['BBT316','BBT318'],10],
 ['BBT421','e',['BBT316','BBT317'],11],['BBT425','e',['BBT417'],11],['BBT427','e',['BBT415'],11],
 ['BBT426','e',['CHE203','BBT335'],12],['BBT422','m',['BBT335','BBT415','BBT416'],12]
];
const ALTS={HIS103:['HIS103','HIS101','PHI101'],BEN205:['BEN205','ENG115']};
const dcr=c=>c==='BBT422'?4:/L$/.test(c)?1:3;
const dgS=()=>{const s=S.settings;if(!s.dg||typeof s.dg!=='object')s.dg={waive:0,ged:'',c:{},x:[]};const d=s.dg;d.c=d.c||{};d.x=d.x||[];d.alt=d.alt||{};return d};
const dgReq=()=>dgS().waive?120:123;
function dgList(){const d=dgS();return BBTMAP.filter(x=>!(x[0]==='ENG102'&&d.waive)).map(x=>{const code=x[0]==='GED'?(d.ged||'GED'):ALTS[x[0]]?(d.alt[x[0]]||x[0]):x[0],sem=x[0]==='ENG103'&&d.waive?1:x[3];return{key:x[0],code:code,type:x[1],pre:x[2].filter(p=>!(p==='ENG102'&&d.waive)),sem:sem,cr:dcr(x[0])}})}
const dgE=k=>dgS().c[k];
const passG=g=>{const p=ngp(g);return p!=null&&p>=1};
const dgPassed=k=>{const e=dgE(k);return!!(e&&!e.now&&passG(e.g))};
const dgOk=p=>dgPassed(p)||!!(dgE(p)&&dgE(p).now);
const labTheory=x=>/L$/.test(x.key)&&BBTMAP.some(y=>y[0]===x.key.slice(0,-1))?x.key.slice(0,-1):'';
const preMet=x=>x.pre.every(dgOk)||(!!labTheory(x)&&dgOk(labTheory(x)));
const preMiss=x=>preMet(x)?[]:x.pre.filter(p=>!dgOk(p));
const dgTitle=code=>{const c=S.courses.find(x=>String(x.code||'').replace(/\s/g,'').toUpperCase()===code);return c?c.title:''};
function dgCalc(useExp){
  const d=dgS(),rule=S.settings.retake;let cr=0,pts=0,earn=0,el=0,elList=0,now=0;const by={g:[0,0],s:[0,0],m:[0,0],e:[0,0]};
  const one=(c,type,e)=>{if(type!=='e')by[type][1]+=c;if(!e)return;let g=e.g;if(e.now){now+=c;if(!(useExp&&e.exp))return;g=e.exp}
    const gp=ngp(g);if(gp==null)return;const o=e.old?ngp(e.old):null,use=o!=null&&rule==='Better grade'?Math.max(gp,o):gp;cr+=c;pts+=c*use;
    if(use>=1&&!e.now){earn+=c;if(type==='e'){el++;by.e[0]+=c}else by[type][0]+=c}};
  dgList().forEach(x=>{one(x.cr,x.type,dgE(x.key));if(x.type==='e'&&dgPassed(x.key))elList++});
  const mjCr=by.e[0];d.x.forEach(x=>one(num(x.cr)||3,'e',x));
  const elCr=by.e[0],core=by.g[0]+by.s[0]+by.m[0];by.e=[Math.min(18,elCr),18];
  return{cr:cr,pts:pts,g:cr?pts/cr:0,earn:core+Math.min(18,elCr),extra:Math.max(0,elCr-18),el:el,elList:elList,mjCr:mjCr,frCr:elCr-mjCr,now:now,by:by,elOk:elList>=3&&elCr>=18};
}
const dgUsed=()=>{const d=dgS();return Object.keys(d.c).length+d.x.length>0};
const cgMode=()=>S.settings.cgSrc||(dgUsed()?'map':'sems');
const _cg17=cg;
cg=function(){return cgMode()==='map'?dgCalc(false):_cg17()};
function dgNext(){const l=dgList();return l.filter(x=>{const e=dgE(x.key);if(e&&(e.now||passG(e.g)))return false;if(x.key==='GED'&&!dgS().ged)return true;return preMet(x)})}
function ring(p,big,small){const r=44,C=2*Math.PI*r;return`<svg viewBox="0 0 110 110" class="dgring" role="img" aria-label="${esc(big+' '+small)}"><circle cx="55" cy="55" r="${r}" class="dgr0"/><circle cx="55" cy="55" r="${r}" class="dgr1" style="stroke-dasharray:${(Math.min(1,p)*C).toFixed(1)} ${C.toFixed(1)}"/><text x="55" y="53" class="dgt">${big}</text><text x="55" y="69" class="dgs">${small}</text></svg>`}
function dgRow(x){
  const e=dgE(x.key),t=dgTitle(x.code),miss=preMiss(x),lt=labTheory(x);let st;
  if(x.key==='GED'&&!dgS().ged)st='<span class="pill">Pick one</span>';
  else if(e&&e.now)st=`<span class="pill c-sky col">Taking now${e.exp?' · aiming '+esc(e.exp):''}</span>`;
  else if(e&&e.g)st=`<span class="dgg${passG(e.g)?'':' bad'}">${esc(e.g)}</span>`;
  else if(miss.length)st=`<span class="muted dglock">Needs ${miss.join(', ')}${lt?' or '+lt:''}</span>`;
  else st='<span class="pill">Can take</span>';
  return`<button class="dgrow t-${DGT[x.type][1]}${e&&e.g&&!e.now?' done':''}${!e&&miss.length?' lock':''}" data-a="dgEdit" data-id="${x.key}"><i class="dgbar"></i><span class="grow"><b>${x.key==='GED'?(dgS().ged||'POL / ECO / SOC / ANT'):x.code}</b>${t?`<small>${esc(t)}</small>`:''}<small>${x.cr} credit${x.cr>1?'s':''} · ${x.type==='e'?'Major elective':DGT[x.type][0]}${x.key==='BBT422'?'':''}${e&&e.t?' · '+esc(e.t):''}${e&&e.old?' · retake, was '+esc(e.old):''}</small></span>${st}</button>`;
}
function cgMapView(){
  const d=dgS(),c=dgCalc(false),pj=dgCalc(true),req=dgReq(),s=S.settings,tg=num(s.cgTarget),rm=Math.max(0,req-c.earn),need=tg&&rm?(tg*(c.cr+rm)-c.pts)/rm:null,l=dgList(),core=l.filter(x=>x.type!=='e'),els=l.filter(x=>x.type==='e'),vw=d.view||'status';
  let o=`<div class="card cghero"><div class="row"><div class="grow"><span class="pill">CGPA · NSU 4.00 scale</span><div class="big">${c.cr?c.g.toFixed(2):'–'}</div><p class="muted">${c.cr} credits counted${c.cr&&c.g<2?'. Below 2.00 means academic probation at NSU.':''}</p>${pj.cr!==c.cr||Math.abs(pj.g-c.g)>.0001?`<p class="dgproj">With the grades you are aiming for this semester: <b>${pj.g.toFixed(2)}</b></p>`:''}</div>${ring(c.earn/req,c.earn+'/'+req,'credits')}</div>
   <div class="dgbars">${['g','s','m','e'].map(k=>{const b=c.by[k];return`<div><div class="row between"><span>${DGT[k][0]}</span><span class="muted">${b[0]} / ${b[1]}</span></div><div class="bar t-${DGT[k][1]}"><i style="width:${b[1]?Math.min(100,b[0]/b[1]*100):0}%"></i></div></div>`}).join('')}</div>
   <p class="muted">Degree: ${req} credits${d.waive?' (ENG102 waived)':' including ENG102'}. Electives: 18 credits in total, with at least 3 major electives. So far ${c.elList} major elective${c.elList===1?'':'s'} and ${c.frCr} free elective credit${c.frCr===1?'':'s'}.${c.extra?' '+c.extra+' extra elective credits beyond 18.':''}${c.now?' Taking '+c.now+' credits now.':''}</p></div>`;
  const alt=(k,label)=>`<p class="muted">${label}</p><div class="chips wrapc">${ALTS[k].map(g=>`<button class="chip${(d.alt[k]||k)===g?' on':''}" data-a="dgAlt" data-k="${k}" data-v="${g}">${g}</button>`).join('')}</div>`;
  o+=`<div class="card"><h3>About you</h3><p class="muted">ENG102</p><div class="chips wrapc">${[[0,'I take ENG102'],[1,'ENG102 was waived']].map(x=>`<button class="chip${+d.waive===x[0]?' on':''}" data-a="dgWaive" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><p class="muted">GED choice</p><div class="chips wrapc">${GEDOPT.map(g=>`<button class="chip${d.ged===g?' on':''}" data-a="dgGed" data-v="${g}">${g}</button>`).join('')}</div>${alt('HIS103','History or philosophy')}${alt('BEN205','Bangla or English')}</div>`;
  o+=`<div class="card"><div class="chips wrapc">${[['status','By progress'],['plan','Suggested plan']].map(x=>`<button class="chip${vw===x[0]?' on':''}" data-a="dgView" data-v="${x[0]}">${x[1]}</button>`).join('')}</div><p class="muted">You can take courses in any semester once their prerequisites are done. A lab only needs its own theory course, even if its listed lab prerequisite is not done.</p></div>`;
  const grp=(title,list,note,open)=>list.length?`<div class="card dgyear"><div class="row between"><h2>${title}</h2><span class="pill">${list.length}</span></div>${note?`<p class="muted">${note}</p>`:''}${open===false?`<details><summary class="btn sm">Show ${list.length} course${list.length===1?'':'s'}</summary><div class="dgsem">${list.map(dgRow).join('')}</div></details>`:`<div class="dgsem">${list.map(dgRow).join('')}</div>`}</div>`:'';
  if(vw==='status'){
    const st=x=>{const e=dgE(x.key);return e&&e.now?'now':e&&e.g&&passG(e.g)?'done':(x.key!=='GED'||d.ged)&&preMet(x)?'can':x.key==='GED'?'can':'lock'};
    o+=grp('Taking now',core.filter(x=>st(x)==='now'));
    o+=grp('You can take',core.filter(x=>st(x)==='can'),'Prerequisites done. Courses you are taking now count as done here.');
    o+=`<div class="card dgyear"><div class="row between"><h2>Major electives</h2><span class="pill">${c.elList} of at least 3</span></div><p class="muted">Take at least 3 of these 7. Your other elective credits can be any course from any department: add them under Other courses.</p><div class="dgsem">${els.map(dgRow).join('')}</div></div>`;
    o+=grp('Not yet open',core.filter(x=>st(x)==='lock'),'Each shows what it still needs.',false);
    o+=grp('Done',core.filter(x=>st(x)==='done'),'',false);
  }else{
    o+=`<p class="muted" style="text-align:center">The course map’s suggested order. It is only a guide.</p>`;
    for(let y=1;y<=4;y++){o+=`<div class="card dgyear"><h2>Year ${y}</h2>`;for(let sm=y*3-2;sm<=y*3;sm++){const r=l.filter(x=>x.sem===sm);if(!r.length)continue;const dn=r.filter(x=>dgPassed(x.key)).length;o+=`<div class="dgsem"><div class="row between"><h3>Semester ${sm}</h3><span class="muted">${dn}/${r.length} done</span></div>${r.map(dgRow).join('')}</div>`}o+='</div>'}
  }
  o+=`<div class="card">${head('Other courses',addBtn('dgxAdd','Course'))}<p class="muted">Free electives from any department, or anything not on the map. They count toward your 18 elective credits and your CGPA.</p>${d.x.length?'<div class="list">'+d.x.map(x=>`<div class="item"><button class="tap" data-a="dgxEdit" data-id="${x.id}"><span class="t">${esc(x.code)}</span><span class="muted">${num(x.cr)} credits${x.t?' · '+esc(x.t):''}</span></button><span class="dgg${passG(x.g)?'':' bad'}">${esc(x.g)}</span></div>`).join('')+'</div>':''}</div>`;
  o+=`<div class="card">${head('Target',`<button class="btn sm" data-a="cgTarget2">${ic('edit')}Set</button>`)}${!tg?'<p class="muted">Set the CGPA you want. Catalyst works out the average you need in the credits you have left.</p>':need==null?'<p>You have finished your credits.</p>':`<p>To finish with <b>${tg.toFixed(2)}</b> you need an average of <b>${need>4?'more than 4.00':need<=0?'0.00':need.toFixed(2)}</b> in your remaining ${rm} credits.</p><p class="muted">${need>4?'Not reachable with the credits left. Retaking low grades can help.':need>3.7?'That means nearly all A and A-.':need<=0?'You are already above it.':'That is within reach.'}</p>`}</div>`;
  o+=`<div class="card"><h3>When I retake a course, count</h3><div class="chips wrapc">${['Latest grade','Better grade'].map(x=>`<button class="chip${s.retake===x?' on':''}" data-a="cgRule" data-v="${x}">${x}</button>`).join('')}</div><p class="muted">Open the course and add its old grade. It is counted once, by the rule your transcript follows.</p></div>`;
  o+=`<div class="card"><h3>NSU grading scale</h3><div class="list">${NSU.map(g=>`<div class="item"><span class="t" style="width:34px">${g[0]}</span><span class="grow muted">${g[2]}</span><span class="t">${g[1].toFixed(1)}</span></div>`).join('')}</div><p class="muted">W and I carry no grade points. F counts in your CGPA but earns no credits. Based on the BBT course map of the Department of Biochemistry & Microbiology.</p></div>`;
  o+=`<button class="btn sm" data-a="dgReset" style="align-self:center">Clear all course map grades</button>`;
  return o;
}
const _cgpa17=EXT.cgpa;
EXT.cgpa=()=>{const m=cgMode();return`<div class="card"><p class="muted">Work out my CGPA from</p><div class="chips wrapc">${[['map','BBT course map'],['sems','Current CGPA and semesters']].map(x=>`<button class="chip${m===x[0]?' on':''}" data-a="cgSrc" data-v="${x[0]}">${x[1]}</button>`).join('')}</div></div>`+(m==='map'?cgMapView():_cgpa17())};
const GOPT=[['','—'],['NOW','Now']].concat(NSU.map(g=>[g[0],g[0]])).concat([['W','W'],['I','I']]);
const dgF=(x)=>[['g','Grade (Now = taking it this semester)','select',{opts:GOPT}],['exp','Grade I am aiming for (if taking now)','select',{opts:[['','—']].concat(NSU.map(g=>[g[0],g[0]]))}],['old','Retake? Old grade','select',{opts:[['','No']].concat(NSU.map(g=>[g[0],g[0]]))}],['t','Semester','text',{ph:'Spring 2026'}]];
Object.assign(A,{
  cgSrc(d){S.settings.cgSrc=d.v;save('settings');render()},
  dgAlt(d){dgS().alt[d.k]=d.v;save('settings');render()},
  dgView(d){dgS().view=d.v;save('settings');render()},
  dgWaive(d){dgS().waive=+d.v;save('settings');render()},
  dgGed(d){const x=dgS();x.ged=d.v;save('settings');render()},
  dgEdit(d){const x=dgList().find(y=>y.key===d.id);if(!x)return;if(x.key==='GED'&&!dgS().ged){A.go({tab:'study',k:'study',v:'cgpa'});toast({title:'Pick your GED course first, under About you.',src:'CGPA',t:hm(nowMin())});return}
    const e=dgE(x.key)||{},v={g:e.now?'NOW':e.g||'',exp:e.exp||'',old:e.old||'',t:e.t||''};
    const miss=preMiss(x);
    form(x.code+' · '+x.cr+' credit'+(x.cr>1?'s':'')+(miss.length?' · needs '+miss.join(', ')+(labTheory(x)?' or '+labTheory(x):''):''),dgF(x),Object.assign({id:1},v),r=>{const c=dgS().c;if(!r.g){delete c[x.key]}else c[x.key]={g:r.g==='NOW'?'':r.g,now:r.g==='NOW'?1:0,exp:r.g==='NOW'?r.exp:'',old:r.old,t:r.t};save('settings');if(r.g&&r.g!=='NOW'&&passG(r.g))badgeCheck(true)},e.g||e.now?()=>{delete dgS().c[x.key];save('settings')}:null)},
  dgxAdd(){form('Other course',[['code','Course code','text',{req:true,ph:'PSY101'}],['cr','Credits','number',R],['g','Grade','select',{opts:NSU.map(g=>[g[0],g[0]]).concat([['W','W'],['I','I']])}],['old','Retake? Old grade','select',{opts:[['','No']].concat(NSU.map(g=>[g[0],g[0]]))}],['t','Semester','text',{ph:'Spring 2026'}]],{cr:3,g:'A'},v=>{v.code=String(v.code).toUpperCase().replace(/\s+/g,'');dgS().x.push(Object.assign({id:uid()},v));save('settings')})},
  dgxEdit(d){const l=dgS().x,x=l.find(y=>y.id===d.id);form('Other course',[['code','Course code','text',R],['cr','Credits','number',R],['g','Grade','select',{opts:NSU.map(g=>[g[0],g[0]]).concat([['W','W'],['I','I']])}],['old','Retake? Old grade','select',{opts:[['','No']].concat(NSU.map(g=>[g[0],g[0]]))}],['t','Semester','text']],x,v=>{Object.assign(x,v);save('settings')},()=>{dgS().x=l.filter(y=>y.id!==d.id);save('settings')})},
  cgTarget2(){form('Target CGPA',[['cgTarget','CGPA I want','number',R]],S.settings,v=>{S.settings.cgTarget=Math.min(4,v.cgTarget);save('settings')})},
  dgReset(){confirmSheet('Clear course map grades?','This removes every grade you entered on the course map. Your semesters and current CGPA stay.','Clear',()=>{const d=dgS();d.c={};d.x=[];save('settings');render()})}
});
/* degree card at the top of Courses */
const _cour17=EXT.courses;
EXT.courses=()=>{const h=_cour17();if(!dgUsed())return`<div class="card dgcta" role="button" tabindex="0" data-a="go" data-tab="study" data-k="study" data-v="cgpa"><div class="row">${ill('exam')}<div class="grow"><h3>Your BBT degree map</h3><p class="muted">Tick courses with grades to see your CGPA, credits left and what you can take next.</p></div>${ic('next')}</div></div>`+h;const c=dgCalc(false),r=dgReq();return`<div class="card dgcta" role="button" tabindex="0" data-a="go" data-tab="study" data-k="study" data-v="cgpa"><div class="row">${ring(c.earn/r,Math.round(c.earn/r*100)+'%','degree')}<div class="grow"><h3>${c.earn} of ${r} credits</h3><p class="muted">CGPA ${c.cr?c.g.toFixed(2):'–'} · ${dgNext().length} courses you can take next</p></div>${ic('next')}</div></div>`+h};
/* badge: halfway through the degree */
BADGES.push(['halfway','Halfway there','Earn half the credits of your degree','exam','sun',s=>[dgCalc(false).earn,Math.ceil(dgReq()/2)]],['graduate','Graduate','Earn every credit of your degree','medal','sun',s=>[dgCalc(false).earn,dgReq()]]);

/* ---------- citation from a DOI ---------- */
const doiOf=t=>{const m=String(t||'').match(/10\.\d{4,9}\/[^\s"<>]+/i);return m?m[0].replace(/[.,;)\]]+$/,''):''};
function csl2cite(m,doi){
  const au=(m.author||[]).map(a=>a.family?(a.family+(a.given?', '+a.given:'')):a.name?'['+a.name+']':'').filter(Boolean).join('\n');
  const dp=(m.issued&&m.issued['date-parts']&&m.issued['date-parts'][0])||(m.published&&m.published['date-parts']&&m.published['date-parts'][0])||(m['published-print']&&m['published-print']['date-parts'][0])||[];
  const t=String(m.type||''),arr=x=>Array.isArray(x)?x[0]:x;
  return{type:/book/.test(t)?'Book':'Journal article',authors:au,year:dp[0]?String(dp[0]):'',title:String(arr(m.title)||'').replace(/<[^>]+>/g,'').trim(),source:String(arr(m['container-title'])||m.publisher||'').trim(),vol:String(m.volume||''),issue:String(m.issue||''),pages:String(m.page||''),doi:doi,proj:''};
}
async function doiFetch(raw){
  const doi=doiOf(raw);if(!doi){say('doi','That does not look like a DOI. It starts with 10. and has a slash, like 10.1016/j.foodcont.2021.108123.');return}
  say('doi','Looking up '+doi+'…');let m=null;
  try{const r=await fetch('https://api.crossref.org/works/'+encodeURIComponent(doi));if(r.ok)m=(await r.json()).message}catch(e){}
  if(!m)try{const r=await fetch('https://doi.org/'+doi,{headers:{Accept:'application/vnd.citationstyles.csl+json'}});if(r.ok)m=await r.json()}catch(e){}
  if(!m){say('doi',navigator.onLine===false?'You are offline. Connect to the internet and try again.':'Could not find that DOI, or this view cannot reach the internet. In the Catalyst app it works when you are online.');return}
  say('doi','');const v=csl2cite(m,doi);
  form('Check and save',ctF(),v,x=>{upsert('cites',null,x);celebrate('Citation added')});
}
Q.doi=function(){const el=document.getElementById('q_doi');if(el&&el.value.trim()){doiFetch(el.value.trim());el.value=''}};
const _cite17=EXT.cite;
EXT.cite=()=>`<div class="card c-sky"><h3>Add from a DOI</h3><form class="quick" data-f="doi"><input id="q_doi" placeholder="Paste a DOI or the paper’s link" aria-label="DOI or link" autocomplete="off"><button class="btn pri">Find</button></form>${said('doi')}<p class="muted">Catalyst fills in the authors, year, title, journal, volume, issue and pages for you to check. Needs internet.</p></div>`+_cite17();

/* tips and Bangla */
TUT['study/cgpa']=[[null,'CGPA and degree map','Your BBT courses with prerequisites. Tap a course to add its grade, or mark it Now if you are taking it. Take them in any order once prerequisites are done.'],['.cghero','Where you stand','CGPA, credits earned out of 120 or 123, and your progress in each part of the degree.']];
TUT['study/cite']=[[null,'Citations','Paste a DOI and Catalyst fills the reference for you. Copy everything in APA 7 style.']];
Object.assign(BN,{'You can take':'যে কোর্স নিতে পারবেন','Taking now':'এখন করছি','Major electives':'মেজর ইলেক্টিভ','Not yet open':'এখনো খোলেনি','Done':'শেষ','By progress':'অগ্রগতি অনুযায়ী','Suggested plan':'প্রস্তাবিত পরিকল্পনা','About you':'আপনার তথ্য','Other courses':'অন্যান্য কোর্স','Can take':'নিতে পারবেন','Pick one':'একটি বেছে নিন','Add from a DOI':'DOI থেকে যোগ করুন','Find':'খুঁজুন','Check and save':'দেখে সেভ করুন','Target':'লক্ষ্য','Clear all course map grades':'কোর্স ম্যাপের সব গ্রেড মুছুন','BBT course map':'BBT কোর্স ম্যাপ','Current CGPA and semesters':'বর্তমান CGPA ও সেমিস্টার','Work out my CGPA from':'CGPA হিসাব হবে'});
BNP.push([/^Year (\d)$/,'বর্ষ $1'],[/^Semester (\d+)$/,'সেমিস্টার $1']);
window.__v17={calc:dgCalc,next:dgNext,list:dgList,csl:csl2cite,doiOf:doiOf};


/* ================= v18: Bangladesh Ramadan, online prayer times, PDF websites, primer, gel, chemical safety, pathways, papers, thesis, daily quiz, petri dish ================= */

/* ---------- Bangladesh calendar: Hijri date usually a day behind Saudi Arabia ---------- */
const hjA=()=>S.settings.hjAdj==null||S.settings.hjAdj===''?(CITY[S.settings.city]||!S.settings.city?-1:0):+S.settings.hjAdj;
const _hjOf18=hijriOf;
hijriOf=function(d){return _hjOf18(addDays(d,hjA()))};
hijriParts=function(){return hijriOf(today())};
const ramStartSet=()=>{const r=S.settings.ramStart;return/^\d{4}-\d{2}-\d{2}$/.test(r||'')?r:''};
const _isRam18=isRam;
isRam=function(d){const s=S.settings,x=d||today(),st=ramStartSet();if(s.deenOff||s.ramOn==='off')return false;if(s.ramOn==='on')return true;if(st){const n=diffDays(x,st);if(n>=0&&n<(s.ramEnd&&s.ramEnd>=st?diffDays(s.ramEnd,st)+1:30))return true;if(n>=0&&n<45)return false}return _isRam18(x)};
const _ramDays18=ramDays;
ramDays=function(){const st=ramStartSet();if(st&&diffDays(today(),st)>=0&&diffDays(today(),st)<45){const n=S.settings.ramEnd&&S.settings.ramEnd>=st?diffDays(S.settings.ramEnd,st)+1:30;return Array.from({length:n},(x,i)=>addDays(st,i))}return _ramDays18()};
/* Islamic Foundation Bangladesh: sehri ends 3 minutes before dawn, iftar 3 minutes after sunset */
const sehriT=ds=>hm(toMin(ptimes(ds).fajr)-3),iftarT=ds=>hm(toMin(ptimes(ds).maghrib)+3);
ramCount=function(){const t=today(),n=nowMin(),f=toMin(sehriT(t)),m=toMin(iftarT(t));if(n<f)return['Sehri ends in',dur(f-n),tfmt(sehriT(t))];if(n<m)return['Iftar in',dur(m-n),tfmt(iftarT(t))];const t2=addDays(t,1);return['Sehri ends in',dur(toMin(sehriT(t2))+1440-n),tfmt(sehriT(t2))]};
const _ram18=EXT.ramadan;
EXT.ramadan=()=>{
  const t=today(),pt=ptimes(t),s=S.settings,h=hijriOf(t),st=ramStartSet();let o=_ram18();
  o=o.split(`${stat(tfmt(pt.fajr),'Sehri ends')}${stat(tfmt(pt.maghrib),'Iftar')}`).join(`${stat(tfmt(sehriT(t)),'Sehri ends')}${stat(tfmt(iftarT(t)),'Iftar')}`);
  o=o.replace(/<p class="muted">Sehri ends at Fajr time and iftar is at Maghrib[^<]*<\/p>/,`<p class="muted">Following the Islamic Foundation Bangladesh: sehri ends 3 minutes before dawn (Subh Sadiq) and iftar is 3 minutes after sunset, for ${esc(s.city||'your city')}. ${ptOnline()?'Times were updated online.':'Times are calculated on your phone and update online when you connect.'}</p>`);
  o=o.replace(/<p class="muted">The start date follows the Umm al-Qura[^<]*<\/p>/,'');
  const adj=hjA();
  o=o.replace('</div></div>',`</div></div><p class="muted">Follows the moon sighting in Bangladesh, which usually starts Ramadan a day after Saudi Arabia. Today here is <b>${h?h.d+' '+HM[h.m-1]+' '+h.y:''}</b>.</p><p class="muted">Adjust the Islamic date</p><div class="chips wrapc">${[[-2,'−2 days'],[-1,'−1 day'],[0,'Same as Saudi'],[1,'+1 day']].map(x=>`<button class="chip${adj===x[0]?' on':''}" data-a="hjAdj" data-n="${x[0]}">${x[1]}</button>`).join('')}</div><div class="row wrap"><button class="btn sm" data-a="ramBegin">Ramadan began today</button><button class="btn sm" data-a="ramSetStart">${st?'Start: '+fmt(st):'Set the start date'}</button>${isRam(t)?'<button class="btn sm" data-a="ramEid">Eid was announced</button>':''}</div>`);
  return o;
};
const _ag18=agenda;
agenda=function(ds){const a=_ag18(ds),s=S.settings;a.forEach(x=>{if(x.key==='ram-i')x.t=iftarT(ds);if(x.key==='ram-s'){x.t=hm(toMin(sehriT(ds))-(+s.sehriMin||45));x.title='Time for sehri. Sehri ends at '+tfmt(sehriT(ds))}});return a.sort((x,y)=>x.t<y.t?-1:1)};
Object.assign(A,{
  hjAdj(d){S.settings.hjAdj=+d.n;save('settings');render()},
  ramBegin(){S.settings.ramStart=today();S.settings.ramEnd='';S.settings.ramOn='auto';save('settings');render();celebrate('Ramadan Mubarak')},
  ramSetStart(){form('When did Ramadan start in Bangladesh?',[['ramStart','First day of fasting','date',R]],{ramStart:ramStartSet()||today()},v=>{S.settings.ramStart=v.ramStart;S.settings.ramEnd='';save('settings')})},
  ramEid(){S.settings.ramEnd=addDays(today(),-1);save('settings');render();celebrate('Eid Mubarak')}
});

/* ---------- prayer times refresh online (Karachi method, Hanafi), kept for offline ---------- */
const PTK='catalyst.pt';
const ptStore=()=>{try{return JSON.parse(localStorage.getItem(PTK)||'{}')||{}}catch(e){return{}}};
const ptLoc=()=>{const s=S.settings;return(+s.lat).toFixed(3)+','+(+s.lng).toFixed(3)+','+(s.asr==='Shafi'?0:1)};
let ptMem=null;
function ptGet(ds){if(!ptMem)ptMem=ptStore();const m=ptMem[ptLoc()+'|'+ds.slice(0,7)];return m&&m[+ds.slice(8)]}
const ptOnline=()=>!!ptGet(today());
const _pt18=ptimes;
ptimes=function(ds){const o=ptGet(ds);if(o)return o;return _pt18(ds)};
async function ptFetch(force){
  if(navigator.onLine===false)return;const s=S.settings;if(!s.lat)return;const st=ptStore();if(!force&&st._d===today()&&st._l===ptLoc())return;
  const loc=ptLoc(),months=[today(),addDays(today(),32)].map(d=>d.slice(0,7));let got=0;
  for(const ym of months){try{
    const r=await fetch(`https://api.aladhan.com/v1/calendar/${ym.slice(0,4)}/${+ym.slice(5)}?latitude=${s.lat}&longitude=${s.lng}&method=1&school=${s.asr==='Shafi'?0:1}`);if(!r.ok)continue;
    const j=await r.json(),days={};(j.data||[]).forEach(x=>{const d=+x.date.gregorian.day,t=x.timings,c=k=>String(t[k]||'').slice(0,5);if(/^\d\d:\d\d$/.test(c('Fajr')))days[d]={fajr:c('Fajr'),sunrise:c('Sunrise'),dhuhr:c('Dhuhr'),asr:c('Asr'),maghrib:c('Maghrib'),isha:c('Isha')}});
    if(Object.keys(days).length>25){st[loc+'|'+ym]=days;got++}
  }catch(e){}}
  if(got){Object.keys(st).forEach(k=>{if(k[0]!=='_'&&(k.split('|')[0]!==loc||k.split('|')[1]<today().slice(0,7)))delete st[k]});st._d=today();st._l=loc;try{localStorage.setItem(PTK,JSON.stringify(st))}catch(e){}ptMem=null;try{ptc={}}catch(e){}render();try{nativeSync()}catch(e){}}
}
setTimeout(()=>ptFetch(false),2500);
window.addEventListener('online',()=>ptFetch(false));
const _deen18=VIEWS.deen;
VIEWS.deen=()=>_deen18().replace('Times are calculated for your city and can differ from your mosque by a minute or two.',ptOnline()?'Times were updated online for your city (University of Islamic Sciences, Karachi method, used in Bangladesh). They can differ from your mosque by a minute or two.':'Times are calculated on your phone and update online whenever you connect. They can differ from your mosque by a minute or two.');

/* ---------- PDF tools: online converters ---------- */
const PDFW=[['Word to PDF','word_to_pdf'],['PowerPoint to PDF','powerpoint_to_pdf'],['Excel to PDF','excel_to_pdf'],['PDF to Word','pdf_to_word'],['PDF to PowerPoint','pdf_to_powerpoint'],['Compress PDF','compress_pdf'],['Merge PDF','merge_pdf'],['Split PDF','split_pdf'],['Images to PDF','jpg_to_pdf'],['PDF to images','pdf_to_jpg'],['Rotate PDF','rotate_pdf']];
const _tools18=EXT.tools;
EXT.tools=()=>`<div class="card c-sky"><h2>Convert online</h2><p class="muted">Opens iLovePDF, a free converter website, for conversions a phone cannot do by itself, like Word or PowerPoint to PDF. Your file is uploaded to their site, so avoid private documents. Needs internet.</p><div class="pdfw">${PDFW.map(x=>`<a class="btn sm" href="https://www.ilovepdf.com/${x[1]}" target="_blank" rel="noopener">${x[0]}</a>`).join('')}</div></div>`+_tools18().replace(/<div class="card"><h3>Word or PowerPoint to PDF<\/h3>[\s\S]*?<\/div>/,'').replace('<h2>PDF tools</h2><p class="muted">Everything runs on your phone. Your files are not sent anywhere.</p>','<h2>On your phone</h2><p class="muted">Merge, split and photos to PDF work offline. Your files stay on your phone.</p>');

/* ---------- Lab: primer checker ---------- */
const NNT={AA:[-7.9,-22.2],TT:[-7.9,-22.2],AT:[-7.2,-20.4],TA:[-7.2,-21.3],CA:[-8.5,-22.7],TG:[-8.5,-22.7],GT:[-8.4,-22.4],AC:[-8.4,-22.4],CT:[-7.8,-21.0],AG:[-7.8,-21.0],GA:[-8.2,-22.2],TC:[-8.2,-22.2],CG:[-10.6,-27.2],GC:[-9.8,-24.4],GG:[-8.0,-19.9],CC:[-8.0,-19.9]};
const rcomp=s=>s.split('').reverse().map(c=>({A:'T',T:'A',G:'C',C:'G'})[c]||'N').join('');
function primerInfo(raw){
  const s=String(raw||'').toUpperCase().replace(/[^A-Z]/g,'');if(!s)return null;if(/[^ACGT]/.test(s))return{err:'Use only A, C, G and T.'};
  const n=s.length,gc=(s.match(/[GC]/g)||[]).length,at=n-gc;let dH=0,dS=0;
  for(let i=0;i<n-1;i++){const v=NNT[s.substr(i,2)];dH+=v[0];dS+=v[1]}
  [s[0],s[n-1]].forEach(e=>{if(e==='G'||e==='C'){dH+=.1;dS+=-2.8}else{dH+=2.3;dS+=4.1}});
  const na=.05,ct=250e-9;dS+=.368*(n-1)*Math.log(na);
  const tmNN=n>1?dH*1000/(dS+1.987*Math.log(ct/4))-273.15:0,tmBasic=n<14?2*at+4*gc:64.9+41*(gc-16.4)/n;
  const warn=[],good=[];
  if(n<18)warn.push('Short. Primers usually work best at 18 to 25 bases.');else if(n>30)warn.push('Long. Over 30 bases can bind loosely elsewhere.');else good.push('Length is good.');
  const g=gc/n*100;if(g<40||g>60)warn.push('GC content '+g.toFixed(0)+'% is outside the usual 40 to 60%.');else good.push('GC content is in the 40 to 60% range.');
  const end5=s.slice(-5),gce=(end5.match(/[GC]/g)||[]).length;if(gce>3)warn.push('More than 3 G or C in the last 5 bases at the 3′ end can cause mispriming.');else if(!/[GC]$/.test(s))warn.push('No G or C clamp at the 3′ end. Ending in G or C helps it bind firmly.');else good.push('Has a 3′ G/C clamp.');
  const run=s.match(/(A{4,}|C{4,}|G{4,}|T{4,})/);if(run)warn.push('Run of '+run[0].length+' '+run[0][0]+'s. Avoid 4 or more of the same base.');
  const rep=s.match(/(..)\1{3,}/);if(rep)warn.push('Repeat of '+rep[1]+'. Avoid 4 or more dinucleotide repeats.');
  const rc=rcomp(s);let hp=0;for(let L=4;L<=Math.min(8,n);L++)for(let i=0;i+L<=n;i++){const sub=s.substr(i,L),j=s.indexOf(rcomp(sub));if(j>=0&&Math.abs(j-i)>=L+3)hp=Math.max(hp,L)}
  if(hp>=4)warn.push('Possible hairpin: a '+hp+'-base stretch can pair with another part of itself.');
  const t4=s.slice(-4);if(rc.indexOf(t4)>=0||s.indexOf(rcomp(t4))>=0)warn.push('Possible self-dimer at the 3′ end.');
  return{s:s,n:n,gc:g,tm:tmNN,tmb:tmBasic,rc:rc,mw:s.split('').reduce((a,c)=>a+{A:313.21,C:289.18,G:329.21,T:304.2}[c],0)-61.96,warn:warn,good:good};
}
function crossDimer(a,b){const t=a.s.slice(-4),u=b.s.slice(-4);return b.s.indexOf(rcomp(t))>=0||a.s.indexOf(rcomp(u))>=0}
ui.pr1=ui.pr1||'';ui.pr2=ui.pr2||'';
EXT.lab_primer=()=>{
  const a=primerInfo(ui.pr1),b=primerInfo(ui.pr2);
  const box=(p,k,label)=>`<label>${label}<textarea data-c="${k}" class="seq" placeholder="5′ ATGCGTACCTGAAGCTTGCA 3′" aria-label="${label}">${esc(ui[k==='pr1'?'pr1':'pr2'])}</textarea></label>${!p?'':p.err?`<p style="color:var(--bad)">${p.err}</p>`:`<div class="g3">${stat(p.tm.toFixed(1)+' °C','Tm (nearest-neighbour)')}${stat(p.gc.toFixed(0)+'%','GC')}${stat(p.n,'bases')}</div><p class="muted">Basic formula Tm ${p.tmb.toFixed(1)} °C · MW ${Math.round(p.mw).toLocaleString()} g/mol · reverse complement <span class="mono">${p.rc}</span></p>${p.good.map(x=>`<p class="pok">✓ ${x}</p>`).join('')}${p.warn.map(x=>`<p class="pwarn">⚠ ${x}</p>`).join('')}`}`;
  let pair='';if(a&&b&&!a.err&&!b.err){const d=Math.abs(a.tm-b.tm),x=crossDimer(a,b);pair=`<div class="card ${d<=5&&!x?'c-leaf':'c-sun'}"><h3>As a pair</h3><p>${d<=5?'✓ Tm values are within 5 °C of each other.':'⚠ Tm values differ by '+d.toFixed(1)+' °C. Keep them within 5 °C.'}</p><p>${x?'⚠ The 3′ ends may pair with each other (primer-dimer).':'✓ No 3′ end pairing found between them.'}</p><p class="muted">A good starting annealing temperature is about ${(Math.min(a.tm,b.tm)-5).toFixed(0)} °C, 5 °C below the lower Tm. Run a gradient PCR to fine-tune it.</p></div>`}
  return`<div class="card"><h2>Primer checker</h2>${box(a,'pr1','Forward primer')}${box(b,'pr2','Reverse primer (optional)')}</div>${pair}<p class="muted">Tm uses SantaLucia nearest-neighbour values at 50 mM Na⁺ and 250 nM primer. Your polymerase kit’s calculator may differ by a few degrees.</p>`;
};
document.addEventListener('input',e=>{const k=e.target.dataset&&e.target.dataset.c;if(k==='pr1'||k==='pr2'){ui[k]=e.target.value;clearTimeout(window.__prT);window.__prT=setTimeout(()=>{const el=document.activeElement,pos=el&&el.selectionStart;render();const n=document.querySelector('[data-c="'+k+'"]');if(n){n.focus();try{n.setSelectionRange(pos,pos)}catch(x){}}},500)}});

/* ---------- Lab: gel band sizer ---------- */
const LADD={'1 kb DNA ladder (bp)':[10000,8000,6000,5000,4000,3500,3000,2500,2000,1500,1000,750,500,250],'100 bp DNA ladder (bp)':[1000,900,800,700,600,500,400,300,200,100],'Protein marker (kDa)':[250,150,100,75,50,37,25,20,15,10]};
ui.gel=ui.gel||{lad:'1 kb DNA ladder (bp)',d:{},u:''};
function gelFit(){const g=ui.gel,L=LADD[g.lad]||[],pts=L.map((s,i)=>[num(g.d[i]),Math.log10(s)]).filter(p=>p[0]>0);if(pts.length<3)return null;const n=pts.length,mx=pts.reduce((a,p)=>a+p[0],0)/n,my=pts.reduce((a,p)=>a+p[1],0)/n;let sxy=0,sxx=0,syy=0;pts.forEach(p=>{sxy+=(p[0]-mx)*(p[1]-my);sxx+=(p[0]-mx)**2;syy+=(p[1]-my)**2});const m=sxy/sxx,c=my-m*mx;return{m:m,c:c,r2:sxy*sxy/(sxx*syy),lo:Math.min(...pts.map(p=>p[0])),hi:Math.max(...pts.map(p=>p[0]))}}
EXT.lab_gel=()=>{
  const g=ui.gel,L=LADD[g.lad]||[],f=gelFit(),unk=String(g.u||'').split(/[,\s]+/).map(num).filter(x=>x>0),unit=/kDa/.test(g.lad)?'kDa':'bp';
  return`<div class="card"><h2>Gel band sizer</h2><p class="muted">Measure from the bottom of each well to the middle of each band, in mm. Fill in at least 3 ladder bands you can see clearly.</p><div class="chips wrapc">${Object.keys(LADD).map(k=>`<button class="chip${g.lad===k?' on':''}" data-a="gelLad" data-v="${esc(k)}">${k}</button>`).join('')}</div>
  <div class="gelg">${L.map((s,i)=>`<label>${s.toLocaleString()}<input data-gel="${i}" inputmode="decimal" value="${esc(g.d[i]||'')}" placeholder="mm"></label>`).join('')}</div>
  <label>Your bands (mm), separated by commas<input data-gel="u" inputmode="decimal" value="${esc(g.u||'')}" placeholder="22, 31.5"></label></div>
  ${f?`<div class="card c-leaf"><h3>Estimated sizes</h3>${unk.length?'<div class="list">'+unk.map(x=>{const v=Math.pow(10,f.m*x+f.c),out=x<f.lo||x>f.hi;return`<div class="item"><span class="t grow">${x} mm</span><span class="big" style="font-size:22px">≈ ${v>=100?Math.round(v).toLocaleString():v.toFixed(1)} ${unit}</span>${out?'<span class="pill bad">outside ladder</span>':''}</div>`}).join('')+'</div>':'<p class="muted">Type your band distances above.</p>'}<p class="muted">Fit: log(size) vs distance, R² = ${f.r2.toFixed(3)}${f.r2<.97?'. Below 0.97: re-check your measurements.':'.'} Bands outside the ladder range are less reliable.</p></div>`:'<p class="muted">Enter at least 3 ladder distances to see estimates.</p>'}
  <button class="btn sm" data-a="gelReset" style="align-self:flex-start">Clear</button><p class="muted">Ladder sizes follow common 1 kb and 100 bp ladders and a common protein marker. Check the sizes printed on your own ladder’s sheet.</p>`;
};
document.addEventListener('input',e=>{const k=e.target.dataset&&e.target.dataset.gel;if(k==null)return;if(k==='u')ui.gel.u=e.target.value;else ui.gel.d[k]=e.target.value;clearTimeout(window.__gT);window.__gT=setTimeout(()=>{const id=k,pos=e.target.selectionStart;render();const n=document.querySelector('[data-gel="'+id+'"]');if(n){n.focus();try{n.setSelectionRange(pos,pos)}catch(x){}}},700)});
Object.assign(A,{gelLad(d){ui.gel.lad=d.v;ui.gel.d={};render()},gelReset(){ui.gel={lad:ui.gel.lad,d:{},u:''};render()}});

/* ---------- Lab: chemical safety ---------- */
const CHEM=[
 ['Phenol','toxic,corrosive','Toxic through the skin and causes severe burns that may not hurt at first.','Double nitrile gloves, goggles, lab coat. Work in the fume hood.','Hazardous chemical waste. Never down the sink.'],
 ['Chloroform','toxic,health','Harmful if breathed in or swallowed. Suspected of causing cancer. Damages liver and kidneys.','Fume hood, goggles. It passes through nitrile quickly: change gloves at once after a splash.','Halogenated solvent waste.'],
 ['Phenol:chloroform:isoamyl alcohol','toxic,corrosive,health','Combines the hazards of phenol and chloroform.','Fume hood, double gloves, goggles.','Halogenated organic waste.'],
 ['TRIzol (phenol + guanidine)','toxic,corrosive','Toxic and corrosive. Never mix with bleach: it can release toxic gas.','Fume hood, gloves, goggles.','Its own waste bottle. Keep away from bleach and acids.'],
 ['Guanidine thiocyanate / guanidine HCl','toxic','Harmful if swallowed or on skin. With bleach or acid it can release toxic gases.','Gloves, goggles.','Chemical waste. Never mix with bleach.'],
 ['Ethidium bromide (EtBr)','health,toxic','Binds DNA and is a suspected mutagen. Irritant.','Nitrile gloves, a dedicated EtBr bench and pipettes. UV shield when viewing.','EtBr waste container or destaining filter, as your lab directs.'],
 ['SYBR Safe / GelRed','irritant','Lower hazard than EtBr but still binds DNA.','Gloves.','Follow your lab’s gel waste rule.'],
 ['Acrylamide (unpolymerised)','toxic,health','Neurotoxin and probable carcinogen. Absorbed through skin.','Gloves, goggles. Use ready-made solution rather than powder. Mask if weighing powder.','Polymerise leftover solution before disposal, then solid chemical waste.'],
 ['TEMED','flammable,corrosive,toxic','Flammable, corrosive and harmful if breathed in.','Fume hood, gloves, goggles.','Chemical waste.'],
 ['Ammonium persulfate (APS)','oxidizer,irritant,health','Strong oxidiser. Can cause allergy and asthma-like reactions.','Gloves, goggles. Make fresh and keep small amounts.','Chemical waste, away from flammables.'],
 ['SDS (sodium dodecyl sulfate)','flammable,irritant','Powder irritates lungs, eyes and skin. Flammable solid.','Mask or weigh in a hood, gloves, goggles.','Small amounts in solution: as your lab directs.'],
 ['β-Mercaptoethanol','toxic,environment','Toxic by skin contact and breathing. Strong bad smell.','Fume hood only, gloves, goggles.','Chemical waste.'],
 ['DTT (dithiothreitol)','irritant','Harmful if swallowed. Irritates eyes and skin.','Gloves, goggles.','Chemical waste.'],
 ['Formaldehyde / formalin','toxic,corrosive,health','Causes cancer, toxic, and can cause skin and breathing allergy.','Fume hood, gloves, goggles.','Formaldehyde waste container.'],
 ['Glutaraldehyde','toxic,corrosive,health','Toxic and a strong sensitiser.','Fume hood, gloves, goggles.','Chemical waste.'],
 ['Methanol','flammable,toxic,health','Highly flammable. Toxic if swallowed, breathed or on skin: can cause blindness.','Fume hood, gloves, no flames.','Flammable solvent waste.'],
 ['Ethanol','flammable','Highly flammable liquid and vapour.','Keep away from the Bunsen flame. Small amounts on the bench.','Flammable solvent waste for large volumes.'],
 ['Isopropanol','flammable,irritant','Highly flammable. Irritates eyes. Can cause drowsiness.','No flames, goggles.','Flammable solvent waste.'],
 ['Acetone','flammable,irritant','Highly flammable. Irritates eyes.','No flames, good airflow.','Flammable solvent waste.'],
 ['Hydrochloric acid (conc.)','corrosive','Severe burns. Gives off irritating fumes.','Fume hood, goggles, gloves. Add acid to water, never water to acid.','Neutralise if your lab allows, or acid waste.'],
 ['Sulfuric acid (conc.)','corrosive','Severe burns. Mixing with water releases a lot of heat.','Goggles, gloves, apron. Add acid slowly to water.','Acid waste.'],
 ['Nitric acid','corrosive,oxidizer','Severe burns and a strong oxidiser.','Fume hood, goggles, gloves. Keep away from organics.','Separate acid waste. Never mix with organic waste.'],
 ['Glacial acetic acid','flammable,corrosive','Flammable and causes severe burns. Strong vapour.','Fume hood, gloves, goggles.','Acid waste.'],
 ['Trichloroacetic acid (TCA)','corrosive,environment','Causes severe burns.','Gloves, goggles.','Chemical waste.'],
 ['Sodium hydroxide','corrosive','Causes severe skin burns and eye damage. Pellets heat up when dissolving.','Goggles are a must, gloves.','Neutralise if your lab allows, or base waste.'],
 ['Hydrogen peroxide (30%)','oxidizer,corrosive','Strong oxidiser. Causes serious eye damage.','Goggles, gloves.','Dilute as your lab directs.'],
 ['Sodium hypochlorite (bleach)','corrosive,environment','Corrosive. Releases toxic gas with acids, ammonia or guanidine.','Gloves, goggles. Never mix with other chemicals.','Down the sink with plenty of water only if your lab allows.'],
 ['Crystal violet','health,environment','Harmful if swallowed, causes serious eye damage, suspected of causing cancer.','Gloves, goggles.','Collect stain waste as your lab directs.'],
 ['Safranin','irritant','Irritant. Stains skin.','Gloves.','Stain waste.'],
 ['Gram’s iodine / Lugol’s','irritant','Harmful and irritant. Stains.','Gloves.','Stain waste.'],
 ['Malachite green','toxic,environment','Harmful if swallowed, eye damage, very toxic to water life.','Gloves, goggles.','Stain waste, never down the sink.'],
 ['DNS reagent','corrosive','Contains sodium hydroxide: corrosive to eyes and skin.','Goggles, gloves.','Chemical waste.'],
 ['Coomassie stain / destain','flammable,toxic','Usually contains methanol and acetic acid: flammable and toxic.','Fume hood or good airflow, gloves.','Solvent waste.'],
 ['Bradford reagent','corrosive,flammable','Contains phosphoric acid and alcohol.','Gloves, goggles.','Chemical waste.'],
 ['Folin–Ciocalteu reagent','corrosive','Corrosive acid mixture.','Gloves, goggles.','Chemical waste.'],
 ['Ninhydrin','irritant','Harmful if swallowed. Irritant. Stains skin purple.','Gloves.','Chemical waste.'],
 ['Benedict’s / Fehling’s reagent','irritant,environment','Copper salts are harmful and toxic to water life. Fehling’s B contains NaOH: corrosive.','Gloves, goggles.','Heavy metal waste.'],
 ['Silver nitrate','corrosive,oxidizer,environment','Corrosive, oxidiser, stains skin black, toxic to water life.','Gloves, goggles.','Heavy metal waste.'],
 ['Potassium dichromate / chromic acid','toxic,health,oxidizer,environment','Causes cancer and genetic damage. Strong oxidiser.','Fume hood, gloves, goggles. Use a safer alternative if possible.','Chromium waste.'],
 ['DMSO','irritant','Passes through skin and carries other chemicals with it.','Nitrile gloves, change if splashed.','Solvent waste.'],
 ['DAPI','health','Binds DNA, possible mutagen.','Gloves.','Chemical waste.'],
 ['Triton X-100','irritant,environment','Harmful if swallowed, serious eye damage, toxic to water life.','Gloves, goggles.','Chemical waste.'],
 ['EDTA','health','Harmful if dust is breathed in repeatedly.','Gloves, avoid dust.','Small amounts as your lab directs.'],
 ['Ampicillin','health','Can cause allergy in sensitive people.','Gloves, avoid dust.','Chemical or biohazard waste as directed.'],
 ['Kanamycin','health','May damage the unborn child.','Gloves, avoid dust.','Chemical waste.'],
 ['Chloramphenicol','health','Suspected of causing cancer.','Gloves, avoid dust.','Chemical waste.'],
 ['Proteinase K / lysozyme','health','Enzyme powders can cause breathing allergy.','Avoid dust, gloves.','As your lab directs.'],
 ['Liquid nitrogen','cold','−196 °C: severe cold burns. Can push out oxygen in closed rooms.','Cryo gloves, face shield, good airflow. Never seal in a closed container.','Let it evaporate in a well-ventilated place.'],
 ['Dry ice','cold','−78 °C: cold burns. CO₂ gas can build up.','Insulated gloves. Never in airtight containers or small closed rooms.','Let it sublime in a ventilated place.'],
 ['Hot agarose','burn','Can boil over suddenly in the microwave.','Heat-proof glove, swirl gently, short heating bursts.','Solid gel waste as your lab directs.'],
 ['Bacterial cultures (E. coli, etc.)','bio','Even lab strains can cause infection in the wrong place.','Gloves, aseptic technique, no mouth pipetting.','Autoclave before disposal.']
];
const HZ={toxic:['Toxic','tomato'],corrosive:['Corrosive','tomato'],flammable:['Flammable','sun'],oxidizer:['Oxidiser','sun'],health:['Health hazard','grape'],irritant:['Irritant','sky'],environment:['Water life','leaf'],cold:['Cryogenic','sky'],burn:['Burn risk','sun'],bio:['Biohazard','pink']};
ui.chq=ui.chq||'';
EXT.lab_safety=()=>{const q=ui.chq.toLowerCase().trim(),l=CHEM.filter(c=>!q||c[0].toLowerCase().indexOf(q)>=0||c[1].indexOf(q)>=0);
  return`<input data-c="chq" placeholder="Search a chemical: phenol, EtBr, SDS…" aria-label="Search chemicals" value="${esc(ui.chq)}"><div class="chips wrapc">${Object.keys(HZ).map(k=>`<button class="chip${q===k?' on':''}" data-a="chqSet" data-v="${k}">${HZ[k][0]}</button>`).join('')}</div>
  ${l.map(c=>`<details class="card chem"><summary><span class="grow"><b>${esc(c[0])}</b><span class="hzs">${c[1].split(',').map(h=>`<i class="hz t-${HZ[h][1]}">${HZ[h][0]}</i>`).join('')}</span></span>${ic('next')}</summary><p>${esc(c[2])}</p><p><b>Protect yourself:</b> ${esc(c[3])}</p><p><b>Disposal:</b> ${esc(c[4])}</p></details>`).join('')||'<div class="card"><p class="muted">Not in the list. Check the chemical’s Safety Data Sheet (SDS).</p></div>'}
  <p class="muted">A quick guide only. Always read the Safety Data Sheet and follow your lab instructor’s rules.</p>`};
document.addEventListener('input',e=>{if(e.target.dataset&&e.target.dataset.c==='chq'){ui.chq=e.target.value;clearTimeout(window.__cT);window.__cT=setTimeout(()=>{const pos=e.target.selectionStart;render();const n=document.querySelector('[data-c="chq"]');if(n){n.focus();try{n.setSelectionRange(pos,pos)}catch(x){}}},350)}});
A.chqSet=d=>{ui.chq=ui.chq===d.v?'':d.v;render()};
SUB.lab.splice(1,0,['primer','Primer'],['gel','Gel sizer'],['safety','Chem safety']);
{const g=MENU.find(x=>x[0]==='Lab');if(g)g[1].push(['lab','lab','primer','Primer checker','sun'],['lab','lab','gel','Gel band sizer','sun'],['lab','lab','safety','Chemical safety','sun'])}

/* ---------- Study: pathway explorer ---------- */
const PW=[
 ['Glycolysis','Cytosol. Glucose to 2 pyruvate. Net 2 ATP and 2 NADH.',[
  ['Glucose → Glucose-6-phosphate','Hexokinase (glucokinase in liver)','Uses 1 ATP. Irreversible. Hexokinase is inhibited by glucose-6-phosphate.'],
  ['Glucose-6-phosphate → Fructose-6-phosphate','Phosphoglucose isomerase','Reversible isomerisation.'],
  ['Fructose-6-phosphate → Fructose-1,6-bisphosphate','Phosphofructokinase-1 (PFK-1)','Uses 1 ATP. Rate-limiting step. Activated by AMP and fructose-2,6-bisphosphate; inhibited by ATP and citrate.'],
  ['Fructose-1,6-bisphosphate → DHAP + Glyceraldehyde-3-phosphate','Aldolase','Splits the 6-carbon sugar into two 3-carbon sugars.'],
  ['DHAP → Glyceraldehyde-3-phosphate','Triose phosphate isomerase','Now there are 2 glyceraldehyde-3-phosphate per glucose.'],
  ['Glyceraldehyde-3-phosphate → 1,3-Bisphosphoglycerate','Glyceraldehyde-3-phosphate dehydrogenase','Makes NADH (2 per glucose). Uses inorganic phosphate.'],
  ['1,3-Bisphosphoglycerate → 3-Phosphoglycerate','Phosphoglycerate kinase','Makes ATP by substrate-level phosphorylation (2 per glucose).'],
  ['3-Phosphoglycerate → 2-Phosphoglycerate','Phosphoglycerate mutase','Moves the phosphate group.'],
  ['2-Phosphoglycerate → Phosphoenolpyruvate','Enolase','Removes water. Inhibited by fluoride.'],
  ['Phosphoenolpyruvate → Pyruvate','Pyruvate kinase','Makes ATP (2 per glucose). Irreversible. Activated by fructose-1,6-bisphosphate.']]],
 ['Krebs cycle','Mitochondrial matrix. Per acetyl-CoA: 3 NADH, 1 FADH₂, 1 GTP, 2 CO₂.',[
  ['Pyruvate → Acetyl-CoA','Pyruvate dehydrogenase complex','Makes NADH and CO₂. Needs TPP (B1), lipoate, CoA (B5), FAD (B2) and NAD⁺ (B3). Links glycolysis to the cycle.'],
  ['Acetyl-CoA + Oxaloacetate → Citrate','Citrate synthase','Inhibited by ATP, NADH, succinyl-CoA and citrate.'],
  ['Citrate → Isocitrate','Aconitase','Goes through cis-aconitate. Blocked by fluoroacetate (as fluorocitrate).'],
  ['Isocitrate → α-Ketoglutarate','Isocitrate dehydrogenase','Makes NADH and CO₂. Main rate-limiting step. Activated by ADP and Ca²⁺; inhibited by ATP and NADH.'],
  ['α-Ketoglutarate → Succinyl-CoA','α-Ketoglutarate dehydrogenase complex','Makes NADH and CO₂. Same cofactors as pyruvate dehydrogenase.'],
  ['Succinyl-CoA → Succinate','Succinyl-CoA synthetase','Makes GTP (or ATP): substrate-level phosphorylation.'],
  ['Succinate → Fumarate','Succinate dehydrogenase','Makes FADH₂. Also Complex II of the electron transport chain. Malonate is a competitive inhibitor.'],
  ['Fumarate → Malate','Fumarase','Adds water.'],
  ['Malate → Oxaloacetate','Malate dehydrogenase','Makes NADH. Oxaloacetate is ready for the next turn.']]],
 ['Electron transport chain','Inner mitochondrial membrane. About 2.5 ATP per NADH and 1.5 per FADH₂.',[
  ['NADH → Ubiquinone (Q)','Complex I (NADH dehydrogenase)','Pumps 4 H⁺. Inhibited by rotenone.'],
  ['FADH₂ (from succinate) → Q','Complex II (succinate dehydrogenase)','Pumps no protons, so FADH₂ gives less ATP. Inhibited by malonate.'],
  ['QH₂ → Cytochrome c','Complex III (cytochrome bc₁)','Pumps 4 H⁺ through the Q cycle. Inhibited by antimycin A.'],
  ['Cytochrome c → O₂ → H₂O','Complex IV (cytochrome c oxidase)','Pumps 2 H⁺. Inhibited by cyanide, carbon monoxide and azide.'],
  ['H⁺ flow → ATP','Complex V (ATP synthase)','Makes ATP from the proton gradient. Inhibited by oligomycin. Uncouplers like 2,4-DNP let protons leak back, releasing heat instead.']]],
 ['β-Oxidation','Mitochondria. Palmitate (C16) gives 8 acetyl-CoA, 7 FADH₂ and 7 NADH: 106 ATP net.',[
  ['Fatty acid → Fatty acyl-CoA','Acyl-CoA synthetase','In the cytosol. Uses ATP → AMP (2 high-energy bonds).'],
  ['Acyl-CoA enters mitochondria','Carnitine palmitoyltransferase I (CPT-I)','Carnitine shuttle. Rate-limiting. Inhibited by malonyl-CoA.'],
  ['Acyl-CoA → trans-Δ²-Enoyl-CoA','Acyl-CoA dehydrogenase','Makes FADH₂.'],
  ['Enoyl-CoA → L-3-Hydroxyacyl-CoA','Enoyl-CoA hydratase','Adds water.'],
  ['3-Hydroxyacyl-CoA → 3-Ketoacyl-CoA','3-Hydroxyacyl-CoA dehydrogenase','Makes NADH.'],
  ['3-Ketoacyl-CoA → Acetyl-CoA + shorter acyl-CoA','Thiolase (β-ketothiolase)','Cuts off 2 carbons. Repeats until the chain is used up.']]],
 ['Urea cycle','Liver: first two steps in mitochondria, the rest in cytosol. 3 ATP (4 high-energy bonds) per urea.',[
  ['NH₄⁺ + HCO₃⁻ → Carbamoyl phosphate','Carbamoyl phosphate synthetase I','Uses 2 ATP. Rate-limiting. Needs N-acetylglutamate to work.'],
  ['Carbamoyl phosphate + Ornithine → Citrulline','Ornithine transcarbamylase','In mitochondria. Its deficiency is the most common urea cycle disorder.'],
  ['Citrulline + Aspartate → Argininosuccinate','Argininosuccinate synthetase','Uses ATP → AMP + PPi. Aspartate brings the second nitrogen.'],
  ['Argininosuccinate → Arginine + Fumarate','Argininosuccinate lyase','Fumarate links to the Krebs cycle.'],
  ['Arginine → Urea + Ornithine','Arginase','Urea goes to the kidneys. Ornithine returns to mitochondria.']]],
 ['Gluconeogenesis','Liver and kidney. Bypasses the 3 irreversible steps of glycolysis. Costs 4 ATP, 2 GTP and 2 NADH per glucose.',[
  ['Pyruvate → Oxaloacetate','Pyruvate carboxylase','In mitochondria. Uses ATP. Needs biotin. Activated by acetyl-CoA.'],
  ['Oxaloacetate → Phosphoenolpyruvate','PEP carboxykinase (PEPCK)','Uses GTP.'],
  ['Fructose-1,6-bisphosphate → Fructose-6-phosphate','Fructose-1,6-bisphosphatase','Inhibited by AMP and fructose-2,6-bisphosphate.'],
  ['Glucose-6-phosphate → Glucose','Glucose-6-phosphatase','In the ER of liver and kidney, not muscle. Its deficiency causes von Gierke disease.']]]
];
ui.pw=ui.pw||0;ui.pwo=ui.pwo||{};
function pwQ(){const p=PW[ui.pw],i=Math.floor(Math.random()*p[2].length),right=p[2][i][1],pool=[].concat(...PW.map(x=>x[2].map(s=>s[1]))).filter(e=>e!==right);const opts=[right];while(opts.length<4){const e=pool[Math.floor(Math.random()*pool.length)];if(opts.indexOf(e)<0)opts.push(e)}opts.sort(()=>Math.random()-.5);return{step:p[2][i][0],right:right,opts:opts,picked:''}}
EXT.paths=()=>{
  const p=PW[ui.pw],q=ui.pwq;
  let o=`<div class="chips wrapc">${PW.map((x,i)=>`<button class="chip${ui.pw===i?' on':''}" data-a="pwSet" data-n="${i}">${x[0]}</button>`).join('')}</div><div class="card c-grape"><h2>${p[0]}</h2><p class="muted">${p[1]}</p><button class="btn sm pri" data-a="pwQuiz" style="align-self:flex-start">Guess the enzyme</button></div>`;
  if(q)o+=`<div class="card pwq"><span class="pill">Which enzyme does this? · ${ui.pwScore||0} right</span><h3>${esc(q.step)}</h3><div class="pwopts">${q.opts.map(x=>`<button class="btn${q.picked?(x===q.right?' ok':x===q.picked?' no':''):''}" data-a="pwPick" data-v="${esc(x)}" ${q.picked?'disabled':''}>${esc(x)}</button>`).join('')}</div>${q.picked?`<p>${q.picked===q.right?'✓ Correct. +2 ATP':'Not quite. It is '+esc(q.right)+'.'}</p><div class="row"><button class="btn" data-a="pwQuitQ">Stop</button><button class="btn pri grow" data-a="pwQuiz">Next question</button></div>`:''}</div>`;
  o+=`<div class="card pwlist">${p[2].map((s,i)=>{const op=ui.pwo[ui.pw+'_'+i];return`<button class="pwstep${op?' open':''}" data-a="pwStep" data-n="${i}"><span class="pwn2">${i+1}</span><span class="grow"><b>${esc(s[0])}</b>${op?`<span class="pwenz">${esc(s[1])}</span><span class="muted">${esc(s[2])}</span>`:'<span class="muted">Tap to see the enzyme</span>'}</span></button>${i<p[2].length-1?'<div class="pwarrow">↓</div>':''}`}).join('')}</div><p class="muted">Textbook summaries for revision. Your lecture notes and textbook come first.</p>`;
  return o;
};
Object.assign(A,{
  pwSet(d){ui.pw=+d.n;ui.pwq=null;render()},
  pwStep(d){const k=ui.pw+'_'+d.n;ui.pwo[k]=!ui.pwo[k];render()},
  pwQuiz(){ui.pwq=pwQ();render()},
  pwQuitQ(){ui.pwq=null;render()},
  pwPick(d){const q=ui.pwq;if(!q||q.picked)return;q.picked=d.v;if(d.v===q.right){ui.pwScore=(ui.pwScore||0)+1;const t=today(),z=qzS();z.pw[t]=(z.pw[t]||0)+1;save('settings')}render()}
});

/* ---------- Study: paper log (kept as notes, so they sync) ---------- */
const papers=()=>S.notes.filter(n=>n.ref==='paper').sort((a,b)=>(b.updated||0)-(a.updated||0));
const paperF=()=>[['title','Paper title','text',R],['status','Status','select',{opts:['To read','Reading','Read']}],['aim','Aim: what question does it ask?','textarea'],['meth','Methods: how did they test it?','textarea'],['find','Key finding','textarea'],['take','My takeaway, or how I can use it','textarea'],['doi','DOI or link','text',{ph:'10.1016/…'}]];
EXT.papers=()=>{const l=papers(),c={};l.forEach(p=>c[p.status||'To read']=(c[p.status||'To read']||0)+1);
  return`<div class="card">${head('Paper log',addBtn('ppAdd','Paper'))}<p class="muted">Read a paper with a purpose: note its aim, methods, finding and your takeaway. Great for journal club and your thesis.</p><div class="g3">${stat(c['Read']||0,'read')}${stat(c['Reading']||0,'reading')}${stat(c['To read']||0,'to read')}</div></div>`+
  (l.length?l.map(p=>`<div class="card paper"><div class="row between"><span class="pill${p.status==='Read'?' c-leaf col':''}">${esc(p.status||'To read')}</span><div class="row"><button class="btn sm" data-a="ppEdit" data-id="${p.id}">${ic('edit')}Edit</button>${p.doi&&!S.cites.some(c=>c.doi===p.doi)?`<button class="btn sm" data-a="ppCite" data-id="${p.id}">Make citation</button>`:''}</div></div><h3>${esc(p.title)}</h3>${[['Aim',p.aim],['Methods',p.meth],['Finding',p.find],['My takeaway',p.take]].filter(x=>x[1]).map(x=>`<p><b>${x[0]}:</b> ${esc(x[1])}</p>`).join('')}${p.doi?`<p class="muted">${esc(p.doi)}</p>`:''}</div>`).join(''):`<div class="card">${empty('No papers yet','Add the first paper you are reading for a course or your thesis.')}</div>`)};
Object.assign(A,{
  ppAdd(){form('New paper',paperF(),{status:'To read'},v=>{const n=Object.assign({id:uid(),ref:'paper',body:'',updated:Date.now()},v);S.notes.push(n);save('n_'+n.id)})},
  ppEdit(d){const n=S.notes.find(x=>x.id===d.id);form('Paper',paperF(),Object.assign({id:1},n),v=>{const was=n.status;Object.assign(n,v,{updated:Date.now()});save('n_'+n.id);if(was!=='Read'&&v.status==='Read')celebrate('Paper read. Nice work')},()=>{S.notes=S.notes.filter(x=>x.id!==n.id);save('n_'+n.id)})},
  ppCite(d){const n=S.notes.find(x=>x.id===d.id);if(n)doiFetch(n.doi)}
});

/* ---------- Study: thesis and internship tracker ---------- */
const TH=()=>{const s=S.settings;if(!s.thesis||typeof s.thesis!=='object')s.thesis={title:'',sup:'',due:'',ms:[],meet:[]};const t=s.thesis;t.ms=t.ms||[];t.meet=t.meet||[];return t};
const THMS=['Choose a topic and supervisor','Literature review','Write the proposal','Proposal approved','Lab work or data collection','Analyse results','Write the first draft','Supervisor feedback','Final draft','Submit','Presentation / defence'];
EXT.thesis=()=>{const t=TH(),dn=t.ms.filter(m=>m.done).length,left=t.due?diffDays(t.due,today()):null;
  let o=`<div class="card c-grape"><div class="row between"><span class="pill">Thesis or internship (BBT422)</span><button class="btn sm" data-a="thEdit">${ic('edit')}Edit</button></div><h2>${esc(t.title||'Your project')}</h2><p class="muted">${t.sup?'Supervisor: '+esc(t.sup):'Add your topic and supervisor.'}</p>${t.due?`<div class="g3">${stat(left>=0?left:'Past','days left')}${stat(dn+'/'+t.ms.length,'milestones')}${stat(t.meet.length,'meetings')}</div>`:''}${t.ms.length?`<div class="bar"><i style="width:${dn/t.ms.length*100}%"></i></div>`:''}</div>`;
  o+=`<div class="card">${head('Milestones',addBtn('msAdd','Milestone'))}${t.ms.length?'<div class="list">'+t.ms.slice().sort((a,b)=>(a.d||'9')<(b.d||'9')?-1:1).map(m=>`<div class="item${m.done?' done':''}">${chk(m.done,'msTog',`data-id="${m.id}"`,m.t)}<button class="tap" data-a="msEdit" data-id="${m.id}"><span class="t">${esc(m.t)}</span><span class="muted">${m.d?'by '+fmt(m.d):'No date'}${!m.done&&m.d&&m.d<today()?' · overdue':''}</span></button></div>`).join('')+'</div>':`<p class="muted">Start with a ready-made plan, then set your dates.</p><button class="btn sm pri" data-a="msPlan" style="align-self:flex-start">Use the standard plan</button>`}</div>`;
  o+=`<div class="card">${head('Supervisor meetings',addBtn('mtAdd','Meeting'))}${t.meet.length?'<div class="list">'+t.meet.slice().sort((a,b)=>a.d<b.d?1:-1).map(m=>`<div class="item"><button class="tap" data-a="mtEdit" data-id="${m.id}"><span class="t">${fmt(m.d)}</span><span class="muted">${esc(m.n||'')}${m.next?' · Next: '+esc(m.next):''}</span></button></div>`).join('')+'</div>':'<p class="muted">After each meeting, note what was said and what to do next.</p>'}</div>`;
  return o;
};
Object.assign(A,{
  thEdit(){form('Thesis or internship',[['title','Topic','text',{ph:'Bacterial load on fresh vegetables in Dhaka'}],['sup','Supervisor','text'],['due','Submission date','date']],TH(),v=>{Object.assign(TH(),v);save('settings')})},
  msPlan(){const t=TH(),n=THMS.length,end=t.due||addDays(today(),120),span=Math.max(n,diffDays(end,today()));t.ms=THMS.map((x,i)=>({id:uid(),t:x,d:addDays(today(),Math.round(span*(i+1)/n)),done:0}));save('settings');render()},
  msAdd(){form('Milestone',[['t','Milestone','text',R],['d','Due','date']],{},v=>{TH().ms.push(Object.assign({id:uid(),done:0},v));save('settings')})},
  msEdit(d){const t=TH(),m=t.ms.find(x=>x.id===d.id);form('Milestone',[['t','Milestone','text',R],['d','Due','date']],Object.assign({id:1},m),v=>{Object.assign(m,v);save('settings')},()=>{t.ms=t.ms.filter(x=>x.id!==d.id);save('settings')})},
  msTog(d){const m=TH().ms.find(x=>x.id===d.id);m.done=m.done?0:1;save('settings');render();if(m.done)celebrate('Milestone done: '+m.t)},
  mtAdd(){form('Supervisor meeting',[['d','Date','date',R],['n','What was discussed','textarea'],['next','Next steps','text']],{d:today()},v=>{TH().meet.push(Object.assign({id:uid()},v));save('settings')})},
  mtEdit(d){const t=TH(),m=t.meet.find(x=>x.id===d.id);form('Supervisor meeting',[['d','Date','date',R],['n','What was discussed','textarea'],['next','Next steps','text']],Object.assign({id:1},m),v=>{Object.assign(m,v);save('settings')},()=>{t.meet=t.meet.filter(x=>x.id!==d.id);save('settings')})}
});
const _ag18b=agenda;
agenda=function(ds){const a=_ag18b(ds);TH().ms.forEach(m=>{if(!m.done&&m.d&&(m.d===ds||addDays(m.d,-3)===ds))a.push({t:'09:00',title:(m.d===ds?'Thesis milestone due today: ':'Thesis milestone in 3 days: ')+m.t,src:'Thesis',key:'th-'+m.id+ds})});return a.sort((x,y)=>x.t<y.t?-1:1)};
SUB.study.push(['paths','Pathways'],['papers','Papers'],['thesis','Thesis']);
{const g=MENU.find(x=>x[0]==='Study');if(g)g[1].push(['study','study','paths','Pathway explorer','grape'],['study','study','papers','Paper log','grape',()=>papers().filter(p=>p.status!=='Read').length||''],['study','study','thesis','Thesis and internship','grape'])}

/* ---------- daily biochem quiz on Today ---------- */
const QB=[
 ['Km is the substrate concentration at which…','the reaction runs at half its maximum speed',['the enzyme is fully saturated','the reaction stops','the inhibitor binds']],
 ['A competitive inhibitor…','raises the apparent Km, Vmax stays the same',['lowers Vmax, Km stays the same','lowers both Km and Vmax','lowers Km and Vmax together']],
 ['A non-competitive inhibitor…','lowers Vmax, Km stays the same',['raises Km, Vmax stays the same','raises Vmax','only works at low substrate']],
 ['On a Lineweaver–Burk plot, the x-intercept is…','−1/Km',['1/Vmax','Km/Vmax','−Vmax']],
 ['Pure DNA has an A260/A280 ratio of about…','1.8',['1.0','2.5','0.6']],
 ['DNA is usually measured at which wavelength?','260 nm',['280 nm','340 nm','595 nm']],
 ['Bradford protein assay is read at…','595 nm',['260 nm','340 nm','750 nm']],
 ['NADH absorbs strongly at…','340 nm',['260 nm','595 nm','450 nm']],
 ['Which amino acid is not chiral?','Glycine',['Alanine','Serine','Proline']],
 ['A G–C base pair has how many hydrogen bonds?','3',['2','1','4']],
 ['In agarose gel electrophoresis, DNA moves toward the…','positive electrode (anode)',['negative electrode (cathode)','well','loading dye']],
 ['SDS-PAGE separates proteins mainly by…','size (mass)',['charge','pI','hydrophobicity']],
 ['Standard autoclave conditions are…','121 °C at 15 psi for at least 15 minutes',['100 °C for 5 minutes','80 °C for 1 hour','160 °C dry for 10 minutes']],
 ['Taq polymerase comes from…','Thermus aquaticus',['Escherichia coli','Pyrococcus furiosus','Bacillus subtilis']],
 ['EcoRI cuts at the sequence…','GAATTC',['GGATCC','AAGCTT','GCGGCCGC']],
 ['Okazaki fragments are made on the…','lagging strand',['leading strand','mRNA','template RNA']],
 ['The start codon AUG codes for…','methionine',['alanine','tryptophan','stop']],
 ['Gram-positive bacteria stain purple because of their…','thick peptidoglycan layer',['outer membrane','capsule','flagella']],
 ['NAD⁺ is made from which vitamin?','Niacin (B3)',['Riboflavin (B2)','Thiamine (B1)','Biotin (B7)']],
 ['FAD is made from which vitamin?','Riboflavin (B2)',['Niacin (B3)','Folate (B9)','Vitamin C']],
 ['Coenzyme A contains which vitamin?','Pantothenic acid (B5)',['Pyridoxine (B6)','Cobalamin (B12)','Vitamin K']],
 ['Vitamin C deficiency causes scurvy because it is needed for…','collagen hydroxylation',['blood clotting','calcium absorption','DNA synthesis']],
 ['Vitamin K is needed for…','γ-carboxylation of clotting factors',['vision','collagen synthesis','bone mineral only']],
 ['Net ATP from glycolysis per glucose is…','2',['4','36','0']],
 ['The rate-limiting enzyme of glycolysis is…','Phosphofructokinase-1',['Hexokinase','Enolase','Aldolase']],
 ['The rate-limiting enzyme of the urea cycle is…','Carbamoyl phosphate synthetase I',['Arginase','Ornithine transcarbamylase','Argininosuccinate lyase']],
 ['Which complex of the ETC does not pump protons?','Complex II',['Complex I','Complex III','Complex IV']],
 ['Cyanide blocks…','Complex IV (cytochrome c oxidase)',['Complex I','ATP synthase','Complex II']],
 ['The main buffer in blood is…','bicarbonate',['phosphate','haemoglobin only','acetate']],
 ['Haemoglobin’s O₂ curve is sigmoidal because of…','cooperative binding',['competitive inhibition','covalent modification','its iron being Fe³⁺']],
 ['At its isoelectric point, a protein has…','no net charge',['maximum solubility','a positive charge','a negative charge']],
 ['Which are the essential fatty acids?','Linoleic and α-linolenic acid',['Palmitic and stearic acid','Oleic and palmitic acid','Arachidonic and stearic acid']],
 ['Chargaff’s rule says that in double-stranded DNA…','A = T and G = C',['A = G and T = C','A + T = 100%','G = U']],
 ['A peptide bond links…','the carboxyl group of one amino acid to the amino group of the next',['two side chains','two amino groups','sugar and phosphate']],
 ['C1V1 = C2V2: to make 100 mL of 1× from a 10× stock, you take…','10 mL of stock',['1 mL of stock','100 mL of stock','90 mL of stock']],
 ['A positive Biuret test (violet) shows…','peptide bonds (protein)',['reducing sugars','starch','lipids']],
 ['Benedict’s test detects…','reducing sugars',['proteins','starch','fats']],
 ['Iodine turns starch…','blue-black',['brick red','violet','yellow']],
 ['Which bond holds the two DNA strands together?','Hydrogen bonds',['Peptide bonds','Phosphodiester bonds','Disulfide bonds']],
 ['Restriction enzymes are naturally used by bacteria to…','destroy invading viral DNA',['copy their own DNA','make proteins','repair membranes']]
];
const qzS=()=>{const s=S.settings;if(!s.qz||typeof s.qz!=='object')s.qz={d:{},pw:{}};s.qz.d=s.qz.d||{};s.qz.pw=s.qz.pw||{};return s.qz};
function qzToday(){const t=today(),k=DAY0(t),z=qzS(),r=z.d[t]||{a:{}};const idx=[0,1,2].map(i=>(k*7+i*13)%QB.length);return{t:t,idx:idx,r:r}}
const shuf=(arr,seed)=>arr.map((x,i)=>[x,Math.sin(seed*99+i)*1e4%1]).sort((a,b)=>a[1]-b[1]).map(x=>x[0]);
function qzCard(){
  const q=qzToday(),ans=q.r.a,done=Object.keys(ans).length,right=Object.values(ans).filter(Boolean).length,z=qzS();
  const days=Object.keys(z.d).filter(d=>Object.keys(z.d[d].a||{}).length>=3).sort();let st=0;for(let d=today();days.indexOf(d)>=0||(d===today()&&days.indexOf(addDays(d,-1))>=0);d=addDays(d,-1)){if(days.indexOf(d)>=0)st++;if(st>400)break}
  const i=q.idx.findIndex((x,j)=>ans[j]==null);
  if(i<0)return`<div class="card qz done"><div class="row between"><span class="pill">Daily biochem quiz</span><span class="pill">🔥 ${st} day${st===1?'':'s'}</span></div><h3>${right} of 3 right today${right===3?'. Perfect!':''}</h3><p class="muted">+${right*5} ATP. New questions tomorrow.</p><p class="tip">${esc(TIPS[DAY0(today())%TIPS.length])}</p></div>`;
  const x=QB[q.idx[i]],opts=shuf([x[1]].concat(x[2]),q.idx[i]+DAY0(q.t)),last=ui.qzLast;
  return`<div class="card qz"><div class="row between"><span class="pill">Daily biochem quiz · ${i+1} of 3</span>${st?`<span class="pill">🔥 ${st}</span>`:''}</div>${last?`<p class="${last.ok?'pok':'pwarn'}">${last.ok?'✓ Correct! +5 ATP':'✗ The answer was: '+esc(last.r)}</p>`:''}<h3>${esc(x[0])}</h3><div class="pwopts">${opts.map(o=>`<button class="btn" data-a="qzPick" data-i="${i}" data-v="${esc(o)}">${esc(o)}</button>`).join('')}</div></div>`;
}
const TIPS=['Senior tip: start your lab report the day of the lab, while the details are fresh.','Senior tip: build a relationship with a faculty member early. Thesis supervisors remember curious students.','Senior tip: draw pathways by hand three times before an exam. It sticks.','Senior tip: label tubes on the side and the cap. Caps get mixed up.','Senior tip: read one paper a week from your favourite topic. By final year, that is your thesis literature review.','Senior tip: make a sheet of every buffer recipe you use. You will need it again.','Senior tip: ask for the course outline’s mark split in week 1 and put it in the grade predictor.','Senior tip: practise calculations (molarity, dilution) until they are automatic. Lab exams test speed.','Senior tip: keep a clean lab notebook. Date, aim, what you did, what you saw.','Senior tip: apply for internships two semesters before you need one.','Senior tip: when stuck in the lab, write down exactly what you changed. Troubleshooting needs records.','Senior tip: sleep before exams beats one more hour of cramming.'];
A.qzPick=d=>{const q=qzToday(),z=qzS(),i=+d.i,x=QB[q.idx[i]];const r=z.d[q.t]=z.d[q.t]||{a:{}};if(r.a[i]!=null)return;const ok=d.v===x[1];r.a[i]=ok?1:0;ui.qzLast={ok:ok,r:x[1]};save('settings');render();if(Object.keys(r.a).length===3){const n=Object.values(r.a).filter(Boolean).length;setTimeout(()=>celebrate(n===3?'Perfect quiz! +15 ATP':'Quiz done: +'+n*5+' ATP'),300)}};
const _xp18=xpOf;
xpOf=function(s){const z=qzS();let q=0;Object.values(z.d).forEach(r=>{q+=Object.values(r.a||{}).filter(Boolean).length});const pw=Object.values(z.pw).reduce((a,b)=>a+b,0);return _xp18(s)+q*5+pw*2};
const _today18=VIEWS.today;
VIEWS.today=()=>{const h=_today18();if(h.indexOf('class="card examday"')>=0&&!ui.examFull)return h;const k=h.indexOf('<div class="card krebs');return k>=0?h.slice(0,k)+qzCard()+h.slice(k):h+qzCard()};
BADGES.push(['quiz7','Quiz whiz','Finish the daily quiz on 7 days','medal','grape',s=>[Object.keys(qzS().d).filter(d=>Object.keys(qzS().d[d].a||{}).length>=3).length,7]],['pathfinder','Pathfinder','Name 25 enzymes in Guess the enzyme','flask','leaf',s=>[Object.values(qzS().pw).reduce((a,b)=>a+b,0),25]]);

/* ---------- petri dish that grows with this week’s focus ---------- */
function petriCard(){
  const wk=dayKeys(7),min=S.focus.filter(f=>wk.indexOf(f.date)>=0).reduce((a,f)=>a+(+f.min||0),0),n=Math.min(80,Math.floor(min/10)),cols=['var(--sun)','var(--pink)','var(--leaf)','var(--grape)','var(--sky)'];
  let dots='';for(let i=0;i<n;i++){const a=i*2.39996,r=Math.sqrt((i+.5)/80)*58,x=70+r*Math.cos(a),y=70+r*Math.sin(a),sz=3+((i*7)%5);dots+=`<circle class="col" style="animation-delay:${Math.min(i,30)*40}ms" cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${sz}" fill="${cols[i%5]}"/>`}
  return`<div class="card petri"><div class="row"><svg viewBox="0 0 140 140" class="pdish" aria-hidden="true"><circle cx="70" cy="70" r="66" class="pd0"/><circle cx="70" cy="70" r="60" class="pd1"/>${dots}</svg><div class="grow"><span class="pill">Your culture this week</span><h3>${n} colon${n===1?'y':'ies'}</h3><p class="muted">Every 10 minutes of focus grows one colony. ${n>=80?'The plate is full. Amazing week!':'Fill the plate with '+(800-min)+' more minutes this week.'}</p></div></div></div>`;
}
const _tim18=EXT.timer;EXT.timer=()=>{const h=_tim18(),k=h.indexOf('<div class="card"><div class="row between"><h2>Study heatmap');return k>=0?h.slice(0,k)+petriCard()+h.slice(k):h+petriCard()};

/* tips and Bangla */
Object.assign(TUT,{'lab/primer':[[null,'Primer checker','Paste a primer to see its Tm, GC% and warnings. Add the reverse primer to check them as a pair.']],'lab/gel':[[null,'Gel band sizer','Measure how far the ladder bands ran, then your bands. Catalyst estimates their sizes.']],'lab/safety':[[null,'Chemical safety','Hazards, protection and disposal for common lab chemicals. Always read the SDS too.']],'study/paths':[[null,'Pathway explorer','Tap each step to reveal its enzyme and regulation. Try Guess the enzyme to test yourself.']],'study/papers':[[null,'Paper log','Note each paper’s aim, methods, finding and your takeaway.']],'study/thesis':[[null,'Thesis and internship','Milestones with reminders, and notes from each supervisor meeting.']]});
Object.assign(BN,{'Convert online':'অনলাইনে রূপান্তর','On your phone':'আপনার ফোনে','Primer checker':'প্রাইমার চেকার','Gel band sizer':'জেল ব্যান্ড সাইজার','Chemical safety':'রাসায়নিক নিরাপত্তা','Pathway explorer':'পাথওয়ে এক্সপ্লোরার','Paper log':'পেপার লগ','Thesis and internship':'থিসিস ও ইন্টার্নশিপ','Guess the enzyme':'এনজাইম চিনুন','Next question':'পরের প্রশ্ন','Milestones':'ধাপসমূহ','Supervisor meetings':'সুপারভাইজারের সাথে মিটিং','Use the standard plan':'সাধারণ পরিকল্পনা ব্যবহার করুন','Ramadan began today':'আজ রমজান শুরু হয়েছে','Eid was announced':'ঈদ ঘোষণা হয়েছে','Set the start date':'শুরুর তারিখ দিন','Adjust the Islamic date':'হিজরি তারিখ ঠিক করুন'});
window.__v18={primer:primerInfo,gelFit:gelFit,qz:()=>qzToday(),sehri:sehriT,iftar:iftarT,ptFetch:ptFetch,isRam:d=>isRam(d),hijriOf:d=>hijriOf(d)};

/* ================= v19: a readable user document in Firebase ================= */
function fbMeta(){
  try{
    if(!fbUser||cloud!=='fb'||!window.firebase)return;const F=window.firebase,s=S.settings,rec={};
    KEYS.forEach(k=>{const v=S[k];if(Array.isArray(v)&&v.length)rec[k]=v.length});if(S.notes.length)rec.notes=S.notes.length;['water','prayers','habitLog'].forEach(k=>{const n=Object.keys(S[k]||{}).length;if(n)rec[k+'Days']=n});
    let ver='';try{ver=NV&&NV.appVersion?String(NV.appVersion()):''}catch(e){}
    F.firestore().collection('users').doc(fbUser.uid).set({
      email:fbUser.email||'',name:s.name||'',city:s.city||'',semester:s.sem||'',
      level:LV.lv+' · '+LV.name,atp:LV.xp,streak:(ST().count||0),
      app:'Catalyst',platform:NV&&NV.sync?'Android app':'Web',appVersion:ver,
      joined:(fbUser.metadata&&fbUser.metadata.creationTime)||'',
      lastSync:F.firestore.FieldValue.serverTimestamp(),lastSyncLocal:new Date().toLocaleString('en-GB',{timeZone:'Asia/Dhaka'}),
      records:rec
    },{merge:true}).catch(()=>{});
  }catch(e){}
}
const _fbc19=fbConnect;
fbConnect=async function(u,c){await _fbc19(u,c);if(fbState==='on')fbMeta()};
setInterval(()=>{if(document.visibilityState==='visible')fbMeta()},5*60*1000);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')fbMeta()});
window.__v19={meta:fbMeta};

window.__daybook={ptimes:ptimes,SUR:SUR,agenda:agenda,dayScore:dayScore,pageList:pageList,qibla:qibla,doses:doses,activeEp:activeEp};
})();
