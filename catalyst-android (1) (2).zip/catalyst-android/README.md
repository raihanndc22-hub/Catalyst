# Catalyst for Android

App developed by Md. Raihan Mehedi, Undergraduate Student, Department of Biochemistry & Biotechnology, North South University.

## Get the APK without installing anything (GitHub, free)
1. Sign in at github.com and create a new repository (the green "New" button). Name it `catalyst`.
2. On the new repository page, choose "uploading an existing file", then drag in **everything inside this folder**, including the `.github` folder. Commit.
   (On a phone, use a computer or "Desktop site" mode, since folders upload more reliably there.)
3. Open the **Actions** tab. A run called "Build Catalyst APK" starts by itself and takes about 5 minutes.
4. When it shows a green tick, open the run and download **Catalyst-apk** under Artifacts. Unzip it to get `app-debug.apk`.
5. Copy it to your phone, open it, and allow "Install unknown apps" when Android asks.

## Or build it in Android Studio
Open this folder in Android Studio, let it sync, then choose Build > Build APK(s).

## What differs from the web version
- Everything is saved on the phone. Use More > Settings > Backup to keep a copy, since uninstalling the app erases its data.
- Works fully offline. Only the PDF tools and the nicer fonts need internet.
- Real phone notifications: reminders for the next 7 days ring even when the app is closed. Open the app at least once a week.
- Important: only an APK built from this whole project has notifications and file opening. A website-to-APK converter that takes just the `www` folder will not include them.
- To update the app, replace the files in `app/src/main/assets/www` and build again. Raise `versionCode` in `app/build.gradle` each time so phones accept the update.

## Updating the app
From version 2.2 builds are signed with a private key kept in GitHub Secrets (CATALYST_KEYSTORE_B64 and CATALYST_PASSWORD). Never put the key file in this project.
If you installed version 1.0 or 1.1, uninstall it once before installing 1.2. Back up first from Settings if you have data to keep.
