package com.raihanmehedi.catalyst;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        String act = in.getAction();
        int id = in.getIntExtra("nid", 0);
        if (Scheduler.ACTION_STOP.equals(act)) { Scheduler.stop(c, id); return; }
        if (Scheduler.ACTION_SNOOZE.equals(act)) { Scheduler.snooze(c, id, in.getStringExtra("title"), in.getStringExtra("src")); return; }
        if (in.getBooleanExtra("alarm", false)) Scheduler.ring(c, in.getStringExtra("title"), in.getStringExtra("src"));
        else Scheduler.show(c, in.getStringExtra("title"), in.getStringExtra("src"));
    }
}
