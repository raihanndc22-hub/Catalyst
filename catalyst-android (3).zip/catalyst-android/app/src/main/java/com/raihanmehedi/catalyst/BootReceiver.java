package com.raihanmehedi.catalyst;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Alarms are wiped when the phone restarts, so set them again from the saved list. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(in.getAction())) return;
        String json = c.getSharedPreferences("catalyst", Context.MODE_PRIVATE).getString("agenda", "[]");
        Scheduler.apply(c, json);
    }
}
