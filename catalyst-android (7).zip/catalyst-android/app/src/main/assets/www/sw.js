/* Catalyst offline support for the website and iPhone home-screen app.
   Pages and scripts: network first (so updates arrive at once), saved copy when offline.
   Fonts: saved copy first. Everything else (Firebase, prayer times) goes straight to the network. */
const CACHE='catalyst-v19';
const CORE=['./','./index.html','./more.js','./more.css','./logo.png','./manifest.webmanifest','./icons/icon-192.png','./icons/apple-touch-icon.png',
  './fb/firebase-app-compat.js','./fb/firebase-auth-compat.js','./fb/firebase-firestore-compat.js','./pdf-lib.min.js','./admin.html'];
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(CACHE).then(c=>Promise.all(CORE.map(u=>c.add(u).catch(()=>{})))))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(n=>n!==CACHE).map(n=>caches.delete(n)))).then(()=>self.clients.claim()))});
const timeout=(p,ms)=>new Promise((ok,no)=>{const t=setTimeout(no,ms);p.then(r=>{clearTimeout(t);ok(r)},e=>{clearTimeout(t);no(e)})});
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);
  if(u.origin===location.origin&&/\.apk$/i.test(u.pathname))return;
  if(u.origin===location.origin){
    e.respondWith(timeout(fetch(r),5000).then(res=>{if(res&&res.ok){const cp=res.clone();caches.open(CACHE).then(c=>c.put(r,cp))}return res})
      .catch(()=>caches.match(r,{ignoreSearch:true}).then(m=>m||(r.mode==='navigate'?caches.match('./index.html'):Response.error()))));
    return;
  }
  if(/fonts\.(googleapis|gstatic)\.com$/.test(u.hostname)){
    e.respondWith(caches.match(r).then(m=>m||fetch(r).then(res=>{const cp=res.clone();caches.open(CACHE).then(c=>c.put(r,cp));return res})));
  }
});
self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(self.clients.matchAll({type:'window'}).then(l=>l.length?l[0].focus():self.clients.openWindow('./index.html')))});
